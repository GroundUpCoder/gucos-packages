#include <assert.h>
void __wasm_posix_assert(const char *expr,const char *file,int line,const char *function){__assert_fail(expr,file,line);}
