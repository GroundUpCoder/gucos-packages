#include <stdio.h>
FILE *__wasm_posix_stderr(void){return stderr;}
