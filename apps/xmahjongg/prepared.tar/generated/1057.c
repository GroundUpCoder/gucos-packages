extern unsigned int __main_argc_argv(unsigned int, void *);
int main(int argc,char **argv){return (int)__main_argc_argv((unsigned int)argc,(void *)argv);}
