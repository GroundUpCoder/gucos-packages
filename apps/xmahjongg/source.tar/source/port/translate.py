#!/usr/bin/env python3
import argparse, subprocess, sys
from pathlib import Path
P=Path(__file__).resolve().parent
R=P.parents[2]
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--sdk',type=Path,required=True);a=p.parse_args()
cmd=[sys.executable,str(R/'tools/cpp-translator/translate.py'),'translate',str(P/'world.cpp'),'--unit-key','xmahjongg/world.cpp','--wasi-libc','--api-header',str(P/'api.h'),'-o',str(a.output),'--ir-output',str(a.output)+'.ll','--clang-arg=-DHAVE_CONFIG_H','--clang-arg=-D_WASI_EMULATED_SIGNAL']
for d in [P/"headers",P,P.parent/'upstream/xmahjongg-3.7/include',P.parent/'upstream/xmahjongg-3.7/src',R/'apps/x11-apps/source/include',a.sdk/'c++/v1',a.sdk]:cmd+=['--clang-arg=-I'+str(d)]
subprocess.run(cmd,check=True)
