import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,output,close}=await appBrowser('xmahjongg',1200000);
try{
 const pending=runCached(page,`set -e
gucman install xmahjongg
xmahjongg --version
cc -I/usr/local/include /usr/src/xmahjongg/port/control.c -L/usr/local/lib -lX11 -lxcb -lXau -o /tmp/xmj-control
export DISPLAY=:1
Xvfb :1 -screen 0 1024x768x24 -ac -noreset -fp built-ins &
server=$!
trap 'kill "$server" 2>/dev/null; wait "$server" 2>/dev/null' EXIT
sleep 2
export XMAHJONGG_TEST_OBSERVER=1
xmahjongg --name XMahjongg-Test --number 1 --geometry +0+0 &
game=$!
/tmp/xmj-control 144 /tmp/initial.json
echo XMJ_INITIAL
while [ ! -f /tmp/clicked ]; do sleep 1; done
/tmp/xmj-control 142 /tmp/removed.json
echo XMJ_REMOVED
while [ ! -f /tmp/undo ]; do sleep 1; done
/tmp/xmj-control 144 /tmp/undo.json
echo XMJ_UNDONE
while [ ! -f /tmp/redo ]; do sleep 1; done
/tmp/xmj-control 142 /tmp/redo.json
echo XMJ_REDONE
while [ ! -f /tmp/new ]; do sleep 1; done
/tmp/xmj-control 144 /tmp/new.json
echo XMJ_NEW
wait "$game"
xmahjongg --name XMahjongg-Test --number 1 --geometry +0+0 &
game=$!
/tmp/xmj-control 144 /tmp/restart.json
echo XMJ_RESTART
wait "$game"
kill "$server"
wait "$server"
trap - EXIT
echo XMAHJONGG-PASS
`,{packages:['xmahjongg'],fresh:['xmahjongg']});pending.catch(()=>{});
 async function marker(s){await Promise.race([page.waitForFunction(s=>shell.busybox?.log.includes(s),s,{timeout:1100000}),pending.then(async r=>{throw Error('Ended before '+s+': '+JSON.stringify(r)+'\n'+await page.evaluate(()=>shell.busybox.log));})]);}
 const read=name=>page.evaluate(async name=>JSON.parse(new TextDecoder().decode(await shell.busybox.read('/tmp/'+name+'.json'))),name);
 const signal=name=>page.evaluate(name=>shell.busybox.write('/tmp/'+name,new TextEncoder().encode('1')),name);
 await marker('XMJ_INITIAL');const initial=await read('initial');assert.equal(initial.remaining,144);await writeFile(output+'/initial.json',JSON.stringify(initial,null,2));
 const canvas=page.locator('.screen:not([hidden]) canvas').last();await writeFile(output+'/board.png',await canvas.screenshot());
 for(const [x,y] of initial.pair)await canvas.click({position:{x,y}});await signal('clicked');
 await marker('XMJ_REMOVED');const removed=await read('removed');assert.equal(removed.remaining,142);assert.notEqual(removed.hash,initial.hash);
 await page.keyboard.press('u');await signal('undo');await marker('XMJ_UNDONE');assert.equal((await read('undo')).hash,initial.hash);
 await page.keyboard.press('r');await signal('redo');await marker('XMJ_REDONE');assert.equal((await read('redo')).hash,removed.hash);
 await page.keyboard.press('n');await signal('new');await marker('XMJ_NEW');const fresh=await read('new');assert.notEqual(fresh.seed,initial.seed);
 await page.keyboard.press('q');await marker('XMJ_RESTART');const restarted=await read('restart');assert.equal(restarted.hash,initial.hash);assert.equal(restarted.seed,initial.seed);
 await page.keyboard.press('q');const result=await pending;assert.equal(result.code,0,await page.evaluate(()=>shell.busybox.log));assert.deepEqual(errors,[]);
 await writeFile(output+'/state.json',JSON.stringify({initial,removed,fresh,restarted},null,2));console.log('XMahjongg actual pointer, undo, redo, new, restart and close passed');
}finally{await close();}
