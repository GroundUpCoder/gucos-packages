#include <sys/select.h>
#include <dirent.h>
#include <stddef.h>
#include <stdlib.h>
_Static_assert(sizeof(fd_set)==8,"fd_set ABI");
_Static_assert(offsetof(struct timeval,tv_usec)==8,"timeval ABI");
_Static_assert(sizeof(((struct timeval *)0)->tv_usec)==4,"timeval microseconds ABI");
_Static_assert(offsetof(struct dirent,d_name)==8,"dirent ABI");
_Static_assert(sizeof(struct dirent)==264,"dirent size ABI");
int xmj_select(int n,void *r,void *w,void *e,struct timeval *t){return select(n,r,w,e,t);}
void __cxa_pure_virtual(void){abort();}
/* WASI declares getc as a function; destination stdio exposes it as a macro. */
#include <stdio.h>
#undef getc
int getc(FILE *stream){return fgetc(stream);}
