#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static Window find(Display *d,Window w){
 char *name=0;Window root,parent,*children=0,result=0;unsigned n=0;
 if(XFetchName(d,w,&name)&&name){int yes=strstr(name,"Mahjongg")!=0;XFree(name);if(yes)return w;}
 if(XQueryTree(d,w,&root,&parent,&children,&n)){for(unsigned i=0;i<n&&!result;i++)result=find(d,children[i]);if(children)XFree(children);}return result;
}
int main(int argc,char **argv){
 assert(argc==3);Display *d=XOpenDisplay(0);assert(d);Window w=0;unsigned long state[10];
 for(int retry=0;retry<200;retry++){
  w=find(d,DefaultRootWindow(d));
  if(w){Atom type;int format;unsigned long n,left;unsigned char *data=0;
   if(XGetWindowProperty(d,w,XInternAtom(d,"_XMAHJONGG_TEST_STATE",False),0,10,False,XA_CARDINAL,&type,&format,&n,&left,&data)==Success&&format==32&&n==10){memcpy(state,data,sizeof(state));XFree(data);if(state[1]==(unsigned long)atoi(argv[1]))break;}else if(data)XFree(data);
  }usleep(100000);if(retry==199)return 2;
 }
 assert(w);XRaiseWindow(d,w);XSetInputFocus(d,w,RevertToPointerRoot,CurrentTime);XSync(d,False);
 int rx,ry;Window child;assert(XTranslateCoordinates(d,w,DefaultRootWindow(d),0,0,&rx,&ry,&child));
 XWindowAttributes a;assert(XGetWindowAttributes(d,w,&a));XImage *im=XGetImage(d,w,0,0,a.width,a.height,AllPlanes,ZPixmap);assert(im);
 unsigned colors[64],nc=0;for(int y=0;y<a.height;y+=2)for(int x=0;x<a.width;x+=2){unsigned pixel=XGetPixel(im,x,y);unsigned i=0;while(i<nc&&colors[i]!=pixel)i++;if(i==nc&&nc<64)colors[nc++]=pixel;}XDestroyImage(im);assert(nc>=8);
 FILE *f=fopen(argv[2],"w");assert(f);fprintf(f,"{\"remaining\":%lu,\"seed\":%lu,\"hash\":%lu,\"colors\":%u,\"pair\":[[%lu,%lu],[%lu,%lu]]}\n",state[1],state[2],state[9],nc,state[5]+rx,state[6]+ry,state[7]+rx,state[8]+ry);fclose(f);assert(state[3]&&state[4]);XCloseDisplay(d);return 0;
}
