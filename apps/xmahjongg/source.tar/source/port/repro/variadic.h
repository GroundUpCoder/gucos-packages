int printf(const char *, ...);
int xmj_variadic_probe(int);
