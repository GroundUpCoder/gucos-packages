// XMahjongg main.cc uses fprintf in fatal_error/error/help/version paths.
extern "C" int printf(const char *, ...);
extern "C" int xmj_variadic_probe(int n) { return printf("%d\n", n); }
