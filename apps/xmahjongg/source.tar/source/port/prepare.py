#!/usr/bin/env python3
"""Verify and export translated C; all executable compilation stays in the guest."""
import hashlib, json, subprocess, sys
from pathlib import Path
p=Path(__file__).resolve().parent
root=p.parents[2]
world=Path(sys.argv[1]).resolve()
m=json.loads((world/'manifest.json').read_text())
assert m['unitKey']=='xmahjongg/world.cpp' and m['profile']['hostedMain']
assert m['provenance']['sourceSha256']==hashlib.sha256((p/'world.cpp').read_bytes()).hexdigest()
assert m['provenance']['apiHeaderSha256']==hashlib.sha256((p/'api.h').read_bytes()).hexdigest()
d=p/'generated';d.mkdir()
units=[];startup=[];hashes={}
for i,a in enumerate(m['artifacts']):
    source=(world/a['path']).resolve();assert source.is_relative_to(world)
    data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==a['sha256']
    name=f'{i}.c';(d/name).write_bytes(data);hashes[name]=a['sha256']
    (startup if 'constructorPriority' in a else units).append(str(i)+'.o')
bridges=json.loads(subprocess.check_output([sys.executable,str(root/'tools/cpp-translator/runtime_abi.py')]))
imports=set().union(*(set(a['dependencies']) for a in m['artifacts']))-{a['symbol'] for a in m['artifacts']}
for i,(symbol,source) in enumerate(sorted(bridges.items())):
    if symbol not in imports:continue
    name=f'runtime-{i}.c';(d/name).write_text(source);hashes[name]=hashlib.sha256(source.encode()).hexdigest()
(d/'archive.rsp').write_text('\n'.join(units)+'\n')
(d/'startup.rsp').write_text('\n'.join(startup)+'\n')
(d/'manifest.json').write_bytes((world/'manifest.json').read_bytes())
(d/'provenance.json').write_text(json.dumps({'manifestSha256':hashlib.sha256((world/'manifest.json').read_bytes()).hexdigest(),'profile':m['profile'],'files':hashes},indent=2)+'\n')
print(f'Exported {len(units)} archive definitions, {len(startup)} startup definitions, {len(hashes)-len(m["artifacts"])} runtime adapters')
