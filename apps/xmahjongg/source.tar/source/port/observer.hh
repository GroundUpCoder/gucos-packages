// Opt-in, read-only acceptance telemetry. Never selects, removes, or assigns tiles.
#include "board.hh"
#include "tileset.hh"
#include <X11/Xatom.h>
#include <cstdlib>
static void xmj_observe(Game *game, Panel *panel) {
  static int enabled = getenv("XMAHJONGG_TEST_OBSERVER") != 0;
  if (!enabled) return;
  Board *board=panel->board();
  unsigned long state[10]={1,(unsigned long)game->nremaining(),game->board_number(),0,0,0,0,0,0,2166136261UL};
  Tile *first[Tileset::IVORY_NMATCHES]={0}, *pair[2]={0,0};
  for(int i=0;i<game->ntiles();++i){
    Tile *t=game->tile(i);
    state[9]=(state[9]^(unsigned long)(t->match()*2+t->real()))*16777619UL;
    if(t->real()&&t->open()&&t->match()>=0&&t->match()<Tileset::IVORY_NMATCHES&&!pair[0]){
      if(first[t->match()]){pair[0]=first[t->match()];pair[1]=t;}
      else first[t->match()]=t;
    }
  }
  if(pair[0]) for(int i=0;i<2;++i){
    short x,y;board->position(pair[i],&x,&y);
    state[3+i]=pair[i]->number()+1;
    state[5+i*2]=x+game->tileset()->width()/2;
    state[6+i*2]=y+game->tileset()->height()/2;
  }
  XChangeProperty(panel->display(),panel->window(),XInternAtom(panel->display(),"_XMAHJONGG_TEST_STATE",False),XA_CARDINAL,32,PropModeReplace,(const unsigned char*)state,10);
  XFlush(panel->display());
}
