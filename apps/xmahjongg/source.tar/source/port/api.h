#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>
#include <sys/select.h>
#include <unistd.h>
#include <dirent.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <lcdf/clp.h>
#include <lcdfgif/gif.h>
#include <lcdfgif/gifx.h>

void __cxa_pure_virtual(void);
