#!/bin/sh
set -eu
stage=$1
cd /usr/src/xmahjongg
mkdir -p port/build "$stage/bin" "$stage/share/xmahjongg/tiles" "$stage/share/xmahjongg/backgrounds" "$stage/share/xmahjongg/layouts" "$stage/share/applications" "$stage/share/licenses/xmahjongg"
cd port/build
for src in ../generated/[0-9]*.c; do
 cc -c "$src"
done
ar qcs world.a $(cat ../generated/archive.rsp)
for name in clp fmalloc giffunc gifread gifx; do
 cc -DHAVE_CONFIG_H -I.. -I../../upstream/xmahjongg-3.7/include -I/usr/local/include -c "../../upstream/xmahjongg-3.7/liblcdf/$name.c" -o "$name.o"
done
cc -c ../abi.c -o abi.o
cc @../generated/startup.rsp world.a clp.o fmalloc.o giffunc.o gifread.o gifx.o abi.o -L/usr/local/lib -lX11 -lxcb -lXau -o "$stage/bin/xmahjongg"
cd ../..
cp upstream/xmahjongg-3.7/share/tiles/thick.gif "$stage/share/xmahjongg/tiles/"
cp upstream/xmahjongg-3.7/share/backgrounds/default.gif "$stage/share/xmahjongg/backgrounds/"
cp upstream/xmahjongg-3.7/share/layouts/default "$stage/share/xmahjongg/layouts/"
cp port/xmahjongg.desktop "$stage/share/applications/"
cp licenses/* upstream/xmahjongg-3.7/README "$stage/share/licenses/xmahjongg/"
cp port/generated/provenance.json "$stage/share/xmahjongg/translation.json"
