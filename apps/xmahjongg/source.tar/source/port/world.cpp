#include "images.cpp"
#pragma clang diagnostic ignored "-Wregister"
#define initializer permstr_initializer
#define mapping permstr_mapping
#include "../upstream/xmahjongg-3.7/liblcdf/permstr.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer straccum_initializer
#define mapping straccum_mapping
#include "../upstream/xmahjongg-3.7/liblcdf/straccum.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer string_initializer
#define mapping string_mapping
#include "../upstream/xmahjongg-3.7/liblcdf/string.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer vectorv_initializer
#define mapping vectorv_mapping
#include "../upstream/xmahjongg-3.7/liblcdf/vectorv.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer alarm_initializer
#define mapping alarm_mapping
#include "../upstream/xmahjongg-3.7/src/alarm.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer board_initializer
#define mapping board_mapping
#include "../upstream/xmahjongg-3.7/src/board.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer button_initializer
#define mapping button_mapping
#include "../upstream/xmahjongg-3.7/src/button.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer counter_initializer
#define mapping counter_mapping
#include "../upstream/xmahjongg-3.7/src/counter.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer game_initializer
#define mapping game_mapping
#include "../upstream/xmahjongg-3.7/src/game.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer gmjts_initializer
#define mapping gmjts_mapping
#include "../upstream/xmahjongg-3.7/src/gmjts.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer hint_initializer
#define mapping hint_mapping
#include "../upstream/xmahjongg-3.7/src/hint.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer kdets_initializer
#define mapping kdets_mapping
#include "../upstream/xmahjongg-3.7/src/kdets.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer kmjts_initializer
#define mapping kmjts_mapping
#include "../upstream/xmahjongg-3.7/src/kmjts.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer main_initializer
#define mapping main_mapping
#include "main.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer matches_initializer
#define mapping matches_mapping
#include "../upstream/xmahjongg-3.7/src/matches.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer moment_initializer
#define mapping moment_mapping
#include "../upstream/xmahjongg-3.7/src/moment.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer panel_initializer
#define mapping panel_mapping
#include "../upstream/xmahjongg-3.7/src/panel.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer random_initializer
#define mapping random_mapping
#include "../upstream/xmahjongg-3.7/src/random.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer solution_initializer
#define mapping solution_mapping
#include "../upstream/xmahjongg-3.7/src/solution.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer solvable_initializer
#define mapping solvable_mapping
#include "../upstream/xmahjongg-3.7/src/solvable.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer swgeneral_initializer
#define mapping swgeneral_mapping
#include "../upstream/xmahjongg-3.7/src/swgeneral.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer swwidget_initializer
#define mapping swwidget_mapping
#include "../upstream/xmahjongg-3.7/src/swwidget.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer tile_initializer
#define mapping tile_mapping
#include "../upstream/xmahjongg-3.7/src/tile.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer tileset_initializer
#define mapping tileset_mapping
#include "../upstream/xmahjongg-3.7/src/tileset.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer traverse_initializer
#define mapping traverse_mapping
#include "../upstream/xmahjongg-3.7/src/traverse.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
#define initializer xmj3ts_initializer
#define mapping xmj3ts_mapping
#include "../upstream/xmahjongg-3.7/src/xmj3ts.cc"
#undef initializer
#undef mapping
#undef NIMAGES
#undef NACROSS
#undef NDOWN
#undef NPICTURES
