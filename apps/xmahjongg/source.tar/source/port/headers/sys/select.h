#ifndef XMJ_SELECT_H
#define XMJ_SELECT_H
#include <sys/time.h>
/* Destination ABI and constant-time bit operations, not WASI's fd list. */
#define FD_SETSIZE 64
typedef struct xmj_fd_set { unsigned long fds_bits[2]; } fd_set;
#define FD_ZERO(s) ((s)->fds_bits[0]=(s)->fds_bits[1]=0)
#define FD_SET(d,s) ((unsigned long)(d)<64 ? ((s)->fds_bits[(d)/32]|=1UL<<((d)%32)) : 0UL)
#define FD_ISSET(d,s) ((unsigned long)(d)<64 ? ((s)->fds_bits[(d)/32]&(1UL<<((d)%32))) : 0UL)
#ifdef __cplusplus
extern "C" {
#endif
int xmj_select(int, struct xmj_fd_set *, struct xmj_fd_set *, struct xmj_fd_set *, struct timeval *);
#ifdef __cplusplus
}
#endif
#define select xmj_select
#endif
