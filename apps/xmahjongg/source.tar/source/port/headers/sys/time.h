#ifndef XMJ_TIME_H
#define XMJ_TIME_H
#include <time.h>
/* Destination ABI: libc/include/sys/time.h; WASI uses 64-bit tv_usec. */
#include <__struct_timeval.h>
#ifdef __cplusplus
extern "C" {
#endif
int gettimeofday(struct timeval *, void *);
#ifdef __cplusplus
}
#endif
#include <sys/select.h>
#endif
