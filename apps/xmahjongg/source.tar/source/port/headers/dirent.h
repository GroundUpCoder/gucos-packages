#ifndef XMJ_DIRENT_H
#define XMJ_DIRENT_H
/* Destination layout, libc/include/dirent.h. Only APIs used by upstream. */
struct dirent { long d_ino; int d_type; char d_name[256]; };
struct __DIR;
typedef struct __DIR DIR;
#ifdef __cplusplus
extern "C" {
#endif
DIR *opendir(const char *);
int closedir(DIR *);
struct dirent *readdir(DIR *);
#ifdef __cplusplus
}
#endif
#endif
