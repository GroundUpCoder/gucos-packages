#ifndef __wasilibc___struct_timeval_h
#define __wasilibc___struct_timeval_h
#include <__typedef_time_t.h>
/* wasm-posix has 32-bit microseconds, unlike WASI. */
struct timeval { time_t tv_sec; long tv_usec; };
#endif
