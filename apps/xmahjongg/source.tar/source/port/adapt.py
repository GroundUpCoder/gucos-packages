#!/usr/bin/env python3
"""Small, asserted source adaptations; original release remains byte-identical."""
from pathlib import Path
p=Path(__file__).resolve().parent
u=p.parent/'upstream/xmahjongg-3.7'
s=(u/'src/images.c').read_text()
assert s.count('const Gif_Record ')==2
(p/'images.cpp').write_text('// Only exported record const mismatch is adapted. GIF bytes unchanged.\n'+s.replace('const Gif_Record ','Gif_Record '))
s=(u/'src/main.cc').read_text()
assert s.count('    panel->redraw();')==1
s=s.replace('void\npanel_loop(Game *game, Panel *panel)','#include "observer.hh"\n\nvoid\npanel_loop(Game *game, Panel *panel)').replace('    panel->redraw();','    panel->redraw();\n    xmj_observe(game, panel);')
(p/'main.cc').write_text(s)
