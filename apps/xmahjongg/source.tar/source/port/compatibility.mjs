// Exact retained binary on the current public target, served locally.
// Fixture repository trust is local test evidence, never production approval.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {homedir} from 'node:os';
import {PNG} from 'pngjs';
import {netgucReleaseFixture} from '../../../tests/netguc-release-fixture.mjs';
import {launchBrowserProfile} from '../../../tests/browser-profile.mjs';
const here=new URL('.',import.meta.url),hash=b=>createHash('sha256').update(b).digest('hex');
const inputs=JSON.parse(await readFile(new URL('compatibility-inputs.json',here)));
const candidate=resolve(process.env.WASM_POSIX_NETGUC_CANDIDATE);
const output=resolve(process.env.WASM_POSIX_CLOSURE_OUTPUT);await mkdir(output,{recursive:true});
const releaseBytes=await readFile(join(candidate,'release.json'));assert.equal(hash(releaseBytes),inputs.releaseFileSha256);
const release=JSON.parse(releaseBytes);assert.equal(release.manifest,inputs.targetManifest);
const html=await readFile(join(candidate,'app/index.html'));assert.equal(hash(html),inputs.indexSha256);
const artifact=await readFile(join(homedir(),'.cache/wasm-posix/approved/objects',inputs.artifact.sha256+'.tar'));
assert.equal(hash(artifact),inputs.artifact.sha256);assert.equal(artifact.length,inputs.artifact.size);
assert.equal(hash(await readFile(new URL('../../../docs/research/xmahjongg-candidate-20261004/acceptance-result.json',here))),inputs.originalAcceptanceSha256);
assert.equal(hash(await readFile(new URL('../../../docs/research/xmahjongg-candidate-20261004/independent-approval.json',here))),inputs.originalReviewSha256);
let server,fixture,closeBrowser,page,monitor;const requests=[],errors=[];
try{
 fixture=await netgucReleaseFixture(candidate);
 server=createServer(async(req,res)=>{try{
  const path=new URL(req.url,'http://localhost').pathname;let body;
  if(path==='/os2/')body=html;
  else if(path==='/candidate.tar'){body=artifact;requests.push({artifact:inputs.artifact.sha256,size:body.length});}
  else if(/^\/os2\/assets\/[a-f0-9]{64}\.(js|bin|tar|txt|html)$/.test(path)){
   const asset=path.slice(4),want=release.files[asset];assert.ok(want);body=await readFile(join(candidate,asset));assert.equal(hash(body),want.sha256);assert.equal(body.length,want.size);
  }else{res.writeHead(404).end();return;}
  res.writeHead(200,{'content-type':path.endsWith('.js')?'text/javascript':path.endsWith('/')||path.endsWith('.html')?'text/html':'application/octet-stream','cross-origin-opener-policy':'same-origin','cross-origin-embedder-policy':'require-corp'});res.end(body);
 }catch(error){res.writeHead(500).end(String(error));}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await launchBrowserProfile();closeBrowser=browser.closeBrowser;
 await browser.browser.route('https://os.groundupcoder.net/os2/repository/**',async route=>{
  const path=new URL(route.request().url()).pathname.slice('/os2/repository'.length);
  if(!/^\/(current.json|objects\/[a-f0-9]{64})$/.test(path)){await route.abort();return;}
  const bytes=await readFile(join(fixture.directory,path));requests.push({repository:path,bytes:bytes.length});await route.fulfill({status:200,body:bytes});
 });
 page=await browser.browser.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto(origin+'/os2/?shell=bootstrap');await page.waitForFunction(()=>window.shell?.ready,null,{timeout:60000});
 let printed=0;monitor=setInterval(async()=>{const log=await page.evaluate(()=>shell.busybox?.log||'').catch(()=>'');if(log.length>printed){process.stdout.write(log.slice(printed));printed=log.length;}},1000);
 const script=`set -e
gucman install x11-apps
/usr/libexec/guc-repo-fetch -q -m ${inputs.artifact.size} ${origin}/candidate.tar /tmp/xmj.tar
test "$(sha256sum /tmp/xmj.tar | cut -d ' ' -f 1)" = ${inputs.artifact.sha256}
root=/usr/local/lib/wasm-posix/packages/xmahjongg
mkdir -p "$root"
/usr/libexec/guc-unpack /tmp/xmj.tar "$root/candidate"
/usr/libexec/guc-links-v2 check /usr/local "$root" "$root/candidate/relative-files"
/usr/libexec/guc-links-v2 link /usr/local "$root" "$root/candidate/relative-files"
ln -s "$root/candidate" "$root/current"
rm /tmp/xmj.tar
xmahjongg --version
cc -I/usr/local/include /tmp/xmj-control.c -L/usr/local/lib -lX11 -lxcb -lXau -o /tmp/xmj-control
export DISPLAY=:1
Xvfb :1 -screen 0 1024x768x24 -ac -noreset -fp built-ins &
server=$!
trap 'kill "$server" 2>/dev/null; wait "$server" 2>/dev/null' EXIT
sleep 2
export XMAHJONGG_TEST_OBSERVER=1
xmahjongg --name XMahjongg-Test --number 1 --geometry +0+0 &
game=$!
/tmp/xmj-control 144 /tmp/initial.json
echo XMJ_INITIAL
while [ ! -f /tmp/clicked ]; do sleep 1; done
/tmp/xmj-control 142 /tmp/removed.json
echo XMJ_REMOVED
while [ ! -f /tmp/undo ]; do sleep 1; done
/tmp/xmj-control 144 /tmp/undo.json
echo XMJ_UNDONE
while [ ! -f /tmp/redo ]; do sleep 1; done
/tmp/xmj-control 142 /tmp/redo.json
echo XMJ_REDONE
while [ ! -f /tmp/new ]; do sleep 1; done
/tmp/xmj-control 144 /tmp/new.json
echo XMJ_NEW
wait "$game"
xmahjongg --name XMahjongg-Test --number 1 --geometry +0+0 &
game=$!
/tmp/xmj-control 144 /tmp/restart.json
echo XMJ_RESTART
wait "$game"
kill "$server"
wait "$server"
trap - EXIT
echo XMAHJONGG-PASS
`;
 const pending=page.evaluate(({script,control})=>{shell.files['/tmp/xmj-control.c']=control;shell.files['/tmp/xmj-compat.sh']=script;return shell.command('sh /tmp/xmj-compat.sh');},{script,control:await readFile(new URL('control.c',here),'utf8')});pending.catch(()=>{});
 async function marker(s){await Promise.race([page.waitForFunction(s=>shell.busybox?.log.includes(s),s,{timeout:1100000}),pending.then(async r=>{throw Error('Ended before '+s+': '+JSON.stringify(r)+'\n'+await page.evaluate(()=>shell.busybox.log));})]);}
 const read=name=>page.evaluate(async name=>JSON.parse(new TextDecoder().decode(await shell.busybox.read('/tmp/'+name+'.json'))),name);
 const signal=name=>page.evaluate(name=>shell.busybox.write('/tmp/'+name,new TextEncoder().encode('1')),name);
 await marker('XMJ_INITIAL');const initial=await read('initial');assert.equal(initial.remaining,144);await writeFile(output+'/initial.json',JSON.stringify(initial,null,2));
 const canvas=page.locator('.screen:not([hidden]) canvas').last();
 let board,paintedColors=0,paintedSamples=0;const paintDeadline=Date.now()+30000;
 do {board=await canvas.screenshot();const {data}=PNG.sync.read(board),colors=new Set();for(let i=0;i<data.length;i+=256){colors.add((data[i]<<16)|(data[i+1]<<8)|data[i+2]);}paintedColors=colors.size;paintedSamples=0;for(let i=0;i<data.length;i+=256)if(data[i]+data[i+1]+data[i+2]>300)paintedSamples++;if(paintedColors>=8&&paintedSamples>=1000)break;await page.waitForTimeout(100);}while(Date.now()<paintDeadline);
 assert.ok(paintedColors>=8&&paintedSamples>=1000,'browser board was not painted');await writeFile(output+'/board.png',board);
 await writeFile(output+'/paint.json',JSON.stringify({sampledColors:paintedColors,brightSamples:paintedSamples})+'\n');
 const dimensions=await canvas.evaluate(c=>({width:c.width,height:c.height})),box=await canvas.boundingBox();assert.ok(box&&dimensions.width&&dimensions.height);
 const scale=Math.min(box.width/dimensions.width,box.height/dimensions.height),offsetX=(box.width-dimensions.width*scale)/2,offsetY=(box.height-dimensions.height*scale)/2;
 await writeFile(output+'/pointer-mapping.json',JSON.stringify({dimensions,box,scale,offsetX,offsetY})+'\n');
 for(const [x,y] of initial.pair)await canvas.click({position:{x:offsetX+x*scale,y:offsetY+y*scale}});await signal('clicked');
 await marker('XMJ_REMOVED');const removed=await read('removed');assert.equal(removed.remaining,142);assert.notEqual(removed.hash,initial.hash);
 await page.keyboard.press('u');await signal('undo');await marker('XMJ_UNDONE');assert.equal((await read('undo')).hash,initial.hash);
 await page.keyboard.press('r');await signal('redo');await marker('XMJ_REDONE');assert.equal((await read('redo')).hash,removed.hash);
 await page.keyboard.press('n');await signal('new');await marker('XMJ_NEW');const fresh=await read('new');assert.notEqual(fresh.seed,initial.seed);
 await page.keyboard.press('q');await marker('XMJ_RESTART');const restarted=await read('restart');assert.equal(restarted.hash,initial.hash);assert.equal(restarted.seed,initial.seed);
 await page.keyboard.press('q');const result=await pending;assert.equal(result.code,0,await page.evaluate(()=>shell.busybox.log));assert.deepEqual(errors,[]);
 await writeFile(output+'/state.json',JSON.stringify({initial,removed,fresh,restarted},null,2));console.log('XMahjongg actual pointer, undo, redo, new, restart and close passed');
 await writeFile(output+'/execution.json',JSON.stringify({scope:inputs.scope,target:inputs.targetManifest,artifact:inputs.artifact.sha256,requests},null,2)+'\n');
}catch(error){if(page){await writeFile(output+'/failure.log',await page.evaluate(()=>shell.busybox?.log||'').catch(()=>''));await page.screenshot({path:output+'/failure.png'}).catch(()=>{});}throw error;
}finally{clearInterval(monitor);if(closeBrowser)await closeBrowser();if(fixture)await fixture.close();if(server)await new Promise(r=>server.close(r));}
