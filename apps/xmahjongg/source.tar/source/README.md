# XMahjongg 3.7 — blocked port preparation

This is the real Eddie Kohler upstream release, with every extracted file checked
byte-for-byte against its pinned archive. It is not yet a usable or accepted port.
No generated executable, candidate, publication, or browser acceptance exists.
The manifest is experimental, the install recipe fails explicitly, and acceptance
is deliberately undeclared until executable behavior can be tested.

## Baseline and preserved work

The current package-job worktree is based on fetched origin/main
`131de9450c4bed82da65ffe3891f19c5432a7191`. The workflow generated its
`.package-lane.json`; only the package commit was cherry-picked.
The original preparation commit is `e9137a44c`, preserved by
`archive/xmahjongg-a28f75d8b` and the old worktree
`/Users/jku/git/wasm-posix-xmahjongg-exploratory`.
The shared main checkout was not reset, merged, or edited.

## Verified platform blocker

The pinned baseline has `wasm-posix-llvm-c-v1`. Under the build scheduler,
`port/repro/variadic.cpp` plus `variadic.h` fails with
`cpp-translator: variadic C facade unsupported`; see `variadic.log`.
The original main.cc requires fprintf/vfprintf and variadic error functions.
The newer local-only profile, including its WASI libc ABI adapters and constructor
support, must undergo reviewed integration before this port can use it.
No shared platform files were copied or cherry-picked into this lane.

Reproduce from the repository root with the pinned llvmlite 0.50.0 environment:

```
machine-job run --kind build --timeout 1800 -- PYTHON tools/cpp-translator/translate.py translate apps/xmahjongg/port/repro/variadic.cpp --unit-key xmahjongg/repro/variadic.cpp --api-header apps/xmahjongg/port/repro/variadic.h -o test-results/xmahjongg-variadic-origin
```

Use a fresh output path. `PYTHON` denotes the configured translator venv Python.
`port/translate.py` targets the newer profile and is preparation only; it cannot
run on this pinned baseline. The original exploratory attempts on a28f75d8b did
not produce an accepted translation. Their logs are preserved under
`port/evidence/exploratory-a28f75d8b`. The last reached public-header parsing;
its config-header ordering defect is corrected in port/api.h but not rerun with
unreviewed platform code. The source amalgamation only namespaces colliding
file-local identifiers and undefines per-file macros; it does not replace game
logic. Full translation and ABI validation remain outstanding.

In particular, audit the WASI versus destination fd_set, timeval and dirent
layouts, C callback signatures, global constructors, allocation/deallocation,
and variadic ABI before any executable claim. Preserve native operation costs;
do not add whole-file caches or simulate X11 services.

## License and asset audit

Upstream README declares GPL-2-or-later for the package and specifically for the
colored default/thick tiles derived from Mark Holm's drawings. The original
black-and-white artwork has a non-profit permission statement. Other optional
tiles include credits with less explicit individual grants. Retain all original
source/archive bytes for provenance, but the intended installation is limited to
`share/tiles/thick.gif`, `share/backgrounds/default.gif`, the default layout, and
upstream embedded button/digit images. Do not install optional tiles silently.

Source headers also carry the Click license for portions of liblcdf; the full
current upstream Click license and GNU GPL v2 text are included in licenses/,
with retrieval URLs and hashes in sources.lock.json. The Click text is a current
retrieval, not asserted to be the exact 2005 historical text. Preserve the
original per-file notices and upstream README in any eventual binary package.

## Required completion gates

After the reviewed translator lands, regenerate the C artifacts reproducibly,
compile against the existing approved X11 SDK, and implement the guest recipe.
`port/xmahjongg.desktop` is launcher source, not an installed launcher yet.
Acceptance must launch the real program and verify a visibly rendered board,
a legal matching-pair interaction and tile-count/state change, new game/restart,
and normal close. Repeat through package-job source and fresh binary-only phases.
No such tests have run. Do not promote this preparation as a candidate.

## PARKED checkpoint — 2026-10-04 consolidation

User directed immediate parking and transferred desktop backlog ownership to
platform/release coordinator `01a0fffe-7a98-7926-be11-94aed9332c20`.
Do not automatically resume this lane or start builds/tests without new direction.

Current worktree: `/Users/jku/git/wasm-posix-xmahjongg`.
Base: `106ea1883b7ae7c33a6a821966cccbb400ac9900`.
Branch: `package/xmahjongg-deacad09`.
Package-only transferred commits: `a16eb9d3c`, `6b4f9c6a7`.
Package-job created the accurate lane metadata. Prior worktrees and archive refs
remain preserved, including `archive/xmahjongg-131de9450` and
`/Users/jku/git/wasm-posix-xmahjongg-v1-blocked`.

The earlier blocker/status paragraphs above are historical. On this new base:
- The exact variadic reproducer PASSED, generating two definitions.
- variadic.py, constructors.py, runtime.py PASSED native O0/O2 comparisons and
  six translated execution modes; results were recorded on ticket #2 before any
  resolution. Ticket #2 remains open.
- Full upstream translation v8 PASSED (1,054 definitions).
- Translation v9 with opt-in read-only acceptance observer also completed:
  1,061 definitions, ten Clang warnings. This is translation, not compilation
  or execution of the game.
- Logs: `port/evidence/106ea1883/`; latest `translation-v9.log`.
- Generated artifacts: `test-results/xmahjongg-world-v9/` and its sibling `.ll`
  in the current worktree. Earlier generated outputs remain preserved.

Uncommitted package work: api.h, translate.py, world.cpp; new abi.c, adapt.py,
headers/, images.cpp, main.cc, observer.hh and evidence/106ea1883/. This checkpoint
also modifies README.md. Upstream originals remain unchanged. Adaptations include
explicit destination fd_set/timeval/dirent layouts, native select forwarding,
record-const correction for embedded GIFs, and test-only read-only state telemetry.
These adaptations still require execution/ABI validation. Nothing was pushed or
promoted. No package candidate or source/fresh-binary acceptance run exists.
The install recipe still deliberately fails; launcher source is not installed.

At parking, machine-job status showed no XMahjongg queued/running job, and
`cc-meta waits --watcher 01a1038a-5f0e-7bad-9d6e-e947cd3cadcd` returned no wakes.
The last tool execution session had already ended; its completed translation log
is preserved. Other workers' jobs were not touched. No timers/resumes were created.

Next task ONLY after coordinator authorization: export v9 manifest-verified C
artifacts into package-local generated inputs, retain/link the constructor object,
compile all translated definitions with the guest compiler, compile upstream
liblcdf C sources plus abi.c, then link against approved X11 SDK libraries. Audit
public C callbacks/struct boundaries and exercise --version before interactive
acceptance. Implement the real recipe and source/fresh-binary acceptance (visible
board, legal pair clicks and 144→142 state, undo/restart/new game, normal close).
Exact prospective compiler check, after authorization and through one build job:

```
machine-job run --kind build --timeout 1800 -- node tools/cpp-translator/compile-project.mjs test-results/xmahjongg-world-v9 test-results/xmahjongg-world-v9.a
```

This command has NOT run. Approved artifact compatibility on this baseline has
not been checked; report any missing dependency keys to the coordinator without
importing unlanded shared tooling/transport or bypassing package gates.

## Authorized resumption — current implementation owner

The user unparked this target in docs/logs/2026-10-04/cpp-project-sequence.md.
The new isolated lane is package/xmahjongg-6411e958 at baseline e022630d9.
Original dirty work and all v8/v9 artifacts remain intact in the old lane.
The transfer verified 1,214 package/generated files byte-for-byte, plus all
1,061 v9 manifest artifact hashes. Current compile-project compiled v9 into
a 1,839,432-byte archive and one separate constructor object, without errors.
This is compilation evidence, not execution or package acceptance.

Current-profile translation v10 again produced 1,061 definitions. Run the
port/translate.py script with the retained llvmlite 0.50.0 venv and WASI SDK,
then port/prepare.py OUTPUT to verify and export C into port/generated.
Generated C is local-only and must be prepared before source acceptance.
The guest recipe builds every C definition and upstream liblcdf and links
the startup object explicitly. No host-built archive is installed.

The acceptance draft uses opt-in read-only X11 property telemetry for pair
coordinates and state. Playwright supplies real pointer and keyboard input.
Upstream r means redo; deterministic restart is close/relaunch with --number 1.
Source/binary acceptance, independent review and publication remain pending.

## October 6: exact public os2 target recheck

The initial nine-record release at os.groundupcoder.net is independently approved
and completed. XMahjongg now resumes as the next incremental addition. This lane
uses the retained independently approved experimental archive
884aa3f132bd601da105d31417e6d9780b2e284dea4e92fe871069af3bd71569 (3,616,256 bytes).
The original acceptance and review bytes remain unchanged. No source rebuild or
new package artifact is claimed here.

`port/compatibility.mjs` serves the exact released candidate page/assets locally,
installs its six X11/provider records through the actual repository manager using
an explicitly author-only fixture, then hashes/extracts/links the retained game
archive. This is candidate execution, not a new XMahjongg repository record,
launcher, migration, publication ledger or public release approval. No production
state is changed. `compatibility-inputs.json` pins the original evidence and exact
target; the candidate and output directories are explicit environment inputs.

The controller and gameplay assertions come from the existing acceptance test:
real pointer pair removal144->142, undo/redo state hashes, new seed, normal quit,
and seed1 relaunch restoring the original board. The read-only observer remains
opt-in; telemetry never moves tiles. Candidate checks also retain version output,
48-color board evidence and controller compilation against the selected X11 SDK.

Two initial test adaptations clicked incorrectly: first raw backing coordinates,
then independent-axis scaling that omitted object-fit:contain letterboxing.
Both failed runs are preserved. The final pointer mapping applies one scale and
center offsets, the inverse of the unchanged browser input mapping. V3 passed
all gameplay assertions but captured a black frame before browser presentation;
the final harness waits for at least eight sampled displayed canvas colors before
capturing and interacting. V4 attempted direct getContext on the transferred
offscreen canvas and failed in the harness; final capture instead samples the
actual PNG. This does not relax guest board/state assertions.
Final execution details and evidence hashes are recorded beside the harness.

Next after exact independent execution review: original source/key association,
full repository metadata/provider/path/license audit, actual gucman/dynamic
launcher and JWM/reload composition, reviewed additive publication to the live
repository and independent public closure. No legacy format1 approval or prior
artifact identity may be rewritten. The remaining full queue is retained.

Final V6 exited0 and its screenshot was inspected: visible144-tile board,
49 sampled PNG colors and5451 bright samples. Both real clicks removed a pair;
undo/redo, new seed and deterministic restart passed. V5 had passed gameplay but
its color-only capture check counted the dark window border; V6 additionally
requires1000 bright samples. All prior logs/screenshots remain hashed in
port/compatibility-evidence.json. This is the tested final harness, awaiting the
same independent reviewer; it has not changed the completed public release.

## Correction to screenshot interpretation (independent review N1)

The earlier descriptions of black saved captures in V3/V5 and a dark-border
false positive were unsupported. V3, V5 and V6 board.png are byte-identical,
SHA2569e6f56399134ad39b18613e851598884355589d4e32e69a5718d0f807bba2884, and
the actual PNG bytes show the painted board. The reviewer reproduced a tool
preview showing black while direct data:image rendering of those same bytes
showed the board. The author confused preview appearance with saved content.
No application rendering failure or paint fix was established. V6 adds a
stronger screenshot predicate, not a proven fix to an application defect.
Original evidence/PNGs and their hashes remain unchanged; the independently
replayed exact gameplay approval remains valid. V1/V2 pointer mapping and V4
offscreen getContext failures remain actual harness failures.
