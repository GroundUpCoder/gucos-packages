/* wasm-posix: entropy from the runtime /dev/urandom device. */
#define HAVE_STDLIB_H 1
#define HAVE_STDIO_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define STDC_HEADERS 1
#define BYTEORDER 1234
#define HAVE_FCNTL_H 1
#define XML_CONTEXT_BYTES 1024
#define XML_DEV_URANDOM 1
#define XML_DTD 1
#define XML_GE 1
#define XML_NS 1
