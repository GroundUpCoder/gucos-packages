#include <expat.h>
#include <assert.h>
#include <string.h>
static int starts,chars;static void start(void *u,const char *n,const char **a){starts++;if(starts==1)assert(strcmp(n,"urn:x|root")==0);}static void text(void*u,const char*s,int n){chars+=n;}
int main(void){XML_Parser p=XML_ParserCreateNS(0,'|');XML_SetStartElementHandler(p,start);XML_SetCharacterDataHandler(p,text);const char *a="<root xmlns='urn:x'>",*b="<child>hé</child></root>";assert(XML_Parse(p,a,strlen(a),0)==XML_STATUS_OK);assert(XML_Parse(p,b,strlen(b),1)==XML_STATUS_OK);assert(starts==2&&chars==3);XML_ParserFree(p);p=XML_ParserCreate(0);assert(XML_Parse(p,"<a></b>",7,1)==XML_STATUS_ERROR);assert(XML_GetErrorCode(p)==XML_ERROR_TAG_MISMATCH);XML_ParserFree(p);return 0;}
