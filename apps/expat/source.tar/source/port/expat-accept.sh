set -e
gucman install expat pkgconf
cc /usr/src/expat/port/expat-accept.c $(pkg-config --cflags --libs expat) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
