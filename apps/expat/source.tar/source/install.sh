#!/bin/sh
set -e
stage=$1
cd /usr/src/expat
mkdir -p "$stage/objects" "$stage/include/" "$stage/pkgconfig"
objects=
for source in lib/xmlparse.c lib/xmlrole.c lib/xmltok.c; do
  object="$stage/objects/${source##*/}.o"
  cc -DHAVE_EXPAT_CONFIG_H -I. -Ilib -c "$source" -o "$object"
  objects="$objects $object"
done
ar rcs "$stage/libexpat.a" $objects
cc -shared $objects  -Wl,-soname,libexpat.so -o "$stage/libexpat.so"
cp lib/expat.h lib/expat_external.h "$stage/include//"
cp port/expat.pc "$stage/pkgconfig/"
