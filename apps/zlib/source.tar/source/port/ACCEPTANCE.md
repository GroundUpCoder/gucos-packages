# Independent zlib acceptance

Run `node tools/package-job.mjs run zlib` for isolated source and binary phases.
Both execute the unchanged upstream `src/test/example.c` against installed shared
and static libraries. This suite exercises buffer compression, gzip file I/O,
streaming deflate/inflate, large buffers, parameter changes, flushing, stream
synchronization, and preset dictionaries.

The unchanged upstream `minigzip.c` is an additional installed shared-library
consumer. It decompresses a host-generated gzip containing 256 KiB of binary
input, roundtrips files and pipes, and rejects a damaged gzip CRC. Node's zlib
independently decompresses the guest-produced gzip and verifies every byte.

Only the two upstream consumer source files are exposed on the binary-only disk.
No package rebuild is performed there. The test uses private browser profiles,
output directories and the package job's exact dependency/candidate artifact lock.
