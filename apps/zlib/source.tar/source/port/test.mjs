import assert from 'node:assert/strict';
import {gzipSync,gunzipSync} from 'node:zlib';
import {writeFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';

const {page,errors,output,close}=await appBrowser('zlib',600000);
try {
 // Host-generated gzip exercises interoperability, binary bytes, and many buffers.
 const input=Buffer.alloc(256*1024);
 for(let i=0;i<input.length;i++)input[i]=(i*17+(i>>>8))&255;
 const compressed=gzipSync(input), corrupt=Buffer.from(compressed);
 corrupt[corrupt.length-8]^=0x80; // Damage the gzip CRC, preserving the stream.
 await page.evaluate(({input,gzip,corrupt})=>{
   shell.files['/tmp/zlib-input.b64']=input;
   shell.files['/tmp/zlib-host.b64']=gzip;
   shell.files['/tmp/zlib-corrupt.b64']=corrupt;
 },{input:input.toString('base64'),gzip:compressed.toString('base64'),corrupt:corrupt.toString('base64')});
 const result=await runCached(page,`set -e
gucman install zlib
mkdir -p /tmp/zlib-acceptance
cd /tmp/zlib-acceptance
test -f /usr/local/lib/libz.so
test -f /usr/local/lib/libz.a
# Compile the unchanged upstream suite against each installed library.
cc /usr/src/zlib/src/test/example.c -I/usr/local/include -L/usr/local/lib -lz -o example-shared
./example-shared shared.gz
cc -static /usr/src/zlib/src/test/example.c -I/usr/local/include /usr/local/lib/libz.a -o example-static
./example-static static.gz
cc -DZ_HAVE_UNISTD_H /usr/src/zlib/src/test/minigzip.c -I/usr/local/include -L/usr/local/lib -lz -o minigzip
base64 -d /tmp/zlib-input.b64 > input
base64 -d /tmp/zlib-host.b64 > host.gz
base64 -d /tmp/zlib-corrupt.b64 > corrupt.gz
./minigzip -d -c host.gz > decoded
cmp input decoded
./minigzip -9 -c input > guest.gz
./minigzip -d -c guest.gz > roundtrip
cmp input roundtrip
cat input | ./minigzip -1 | ./minigzip -d > piped
cmp input piped
if ./minigzip -d -c corrupt.gz > corrupt-output; then exit 90; fi
base64 guest.gz > /tmp/zlib-guest.b64
gucman install zlib
echo ZLIB-PACKAGE-PASS
`,{packages:['zlib'],fresh:['zlib']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.equal((log.match(/inflate with dictionary: hello, hello!/g)||[]).length,2,log);
 assert.match(log,/ZLIB-PACKAGE-PASS/);
 const guest=Buffer.from(await page.evaluate(async()=>new TextDecoder().decode(await shell.busybox.read('/tmp/zlib-guest.b64'))),'base64');
 await writeFile(output+'/guest.gz',guest);
 assert.deepEqual(gunzipSync(guest),input);
 assert.deepEqual(errors,[]);
 console.log('PASS zlib unchanged upstream shared/static suites, host/guest gzip interoperability, file/pipe roundtrips and CRC rejection');
} finally {await close();}
