#ifndef WASMPOSIX_GETTEXT_CONFIG_H
#define WASMPOSIX_GETTEXT_CONFIG_H
#define _GL_CONFIG_H_INCLUDED 1
#define _GNU_SOURCE 1
#include <stdbool.h>
#define HAVE_GETCWD 1
#define _GL_ATTRIBUTE_FALLTHROUGH ((void)0)
#define __libc_lock_define_initialized gl_lock_define_initialized
#define __libc_lock_define_initialized_recursive gl_recursive_lock_define_initialized
#define __libc_lock_lock gl_lock_lock
#define __libc_lock_unlock gl_lock_unlock
#define __libc_lock_lock_recursive gl_recursive_lock_lock
#define __libc_lock_unlock_recursive gl_recursive_lock_unlock
#define ENABLE_NLS 1
#define HAVE_ICONV 1
#define ICONV_CONST
#define HAVE_ALLOCA 1
#define HAVE_ALLOCA_H 1
#define HAVE_UNISTD_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDDEF_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_SETLOCALE 1
#define HAVE_POSIX_PRINTF 1
#define HAVE_SNPRINTF 1
#define HAVE_ASPRINTF 1
#define HAVE_TSEARCH 1
#define HAVE_LANGINFO_CODESET 1
#define HAVE_LC_MESSAGES 1
#define USE_POSIX_THREADS 1
#define HAVE_PTHREAD_RWLOCK 1
#define HAVE_PTHREAD_RWLOCK_RDLOCK_PREFER_WRITER 1
#define HAVE_PTHREAD_MUTEX_RECURSIVE 1
#define USE_POSIX_THREADS_WEAK 0
#define IN_LIBINTL 1
#define LIBDIR "/usr/local/lib"
#define LOCALEDIR "/usr/local/share/locale"
#define LOCALE_ALIAS_PATH "/usr/local/share/locale"
#define LIBINTL_VERSION 0x001701
#define FLEXIBLE_ARRAY_MEMBER
#define _GL_ATTRIBUTE_PURE
#define _GL_ATTRIBUTE_CONST
#define _GL_ATTRIBUTE_MALLOC
#define _GL_ATTRIBUTE_DEALLOC_FREE
#define _GL_ATTRIBUTE_RETURNS_NONNULL
#define _GL_ATTRIBUTE_FORMAT(args)
/* localename-unsafe.c may predefine this annotation. */
#ifndef _GL_ARG_NONNULL
#define _GL_ARG_NONNULL(params)
#endif
#define _GL_INLINE static inline
#define _GL_EXTERN_INLINE static inline
#define _GL_INLINE_HEADER_BEGIN
#define _GL_INLINE_HEADER_END
#define _GL_UNUSED
#endif
