# GNU gettext runtime 0.23.1 for wasm-posix

Source: https://ftp.gnu.org/gnu/gettext/gettext-0.23.1.tar.xz
SHA-256: c1f97a72a7385b7e71dd07b5fea6cdaf12c9b88b564976b23bd8c11857af2970

The upstream gettext-runtime/intl tree is copied unchanged. Local generated
files are config.h, include/libintl.h, intl/libgnuintl.h, lib.json, install.sh,
and port/ test sources/catalog. The explicit configuration selects POSIX
threads, real iconv conversion, standard printf, and gnulib's locale-name
fallback. libc only supports C/POSIX/C.UTF-8 locales; localization uses the
LC_ALL/LC_MESSAGES/LANG/LANGUAGE environment, as on other minimal-locale hosts.
No GNU compiler identity is advertised and no native host config.h is reused.

`gucman install libintl` installs libiconv first if needed, then independently
builds libintl.a and installs libintl.h. Link consumers with `-lintl -liconv`.
`cc -shared --project /usr/src/gettext/lib.json -o /tmp/libintl.so` produces a
shared library; load libiconv.so with RTLD_GLOBAL before libintl.so.

The port covers catalog lookup, domains, plural expressions and codeset
conversion. Translation authoring tools are supplied separately by `gucman install gettext`;
see [tools port notes](../gettext-tools/PORT.md). Enhanced locale functions and gettext's
replacement printf family remain outside this runtime package.
Our printf supports positional scalar arguments, including positional width
and precision. Full locale-specific libc formatting/collation is not supplied
by installing libintl. The test catalog exercises ISO-8859-1 to UTF-8 conversion.

The runtime library license is intl/COPYING.LIB (LGPL); per-file gnulib notices
also apply. Top-level COPYING is retained from the complete GNU distribution.
