set -e
gucman install libintl pkgconf
cc /usr/src/gettext/port/test.c -I/usr/local/include -lintl -liconv -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
