#include <libintl.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define CHECK(x) do {if(!(x)){printf("gettext FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 char formatted[64];int count=0;
 CHECK(snprintf(formatted,sizeof formatted,"%2$s %1$d %3$.1f%4$n",42,"answer",1.5,&count)==13);
 CHECK(strcmp(formatted,"answer 42 1.5")==0 && count==13);
 CHECK(snprintf(formatted,sizeof formatted,"%3$*1$.*2$f",8,2,1.25)==8 && strcmp(formatted,"    1.25")==0);
 CHECK(setlocale(LC_ALL,"C.UTF-8")!=0);
 setenv("LANGUAGE","fr",1);setenv("LC_ALL","fr_FR.UTF-8",1);
 CHECK(bindtextdomain("test","/usr/src/gettext/port/locale")!=0);
 CHECK(bind_textdomain_codeset("test","UTF-8")!=0);
 CHECK(textdomain("test")!=0);
 CHECK(strcmp(gettext("hello"),"bonjour")==0);
 CHECK(strcmp(ngettext("apple","apples",1),"pomme")==0);
 CHECK(strcmp(ngettext("apple","apples",2),"pommes")==0);
 CHECK(strcmp(gettext("coffee"),"caf\xc3\xa9")==0);
 CHECK(strcmp(gettext("missing"),"missing")==0);
 CHECK(strcmp(dgettext("absent","hello"),"hello")==0);
 puts("GETTEXT-PASS");return 0;
}
