# bzip2 1.0.8

Unmodified upstream C sources and Makefile from
https://sourceware.org/pub/bzip2/bzip2-1.0.8.tar.gz.
SHA-256: `ab5a03176ee106d3f0fa90e381da478ddae405918153cca248e682cd0c4a2269`.
License: see LICENSE and the original README.

The three sample inputs/compressed references and words0–words3 are copied
verbatim into tests/. The manifests and this README.md are local additions.
No compiler, platform defines, or C source patches are needed.

`bzip2`, `bunzip2`, and `bzcat` share a cached build of bin.json;
`bzip2recover` uses recover/bin.json. The aliases supply `-d` and `-dc`
explicitly because the launcher executes a cached binary named bzip2.

`npm run test:utilities` builds using the upstream Makefile and runs its
`test` target, compares the compressed bytes with upstream reference files,
and checks multiblock/concatenated streams, recovery, rejection of invalid
and truncated input, input deletion, and file-mode preservation.

The environment is single-user, so passing file-mode tests is not evidence
of Unix ownership/access-control enforcement. See docs/PORTABILITY.md.
