# Recovery fixture

Generated with Python `bz2.compress(b"Recover this block: alpha beta gamma\n", compresslevel=9)`. `damaged.bz2` replaces the first four bytes with `XXXX`, preserving the compressed block.

On 2026-10-04, host `/usr/bin/bzip2recover` version 1.0.8 recovered `damaged.bz2` byte-for-byte to `expected.bz2`. Python decompression independently matched the original bytes. SHA-256 of expected.bz2: `ec6e37b6a13c80c74c5e0985ee10f6337d6c0b74051150d80f2ff92932fedeb0`.

The guest test checks exact recovered bytes, without requiring another package to decompress the result.
