set -e
gucman install bzip2
for n in 1 2 3; do
    bzip2 -$n -c /usr/src/bzip2/tests/sample$n.ref > /tmp/compressed
    cmp /tmp/compressed /usr/src/bzip2/tests/sample$n.bz2
    bzip2 -dc /usr/src/bzip2/tests/sample$n.bz2 > /tmp/restored
    cmp /tmp/restored /usr/src/bzip2/tests/sample$n.ref
done
cat /usr/src/bzip2/tests/sample1.bz2 /usr/src/bzip2/tests/sample2.bz2 > /tmp/concatenated.bz2
cat /usr/src/bzip2/tests/sample1.ref /usr/src/bzip2/tests/sample2.ref > /tmp/expected
bzcat /tmp/concatenated.bz2 > /tmp/restored
cmp /tmp/expected /tmp/restored
printf 'not a bzip2 stream' > /tmp/invalid
status=0
bzip2 -dc /tmp/invalid > /tmp/rejected 2>/tmp/rejected.err || status=$?
[ "$status" -ne 0 ]
echo BZIP2-ACCEPTANCE-PASS
