import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('bzip2',1700000);
try {
 const script=await readFile(new URL('./bzip2-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['bzip2'],fresh:['bzip2']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.ok(log.includes('BZIP2-ACCEPTANCE-PASS'),log);
 assert.deepEqual(errors,[]);
} finally {await close();}
