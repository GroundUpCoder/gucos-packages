set -e
gucman install bzip2recover
mkdir /tmp/recovery
cd /tmp/recovery
cp /usr/src/bzip2/port/recovery-fixture/damaged.bz2 damaged.bz2
bzip2recover damaged.bz2
cmp rec00001damaged.bz2 /usr/src/bzip2/port/recovery-fixture/expected.bz2
echo BZIP2RECOVER-ACCEPTANCE-PASS
