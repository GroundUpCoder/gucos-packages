PACKAGE ?= feh
VERSION ?= 3.13.1

app ?= 0
curl ?= 1
debug ?= 0
exif ?= 0
help ?= 0
install_fonts ?= 1
magic ?= 0
mkstemps ?= 1
verscmp ?= 1
xinerama ?= 1

# Prefix for all installed files
PREFIX ?= /usr/local
ICON_PREFIX ?= ${DESTDIR}${PREFIX}/share/icons

# icons in /usr/share/local/icons (and other prefixes != /usr) are not
# generally supported. So ignore PREFIX and always install icons into
# /usr/share/icons if the user wants to install feh on their local machine.
ifeq (${app},1)
	ICON_PREFIX = /usr/share/icons
endif

# Directories for manuals, executables, docs, data, etc.
main_dir = ${DESTDIR}${PREFIX}
man_dir = ${main_dir}/share/man
bin_dir = ${main_dir}/bin
doc_dir = ${main_dir}/share/doc/feh
image_dir = ${main_dir}/share/feh/images
font_dir ?= ${main_dir}/share/feh/fonts
example_dir = ${main_dir}/share/doc/feh/examples
desktop_dir = ${main_dir}/share/applications
icon_dir = ${ICON_PREFIX}/hicolor
48_icon_dir = ${icon_dir}/48x48/apps
scalable_icon_dir = ${icon_dir}/scalable/apps

INSTALL_TARGETS = man doc bin img icon examples applications

# default CFLAGS
CFLAGS ?= -g -O2
CFLAGS += -Wall -Wextra -pedantic

# Settings for glibc >= 2.19 - may need to be adjusted for other systems
CFLAGS += -std=c11 -D_POSIX_C_SOURCE=200809L -D_XOPEN_SOURCE=700 -D_DARWIN_C_SOURCE

ifeq (${curl},1)
	CFLAGS += -DHAVE_LIBCURL
	LDLIBS += -lcurl
	MAN_CURL = enabled
else
	MAN_CURL = disabled
endif

ifeq (${debug},1)
	CFLAGS += -DDEBUG -O0
	MAN_DEBUG = This is a debug build.
else
	MAN_DEBUG = .
endif

ifeq (${help},1)
	CFLAGS += -DINCLUDE_HELP
endif

ifeq (${install_fonts}, 1)
	INSTALL_TARGETS += font
endif

ifeq (${stat64},1)
	CFLAGS += -D_FILE_OFFSET_BITS=64
endif

ifeq (${mkstemps},1)
	CFLAGS += -DHAVE_MKSTEMPS
endif

ifeq (${magic},1)
	CFLAGS += -DHAVE_LIBMAGIC
	LDLIBS += -lmagic
	MAN_MAGIC = enabled
else
	MAN_MAGIC = disabled
endif

ifeq (${verscmp},1)
	CFLAGS += -DHAVE_STRVERSCMP
endif

ifeq (${xinerama},1)
	CFLAGS += -DHAVE_LIBXINERAMA
	LDLIBS += -lXinerama
	MAN_XINERAMA = enabled
else
	MAN_XINERAMA = disabled
endif

ifeq (${exif},1)
	CFLAGS += -DHAVE_LIBEXIF
	LDLIBS += -lexif
	MAN_EXIF = available
else
	MAN_EXIF = not available
endif

ifeq (${inotify},1)
	CFLAGS += -DHAVE_INOTIFY
	MAN_INOTIFY = enabled
else
	MAN_INOTIFY = disabled
endif

# The environment variable SOURCE_DATE_EPOCH is used by build environments
# to produce reproducible binary builds. In fact you can set both manually,
# SOURCE_DATE_EPOCH and MAN_DATE.
SOURCE_DATE_EPOCH ?= $(shell date +%s)
MAN_DATE ?= September 16, 2026

# Uncomment this to use dmalloc
#CFLAGS += -DWITH_DMALLOC

CFLAGS += -DPREFIX=\"${PREFIX}\" \
	-DPACKAGE=\"${PACKAGE}\" -DVERSION=\"${VERSION}\"

LDLIBS += -lm -lpng -lX11 -lImlib2
