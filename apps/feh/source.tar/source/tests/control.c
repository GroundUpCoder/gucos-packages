#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <Imlib2.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc,char**argv){if(argc>1&&!strcmp(argv[1],"create")){for(int j=0;j<2;j++){Imlib_Image im=imlib_create_image(80,60);assert(im);imlib_context_set_image(im);imlib_context_set_color(j?0:255,j?255:0,0,255);imlib_image_fill_rectangle(0,0,80,60);imlib_image_set_format("png");Imlib_Load_Error e;imlib_save_image_with_error_return(j?"/tmp/green.png":"/tmp/red.png",&e);assert(!e);imlib_free_image();}return 0;}unsigned long target=strtoul(argv[1],0,16);Display*d=XOpenDisplay(0);assert(d);Window root=DefaultRootWindow(d);for(int t=0;t<100;t++){Window r,p,*cs=0;unsigned n=0;XQueryTree(d,root,&r,&p,&cs,&n);for(unsigned i=0;i<n;i++){XClassHint h={0};if(XGetClassHint(d,cs[i],&h)){int match=h.res_class&&!strcmp(h.res_class,"feh");if(h.res_name)XFree(h.res_name);if(h.res_class)XFree(h.res_class);if(match){XWindowAttributes a;XGetWindowAttributes(d,cs[i],&a);if(a.map_state==IsViewable){XImage*im=XGetImage(d,cs[i],0,0,a.width,a.height,AllPlanes,ZPixmap);unsigned count=0;if(im){for(int y=0;y<a.height;y++)for(int x=0;x<a.width;x++)if((XGetPixel(im,x,y)&0xffffff)==target)count++;XDestroyImage(im);}if(count>=4000){XSetInputFocus(d,cs[i],RevertToPointerRoot,CurrentTime);XSync(d,False);printf("FEH-COLOR %lx %u\n",target,count);XFree(cs);XCloseDisplay(d);return 0;}}}}}if(cs)XFree(cs);usleep(100000);}return 2;}
