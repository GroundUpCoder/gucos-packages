import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('zstd',600000);
try {
 const r=await runCached(page,`set -e
gucman install zstd
mkdir -p /tmp/zstd-test
cd /tmp/zstd-test
printf 'Zstandard browser roundtrip\\n' > input
# Include binary bytes and enough input to exercise worker compression.
dd if=/dev/zero bs=65536 count=32 >> input
zstd -T2 -f input -o input.zst
zstd -t input.zst
# Unchanged upstream frames exercise interoperability, not just self-roundtrips.
zstd -r -t /usr/src/zstd/tests/golden-decompression
for bad in /usr/src/zstd/tests/golden-decompression-errors/*; do
  if zstd -q -t "$bad"; then exit 98; fi
done
zstd -d -f input.zst -o output
cmp input output
cat input | zstd -q -c | zstd -q -d -c > streamed
cmp input streamed
printf 'not a zstd stream' > bad.zst
if zstd -q -t bad.zst; then exit 99; fi
printf '#include <zstd.h>\n#include <string.h>\nint main(void){char out[100],back[100];const char *s="library consumer";size_t n=ZSTD_compress(out,sizeof out,s,17,3);if(ZSTD_isError(n))return 1;size_t m=ZSTD_decompress(back,sizeof back,out,n);return m!=17||memcmp(s,back,17);}\n' > consumer.c
cc -I/usr/local/include consumer.c /usr/local/lib/libzstd.a -o consumer
./consumer
gucman install zstd
echo ZSTD-PACKAGE-PASS
`,{packages:['zstd'],fresh:['zstd']});
 assert.equal(r.code,0,await page.evaluate(()=>shell.busybox.log));
 assert.match(await page.evaluate(()=>shell.busybox.log),/ZSTD-PACKAGE-PASS/);
 assert.deepEqual(errors,[]);
 console.log('PASS Zstandard threaded binary/file/pipe roundtrips, invalid input rejection, installed static library consumer and package reuse');
} finally {await close();}
