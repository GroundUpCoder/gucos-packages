# Zstandard 1.5.7 browser port

Upstream: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz
SHA-256: eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3
License: upstream BSD (LICENSE) or GPLv2 (COPYING).

Upstream source is unchanged. The manual recipe selects portable C, pthreads,
and current-format support. Older legacy formats and optional gzip/xz/lz4
codecs are disabled. `__inline` is mapped to standard `inline` for this compiler.
The package installs the CLI, static library and public development headers.

Browser validation: threaded binary/file/pipe roundtrips, all four upstream
golden decompression frames, all three upstream corrupt-frame rejections,
a separate static-library consumer and package reuse. Real-time scheduling
priority changes are disabled through ZSTD_SETPRIORITY_SUPPORT=0. The POSIX
platform selector enables directory traversal; it is not a POSIX-conformance claim.
