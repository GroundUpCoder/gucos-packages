LPeg 1.1.0, unmodified upstream sources and test suite.

Source: https://www.inf.puc-rio.br/~roberto/lpeg/lpeg-1.1.0.tar.gz
SHA-256: 4b155d67d2246c1ffa7ad7bc466c1ea899bbc40fef0257cc9c03cecbaed4352a

LICENSE is the notice extracted from upstream lpeg.html.
Build using the upstream makefile with CC=cc, LUADIR=/usr/src/lua/src,
and DLLFLAGS="-shared -fPIC"; run lua test.lua from the build directory.
