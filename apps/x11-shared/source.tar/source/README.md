# Shared X11 client libraries for FLTK

This package links the exact approved x11-server object archives into reusable
wasm-posix shared libraries: libXau.so.6, libxcb.so.1 and libX11.so.6. It does not
rebuild or substitute their upstream sources. Source identity and original
acceptance remain in the pinned build dependency receipt. Original licenses are
included. This new linking recipe requires its own source/binary acceptance and
independent exact-artifact review before promotion or use as an approved input.

The C ABI is the installed x11-server header API and the exported object symbols.
These are wasm-posix dynamic modules, not ELF libraries. Each uses shared fork
libc; XCB depends on Xau, and X11 on XCB/Xau. No static libc is embedded. The test
reuses the unchanged existing X11 consumer, with core X11/XCB/Xau dynamically
selected and extension libraries still static. It checks real errors/callbacks,
resource ownership, fonts, rendering, selection/events, two launches and teardown,
then asserts the actual dynamic dependency metadata. No claim that extension
libraries or the X server itself became shared. Loader/runtime fixes, if needed,
belong to a separate platform lane with a reproducer and review.
