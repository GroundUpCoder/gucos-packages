import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,output,close}=await appBrowser('x11-shared',900000);
try{
 const result=await runCached(page,`set -e
gucman install x11-shared x11-server
cc --enable-fork -I/usr/local/include /usr/src/x11-shared/tests/client.c /usr/local/lib/libXrender.a /usr/local/lib/libXtst.a /usr/local/lib/libXfixes.a /usr/local/lib/libXi.a /usr/local/lib/libXext.a -L/usr/local/lib -lX11 -lxcb -lXau -o /tmp/shared-xlib-client
export DISPLAY=:1
Xvfb :1 -screen 0 320x240x24 -ac -noreset -fp built-ins &
xpid=$!
trap 'kill -TERM "$xpid" 2>/dev/null; wait "$xpid" 2>/dev/null' EXIT
sleep 2
printf q | /tmp/shared-xlib-client
printf q | /tmp/shared-xlib-client
kill -TERM "$xpid"
wait "$xpid"
trap - EXIT
test ! -e /tmp/.X1-lock
test ! -e /tmp/.X11-unix/X1
echo X11-SHARED-PASS
`,{packages:['x11-shared'],fresh:['x11-shared']});
 const log=await page.evaluate(()=>shell.busybox.log);assert.equal(result.code,0,log);assert.ok(log.includes('X11-SHARED-PASS'));assert.equal(log.split('READY xlib xcb render raster font shape sync xfixes xi2 xkb property selection focus input errors').length-1,2);assert.deepEqual(errors,[]);
 const metadata={};
 for(const path of ['/tmp/shared-xlib-client','/usr/local/lib/libX11.so.6','/usr/local/lib/libxcb.so.1','/usr/local/lib/libXau.so.6']){
  const row=await page.evaluate(async path=>{const b=await shell.busybox.read(path);const m=JSON.parse(new TextDecoder().decode(WebAssembly.Module.customSections(new WebAssembly.Module(b),'wasmposix.dylink')[0]));return {bytes:b.length,shared:m.shared,soname:m.soname,needed:m.needed};},path);metadata[path]=row;
 }
 assert.deepEqual(metadata['/usr/local/lib/libXau.so.6'].needed,['libc-fork.so.1']);
 for(const [path,names] of [['/usr/local/lib/libxcb.so.1',['libXau.so.6','libc-fork.so.1']],['/usr/local/lib/libX11.so.6',['libxcb.so.1','libXau.so.6','libc-fork.so.1']],['/tmp/shared-xlib-client',['libX11.so.6','libxcb.so.1','libXau.so.6','libc-fork.so.1']]])assert.deepEqual([...metadata[path].needed].sort(),names.sort());
 await writeFile(output+'/result.json',JSON.stringify({result,errors,metadata},null,2)+'\n');console.log('PASS actual shared X11/XCB/Xau/libc dependency graph, callbacks, allocation, events and relaunch');
}finally{await close();}
