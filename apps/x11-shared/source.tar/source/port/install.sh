#!/bin/sh
set -eu
stage=$1
mkdir -p "$stage/lib" "$stage/share/licenses/x11-shared"
cd /usr/src/x11-shared
mkdir -p build
for spec in Xau:6 xcb:1 X11:6; do
 name=${spec%:*}
 version=${spec#*:}
 mkdir -p "build/$name"
 cd "build/$name"
 ar x "/usr/local/lib/lib$name.a"
 case "$name" in Xau) deps= ;; xcb) deps=-lXau ;; X11) deps='-lxcb -lXau' ;; esac
 cc --enable-fork -shared -Wl,-soname,lib$name.so.$version *.o -L"$stage/lib" $deps /usr/lib/libc-fork.so.1 -o "$stage/lib/lib$name.so.$version"
 ln -s "lib$name.so.$version" "$stage/lib/lib$name.so"
 cd ../..
done
cp licenses/* "$stage/share/licenses/x11-shared/"
