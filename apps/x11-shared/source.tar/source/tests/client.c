/* Real, independent Xlib/XCB consumer. No implementation headers or adapters. */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/extensions/XTest.h>
#include <X11/extensions/Xrender.h>
#include <X11/extensions/shape.h>
#include <X11/extensions/sync.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/XInput2.h>
#include <X11/XKBlib.h>
#include <xcb/xcb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do { if (!(x)) { fprintf(stderr,"CHECK failed: %s at %d\n",#x,__LINE__); exit(1); } } while(0)
static int errors, last_error;
static int error_handler(Display *d, XErrorEvent *e) { (void)d; errors++; last_error=e->error_code; return 0; }
static unsigned long raster(int op, unsigned long s, unsigned long d) {
  switch(op) {
    case GXclear:return 0; case GXand:return s&d; case GXandReverse:return s&~d;
    case GXcopy:return s; case GXandInverted:return ~s&d; case GXnoop:return d;
    case GXxor:return s^d; case GXor:return s|d; case GXnor:return ~(s|d);
    case GXequiv:return ~(s^d); case GXinvert:return ~d; case GXorReverse:return s|~d;
    case GXcopyInverted:return ~s; case GXorInverted:return ~s|d; case GXnand:return ~(s&d);
    default:return ~0UL;
  }
}
int main(void) {
  CHECK(XInitThreads());
  Display *a=XOpenDisplay(NULL), *b=XOpenDisplay(NULL);
  CHECK(a && b); XSetErrorHandler(error_handler);
  Window root=DefaultRootWindow(a);
  int opcode,event,error;
  CHECK(!XQueryExtension(a,"GLX",&opcode,&event,&error));
  CHECK(!XQueryExtension(a,"MIT-SHM",&opcode,&event,&error));
  CHECK(XQueryExtension(a,"RENDER",&opcode,&event,&error));
  CHECK(XQueryExtension(a,"XTEST",&opcode,&event,&error));
  XSetWindowBackground(a,root,0x102030); XClearWindow(a,root);
  Window w=XCreateSimpleWindow(a,root,8,8,64,48,0,0,0x0000ff);
  Window other=XCreateSimpleWindow(b,root,80,10,48,40,0,0,0xffff00);
  XSelectInput(a,w,ExposureMask|KeyPressMask|KeyReleaseMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask|StructureNotifyMask);
  XMapWindow(a,w); XMapWindow(b,other); XSync(a,False); XSync(b,False);
  XWindowAttributes attrs; CHECK(XGetWindowAttributes(a,other,&attrs)); CHECK(attrs.width==48 && attrs.map_state==IsViewable);
  GC gc=XCreateGC(a,w,0,NULL); XSetForeground(a,gc,0xff0000); XFillRectangle(a,w,gc,0,0,16,16);
  XRenderPictFormat *fmt=XRenderFindVisualFormat(a,DefaultVisual(a,DefaultScreen(a))); CHECK(fmt);
  Picture picture=XRenderCreatePicture(a,w,fmt,0,NULL);
  XRenderColor green={0,65535,0,65535}; XRenderFillRectangle(a,PictOpSrc,picture,&green,24,0,16,16);
  /* Identical glyphs exercise server SHA-1 cache keys and Render text. */
  XRenderPictFormat *alpha=XRenderFindStandardFormat(a,PictStandardA8); CHECK(alpha);
  GlyphSet glyphs=XRenderCreateGlyphSet(a,alpha); Glyph ids[2]={1,2};
  XGlyphInfo glyph_info[2]={{8,8,0,0,8,0},{8,8,0,0,8,0}}; unsigned char glyph_pixels[128];memset(glyph_pixels,255,sizeof glyph_pixels);
  XRenderAddGlyphs(a,glyphs,ids,glyph_info,2,(char *)glyph_pixels,sizeof glyph_pixels);
  XRenderColor white={65535,65535,65535,65535};Picture solid=XRenderCreateSolidFill(a,&white);
  const char text[2]={1,2};XRenderCompositeString8(a,PictOpOver,solid,picture,alpha,glyphs,0,0,40,24,text,2);
  XImage *glyph_image=XGetImage(a,w,40,24,16,8,AllPlanes,ZPixmap);CHECK(glyph_image);CHECK(XGetPixel(glyph_image,0,0)==0xffffff&&XGetPixel(glyph_image,15,7)==0xffffff);XDestroyImage(glyph_image);
  XRenderFreePicture(a,solid);XRenderFreeGlyphSet(a,glyphs);
  Pixmap p=XCreatePixmap(a,root,16,16,DefaultDepth(a,DefaultScreen(a)));
  XSetForeground(a,gc,0x123456); XFillRectangle(a,p,gc,0,0,16,16);
  XSetFunction(a,gc,GXxor); XSetForeground(a,gc,0xffffff); XFillRectangle(a,p,gc,0,0,8,8);
  XImage *image=XGetImage(a,p,0,0,16,16,AllPlanes,ZPixmap); CHECK(image);
  CHECK(XGetPixel(image,0,0)==0xedcba9); CHECK(XGetPixel(image,12,12)==0x123456); XDestroyImage(image);
  XSetFunction(a,gc,GXcopy); XCopyArea(a,p,w,gc,0,0,16,16,0,24);
  /* All core raster functions, partial plane masks, and overlapping copies. */
  Pixmap q=XCreatePixmap(a,root,16,16,DefaultDepth(a,DefaultScreen(a)));
  unsigned long src=0xc963a5,dst=0x369c5a,mask=0xff00ff;
  for(int op=0;op<16;op++) {
    XSetPlaneMask(a,gc,AllPlanes); XSetFunction(a,gc,GXcopy); XSetForeground(a,gc,dst); XFillRectangle(a,q,gc,0,0,16,16);
    XSetPlaneMask(a,gc,mask); XSetFunction(a,gc,op); XSetForeground(a,gc,src); XFillRectangle(a,q,gc,0,0,16,16);
    image=XGetImage(a,q,0,0,16,16,AllPlanes,ZPixmap); CHECK(image);
    CHECK(XGetPixel(image,5,5)==(((raster(op,src,dst)&mask)|(dst&~mask))&0xffffff)); XDestroyImage(image);
  }
  XSetPlaneMask(a,gc,AllPlanes); XSetFunction(a,gc,GXcopy);
  for(int x=0;x<16;x++){XSetForeground(a,gc,(unsigned long)(x+1));XFillRectangle(a,q,gc,x,0,1,1);}
  XCopyArea(a,q,q,gc,0,0,15,1,1,0); image=XGetImage(a,q,0,0,16,1,AllPlanes,ZPixmap); CHECK(image);
  for(int x=1;x<16;x++)CHECK(XGetPixel(image,x,0)==(unsigned long)x); XDestroyImage(image);
  XFontStruct *font=XLoadQueryFont(a,"fixed"); CHECK(font && XTextWidth(font,"X11",3)>0);
  XSetFont(a,gc,font->fid); XDrawString(a,q,gc,0,12,"X",1); XFreeFont(a,font); XFreePixmap(a,q);
  /* Version negotiation and actual state for selected extensions. */
  int major=2,minor=0; CHECK(XIQueryVersion(a,&major,&minor)==Success);
  int devices=0; XIDeviceInfo *di=XIQueryDevice(a,XIAllMasterDevices,&devices); CHECK(di && devices>=2); XIFreeDeviceInfo(di);
  major=XkbMajorVersion; minor=XkbMinorVersion; CHECK(XkbQueryExtension(a,&opcode,&event,&error,&major,&minor));
  major=0; minor=0; CHECK(XFixesQueryVersion(a,&major,&minor));
  XRectangle region_rect={1,2,3,4}; XserverRegion region=XFixesCreateRegion(a,&region_rect,1); int rectangles=0;
  XRectangle *rects=XFixesFetchRegion(a,region,&rectangles); CHECK(rects && rectangles==1 && rects[0].width==3); XFree(rects); XFixesDestroyRegion(a,region);
  CHECK(XShapeQueryExtension(a,&event,&error));
  XShapeCombineRectangles(a,other,ShapeBounding,0,0,&region_rect,1,ShapeSet,Unsorted);
  int ordering; rects=XShapeGetRectangles(a,other,ShapeBounding,&rectangles,&ordering); CHECK(rects && rectangles==1 && rects[0].height==4); XFree(rects);
  XShapeCombineMask(a,other,ShapeBounding,0,0,None,ShapeSet);
  CHECK(XSyncInitialize(a,&major,&minor)); XSyncValue counter_value; XSyncIntToValue(&counter_value,42);
  XSyncCounter counter=XSyncCreateCounter(a,counter_value); XSyncValue got; CHECK(XSyncQueryCounter(a,counter,&got)); CHECK(XSyncValueLow32(got)==42); XSyncDestroyCounter(a,counter);
  Atom prop=XInternAtom(a,"_WASM_POSIX_X11_TEST",False), actual;
  const unsigned char message[]="independent Xlib client"; unsigned char *value=NULL;
  XChangeProperty(a,w,prop,XA_STRING,8,PropModeReplace,message,sizeof(message)); XSync(a,False);
  int format; unsigned long count,after;
  CHECK(XGetWindowProperty(b,w,prop,0,100,False,XA_STRING,&actual,&format,&count,&after,&value)==Success);
  CHECK(actual==XA_STRING && format==8 && count==sizeof(message) && !memcmp(value,message,sizeof(message))); XFree(value);
  Atom selection=XInternAtom(a,"CLIPBOARD",False);
  XSetSelectionOwner(a,selection,w,CurrentTime); XSync(a,False); CHECK(XGetSelectionOwner(b,selection)==w);
  XConvertSelection(b,selection,XA_STRING,prop,other,CurrentTime); XSync(b,False); XSync(a,False);
  XEvent e; CHECK(XCheckTypedEvent(a,SelectionRequest,&e));
  CHECK(e.xselectionrequest.requestor==other && e.xselectionrequest.target==XA_STRING);
  XChangeProperty(a,other,prop,XA_STRING,8,PropModeReplace,message,sizeof(message));
  XEvent answer={0}; answer.xselection.type=SelectionNotify; answer.xselection.display=a;
  answer.xselection.requestor=other; answer.xselection.selection=selection;
  answer.xselection.target=XA_STRING; answer.xselection.property=prop; answer.xselection.time=e.xselectionrequest.time;
  XSendEvent(a,other,False,0,&answer); XSync(a,False); XSync(b,False);
  CHECK(XCheckTypedEvent(b,SelectionNotify,&e)); CHECK(e.xselection.property==prop);
  XSetInputFocus(a,w,RevertToParent,CurrentTime); XSync(a,False);
  Window focus; int revert; XGetInputFocus(b,&focus,&revert); CHECK(focus==w);
  while(XPending(a)) XNextEvent(a,&e);
  CHECK(XTestFakeMotionEvent(a,DefaultScreen(a),12,12,CurrentTime));
  CHECK(XTestFakeButtonEvent(a,1,True,CurrentTime)); CHECK(XTestFakeButtonEvent(a,1,False,CurrentTime));
  KeyCode key=XKeysymToKeycode(a,XK_a); CHECK(key);
  CHECK(XTestFakeKeyEvent(a,key,True,CurrentTime)); CHECK(XTestFakeKeyEvent(a,key,False,CurrentTime)); XSync(a,False);
  int press=0,release=0,kpress=0,krelease=0;
  while(XPending(a)) {XNextEvent(a,&e); press+=e.type==ButtonPress; release+=e.type==ButtonRelease; kpress+=e.type==KeyPress; krelease+=e.type==KeyRelease;}
  CHECK(press==1 && release==1 && kpress==1 && krelease==1);
  XFreePixmap(a,p); XSync(a,False); CHECK(errors==0);
  XFreePixmap(a,p); XSync(a,False); CHECK(errors==1 && last_error==BadPixmap);
  xcb_connection_t *xcb=xcb_connect(NULL,NULL); CHECK(!xcb_connection_has_error(xcb));
  xcb_generic_error_t *xcb_error=NULL;
  xcb_intern_atom_reply_t *atom=xcb_intern_atom_reply(xcb,xcb_intern_atom(xcb,0,20,"_WASM_POSIX_XCB_TEST"),&xcb_error);
  CHECK(atom && !xcb_error && atom->atom); free(atom);
  xcb_get_geometry_reply_t *geo=xcb_get_geometry_reply(xcb,xcb_get_geometry(xcb,w),&xcb_error);
  CHECK(geo && !xcb_error && geo->width==64 && geo->height==48); free(geo); xcb_disconnect(xcb);
  XTestFakeMotionEvent(a,DefaultScreen(a),150,90,CurrentTime);
  XSync(a,False); XSync(b,False);
  puts("READY xlib xcb render raster font shape sync xfixes xi2 xkb property selection focus input errors"); fflush(stdout);
  CHECK(getchar()=='q');
  XRenderFreePicture(a,picture); XFreeGC(a,gc); XCloseDisplay(b); XCloseDisplay(a);
  return 0;
}
