/* MiniHB: a C implementation of a bounded HarfBuzz API subset. Public API
 * declarations are HarfBuzz's. Horizontal runs of Latin, Greek, Cyrillic,
 * Han, kana, modern Hangul and emoji go through the OpenType layout in
 * shape.c; printable ASCII can also use the upstream fallback shaper.
 * hb_shape_full reports unsupported requests without changing the buffer.
 */
#include <hb-ft.h>
#include <hb.h>
#include FT_ADVANCES_H
#include <limits.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "private.h"
struct hb_language_impl_t {
  struct hb_language_impl_t *next;
  char text[1];
};
/* Interned language handles have process lifetime, matching HarfBuzz's API.
 * Serialize language interning because callers can shape on worker threads. */
#include <pthread.h>
static pthread_mutex_t language_lock = PTHREAD_MUTEX_INITIALIZER;
static struct hb_language_impl_t *languages;
hb_language_t hb_language_from_string(const char *s, int len) {
  if (!s || !*s || len == 0)
    return HB_LANGUAGE_INVALID;
  if (len < 0)
    len = (int)strlen(s);
  char *key = malloc((size_t)len + 1);
  if (!key)
    return HB_LANGUAGE_INVALID;
  for (int i = 0; i < len; i++) {
    unsigned char c = s[i];
    key[i] = c == '_' ? '-' : c >= 'A' && c <= 'Z' ? c + 32 : c;
  }
  key[len] = 0;
  pthread_mutex_lock(&language_lock);
  struct hb_language_impl_t *p = languages;
  while (p && strcmp(p->text, key))
    p = p->next;
  if (!p) {
    p = malloc(sizeof(*p) + (size_t)len);
    if (p) {
      strcpy(p->text, key);
      p->next = languages;
      languages = p;
    }
  }
  pthread_mutex_unlock(&language_lock);
  free(key);
  return p;
}
const char *hb_language_to_string(hb_language_t language) {
  return language ? language->text : NULL;
}

hb_face_t *hb_ft_face_create(FT_Face face, hb_destroy_func_t destroy) {
  if (!face)
    return NULL;
  hb_face_t *f = calloc(1, sizeof(*f));
  if (f) {
    f->refs = 1;
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&f->lock, &attr);
    pthread_mutexattr_destroy(&attr);
    f->ft = face;
    f->destroy = destroy;
  }
  return f;
}
hb_face_t *hb_face_reference(hb_face_t *f) {
  if (f)
    atomic_fetch_add_explicit(&f->refs, 1, memory_order_relaxed);
  return f;
}
void hb_face_destroy(hb_face_t *f) {
  if (f && atomic_fetch_sub_explicit(&f->refs, 1, memory_order_acq_rel) == 1) {
    if (f->destroy)
      f->destroy(f->ft);
    if (f->library)
      FT_Done_FreeType(f->library);
    hb_blob_destroy(f->blob);
    pthread_mutex_destroy(&f->lock);
    free(f);
  }
}
static void done_face(void *f) { FT_Done_Face((FT_Face)f); }
hb_face_t *hb_ft_face_create_referenced(FT_Face face) {
  if (!face || FT_Reference_Face(face))
    return NULL;
  hb_face_t *f = hb_ft_face_create(face, done_face);
  if (!f)
    FT_Done_Face(face);
  return f;
}
hb_font_t *hb_font_create(hb_face_t *face) {
  if (!face)
    return NULL;
  hb_font_t *f = calloc(1, sizeof(*f));
  if (f) {
    f->refs = 1;
    f->face = hb_face_reference(face);
    f->flags = FT_LOAD_DEFAULT | FT_LOAD_NO_HINTING;
    f->design_units = 1;
    f->x_scale = face->ft ? face->ft->units_per_EM : 0;
    f->y_scale = f->x_scale;
  }
  return f;
}
hb_font_t *hb_font_reference(hb_font_t *f) {
  if (f && !f->immortal)
    atomic_fetch_add_explicit(&f->refs, 1, memory_order_relaxed);
  return f;
}
void hb_font_destroy(hb_font_t *f) {
  if (f && !f->immortal &&
      atomic_fetch_sub_explicit(&f->refs, 1, memory_order_acq_rel) == 1) {
    if (f->data_destroy)
      f->data_destroy(f->font_data);
    hb_font_funcs_destroy(f->funcs);
    hb_font_destroy(f->parent);
    hb_face_destroy(f->face);
    free(f);
  }
}
hb_font_t *hb_ft_font_create(FT_Face ft, hb_destroy_func_t destroy) {
  hb_face_t *face = hb_ft_face_create(ft, destroy);
  if (!face) {
    if (destroy)
      destroy(ft);
    return NULL;
  }
  hb_font_t *f = hb_font_create(face);
  hb_face_destroy(face);
  if (f)
    f->design_units = 0;
  if (f && ft->size) {
    f->x_scale = (int)FT_MulFix(ft->units_per_EM, ft->size->metrics.x_scale);
    f->y_scale = (int)FT_MulFix(ft->units_per_EM, ft->size->metrics.y_scale);
  }
  return f;
}
hb_font_t *hb_ft_font_create_referenced(FT_Face ft) {
  if (!ft || FT_Reference_Face(ft))
    return NULL;
  hb_font_t *f =
      hb_ft_font_create(ft, done_face); /* hb_ft_font_create consumes the
                                           reference once its face exists. */
  return f;
}
/* SDL_ttf calls this after resizing the FT_Face. External size/variation
 * changes invalidate the advance cache even when HB scale is unchanged.
 * Clear any pending HB-to-FT scale update so it cannot undo that external edit. */
void hb_ft_font_changed(hb_font_t *f) {
  if (!f || f->immutable || f->design_units || f->funcs || f->parent ||
      !f->face || !f->face->ft)
    return;
  pthread_mutex_lock(&f->face->lock);
  memset(f->advances, 0, sizeof(f->advances));
  FT_Face ft = f->face->ft;
  if (ft->size) {
    f->x_scale = (int)FT_MulFix(ft->units_per_EM, ft->size->metrics.x_scale);
    f->y_scale = (int)FT_MulFix(ft->units_per_EM, ft->size->metrics.y_scale);
    f->scale_changed = 0;
  }
  pthread_mutex_unlock(&f->face->lock);
}
void hb_ft_font_set_load_flags(hb_font_t *f, int flags) {
  if (f && !f->immortal) {
    pthread_mutex_lock(&f->face->lock);
    if (f->flags != flags) {
      f->flags = flags;
      memset(f->advances, 0, sizeof(f->advances));
    }
    pthread_mutex_unlock(&f->face->lock);
  }
}
int hb_ft_font_get_load_flags(hb_font_t *f) { return f ? f->flags : 0; }
hb_face_t *hb_font_get_face(hb_font_t *f) { return f ? f->face : NULL; }
void hb_font_set_scale(hb_font_t *f, int x, int y) {
  if (f && !f->immutable) {
    pthread_mutex_lock(&f->face->lock);
    f->x_scale = x;
    f->y_scale = y;
    f->scale_changed = 1;
    memset(f->advances, 0, sizeof(f->advances));
    pthread_mutex_unlock(&f->face->lock);
  }
}
void hb_font_get_scale(hb_font_t *f, int *x, int *y) {
  if (x)
    *x = f ? f->x_scale : 0;
  if (y)
    *y = f ? f->y_scale : 0;
}
static hb_bool_t mini_hb_font_get_nominal_glyph(hb_font_t *f, hb_codepoint_t c,
                                                hb_codepoint_t *g) {
  if (!g)
    return 0;
  if (f && f->funcs && f->funcs->nominal)
    return f->funcs->nominal(f, f->font_data, c, g, f->funcs->nominal_data);
  if (f && f->parent)
    return hb_font_get_nominal_glyph(f->parent, c, g);
  *g = f && f->face && f->face->ft ? FT_Get_Char_Index(f->face->ft, c) : 0;
  return *g != 0;
}
static hb_bool_t mini_hb_ft_hb_font_changed(hb_font_t *f) {
  if (!f || !f->scale_changed || f->x_scale == INT_MIN || f->y_scale == INT_MIN)
    return 0;
  FT_Face ft = f->face->ft;
  if (FT_Set_Char_Size(ft, abs(f->x_scale), abs(f->y_scale), 0, 0))
    return 0;
  FT_Matrix matrix = {f->x_scale < 0 ? -65536 : 65536, 0, 0,
                      f->y_scale < 0 ? -65536 : 65536};
  FT_Set_Transform(ft, &matrix, NULL);
  memset(f->advances, 0, sizeof(f->advances));
  f->scale_changed = 0;
  return 1;
}
static hb_position_t mini_hb_font_get_glyph_h_advance(hb_font_t *f,
                                                      hb_codepoint_t g) {
  if (!f)
    return 0;
  if (f->funcs && f->funcs->horizontal)
    return f->funcs->horizontal(f, f->font_data, g, f->funcs->horizontal_data);
  if (f->parent)
    return mini_parent_scale(hb_font_get_glyph_h_advance(f->parent, g),
                             f->x_scale, f->parent->x_scale);
  FT_Face ft = f->face->ft;
  if (!ft)
    return 0;
  if (f->design_units) {
    if (FT_Load_Glyph(ft, g, FT_LOAD_NO_SCALE | FT_LOAD_NO_HINTING))
      return 0;
    return (hb_position_t)FT_MulDiv(ft->glyph->metrics.horiAdvance, f->x_scale,
                                    ft->units_per_EM);
  }
  unsigned slot = g % 256;
  if (f->advances[slot].valid && f->advances[slot].glyph == g)
    return f->advances[slot].advance;
  FT_Fixed advance = 0;
  if (FT_Get_Advance(ft, g, f->flags, &advance))
    return 0;
  if (advance < 0)
    advance = -advance;
  if (f->x_scale < 0)
    advance = -advance;
  hb_position_t result = (hb_position_t)((advance + 512) >> 10);
  f->advances[slot].glyph = g;
  f->advances[slot].advance = result;
  f->advances[slot].valid = 1;
  return result;
}

hb_buffer_t *hb_buffer_create(void) {
  hb_buffer_t *b = calloc(1, sizeof(*b));
  if (b) {
    b->refs = 1;
    b->successful = 1;
  }
  return b;
}
hb_buffer_t *hb_buffer_reference(hb_buffer_t *b) {
  if (b)
    atomic_fetch_add_explicit(&b->refs, 1, memory_order_relaxed);
  return b;
}
void hb_buffer_destroy(hb_buffer_t *b) {
  if (b && atomic_fetch_sub_explicit(&b->refs, 1, memory_order_acq_rel) == 1) {
    free(b->info);
    free(b->pos);
    free(b);
  }
}
void hb_buffer_clear_contents(hb_buffer_t *b) {
  if (b) {
    b->length = 0;
    b->content = HB_BUFFER_CONTENT_TYPE_INVALID;
    b->successful = 1;
    b->error = 0;
  }
}
void hb_buffer_reset(hb_buffer_t *b) {
  if (b) {
    hb_buffer_clear_contents(b);
    b->direction = HB_DIRECTION_INVALID;
    b->script = HB_SCRIPT_INVALID;
    b->language = NULL;
    b->flags = 0;
    b->cluster_level = 0;
    b->invisible = 0;
  }
}
hb_bool_t hb_buffer_allocation_successful(hb_buffer_t *b) {
  return b && b->successful;
}
hb_bool_t hb_buffer_pre_allocate(hb_buffer_t *b, unsigned n) {
  if (!b)
    return 0;
  if (n <= b->capacity)
    return 1;
  if (n > SIZE_MAX / sizeof(hb_glyph_info_t) ||
      n > SIZE_MAX / sizeof(hb_glyph_position_t)) {
    b->successful = 0;
    return 0;
  }
  hb_glyph_info_t *info = calloc(n, sizeof(*info));
  hb_glyph_position_t *pos = calloc(n, sizeof(*pos));
  if (!info || !pos) {
    free(info);
    free(pos);
    b->successful = 0;
    return 0;
  }
  if (b->length) {
    memcpy(info, b->info, b->length * sizeof(*info));
    memcpy(pos, b->pos, b->length * sizeof(*pos));
  }
  free(b->info);
  free(b->pos);
  b->info = info;
  b->pos = pos;
  b->capacity = n;
  return 1;
}
void hb_buffer_add(hb_buffer_t *b, hb_codepoint_t c, unsigned cluster) {
  if (!b || !b->successful || b->content == HB_BUFFER_CONTENT_TYPE_GLYPHS)
    return;
  if (b->length == b->capacity &&
      !hb_buffer_pre_allocate(b, b->capacity > UINT_MAX / 2 ? UINT_MAX
                                 : b->capacity              ? b->capacity * 2
                                                            : 32))
    return;
  if (b->length == b->capacity) {
    b->successful = 0;
    return;
  }
  hb_glyph_info_t *i = &b->info[b->length++];
  memset(i, 0, sizeof(*i));
  i->codepoint = c;
  i->cluster = cluster;
  b->content = HB_BUFFER_CONTENT_TYPE_UNICODE;
}
void hb_buffer_add_utf8(hb_buffer_t *b, const char *s, int length,
                        unsigned offset, int item_length) {
  if (!b || !s)
    return;
  if (length < 0)
    length = (int)strlen(s);
  if (offset > (unsigned)length)
    return;
  unsigned end =
      item_length < 0 ? (unsigned)length : offset + (unsigned)item_length;
  if (end < offset || end > (unsigned)length)
    return;
  for (unsigned i = offset; i < end;) {
    unsigned start = i, c = (unsigned char)s[i++], n = 0, min = 0;
    if (c >= 0xc2 && c <= 0xdf) {
      c &= 31;
      n = 1;
      min = 0x80;
    } else if (c >= 0xe0 && c <= 0xef) {
      c &= 15;
      n = 2;
      min = 0x800;
    } else if (c >= 0xf0 && c <= 0xf4) {
      c &= 7;
      n = 3;
      min = 0x10000;
    } else if (c >= 0x80)
      c = 0xfffd;
    if (n) {
      unsigned j = 0;
      while (j < n && i < end && ((unsigned char)s[i] & 0xc0) == 0x80) {
        c = (c << 6) | ((unsigned char)s[i++] & 63);
        j++;
      }
      if (j != n || c < min || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff))
        c = 0xfffd;
    }
    hb_buffer_add(b, c, start);
  }
}
void hb_buffer_set_direction(hb_buffer_t *b, hb_direction_t v) {
  if (b)
    b->direction = v;
}
hb_direction_t hb_buffer_get_direction(const hb_buffer_t *b) {
  return b ? b->direction : HB_DIRECTION_INVALID;
}
void hb_buffer_set_script(hb_buffer_t *b, hb_script_t v) {
  if (b)
    b->script = v;
}
hb_script_t hb_buffer_get_script(const hb_buffer_t *b) {
  return b ? b->script : HB_SCRIPT_INVALID;
}
void hb_buffer_set_language(hb_buffer_t *b, hb_language_t v) {
  if (b)
    b->language = v;
}
hb_language_t hb_buffer_get_language(const hb_buffer_t *b) {
  return b ? b->language : NULL;
}
void hb_buffer_set_flags(hb_buffer_t *b, hb_buffer_flags_t v) {
  if (b)
    b->flags = v;
}
hb_buffer_flags_t hb_buffer_get_flags(const hb_buffer_t *b) {
  return b ? b->flags : 0;
}
void hb_buffer_set_cluster_level(hb_buffer_t *b, hb_buffer_cluster_level_t v) {
  if (b)
    b->cluster_level = v;
}
hb_buffer_cluster_level_t hb_buffer_get_cluster_level(const hb_buffer_t *b) {
  return b ? b->cluster_level : 0;
}
void hb_buffer_set_content_type(hb_buffer_t *b, hb_buffer_content_type_t type) {
  if (b)
    b->content = type;
}
hb_buffer_content_type_t hb_buffer_get_content_type(const hb_buffer_t *b) {
  return b ? b->content : HB_BUFFER_CONTENT_TYPE_INVALID;
}
unsigned hb_buffer_get_length(const hb_buffer_t *b) {
  return b ? b->length : 0;
}
hb_glyph_info_t *hb_buffer_get_glyph_infos(hb_buffer_t *b, unsigned *n) {
  if (n)
    *n = b ? b->length : 0;
  return b ? b->info : NULL;
}
hb_glyph_position_t *hb_buffer_get_glyph_positions(hb_buffer_t *b,
                                                   unsigned *n) {
  if (n)
    *n = b ? b->length : 0;
  return b ? b->pos : NULL;
}
void hb_buffer_guess_segment_properties(hb_buffer_t *b) {
  if (b) {
    if (!b->direction)
      b->direction = HB_DIRECTION_LTR;
    if (!b->script)
      b->script = HB_SCRIPT_LATIN;
    if (!b->language)
      b->language = hb_language_from_string("en", -1);
  }
}
void hb_buffer_reverse(hb_buffer_t *b) {
  if (b)
    for (unsigned i = 0; i < b->length / 2; i++) {
      unsigned j = b->length - 1 - i;
      hb_glyph_info_t t = b->info[i];
      b->info[i] = b->info[j];
      b->info[j] = t;
      hb_glyph_position_t p = b->pos[i];
      b->pos[i] = b->pos[j];
      b->pos[j] = p;
    }
}
const char **hb_shape_list_shapers(void) {
  static const char *shapers[] = {"ot", "fallback", NULL};
  return shapers;
}
static hb_script_t canonical_script(hb_tag_t tag) {
  switch (tag) {
  case HB_TAG('Q', 'a', 'a', 'i'):
    return HB_SCRIPT_INHERITED;
  case HB_TAG('Q', 'a', 'a', 'c'):
    return HB_SCRIPT_COPTIC;
  case HB_TAG('A', 'r', 'a', 'n'):
    return HB_SCRIPT_ARABIC;
  case HB_TAG('C', 'y', 'r', 's'):
    return HB_SCRIPT_CYRILLIC;
  case HB_TAG('G', 'e', 'o', 'k'):
    return HB_SCRIPT_GEORGIAN;
  case HB_TAG('H', 'a', 'n', 's'):
  case HB_TAG('H', 'a', 'n', 't'):
    return HB_SCRIPT_HAN;
  case HB_TAG('J', 'a', 'm', 'o'):
    return HB_SCRIPT_HANGUL;
  case HB_TAG('L', 'a', 't', 'f'):
  case HB_TAG('L', 'a', 't', 'g'):
    return HB_SCRIPT_LATIN;
  case HB_TAG('S', 'y', 'r', 'e'):
  case HB_TAG('S', 'y', 'r', 'j'):
  case HB_TAG('S', 'y', 'r', 'n'):
    return HB_SCRIPT_SYRIAC;
  default:
    return (hb_script_t)tag;
  }
}
hb_script_t hb_script_from_iso15924_tag(hb_tag_t tag) {
  if (tag == HB_TAG_NONE)
    return HB_SCRIPT_INVALID;
  /* Title case the tag the way upstream does before canonicalizing. */
  unsigned char c[4] = {tag >> 24, tag >> 16, tag >> 8, tag};
  if (c[0] >= 'a' && c[0] <= 'z')
    c[0] -= 32;
  for (int i = 1; i < 4; i++)
    if (c[i] >= 'A' && c[i] <= 'Z')
      c[i] += 32;
  return canonical_script(HB_TAG(c[0], c[1], c[2], c[3]));
}
hb_script_t hb_script_from_string(const char *str, int len) {
  if (!str || !*str || len == 0)
    return HB_SCRIPT_INVALID;
  if (len < 0)
    len = (int)strlen(str);
  unsigned char c[4] = {' ', ' ', ' ', ' '};
  for (int i = 0; i < 4 && i < len; i++)
    c[i] = (unsigned char)str[i];
  return hb_script_from_iso15924_tag(HB_TAG(c[0], c[1], c[2], c[3]));
}
hb_tag_t hb_script_to_iso15924_tag(hb_script_t script) { return (hb_tag_t)script; }
/* Features that only restate a default of the OpenType path are accepted;
 * any other request is reported as unsupported rather than ignored. */
static int feature_is_default(const hb_feature_t *f) {
  static const hb_tag_t defaults[] = {
      HB_TAG('k', 'e', 'r', 'n'), HB_TAG('l', 'i', 'g', 'a'), HB_TAG('c', 'a', 'l', 't'),
      HB_TAG('c', 'l', 'i', 'g'), HB_TAG('c', 'c', 'm', 'p'), HB_TAG('l', 'o', 'c', 'l'),
      HB_TAG('m', 'a', 'r', 'k'), HB_TAG('m', 'k', 'm', 'k'), HB_TAG('r', 'l', 'i', 'g')};
  if (f->value != 1)
    return 0;
  for (size_t i = 0; i < sizeof defaults / sizeof defaults[0]; i++)
    if (defaults[i] == f->tag)
      return 1;
  return 0;
}
/* The upstream fallback shaper, limited to printable ASCII so that text this
 * library cannot shape is reported instead of passed through nominally. */
static hb_bool_t fallback_shape(hb_font_t *f, hb_buffer_t *b) {
  if (b->direction != HB_DIRECTION_LTR && b->direction != HB_DIRECTION_RTL)
    return 0;
  if (b->script != HB_SCRIPT_INVALID && b->script != HB_SCRIPT_LATIN &&
      b->script != HB_SCRIPT_COMMON)
    return 0;
  for (unsigned i = 0; i < b->length; i++)
    if (b->info[i].codepoint < 32 || b->info[i].codepoint > 126)
      return 0;
  for (unsigned i = 0; i < b->length; i++) {
    hb_codepoint_t glyph = 0;
    hb_font_get_nominal_glyph(f, b->info[i].codepoint, &glyph);
    b->info[i].codepoint = glyph;
    memset(&b->pos[i], 0, sizeof(b->pos[i]));
    b->pos[i].x_advance = hb_font_get_glyph_h_advance(f, glyph);
  }
  if (b->direction == HB_DIRECTION_RTL)
    hb_buffer_reverse(b);
  b->content = HB_BUFFER_CONTENT_TYPE_GLYPHS;
  return 1;
}
hb_bool_t hb_shape_full(hb_font_t *f, hb_buffer_t *b,
                        const hb_feature_t *features, unsigned nfeatures,
                        const char *const *shapers) {
  if (!f || !b || !b->successful ||
      b->content == HB_BUFFER_CONTENT_TYPE_GLYPHS)
    return 0;
  for (unsigned i = 0; i < nfeatures; i++)
    if (!feature_is_default(&features[i]))
      return 0;
  for (hb_font_t *p = f; p; p = p->parent)
    if (p->unsupported || !p->face->ft || !FT_IS_SCALABLE(p->face->ft))
      return 0;
  const char *defaults[] = {"ot", "fallback", NULL};
  if (!shapers)
    shapers = defaults;
  b->error = 0;
  for (unsigned attempt = 0; shapers[attempt]; attempt++) {
    if (!strcmp(shapers[attempt], "fallback")) {
      if (fallback_shape(f, b))
        return 1;
      continue;
    }
    if (strcmp(shapers[attempt], "ot") ||
        (b->direction != HB_DIRECTION_LTR && b->direction != HB_DIRECTION_RTL) ||
        f->x_scale <= 0 || f->y_scale <= 0)
      continue;
    unsigned script = minihb_ot_script(b->script);
    if (script == 0) {
      /* Common or unknown: the first covered strong character decides. */
      for (unsigned i = 0; i < b->length && !script; i++)
        script = minihb_script_of(b->info[i].codepoint);
      if (!script)
        script = HB_TAG('D', 'F', 'L', 'T');
    }
    if (script != 0xffffffffu) {
      pthread_mutex_lock(&f->face->lock);
      int error = minihb_shape_script(f, b, script, minihb_ot_language(b->language));
      pthread_mutex_unlock(&f->face->lock);
      if (!error)
        return 1;
      if (error == MINIHB_OUT_OF_MEMORY)
        return 0;
    }
  }
  return 0;
}
void hb_shape(hb_font_t *f, hb_buffer_t *b, const hb_feature_t *features,
              unsigned count) {
  if (!hb_shape_full(f, b, features, count, NULL))
    fprintf(stderr, "minihb: unsupported shaping request; use hb_shape_full to "
                    "check support\n");
}

hb_bool_t hb_font_get_nominal_glyph(hb_font_t *f, hb_codepoint_t c,
                                    hb_codepoint_t *g) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_bool_t result = mini_hb_font_get_nominal_glyph(f, c, g);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}

hb_bool_t hb_ft_hb_font_changed(hb_font_t *f) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_bool_t result = mini_hb_ft_hb_font_changed(f);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}

hb_position_t hb_font_get_glyph_h_advance(hb_font_t *f, hb_codepoint_t g) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_position_t result = mini_hb_font_get_glyph_h_advance(f, g);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}

void minihb_font_reject_shaping(hb_font_t *font) {
  if (font && !font->immutable)
    font->unsupported = 1;
}
