/* C font services used by Pango. This file does not implement an OT shaper. */
#include "private.h"
#include FT_TRUETYPE_TABLES_H
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct hb_blob_t {
  atomic_uint refs;
  char *data;
  unsigned length;
  void *user;
  hb_destroy_func_t destroy;
};
static hb_blob_t empty_blob;
hb_blob_t *hb_blob_get_empty(void) { return &empty_blob; }
hb_blob_t *hb_blob_reference(hb_blob_t *b) {
  if (b && b != &empty_blob)
    atomic_fetch_add(&b->refs, 1);
  return b;
}
hb_blob_t *hb_blob_create(const char *data, unsigned length,
                          hb_memory_mode_t mode, void *user,
                          hb_destroy_func_t destroy) {
  hb_blob_t *b = calloc(1, sizeof(*b));
  if (!b) {
    if (destroy)
      destroy(user);
    return &empty_blob;
  }
  b->refs = 1;
  b->length = length;
  b->data = (char *)data;
  b->user = user;
  b->destroy = destroy;
  if (mode == HB_MEMORY_MODE_DUPLICATE) {
    b->data = malloc(length ? length : 1);
    if (!b->data) {
      free(b);
      if (destroy)
        destroy(user);
      return &empty_blob;
    }
    memcpy(b->data, data, length);
    if (destroy)
      destroy(user);
    b->user = b->data;
    b->destroy = free;
  }
  return b;
}
void hb_blob_destroy(hb_blob_t *b) {
  if (b && b != &empty_blob && atomic_fetch_sub(&b->refs, 1) == 1) {
    if (b->destroy)
      b->destroy(b->user);
    free(b);
  }
}
const char *hb_blob_get_data(hb_blob_t *b, unsigned *length) {
  if (length)
    *length = b ? b->length : 0;
  return b ? b->data : NULL;
}
unsigned hb_blob_get_length(hb_blob_t *b) { return b ? b->length : 0; }
hb_blob_t *hb_blob_create_from_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f)
    return &empty_blob;
  if (fseek(f, 0, SEEK_END)) {
    fclose(f);
    return &empty_blob;
  }
  long n = ftell(f);
  rewind(f);
  if (n < 0 || (unsigned long)n > UINT_MAX) {
    fclose(f);
    return &empty_blob;
  }
  char *data = malloc(n ? n : 1);
  if (!data) {
    fclose(f);
    return &empty_blob;
  }
  if (fread(data, 1, n, f) != (size_t)n) {
    free(data);
    fclose(f);
    return &empty_blob;
  }
  fclose(f);
  return hb_blob_create(data, n, HB_MEMORY_MODE_READONLY, data, free);
}
hb_face_t *hb_face_create(hb_blob_t *blob, unsigned index) {
  FT_Library lib;
  FT_Face ft;
  if (FT_Init_FreeType(&lib))
    return NULL;
  if (!blob || FT_New_Memory_Face(lib, (const FT_Byte *)blob->data,
                                  blob->length, index, &ft)) {
    FT_Done_FreeType(lib);
    return NULL;
  }
  hb_face_t *face = hb_ft_face_create_referenced(ft);
  FT_Done_Face(ft);
  if (!face) {
    FT_Done_FreeType(lib);
    return NULL;
  }
  face->library = lib;
  face->blob = hb_blob_reference(blob);
  return face;
}
hb_blob_t *hb_face_reference_blob(hb_face_t *f) {
  return f && f->blob ? hb_blob_reference(f->blob) : hb_blob_get_empty();
}
/* Sorted sparse Unicode sets: small, inspectable, and independent of a font. */
struct hb_set_t {
  unsigned length, capacity;
  hb_codepoint_t *items;
};
hb_set_t *hb_set_create(void) { return calloc(1, sizeof(hb_set_t)); }
void hb_set_destroy(hb_set_t *s) {
  if (s) {
    free(s->items);
    free(s);
  }
}
static unsigned lower(hb_set_t *s, hb_codepoint_t v) {
  unsigned a = 0, b = s->length;
  while (a < b) {
    unsigned m = a + (b - a) / 2;
    if (s->items[m] < v)
      a = m + 1;
    else
      b = m;
  }
  return a;
}
void hb_set_add(hb_set_t *s, hb_codepoint_t v) {
  if (!s || v == HB_SET_VALUE_INVALID)
    return;
  unsigned i = lower(s, v);
  if (i < s->length && s->items[i] == v)
    return;
  if (s->length == s->capacity) {
    unsigned n = s->capacity ? s->capacity * 2 : 64;
    void *p = realloc(s->items, n * sizeof(*s->items));
    if (!p)
      return;
    s->items = p;
    s->capacity = n;
  }
  memmove(s->items + i + 1, s->items + i, (s->length - i) * sizeof(*s->items));
  s->items[i] = v;
  s->length++;
}
void hb_set_del(hb_set_t *s, hb_codepoint_t v) {
  if (!s)
    return;
  unsigned i = lower(s, v);
  if (i < s->length && s->items[i] == v) {
    memmove(s->items + i, s->items + i + 1,
            (s->length - i - 1) * sizeof(*s->items));
    s->length--;
  }
}
hb_bool_t hb_set_has(const hb_set_t *s, hb_codepoint_t v) {
  if (!s)
    return 0;
  unsigned i = lower((hb_set_t *)s, v);
  return i < s->length && s->items[i] == v;
}
hb_codepoint_t hb_set_get_min(const hb_set_t *s) {
  return s && s->length ? s->items[0] : HB_SET_VALUE_INVALID;
}
hb_codepoint_t hb_set_get_max(const hb_set_t *s) {
  return s && s->length ? s->items[s->length - 1] : HB_SET_VALUE_INVALID;
}
hb_bool_t hb_set_next(const hb_set_t *s, hb_codepoint_t *v) {
  if (!s || !v)
    return 0;
  unsigned i = *v == HB_SET_VALUE_INVALID ? 0 : lower((hb_set_t *)s, *v + 1);
  *v = i < s->length ? s->items[i] : HB_SET_VALUE_INVALID;
  return i < s->length;
}
void hb_face_collect_unicodes(hb_face_t *f, hb_set_t *s) {
  if (!f || !f->ft)
    return;
  pthread_mutex_lock(&f->lock);
  FT_UInt glyph;
  FT_ULong c = FT_Get_First_Char(f->ft, &glyph);
  while (glyph) {
    hb_set_add(s, c);
    c = FT_Get_Next_Char(f->ft, c, &glyph);
  }
  pthread_mutex_unlock(&f->lock);
}
hb_font_funcs_t *hb_font_funcs_create(void) {
  hb_font_funcs_t *f = calloc(1, sizeof(*f));
  if (f)
    f->refs = 1;
  return f;
}
hb_font_funcs_t *hb_font_funcs_reference(hb_font_funcs_t *f) {
  if (f)
    atomic_fetch_add(&f->refs, 1);
  return f;
}
void hb_font_funcs_make_immutable(hb_font_funcs_t *f) {
  if (f)
    f->immutable = 1;
}
void hb_font_funcs_destroy(hb_font_funcs_t *f) {
  if (f && atomic_fetch_sub(&f->refs, 1) == 1) {
    if (f->nominal_destroy)
      f->nominal_destroy(f->nominal_data);
    if (f->horizontal_destroy)
      f->horizontal_destroy(f->horizontal_data);
    if (f->vertical_destroy)
      f->vertical_destroy(f->vertical_data);
    if (f->extents_destroy)
      f->extents_destroy(f->extents_data);
    free(f);
  }
}
#define SETTER(api, field, type)                                               \
  void api(hb_font_funcs_t *f, type cb, void *data,                            \
           hb_destroy_func_t destroy) {                                        \
    if (!f || f->immutable) {                                                  \
      if (destroy)                                                             \
        destroy(data);                                                         \
      return;                                                                  \
    }                                                                          \
    if (f->field##_destroy)                                                    \
      f->field##_destroy(f->field##_data);                                     \
    f->field = cb;                                                             \
    f->field##_data = data;                                                    \
    f->field##_destroy = destroy;                                              \
  }
SETTER(hb_font_funcs_set_nominal_glyph_func, nominal,
       hb_font_get_nominal_glyph_func_t)
SETTER(hb_font_funcs_set_glyph_h_advance_func, horizontal,
       hb_font_get_glyph_h_advance_func_t)
SETTER(hb_font_funcs_set_glyph_v_advance_func, vertical,
       hb_font_get_glyph_v_advance_func_t)
SETTER(hb_font_funcs_set_glyph_extents_func, extents,
       hb_font_get_glyph_extents_func_t)
hb_font_t *hb_font_create_sub_font(hb_font_t *p) {
  if (!p)
    return NULL;
  hb_font_t *f = hb_font_create(p->face);
  if (f) {
    f->parent = hb_font_reference(p);
    f->x_scale = p->x_scale;
    f->y_scale = p->y_scale;
  }
  return f;
}
void hb_font_set_funcs(hb_font_t *f, hb_font_funcs_t *funcs, void *data,
                       hb_destroy_func_t destroy) {
  if (!f || f->immutable) {
    if (destroy)
      destroy(data);
    return;
  }
  hb_font_funcs_reference(funcs);
  hb_font_funcs_destroy(f->funcs);
  if (f->data_destroy)
    f->data_destroy(f->font_data);
  f->funcs = funcs;
  f->font_data = data;
  f->data_destroy = destroy;
}
void hb_font_make_immutable(hb_font_t *f) {
  if (f)
    f->immutable = 1;
}
/* Empty singleton has no face and is never freed. */
static hb_face_t empty_face = {.refs = 1};
static hb_font_t empty_font = {
    .refs = 1, .face = &empty_face, .immutable = 1, .immortal = 1};
hb_font_t *hb_font_get_empty(void) { return &empty_font; }
static hb_position_t mini_hb_font_get_glyph_v_advance(hb_font_t *f,
                                                      hb_codepoint_t glyph) {
  if (!f)
    return 0;
  if (f->funcs && f->funcs->vertical)
    return f->funcs->vertical(f, f->font_data, glyph, f->funcs->vertical_data);
  if (f->parent)
    return mini_parent_scale(hb_font_get_glyph_v_advance(f->parent, glyph),
                             f->y_scale, f->parent->y_scale);
  FT_Face ft = f->face->ft;
  if (!ft || !ft->units_per_EM || FT_Load_Glyph(ft, glyph, FT_LOAD_NO_SCALE))
    return 0;
  return -FT_MulDiv(ft->glyph->metrics.vertAdvance, f->y_scale,
                    ft->units_per_EM);
}
void hb_font_get_glyph_advance_for_direction(hb_font_t *f, hb_codepoint_t glyph,
                                             hb_direction_t dir,
                                             hb_position_t *x,
                                             hb_position_t *y) {
  if (x)
    *x = HB_DIRECTION_IS_HORIZONTAL(dir) ? hb_font_get_glyph_h_advance(f, glyph)
                                         : 0;
  if (y)
    *y = HB_DIRECTION_IS_VERTICAL(dir) ? hb_font_get_glyph_v_advance(f, glyph)
                                       : 0;
}
static hb_bool_t mini_hb_font_get_glyph_extents(hb_font_t *f,
                                                hb_codepoint_t glyph,
                                                hb_glyph_extents_t *e) {
  if (!e)
    return 0;
  memset(e, 0, sizeof(*e));
  if (!f)
    return 0;
  if (f->funcs && f->funcs->extents)
    return f->funcs->extents(f, f->font_data, glyph, e, f->funcs->extents_data);
  if (f->parent) {
    hb_bool_t ok = hb_font_get_glyph_extents(f->parent, glyph, e);
    if (ok) {
      e->x_bearing =
          mini_parent_scale(e->x_bearing, f->x_scale, f->parent->x_scale);
      e->width = mini_parent_scale(e->width, f->x_scale, f->parent->x_scale);
      e->y_bearing =
          mini_parent_scale(e->y_bearing, f->y_scale, f->parent->y_scale);
      e->height = mini_parent_scale(e->height, f->y_scale, f->parent->y_scale);
    }
    return ok;
  }
  FT_Face ft = f->face->ft;
  if (!ft || !ft->units_per_EM || FT_Load_Glyph(ft, glyph, FT_LOAD_NO_SCALE))
    return 0;
  FT_Glyph_Metrics *m = &ft->glyph->metrics;
  float xs = (float)f->x_scale / ft->units_per_EM,
        ys = (float)f->y_scale / ft->units_per_EM;
  e->x_bearing = floorf(m->horiBearingX * xs);
  e->y_bearing = floorf(m->horiBearingY * ys);
  e->width = ceilf((m->horiBearingX + m->width) * xs) - e->x_bearing;
  e->height = ceilf((m->horiBearingY - m->height) * ys) - e->y_bearing;
  return 1;
}
static hb_bool_t mini_hb_font_get_h_extents(hb_font_t *f,
                                            hb_font_extents_t *e) {
  if (!e)
    return 0;
  memset(e, 0, sizeof(*e));
  if (!f || !f->face || !f->face->ft || !f->face->ft->units_per_EM)
    return 0;
  FT_Face ft = f->face->ft;
  e->ascender = FT_MulDiv(ft->ascender, f->y_scale, ft->units_per_EM);
  e->descender = FT_MulDiv(ft->descender, f->y_scale, ft->units_per_EM);
  e->line_gap = FT_MulDiv(ft->height - ft->ascender + ft->descender, f->y_scale,
                          ft->units_per_EM);
  return 1;
}
void hb_font_get_extents_for_direction(hb_font_t *f, hb_direction_t d,
                                       hb_font_extents_t *e) {
  if (!e)
    return;
  if (HB_DIRECTION_IS_HORIZONTAL(d) && hb_font_get_h_extents(f, e))
    return;
  memset(e, 0, sizeof(*e));
  int scale = f ? (HB_DIRECTION_IS_HORIZONTAL(d) ? f->y_scale : f->x_scale) : 0;
  e->ascender = scale / 2;
  e->descender = e->ascender - scale;
}
void hb_buffer_set_invisible_glyph(hb_buffer_t *b, hb_codepoint_t glyph) {
  if (b)
    b->invisible = glyph;
}
void hb_tag_to_string(hb_tag_t tag, char *s) {
  for (int i = 0; i < 4; i++)
    s[i] = (char)(tag >> (24 - 8 * i));
}
hb_bool_t hb_feature_from_string(const char *str, int len, hb_feature_t *f) {
  if (!str || !f)
    return 0;
  if (len < 0)
    len = strlen(str);
  if (len > 127)
    return 0;
  char s[128];
  memcpy(s, str, len);
  s[len] = 0;
  char *p = s;
  while (*p == ' ')
    p++;
  unsigned value = 1;
  if (*p == '+' || *p == '-') {
    value = *p != '-';
    p++;
  }
  char quote = 0;
  if (*p == '\'' || *p == '"')
    quote = *p++;
  char tag[4];
  for (int i = 0; i < 4; i++) {
    if (*p < 32 || *p > 126 || *p == '=' || *p == '[')
      return 0;
    tag[i] = *p++;
  }
  if (quote && *p++ != quote)
    return 0;
  f->tag = HB_TAG(tag[0], tag[1], tag[2], tag[3]);
  f->start = 0;
  f->end = UINT_MAX;
  while (*p == ' ')
    p++;
  if (*p == '[') {
    p++;
    char *end;
    if (*p != ':') {
      f->start = strtoul(p, &end, 10);
      if (end == p)
        return 0;
      p = end;
      f->end = f->start + 1;
    }
    if (*p == ':') {
      p++;
      if (*p != ']') {
        f->end = strtoul(p, &end, 10);
        if (end == p)
          return 0;
        p = end;
      } else
        f->end = UINT_MAX;
    }
    if (*p++ != ']')
      return 0;
  }
  while (*p == ' ')
    p++;
  if (*p == '=') {
    p++;
    while (*p == ' ')
      p++;
    if (!strcmp(p, "on"))
      value = 1;
    else if (!strcmp(p, "off"))
      value = 0;
    else {
      char *end;
      value = strtoul(p, &end, 10);
      if (end == p)
        return 0;
      p = end;
      while (*p == ' ')
        p++;
      if (*p)
        return 0;
    }
  } else if (*p)
    return 0;
  f->value = value;
  return 1;
}
/* Metrics read from FreeType's validated SFNT tables; unsupported tags fail. */
hb_bool_t hb_ot_metrics_get_position(hb_font_t *f, hb_ot_metrics_tag_t tag,
                                     hb_position_t *position) {
  if (!f || !f->face || !f->face->ft || !f->face->ft->units_per_EM)
    return 0;
  FT_Face ft = f->face->ft;
  long v;
  int x = 0;
  TT_OS2 *os = FT_Get_Sfnt_Table(ft, ft_sfnt_os2);
  TT_HoriHeader *h = FT_Get_Sfnt_Table(ft, ft_sfnt_hhea);
  TT_Postscript *post = FT_Get_Sfnt_Table(ft, ft_sfnt_post);
  switch (tag) {
  case HB_OT_METRICS_TAG_HORIZONTAL_ASCENDER:
    v = ft->ascender;
    break;
  case HB_OT_METRICS_TAG_HORIZONTAL_DESCENDER:
    v = ft->descender;
    break;
  case HB_OT_METRICS_TAG_HORIZONTAL_LINE_GAP:
    v = ft->height - ft->ascender + ft->descender;
    break;
  case HB_OT_METRICS_TAG_UNDERLINE_SIZE:
    if (!post)
      return 0;
    v = post->underlineThickness;
    break;
  case HB_OT_METRICS_TAG_UNDERLINE_OFFSET:
    if (!post)
      return 0;
    v = post->underlinePosition;
    break;
  case HB_OT_METRICS_TAG_HORIZONTAL_CARET_RISE:
    if (!h)
      return 0;
    v = h->caret_Slope_Rise;
    break;
  case HB_OT_METRICS_TAG_HORIZONTAL_CARET_RUN:
    if (!h)
      return 0;
    v = h->caret_Slope_Run;
    x = 1;
    break;
  case HB_OT_METRICS_TAG_HORIZONTAL_CARET_OFFSET:
    if (!h)
      return 0;
    v = h->caret_Offset;
    x = 1;
    break;
#define OS_METRIC(t, field, horizontal)                                        \
  case t:                                                                      \
    if (!os || os->version == 0xffff)                                          \
      return 0;                                                                \
    v = os->field;                                                             \
    x = horizontal;                                                            \
    break
    OS_METRIC(HB_OT_METRICS_TAG_STRIKEOUT_SIZE, yStrikeoutSize, 0);
    OS_METRIC(HB_OT_METRICS_TAG_STRIKEOUT_OFFSET, yStrikeoutPosition, 0);
    OS_METRIC(HB_OT_METRICS_TAG_SUBSCRIPT_EM_X_SIZE, ySubscriptXSize, 1);
    OS_METRIC(HB_OT_METRICS_TAG_SUBSCRIPT_EM_Y_SIZE, ySubscriptYSize, 0);
    OS_METRIC(HB_OT_METRICS_TAG_SUBSCRIPT_EM_X_OFFSET, ySubscriptXOffset, 1);
    OS_METRIC(HB_OT_METRICS_TAG_SUBSCRIPT_EM_Y_OFFSET, ySubscriptYOffset, 0);
    OS_METRIC(HB_OT_METRICS_TAG_SUPERSCRIPT_EM_X_SIZE, ySuperscriptXSize, 1);
    OS_METRIC(HB_OT_METRICS_TAG_SUPERSCRIPT_EM_Y_SIZE, ySuperscriptYSize, 0);
    OS_METRIC(HB_OT_METRICS_TAG_SUPERSCRIPT_EM_X_OFFSET, ySuperscriptXOffset,
              1);
    OS_METRIC(HB_OT_METRICS_TAG_SUPERSCRIPT_EM_Y_OFFSET, ySuperscriptYOffset,
              0);
  case HB_OT_METRICS_TAG_X_HEIGHT:
    if (!os || os->version < 2 || os->version == 0xffff)
      return 0;
    v = os->sxHeight;
    break;
  case HB_OT_METRICS_TAG_CAP_HEIGHT:
    if (!os || os->version < 2 || os->version == 0xffff)
      return 0;
    v = os->sCapHeight;
    break;
  default:
    return 0;
  }
  if (position)
    *position = FT_MulDiv(v, x ? f->x_scale : f->y_scale, ft->units_per_EM);
  return 1;
}

hb_position_t hb_font_get_glyph_v_advance(hb_font_t *f, hb_codepoint_t glyph) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_position_t result = mini_hb_font_get_glyph_v_advance(f, glyph);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}

hb_bool_t hb_font_get_glyph_extents(hb_font_t *f, hb_codepoint_t glyph,
                                    hb_glyph_extents_t *e) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_bool_t result = mini_hb_font_get_glyph_extents(f, glyph, e);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}

hb_bool_t hb_font_get_h_extents(hb_font_t *f, hb_font_extents_t *e) {
  if (f && f->face && !f->immortal)
    pthread_mutex_lock(&f->face->lock);
  hb_bool_t result = mini_hb_font_get_h_extents(f, e);
  if (f && f->face && !f->immortal)
    pthread_mutex_unlock(&f->face->lock);
  return result;
}
