#include <hb-ft.h>
#include <hb-ot.h>
#include <hb.h>
#include <pthread.h>
#include <stdatomic.h>
struct hb_font_funcs_t {
  atomic_uint refs;
  int immutable;
  hb_font_get_nominal_glyph_func_t nominal;
  void *nominal_data;
  hb_destroy_func_t nominal_destroy;
  hb_font_get_glyph_h_advance_func_t horizontal;
  void *horizontal_data;
  hb_destroy_func_t horizontal_destroy;
  hb_font_get_glyph_v_advance_func_t vertical;
  void *vertical_data;
  hb_destroy_func_t vertical_destroy;
  hb_font_get_glyph_extents_func_t extents;
  void *extents_data;
  hb_destroy_func_t extents_destroy;
};
struct hb_face_t {
  atomic_uint refs;
  FT_Face ft;
  hb_destroy_func_t destroy;
  hb_blob_t *blob;
  FT_Library library;
  pthread_mutex_t lock;
};
struct hb_font_t {
  atomic_uint refs;
  hb_face_t *face;
  int flags;
  int x_scale, y_scale;
  int scale_changed;
  int design_units, immutable, immortal, unsupported;
  hb_font_t *parent;
  hb_font_funcs_t *funcs;
  void *font_data;
  hb_destroy_func_t data_destroy;
  /* Bounded direct-mapped FT advance cache; guarded by face->lock. */
  struct { hb_codepoint_t glyph; hb_position_t advance; int valid; } advances[256];
};
struct hb_buffer_t {
  atomic_uint refs;
  unsigned length, capacity;
  hb_bool_t successful;
  hb_glyph_info_t *info;
  hb_glyph_position_t *pos;
  hb_direction_t direction;
  hb_script_t script;
  hb_language_t language;
  hb_buffer_content_type_t content;
  hb_buffer_flags_t flags;
  hb_buffer_cluster_level_t cluster_level;
  hb_codepoint_t invisible;
  int error; /* MINIHB_* code of the last failed shaping step */
};

/* shape.c: bounded OpenType layout. Errors are explicit; see shape.c. */
enum {
  MINIHB_OK = 0,
  MINIHB_INVALID_INPUT = 1,
  MINIHB_OUT_OF_MEMORY = 2,
  MINIHB_UNSUPPORTED = 3,
  MINIHB_FONT_ERROR = 4
};
int minihb_shape_script(hb_font_t *font, hb_buffer_t *b, unsigned script,
                        unsigned language);
unsigned minihb_ot_script(hb_script_t script);
unsigned minihb_ot_language(hb_language_t language);
unsigned minihb_script_of(unsigned cp);
int minihb_horizontal_codepoint(unsigned cp);
int minihb_default_ignorable(unsigned cp);
/* unicode-data.c: rows of three ints, generated from pinned HarfBuzz. */
extern const int minihb_unicode_emoji_count, minihb_unicode_emoji[];
extern const int minihb_unicode_mirroring_count, minihb_unicode_mirroring[];
extern const int minihb_unicode_properties_count, minihb_unicode_properties[];
extern const int minihb_unicode_decompositions_count, minihb_unicode_decompositions[];
extern const int minihb_unicode_compositions_count, minihb_unicode_compositions[];

static inline hb_position_t mini_parent_scale(hb_position_t v, int to,
                                              int from) {
  return to == from ? v : from ? (hb_position_t)((int64_t)v * to / from) : 0;
}
