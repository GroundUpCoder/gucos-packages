#include <hb.h>
#include <hb-ft.h>
#include <assert.h>
#include <stdio.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_ADVANCES_H
static FT_Stream_IoFunc original_read;
static unsigned read_calls;
static unsigned long counted_read(FT_Stream s, unsigned long off, unsigned char *buf, unsigned long n) {
  read_calls++;
  return original_read(s, off, buf, n);
}
int main(int argc, char **argv) {
  assert(argc == 2);
  FT_Library library;
  FT_Face face;
  assert(!FT_Init_FreeType(&library));
  assert(!FT_New_Face(library, argv[1], 0, &face));
  assert(!FT_Set_Char_Size(face, 0, 12*64, 72, 72));
  hb_font_t *font = hb_ft_font_create_referenced(face);
  assert(font);
  hb_codepoint_t glyph;
  assert(hb_font_get_nominal_glyph(font, 'M', &glyph));
  hb_position_t small = hb_font_get_glyph_h_advance(font, glyph);
  /* An old, pending HB scale must not overwrite a subsequent FT edit. */
  hb_font_set_scale(font, 99*64, 99*64);
  assert(!FT_Set_Char_Size(face, 0, 30*64, 72, 72));
  hb_ft_font_changed(font);
  int x, y;
  hb_font_get_scale(font, &x, &y);
  assert(x == 30*64 && y == 30*64);
  hb_position_t large = hb_font_get_glyph_h_advance(font, glyph);
  assert(large > small*2 && large < small*3);
  assert(face->size->metrics.y_ppem == 30);
  hb_font_t *fresh = hb_ft_font_create_referenced(face);
  assert(hb_font_get_glyph_h_advance(fresh, glyph) == large);
  hb_font_destroy(fresh);
  /* Repeat at non-square dimensions, then shrink back to the original size. */
  assert(!FT_Set_Char_Size(face, 18*64, 24*64, 72, 72));
  hb_ft_font_changed(font);
  hb_font_get_scale(font, &x, &y);
  assert(x == 18*64 && y == 24*64);
  assert(!FT_Set_Char_Size(face, 0, 12*64, 72, 72));
  hb_ft_font_changed(font);
  assert(hb_font_get_glyph_h_advance(font, glyph) == small);
  /* File-backed, hinted outlines force FT stream reads on cache misses.
   * Repeated queries must return identical metrics without any file reads. */
  original_read = face->stream->read;
  assert(original_read);
  face->stream->read = counted_read;
  hb_ft_font_set_load_flags(font, FT_LOAD_DEFAULT);
  read_calls = 0;
  hb_position_t hinted = hb_font_get_glyph_h_advance(font, glyph);
  assert(read_calls > 0);
  unsigned miss_reads = read_calls;
  for (int i = 0; i < 1000; i++)
    assert(hb_font_get_glyph_h_advance(font, glyph) == hinted);
  assert(read_calls == miss_reads);
  printf("MINIHB-ADVANCE-CACHE first=%u repeated=0 queries=1000\n", miss_reads);
  /* Changing load flags and explicit FT refresh each force a fresh query. */
  hb_ft_font_set_load_flags(font, FT_LOAD_NO_HINTING);
  read_calls = 0;
  assert(hb_font_get_glyph_h_advance(font, glyph) == small);
  assert(read_calls > 0);
  hb_ft_font_changed(font);
  read_calls = 0;
  assert(hb_font_get_glyph_h_advance(font, glyph) == small);
  assert(read_calls > 0);
  /* A direct-map collision must never return the other glyph's advance. */
  hb_codepoint_t collision = glyph + 256;
  assert(collision < (unsigned)face->num_glyphs);
  FT_Fixed expected;
  assert(!FT_Get_Advance(face, collision, FT_LOAD_NO_HINTING, &expected));
  assert(hb_font_get_glyph_h_advance(font, collision) == ((expected + 512) >> 10));
  assert(hb_font_get_glyph_h_advance(font, glyph) == small);
  /* HB scale changes, including reflection, also invalidate the cache. */
  hb_font_set_scale(font, -12*64, 12*64);
  assert(hb_ft_hb_font_changed(font));
  assert(hb_font_get_glyph_h_advance(font, glyph) == -small);
  hb_font_set_scale(font, 12*64, 12*64);
  assert(hb_ft_hb_font_changed(font));
  assert(hb_font_get_glyph_h_advance(font, glyph) == small);
  face->stream->read = original_read;
  hb_buffer_t *buffer = hb_buffer_create();
  assert(hb_buffer_get_content_type(buffer) == HB_BUFFER_CONTENT_TYPE_INVALID);
  hb_buffer_set_content_type(buffer, HB_BUFFER_CONTENT_TYPE_UNICODE);
  assert(hb_buffer_get_content_type(buffer) == HB_BUFFER_CONTENT_TYPE_UNICODE);
  hb_buffer_add_utf8(buffer, "M", -1, 0, -1);
  hb_buffer_guess_segment_properties(buffer);
  assert(hb_shape_full(font, buffer, NULL, 0, NULL));
  assert(hb_buffer_get_content_type(buffer) == HB_BUFFER_CONTENT_TYPE_GLYPHS);
  hb_buffer_clear_contents(buffer);
  hb_buffer_set_content_type(buffer, HB_BUFFER_CONTENT_TYPE_UNICODE);
  assert(hb_buffer_get_length(buffer) == 0);
  hb_buffer_destroy(buffer);
  hb_font_destroy(font);
  FT_Done_Face(face);
  FT_Done_FreeType(library);
  puts("MINIHB-TTF-REFRESH-PASS");
  return 0;
}
