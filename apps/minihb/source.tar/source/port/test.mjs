import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('minihb',1200000);
try {
 const result=await runCached(page,`set -e
gucman install minihb
cc /usr/src/minihb/port/ttf-refresh-check.c -I/usr/local/include/minihb -I/usr/local/include/freetype2 -lminihb -lfreetype -lm -lpthread -o /tmp/hb-refresh
/tmp/hb-refresh /usr/src/minihb/port/fonts/NotoSans-Regular.ttf
cc -static /usr/src/minihb/port/ttf-refresh-check.c -I/usr/local/include/minihb -I/usr/local/include/freetype2 -lminihb -lfreetype -lm -lpthread -o /tmp/hb-refresh-static
/tmp/hb-refresh-static /usr/src/minihb/port/fonts/NotoSans-Regular.ttf
cc /usr/src/minihb/port/check.c -I/usr/local/include/minihb -I/usr/local/include/freetype2 -lminihb -lfreetype -lm -lpthread -o /tmp/hb-check
/tmp/hb-check /usr/src/minihb/port/fonts/NotoSans-Regular.ttf > /tmp/hb-check.log
gucman install minihb
echo MINIHB-PACKAGE-PASS
`,{packages:['minihb'],fresh:['minihb']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.equal((log.match(/MINIHB-TTF-REFRESH-PASS/g)||[]).length,2);
 assert.match(log,/MINIHB-PACKAGE-PASS/);assert.deepEqual(errors,[]);
 console.log('PASS installed MiniHB shared/static FreeType refresh and existing shaping consumer');
} finally {await close();}
