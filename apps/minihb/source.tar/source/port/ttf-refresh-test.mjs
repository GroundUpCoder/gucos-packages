import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'../../..');
const mini=path.join(root,'vendor/minihb'),ft=path.join(root,'vendor/freetype');
fs.mkdirSync(path.join(root,'test-results'),{recursive:true});
const out=fs.mkdtempSync(path.join(root,'test-results/minihb-ttf-'));
const cc=process.env.CC||'cc';
const ftSources=JSON.parse(fs.readFileSync(path.join(ft,'lib.json'))).sources;
execFileSync(cc,['-O0','-DFT2_BUILD_LIBRARY','-I'+ft+'/include',...ftSources.map(s=>ft+'/'+s),'-I'+mini+'/include',...['minihb.c','font-api.c','shape.c','unicode-data.c'].map(s=>mini+'/'+s),mini+'/port/ttf-refresh-check.c','-lm','-lpthread','-o',out+'/check'],{stdio:'inherit'});
for(const name of ['ABeeZee-Regular.ttf','SourceCodePro-Regular.otf']){
 const result=execFileSync(out+'/check',[ft+'/port/fonts/'+name],{encoding:'utf8'});
 assert.match(result,/MINIHB-TTF-REFRESH-PASS/);
 console.log(name,result.trim());
}
