// Test-only helper for the upstream oracle: exposes HarfBuzz's internal
// Extended_Pictographic table so the MiniHB copy is generated, not typed.
#include "hb.hh"
#include "hb-unicode-emoji-table.hh"
extern "C" int oracle_extended_pictographic(unsigned c);
extern "C" int oracle_extended_pictographic(unsigned c) {
  return _hb_unicode_is_emoji_Extended_Pictographic(c);
}
