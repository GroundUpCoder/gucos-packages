import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import http from 'node:http';
import {chromium} from 'playwright';
const root=path.resolve(import.meta.dirname,'../../..');
const ctx=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});ctx.self=ctx;
for(const name of ['path','compiler','trampoline','objects','compile'])vm.runInContext(fs.readFileSync(`${root}/src/${name}.js`,'utf8'),ctx);
const files={};
function add(local,guest){for(const e of fs.readdirSync(local,{withFileTypes:true})){const p=path.join(local,e.name),g=guest+'/'+e.name;if(e.isDirectory())add(p,g);else if(/\.(c|h)$/.test(e.name))files[g]=fs.readFileSync(p,'utf8');}}
add(`${root}/vendor/freetype`,'/ft');add(`${root}/vendor/minihb`,'/hb');
const sources=JSON.parse(fs.readFileSync(`${root}/vendor/freetype/lib.json`)).sources.map(s=>'/ft/'+s);
const font=fs.readFileSync(`${root}/vendor/freetype/port/fonts/ABeeZee-Regular.ttf`);
files['/check.c']='static const unsigned char font_bytes[]={'+[...font].join(',')+'};\n'+fs.readFileSync(`${root}/vendor/minihb/port/ttf-refresh-check.c`,'utf8').replace('FT_New_Face(library, argv[1], 0, &face)','FT_New_Memory_Face(library, font_bytes, sizeof(font_bytes), 0, &face)');
console.log('Compiling MiniHB refresh regression with real FreeType and embedded TrueType font');
const result=ctx.compile(files,[...sources,...['minihb.c','font-api.c','shape.c','unicode-data.c'].map(s=>'/hb/'+s),'/check.c'],['/ft/include','/hb/include'],console.error,{defines:['FT2_BUILD_LIBRARY']});
const server=http.createServer((req,res)=>{res.writeHead(200,{'Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Embedder-Policy':'require-corp'});res.end('MiniHB regression');});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({channel:'chromium',headless:true});
try{
 const page=await browser.newPage();
 await page.goto(`http://127.0.0.1:${server.address().port}`);
 await page.addScriptTag({content:fs.readFileSync(`${root}/src/host.js`,'utf8')});
 const code=await page.evaluate(async bytes=>runModule({bytes:new Uint8Array(bytes),args:['check','embedded-font'],blockFsFactory:ctx=>({c:BLOCK_FS.create(new BLOCK_FS.MemoryByteStore(1<<20)).toWasmEnv(ctx)})}),Array.from(result.bytes));
 assert.equal(code,0);
 console.log('PASS browser Wasm: FT resize refresh, stale HB scale, repeated resize and buffer reuse');
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
