/* Shaping differential driver. The same source builds against upstream
 * HarfBuzz (-DUPSTREAM_REFERENCE, C++ link) and against MiniHB, printing one
 * JSON line per case so the two can be compared byte for byte.
 *
 *   oracle --unicode            dump normalization properties (upstream only)
 *   oracle --batch < cases      one case per line:
 *     FONT SIZE DIR SCRIPT LANG LEVEL SHAPER HEX
 *   DIR is ltr or rtl, SCRIPT an ISO 15924 tag or -, LANG a BCP 47 tag or -,
 *   (the unicode dump also needs oracle-emoji.cc, built with the C++ sources)
 *   LEVEL 0 (graphemes) or 1 (characters), SHAPER ot, fallback or default,
 *   HEX the UTF-8 text. Output: {"ok":0|1,"glyphs":[[glyph,cluster,xa,ya,xo,yo],...]}
 */
#include <hb-ft.h>
#include <hb.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef UPSTREAM_REFERENCE
int oracle_extended_pictographic(unsigned c);
static int unicode_dump(void) {
  hb_unicode_funcs_t *u = hb_unicode_funcs_get_default();
  puts("[");
  int first = 1;
  for (unsigned c = 0; c <= 0x10FFFF; c++) {
    hb_codepoint_t a = 0, b = 0, ab = 0;
    int decomposes = hb_unicode_decompose(u, c, &a, &b);
    hb_unicode_general_category_t gc = hb_unicode_general_category(u, c);
    int mark = gc == HB_UNICODE_GENERAL_CATEGORY_SPACING_MARK ||
               gc == HB_UNICODE_GENERAL_CATEGORY_ENCLOSING_MARK ||
               gc == HB_UNICODE_GENERAL_CATEGORY_NON_SPACING_MARK;
    int cc = hb_unicode_combining_class(u, c);
    int emoji = oracle_extended_pictographic(c);
    unsigned mirror = hb_unicode_mirroring(u, c);
    if (!decomposes && !mark && !cc && !emoji && mirror == c)
      continue;
    if (!decomposes)
      a = b = 0;
    int composes = decomposes && hb_unicode_compose(u, a, b, &ab) && ab == c;
    printf("%s[%u,%d,%d,%u,%u,%d,%d,%u]", first ? "" : ",\n", c, cc, mark, a, b,
           composes, emoji, mirror == c ? 0 : mirror);
    first = 0;
  }
  puts("\n]");
  return 0;
}
#endif

static FT_Library library;
static FT_Face face;
static char face_path[1024];

static int open_face(const char *path, int size) {
  if (strcmp(path, face_path)) {
    if (face)
      FT_Done_Face(face);
    face = NULL;
    face_path[0] = 0;
    if (FT_New_Face(library, path, 0, &face))
      return 0;
    strncpy(face_path, path, sizeof face_path - 1);
  }
  return !FT_Set_Pixel_Sizes(face, 0, size);
}

static void print_buffer(hb_buffer_t *buffer, int ok) {
  unsigned count = hb_buffer_get_length(buffer);
  hb_glyph_info_t *info = hb_buffer_get_glyph_infos(buffer, NULL);
  hb_glyph_position_t *pos = ok ? hb_buffer_get_glyph_positions(buffer, NULL) : NULL;
  printf("{\"ok\":%d,\"glyphs\":[", ok);
  for (unsigned i = 0; i < count; i++)
    printf("%s[%u,%u,%d,%d,%d,%d]", i ? "," : "", info[i].codepoint, info[i].cluster,
           pos ? pos[i].x_advance : 0, pos ? pos[i].y_advance : 0,
           pos ? pos[i].x_offset : 0, pos ? pos[i].y_offset : 0);
  puts("]}");
}

static int run_case(char *line) {
  char font[1024], dir[8], script[8], lang[64], shaper[16], hex[65536];
  int size, level;
  hex[0] = 0;
  if (sscanf(line, "%1023s %d %7s %7s %63s %d %15s %65535s", font, &size, dir, script,
             lang, &level, shaper, hex) < 7) {
    puts("{\"ok\":0,\"error\":\"case\"}");
    return 0;
  }
  if (!open_face(font, size)) {
    puts("{\"ok\":0,\"error\":\"font\"}");
    return 0;
  }
  hb_font_t *hb_font = hb_ft_font_create_referenced(face);
  hb_buffer_t *buffer = hb_buffer_create();
  hb_buffer_set_direction(buffer, strcmp(dir, "rtl") ? HB_DIRECTION_LTR : HB_DIRECTION_RTL);
  if (strcmp(script, "-"))
    hb_buffer_set_script(buffer, hb_script_from_string(script, -1));
  if (strcmp(lang, "-"))
    hb_buffer_set_language(buffer, hb_language_from_string(lang, -1));
  hb_buffer_set_cluster_level(buffer, level ? HB_BUFFER_CLUSTER_LEVEL_MONOTONE_CHARACTERS
                                            : HB_BUFFER_CLUSTER_LEVEL_MONOTONE_GRAPHEMES);
  size_t n = strlen(hex) / 2;
  char *text = malloc(n + 1);
  for (size_t i = 0; i < n; i++) {
    unsigned byte;
    sscanf(hex + 2 * i, "%2x", &byte);
    text[i] = (char)byte;
  }
  text[n] = 0;
  hb_buffer_add_utf8(buffer, text, (int)n, 0, (int)n);
  const char *ot[] = {"ot", NULL}, *fallback[] = {"fallback", NULL};
  const char *fallback_first[] = {"fallback", "ot", NULL};
  const char *ot_first[] = {"ot", "fallback", NULL};
  const char *const *shapers = NULL;
  if (!strcmp(shaper, "ot"))
    shapers = ot;
  else if (!strcmp(shaper, "fallback"))
    shapers = fallback;
  else if (!strcmp(shaper, "fallback-first"))
    shapers = fallback_first;
  else if (!strcmp(shaper, "ot-first"))
    shapers = ot_first;
  int ok = hb_shape_full(hb_font, buffer, NULL, 0, shapers);
  print_buffer(buffer, ok);
  free(text);
  hb_buffer_destroy(buffer);
  hb_font_destroy(hb_font);
  return 0;
}

int main(int argc, char **argv) {
#ifdef UPSTREAM_REFERENCE
  if (argc == 2 && !strcmp(argv[1], "--unicode"))
    return unicode_dump();
#endif
  if (argc != 2 || strcmp(argv[1], "--batch")) {
    fprintf(stderr, "usage: oracle --batch < cases\n");
    return 1;
  }
  if (FT_Init_FreeType(&library))
    return 2;
  static char line[140000];
  while (fgets(line, sizeof line, stdin)) {
    size_t n = strlen(line);
    while (n && (line[n - 1] == '\n' || line[n - 1] == '\r'))
      line[--n] = 0;
    if (!n)
      continue;
    run_case(line);
    fflush(stdout);
  }
  if (face)
    FT_Done_Face(face);
  FT_Done_FreeType(library);
  return 0;
}
