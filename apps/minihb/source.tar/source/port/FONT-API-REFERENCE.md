The two `*.font-api.expected` files are stdout from `font-api-check.c` linked
against upstream HarfBuzz 8.3.0 (`src/harfbuzz.cc`, `HAVE_FREETYPE`) and the
same bundled FreeType sources. Inputs are the pinned fonts in
`vendor/freetype/port/fonts`. The upstream archive URL/hash are in
`../ORIGIN.json`. These are font API results, not OpenType shaping expectations.

The test checks all printable ASCII glyph IDs, advances and bounding boxes,
font metrics, complete Unicode coverage iteration, and subfont callbacks and
destructors. Compile with the upstream headers, link the reference implementation,
and pass the font path as the sole argument to regenerate. The browser test
compares the installed MiniHB shared-library output byte for byte.
