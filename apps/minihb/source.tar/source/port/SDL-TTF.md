# SDL_ttf prerequisite increment, 2026-09-30

Upstream SDL_ttf 3.2.2 calls hb_ft_font_changed after changing a FreeType font
size. MiniHB's public upstream header declared this function but its implementation
was missing. Added it for the existing FreeType-backed font path. It refreshes
the HB scale from the face and cancels a pending HB-to-FT scale update. Metrics
and variation data already come from the live FT_Face; MiniHB has no separate
advance cache to invalidate. This does not expand its supported shaping scripts
or add the full HarfBuzz variation model.

Added hb_buffer_set_content_type, the counterpart of the existing getter.
No existing implementation paths were replaced.

Validation executed:

- node vendor/minihb/port/ttf-refresh-test.mjs: PASS with the vendored FreeType
  source, ABeeZee TrueType and SourceCodePro CFF fonts. The same executable also
  passed with the existing NotoSans fixture.
- node vendor/minihb/port/ttf-refresh-wasm.mjs: PASS in Chromium using the actual
  custom C compiler, real FreeType source and an embedded ABeeZee font. Checks
  resizing, repeated and non-square sizes, stale pending HB scale, fresh-font
  advance equivalence, shaping and buffer reuse.
- node tools/package-job.mjs run minihb: BLOCKED before source acceptance by
  missing approved freetype dependency artifact. Run: minihb-v2w6CK.

The new package-local acceptance module will test installed shared/static
libraries and the existing shaping consumer in both source and binary phases.
It has NOT passed those phases yet. The manifest includes its NotoSans fixture
and license. Version 0.1.0-2 distinguishes this candidate from the existing
package recipe; no artifact was promoted or published.

Other SDL_ttf imports absent from this implementation remain:
hb_buffer_get_unicode_funcs, hb_unicode_script and hb_version. SDL_ttf's bounded
MiniHB adaptation can omit Unicode-script introspection and report no upstream
HarfBuzz version. Full Unicode introspection should be a separate capability,
not synthesized from MiniHB's limited shaping-script classifier.
