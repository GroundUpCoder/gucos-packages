#include <hb.h>
#include <hb-ft.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <stdio.h>
#include <assert.h>
#include <string.h>
int main(int argc,char **argv){
 FT_Library ft;FT_Face face;assert(argc==2);
 assert(!FT_Init_FreeType(&ft));assert(!FT_New_Face(ft,argv[1],0,&face));
 const char *strings[]={"Hello, world!","AV office ffi 123"," !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"};
 const char *shapers[]={"fallback",NULL};
 for(int size=9;size<=36;size+=9){
  assert(!FT_Set_Pixel_Sizes(face,0,size));hb_font_t *font=hb_ft_font_create_referenced(face);assert(font);
  for(int scale=0;scale<3;scale++)for(int dir=0;dir<2;dir++)for(int s=0;s<3;s++){
   hb_font_set_scale(font,scale==2?-size*64:scale==1?size*128+17:size*64,size*64);
   hb_ft_hb_font_changed(font);
   hb_buffer_t *buffer=hb_buffer_create();assert(buffer);
   hb_buffer_add_utf8(buffer,strings[s],-1,0,-1);
   hb_buffer_set_direction(buffer,dir?HB_DIRECTION_RTL:HB_DIRECTION_LTR);
   hb_buffer_set_script(buffer,HB_SCRIPT_LATIN);
   hb_buffer_set_language(buffer,hb_language_from_string("en",-1));
   assert(hb_shape_full(font,buffer,NULL,0,shapers));
   unsigned count=hb_buffer_get_length(buffer),n;
   hb_glyph_info_t *info=hb_buffer_get_glyph_infos(buffer,&n);assert(n==count);
   hb_glyph_position_t *pos=hb_buffer_get_glyph_positions(buffer,&n);assert(n==count);
   printf("size=%d scale=%d dir=%d text=%d count=%u\n",size,scale,dir,s,count);
   for(unsigned i=0;i<count;i++)printf("%u %u %d %d %d %d\n",info[i].codepoint,info[i].cluster,pos[i].x_advance,pos[i].y_advance,pos[i].x_offset,pos[i].y_offset);
   hb_buffer_destroy(buffer);
  }
#ifndef UPSTREAM_REFERENCE
  hb_buffer_t *bad=hb_buffer_create();
  hb_buffer_add_utf8(bad,"\xd7\xa9\xd7\x9c",-1,0,-1);hb_buffer_guess_segment_properties(bad);
  assert(!hb_shape_full(font,bad,NULL,0,NULL));
  assert(hb_buffer_get_content_type(bad)==HB_BUFFER_CONTENT_TYPE_UNICODE);
  assert(hb_buffer_get_length(bad)==2);
  hb_buffer_reset(bad);hb_buffer_add_utf8(bad,"abc",-1,0,-1);hb_buffer_guess_segment_properties(bad);
  const char *unsupported[]={"unknown-shaper",NULL};assert(!hb_shape_full(font,bad,NULL,0,unsupported));
  hb_feature_t feature={HB_TAG('k','e','r','n'),0,0,(unsigned)-1};assert(!hb_shape_full(font,bad,&feature,1,NULL));
  hb_buffer_set_direction(bad,HB_DIRECTION_TTB);assert(!hb_shape_full(font,bad,NULL,0,NULL));
  hb_buffer_destroy(bad);
#endif
  hb_font_destroy(font);
 }
 assert(!strcmp(hb_language_to_string(hb_language_from_string("EN_us",-1)),"en-us"));
 assert(hb_language_from_string("EN_us",-1)==hb_language_from_string("en-us",-1));
 FT_Done_Face(face);FT_Done_FreeType(ft);return 0;
}
