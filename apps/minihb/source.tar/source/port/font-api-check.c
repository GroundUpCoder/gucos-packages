#include <assert.h>
#include <hb-ot.h>
#include <hb.h>
#include <stdio.h>
static int destroyed;
static void destroy(void *p) { destroyed += *(int *)p; }
static hb_bool_t nominal(hb_font_t *font, void *parent, hb_codepoint_t c,
                         hb_codepoint_t *g, void *data) {
  return hb_font_get_nominal_glyph(parent, c == 'X' ? 'A' : c, g);
}
static hb_position_t advance(hb_font_t *font, void *parent, hb_codepoint_t g,
                             void *data) {
  return hb_font_get_glyph_h_advance(parent, g) + 7;
}
int main(int argc, char **argv) {
  assert(argc == 2);
  hb_blob_t *blob = hb_blob_create_from_file(argv[1]);
  assert(hb_blob_get_length(blob) > 100);
  hb_face_t *face = hb_face_create(blob, 0);
  hb_blob_destroy(blob);
  assert(face);
  hb_set_t *set = hb_set_create();
  hb_face_collect_unicodes(face, set);
  hb_codepoint_t u = HB_SET_VALUE_INVALID;
  unsigned count = 0, sum = 0;
  while (hb_set_next(set, &u)) {
    count++;
    sum += u;
  }
  printf("coverage %u %u %u %u\n", count, sum, hb_set_get_min(set),
         hb_set_get_max(set));
  assert(hb_set_has(set, 'A'));
  hb_set_del(set, 'A');
  assert(!hb_set_has(set, 'A'));
  hb_set_add(set, 'A');
  assert(hb_set_has(set, 'A'));
  hb_set_destroy(set);
  hb_font_t *font = hb_font_create(face);
  hb_face_destroy(face);
  hb_font_set_scale(font, 22528, 22528);
  hb_font_extents_t e;
  assert(hb_font_get_h_extents(font, &e));
  printf("metrics %d %d %d\n", e.ascender, e.descender, e.line_gap);
  for (int c = 32; c < 127; c++) {
    hb_codepoint_t g;
    hb_glyph_extents_t e;
    assert(hb_font_get_nominal_glyph(font, c, &g));
    assert(hb_font_get_glyph_extents(font, g, &e));
    printf("glyph %d %u %d %d %d %d %d\n", c, g,
           hb_font_get_glyph_h_advance(font, g), e.x_bearing, e.y_bearing,
           e.width, e.height);
  }
  hb_font_t *sub = hb_font_create_sub_font(font);
  hb_font_funcs_t *funcs = hb_font_funcs_create();
  int one = 1;
  hb_font_funcs_set_nominal_glyph_func(funcs, nominal, &one, destroy);
  hb_font_funcs_set_glyph_h_advance_func(funcs, advance, NULL, NULL);
  hb_font_funcs_make_immutable(funcs);
  hb_font_set_funcs(sub, funcs, font, NULL);
  hb_font_funcs_destroy(funcs);
  hb_codepoint_t a, x;
  assert(hb_font_get_nominal_glyph(font, 'A', &a));
  assert(hb_font_get_nominal_glyph(sub, 'X', &x));
  assert(a == x);
  assert(hb_font_get_glyph_h_advance(sub, a) ==
         hb_font_get_glyph_h_advance(font, a) + 7);
  hb_font_destroy(sub);
  assert(destroyed == 1);
  hb_font_destroy(font);
  puts("FONT-API-PASS");
  return 0;
}
