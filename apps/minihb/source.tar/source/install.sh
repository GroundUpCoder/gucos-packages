#!/bin/sh
set -e
stage=$1
cd /usr/src/minihb
mkdir -p "$stage/objects" "$stage/include/minihb" "$stage/pkgconfig"
for source in minihb font-api shape unicode-data; do
  cc -Iinclude -I/usr/local/include/freetype2 -c "$source.c" -o "$stage/objects/$source.o"
done
ar rcs "$stage/libminihb.a" "$stage"/objects/*.o
cc -shared "$stage"/objects/*.o -lfreetype -lm -lpthread -Wl,-soname,libminihb.so -o "$stage/libminihb.so"
cp include/*.h "$stage/include/minihb/"
cp port/minihb.pc "$stage/pkgconfig/"
