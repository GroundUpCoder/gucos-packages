/*
 * Copyright (c) 1998-2004  David Turner and Werner Lemberg
 * Copyright (c) 2004,2007,2009,2010  Red Hat, Inc.
 * Copyright (c) 2011,2012,2013,2017,2018  Google, Inc.
 * Copyright (c) 2018  Ebrahim Byagowi
 *
 *  This is part of HarfBuzz, a text shaping library.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 * IF THE COPYRIGHT HOLDER HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 *
 * THE COPYRIGHT HOLDER SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE COPYRIGHT HOLDER HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Google Author(s): Behdad Esfahbod
 */
/* Bounded horizontal OpenType layout for MiniHB: font-aware normalization,
 * modern Hangul composition, GSUB/GPOS lookups, classic kern, AAT morx/kerx
 * and geometric mark fallback. This is a C translation of the HarfBuzz subset
 * ported to the Small language (apps/harfbuzz in the sibling project), which
 * in turn follows the algorithms of the files listed in ORIGIN.json. It is
 * not a complete OpenType shaper: unsupported table formats and scripts fail
 * explicitly so the caller can fall back, never silently produce wrong output.
 *
 * Return conventions inside this file follow the original port. A lookup
 * returns 0 for no match, a positive input span on success, -1 for malformed
 * tables and -2 for unsupported operations. Work is bounded by a budget.
 * Glyph metadata lives in the private var fields of the buffer entries:
 *   info.var1.u32 bits 0-23: 0 base, 1 mark, 2 hidden ignorable, 3 visible
 *     joiner/selector, 4-6 Hangul L/V/T, 7/8 AAT-deleted, or a space code
 *     point whose width is synthesized; bits 24-31: combining class.
 *   info.var2.u32: ligature id << 16 | component.
 *   info.mask: multiple-substitution sequence id << 16 | index.
 *   pos.var.u32: attachment parent index + 1.
 */
#include "private.h"
#include FT_ADVANCES_H
#include FT_MULTIPLE_MASTERS_H
#include FT_TRUETYPE_TABLES_H
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define TAG(a, b, c, d) HB_TAG(a, b, c, d)
#define VAR1(b, i) ((b)->info[i].var1.u32)
#define VAR2(b, i) ((b)->info[i].var2.u32)
#define KIND(b, i) (VAR1(b, i) & 0xffffffu)
#define PVAR(b, i) ((b)->pos[i].var.u32)

typedef struct {
  const unsigned char *data;
  int length;
} view_t;
typedef struct {
  view_t view;
} table_t;
typedef struct {
  view_t lookups, gdef;
  hb_buffer_t *buffer;
  hb_font_t *font;
  int positioning, budget, flags, mark_set;
  unsigned lig_id, language, script;
  int has_kern;
  long x_mult, y_mult;
  float x_float, y_float;
  int coords[64];
  int axes;
  view_t var_store;
  int merge_graphemes;
} layout_t;

static inline FT_Face face_of(hb_font_t *font) { return font->face->ft; }
static inline int blen(const hb_buffer_t *b) { return (int)b->length; }

/* ---- Bounded table views -------------------------------------------- */

static int view_contains(const view_t *v, int offset, int length) {
  return v && v->length >= 0 && offset >= 0 && length >= 0 &&
         offset <= v->length && length <= v->length - offset &&
         (v->data || length == 0);
}
static int view_slice(const view_t *v, int offset, int length, view_t *out) {
  if (!out || !view_contains(v, offset, length))
    return 0;
  out->data = v->data ? v->data + offset : NULL;
  out->length = length;
  return 1;
}
static int view_u16(const view_t *v, int offset) {
  if (!view_contains(v, offset, 2))
    return -1;
  return (v->data[offset] << 8) | v->data[offset + 1];
}
static int view_u32(const view_t *v, int offset, unsigned *out) {
  if (!out || !view_contains(v, offset, 4))
    return 0;
  *out = ((unsigned)view_u16(v, offset) << 16) | (unsigned)view_u16(v, offset + 2);
  return 1;
}
/* Resolve a relative offset without unchecked addition. Zero (a null OT
 * offset) fails. */
static int view_offset(const view_t *v, int base, unsigned offset, int minimum,
                       view_t *out) {
  if (!out || !view_contains(v, base, 0) || offset == 0 ||
      offset > (unsigned)(v->length - base))
    return 0;
  int start = base + (int)offset;
  return view_contains(v, start, minimum) && view_slice(v, start, v->length - start, out);
}
static int ot_s16(const view_t *v, int at) {
  int n = view_u16(v, at);
  return n >= 32768 ? n - 65536 : n;
}
static int ot_child(const view_t *v, int at, int minimum, view_t *out) {
  int offset = view_u16(v, at);
  return offset > 0 && view_offset(v, 0, (unsigned)offset, minimum, out);
}
static int ot_child32(const view_t *v, int at, int minimum, view_t *out) {
  unsigned offset = 0;
  return view_u32(v, at, &offset) && view_offset(v, 0, offset, minimum, out);
}
static int aat_u32(const view_t *v, int at) {
  unsigned n = 0;
  return view_u32(v, at, &n) && n <= 2147483647u ? (int)n : -1;
}

/* Tables are immutable owned copies. Missing tables and load or allocation
 * failures return NULL. 16 MiB is a deliberate cap. */
static table_t *font_reference_table(hb_font_t *font, unsigned tag) {
  FT_ULong length = 0;
  if (!font || FT_Load_Sfnt_Table(face_of(font), tag, 0, NULL, &length) || length == 0 ||
      length > 16777216)
    return NULL;
  table_t *table = calloc(1, sizeof *table);
  if (!table)
    return NULL;
  unsigned char *data = malloc(length);
  if (!data) {
    free(table);
    return NULL;
  }
  FT_ULong actual = length;
  if (FT_Load_Sfnt_Table(face_of(font), tag, 0, data, &actual) || actual != length) {
    free(data);
    free(table);
    return NULL;
  }
  table->view.data = data;
  table->view.length = (int)length;
  return table;
}
static void table_destroy(table_t *table) {
  if (table) {
    free((void *)table->view.data);
    free(table);
  }
}
/* Distinguish an absent optional table from allocation, load or size
 * failures. Returns 0 with *out NULL when the table is absent. */
static int aat_table(hb_font_t *font, unsigned tag, table_t **out) {
  *out = NULL;
  FT_ULong length = 0;
  int error = FT_Load_Sfnt_Table(face_of(font), tag, 0, NULL, &length);
  if (error == FT_Err_Table_Missing)
    return 0;
  if (error || length == 0 || length > 16777216)
    return MINIHB_FONT_ERROR;
  *out = font_reference_table(font, tag);
  return *out ? 0 : MINIHB_FONT_ERROR;
}

/* Coverage formats 1/2: -1 absent, -2 malformed, otherwise coverage index.
 * Validate all records even if an early record matches. */
static int ot_coverage(const view_t *v, int offset, unsigned glyph) {
  if (!view_contains(v, offset, 4))
    return -2;
  int format = view_u16(v, offset), count = view_u16(v, offset + 2);
  int stride = format == 1 ? 2 : format == 2 ? 6 : 0;
  if (!stride || !view_contains(v, offset + 4, count * stride))
    return -2;
  int previous = -1, index = 0, found = -1;
  for (int i = 0; i < count; i++) {
    int at = offset + 4 + i * stride;
    int start = view_u16(v, at), end = format == 1 ? start : view_u16(v, at + 2);
    if (start <= previous || end < start)
      return -2;
    if (format == 2 && view_u16(v, at + 4) != index)
      return -2;
    if (glyph >= (unsigned)start && glyph <= (unsigned)end)
      found = index + (int)glyph - start;
    index += end - start + 1;
    if (index > 65536)
      return -2;
    previous = end;
  }
  return found;
}
/* ClassDef formats 1/2: absent glyphs are class zero; malformed returns -1. */
static int ot_glyph_class(const view_t *v, int offset, unsigned glyph) {
  if (!view_contains(v, offset, 4))
    return -1;
  int format = view_u16(v, offset);
  if (format == 1) {
    if (!view_contains(v, offset, 6))
      return -1;
    int start = view_u16(v, offset + 2), count = view_u16(v, offset + 4);
    if (count > 65536 - start || !view_contains(v, offset + 6, count * 2))
      return -1;
    return glyph >= (unsigned)start && glyph - (unsigned)start < (unsigned)count
               ? view_u16(v, offset + 6 + ((int)glyph - start) * 2)
               : 0;
  }
  if (format != 2)
    return -1;
  int count = view_u16(v, offset + 2);
  if (!view_contains(v, offset + 4, count * 6))
    return -1;
  int previous = -1, found = 0;
  for (int i = 0; i < count; i++) {
    int at = offset + 4 + i * 6, start = view_u16(v, at), end = view_u16(v, at + 2);
    if (start <= previous || end < start)
      return -1;
    if (glyph >= (unsigned)start && glyph <= (unsigned)end)
      found = view_u16(v, at + 4);
    previous = end;
  }
  return found;
}

/* ---- Unicode data ---------------------------------------------------- */

static int unicode_find(const int *data, int count, unsigned c) {
  int lo = 0, hi = count;
  while (lo < hi) {
    int mid = lo + (hi - lo) / 2;
    if ((unsigned)data[mid * 3] < c)
      lo = mid + 1;
    else
      hi = mid;
  }
  return lo < count && (unsigned)data[lo * 3] == c ? lo * 3 : -1;
}
/* HarfBuzz's modified combining classes, not a general NFC implementation. */
static int unicode_cc(unsigned c) {
  int i = unicode_find(minihb_unicode_properties, minihb_unicode_properties_count, c);
  int cc = i < 0 ? 0 : minihb_unicode_properties[i + 1];
  if (c == 0x1A60 || c == 0xFC6)
    return 254;
  if (c == 0xF39)
    return 127;
  if (cc >= 10 && cc <= 25) {
    static const int hebrew[16] = {22, 15, 16, 17, 23, 18, 19, 20,
                                   21, 14, 24, 12, 25, 13, 10, 11};
    return hebrew[cc - 10];
  }
  if (cc >= 27 && cc <= 32)
    return cc + 1;
  if (cc == 33)
    return 27;
  if (cc == 84)
    return 4;
  if (cc == 91)
    return 5;
  if (cc == 103)
    return 3;
  if (cc == 130)
    return 132;
  if (cc == 132)
    return 131;
  return cc;
}
static int unicode_mark(unsigned c) {
  int i = unicode_find(minihb_unicode_properties, minihb_unicode_properties_count, c);
  return i >= 0 && minihb_unicode_properties[i + 2] != 0;
}
static int unicode_decompose(unsigned c, unsigned *a, unsigned *b) {
  if (c >= 0xAC00 && c <= 0xD7A3) {
    int s = (int)c - 0xAC00, t = s % 28;
    *a = (unsigned)(t ? (int)c - t : 0x1100 + s / 588);
    *b = (unsigned)(t ? 0x11A7 + t : 0x1161 + (s % 588) / 28);
    return 1;
  }
  int i = unicode_find(minihb_unicode_decompositions, minihb_unicode_decompositions_count, c);
  *a = i < 0 ? c : (unsigned)minihb_unicode_decompositions[i + 1];
  *b = i < 0 ? 0 : (unsigned)minihb_unicode_decompositions[i + 2];
  return i >= 0;
}
/* Generic diacritic normalization deliberately does not compose Hangul Jamo. */
static unsigned unicode_compose(unsigned a, unsigned b) {
  const int *t = minihb_unicode_compositions;
  int lo = 0, hi = minihb_unicode_compositions_count;
  while (lo < hi) {
    int mid = lo + (hi - lo) / 2;
    unsigned x = (unsigned)t[mid * 3], y = (unsigned)t[mid * 3 + 1];
    if (x < a || (x == a && y < b))
      lo = mid + 1;
    else
      hi = mid;
  }
  if (lo < minihb_unicode_compositions_count && (unsigned)t[lo * 3] == a &&
      (unsigned)t[lo * 3 + 1] == b)
    return (unsigned)t[lo * 3 + 2];
  return 0;
}
/* Pinned upstream hb_unicode_funcs_t::is_default_ignorable (with exclusions). */
int minihb_default_ignorable(unsigned c) {
  return c == 0xAD || c == 0x34F || c == 0x61C || (c >= 0x17B4 && c <= 0x17B5) ||
         (c >= 0x180B && c <= 0x180F) || (c >= 0x200B && c <= 0x200F) ||
         (c >= 0x202A && c <= 0x202E) || (c >= 0x2060 && c <= 0x206F) ||
         (c >= 0xFE00 && c <= 0xFE0F) || c == 0xFEFF || (c >= 0xFFF0 && c <= 0xFFF8) ||
         (c >= 0x1D173 && c <= 0x1D17A) || (c >= 0xE0000 && c <= 0xE0FFF);
}
static int variation_selector(unsigned c) {
  return (c >= 0xFE00 && c <= 0xFE0F) || (c >= 0xE0100 && c <= 0xE01EF);
}
static int emoji_tag(unsigned cp) { return cp >= 0xE0020 && cp <= 0xE007F; }
static int has_char(hb_font_t *font, unsigned c) {
  hb_codepoint_t glyph = 0;
  return hb_font_get_nominal_glyph(font, c, &glyph);
}

/* ---- Buffer helpers --------------------------------------------------- */

static int buffer_error(hb_buffer_t *b) { return b->error; }
static void set_error(hb_buffer_t *b, int error) {
  if (!b->error)
    b->error = error;
  if (error == MINIHB_OUT_OF_MEMORY)
    b->successful = 0;
}
static hb_buffer_t *scratch_create(void) {
  hb_buffer_t *b = hb_buffer_create();
  return b;
}
/* Append to a scratch buffer; allocation failure records the error. */
static void scratch_add(hb_buffer_t *b, unsigned c, unsigned cluster) {
  if (!b->successful)
    return;
  hb_buffer_add(b, c, cluster);
  if (!b->successful)
    set_error(b, MINIHB_OUT_OF_MEMORY);
}
static int scratch_reserve(hb_buffer_t *b, unsigned n) {
  if (!hb_buffer_pre_allocate(b, n)) {
    set_error(b, MINIHB_OUT_OF_MEMORY);
    return 0;
  }
  return 1;
}

/* HarfBuzz's merge_clusters: everything in [start, end) takes the smallest
 * cluster, and the range grows to whole clusters on both sides first. */
static void merge_clusters(hb_buffer_t *b, int start, int end) {
  int n = blen(b);
  if (end - start < 2 || start < 0 || end > n)
    return;
  unsigned cluster = b->info[start].cluster;
  for (int i = start + 1; i < end; i++)
    if (b->info[i].cluster < cluster)
      cluster = b->info[i].cluster;
  while (end < n && b->info[end - 1].cluster == b->info[end].cluster)
    end++;
  while (start > 0 && b->info[start - 1].cluster == b->info[start].cluster)
    start--;
  for (int i = start; i < end; i++)
    b->info[i].cluster = cluster;
}

/* ---- Font-aware composed-diacritics normalization ------------------- */
/* Adapted from hb-ot-shape-normalize.cc. Fixed Unicode data is acyclic; the
 * depth guard also bounds work if regenerated data is bad. */
static int decompose_into(hb_font_t *font, hb_buffer_t *out, unsigned c, unsigned cluster,
                          int shortest, int depth) {
  if (depth > 32)
    return 0;
  unsigned a = 0, b = 0;
  if (!unicode_decompose(c, &a, &b) || (b && !has_char(font, b)))
    return 0;
  int has_a = has_char(font, a);
  if (!(shortest && has_a) && decompose_into(font, out, a, cluster, shortest, depth + 1)) {
    if (b)
      scratch_add(out, b, cluster);
    return 1;
  }
  if (!has_a)
    return 0;
  scratch_add(out, a, cluster);
  if (b)
    scratch_add(out, b, cluster);
  return 1;
}
/* Leaves Unicode content in the buffer. Transactional: on failure the input
 * arrays remain intact. Decomposed pieces keep their character's cluster;
 * reordering and composition merge clusters exactly as upstream does. */
static int buffer_normalize(hb_font_t *font, hb_buffer_t *b) {
  hb_buffer_t *out = scratch_create();
  int ok = 0;
  if (!out) {
    set_error(b, MINIHB_OUT_OF_MEMORY);
    return 0;
  }
  int all_simple = 1, n = blen(b);
  for (int start = 0; start < n;) {
    int end = start + 1;
    while (end < n && unicode_mark(b->info[end].codepoint))
      end++;
    int simple = end == start + 1;
    if (!simple)
      all_simple = 0;
    int variation = 0;
    for (int i = start; i < end; i++)
      if (variation_selector(b->info[i].codepoint))
        variation = 1;
    for (int i = start; i < end; i++) {
      unsigned c = b->info[i].codepoint;
      unsigned own = b->info[i].cluster;
      if (variation || (simple && has_char(font, c)) ||
          !decompose_into(font, out, c, own, simple, 0)) {
        scratch_add(out, c, own);
        if (out->successful)
          VAR1(out, blen(out) - 1) = VAR1(b, i); /* keeps Hangul feature marks */
      }
    }
    if (buffer_error(out)) {
      set_error(b, buffer_error(out));
      goto done;
    }
    start = end;
  }
  if (!all_simple) {
    /* Stable sorting, with the same 32-mark work limit as pinned HarfBuzz. */
    int m = blen(out);
    for (int i = 0; i < m;) {
      if (unicode_cc(out->info[i].codepoint) == 0) {
        i++;
        continue;
      }
      int end = i + 1;
      while (end < m && unicode_cc(out->info[end].codepoint) != 0)
        end++;
      if (end - i <= 32) {
        for (int j = i + 1; j < end; j++) {
          hb_glyph_info_t value = out->info[j];
          int k = j;
          while (k > i && unicode_cc(out->info[k - 1].codepoint) > unicode_cc(value.codepoint))
            k--;
          if (k == j)
            continue;
          /* A moved mark merges the clusters it crossed, as upstream's sort. */
          merge_clusters(out, k, j + 1);
          value.cluster = out->info[k].cluster;
          for (int m = j; m > k; m--)
            out->info[m] = out->info[m - 1];
          out->info[k] = value;
        }
      }
      i = end;
    }
    int length = m == 0 ? 0 : 1, starter = 0;
    for (int i = 1; i < m; i++) {
      unsigned c = out->info[i].codepoint, composed = 0;
      if (unicode_mark(c) && (starter == length - 1 ||
                              unicode_cc(out->info[length - 1].codepoint) < unicode_cc(c)))
        composed = unicode_compose(out->info[starter].codepoint, c);
      if (composed && has_char(font, composed)) {
        /* merge_out_clusters(starter, out_len) including the consumed mark */
        unsigned cluster = out->info[i].cluster;
        for (int j = starter; j < length; j++)
          if (out->info[j].cluster < cluster)
            cluster = out->info[j].cluster;
        int start = starter;
        while (start > 0 && out->info[start - 1].cluster == out->info[start].cluster)
          start--;
        for (int j = start; j < length; j++)
          out->info[j].cluster = cluster;
        /* merge_out_clusters reaches the end of the out buffer here, so it
         * continues through the pending input sharing the mark's cluster. */
        unsigned tail = out->info[i].cluster;
        for (int j = i + 1; j < m && out->info[j].cluster == tail; j++)
          out->info[j].cluster = cluster;
        out->info[starter].codepoint = composed;
      } else {
        out->info[length] = out->info[i];
        if (unicode_cc(c) == 0)
          starter = length;
        length++;
      }
    }
    out->length = (unsigned)length;
  }
  /* Swap complete arrays only after success. */
  {
    hb_glyph_info_t *old_info = b->info;
    hb_glyph_position_t *old_pos = b->pos;
    b->info = out->info;
    b->pos = out->pos;
    b->capacity = out->capacity;
    b->length = out->length;
    b->content = HB_BUFFER_CONTENT_TYPE_UNICODE;
    out->info = old_info;
    out->pos = old_pos;
    ok = 1;
  }
done:
  hb_buffer_destroy(out);
  return ok;
}

/* ---- Grapheme clusters ----------------------------------------------- */
static int extended_pictographic(unsigned c) {
  const int *t = minihb_unicode_emoji;
  int lo = 0, hi = minihb_unicode_emoji_count;
  while (lo < hi) {
    int mid = lo + (hi - lo) / 2;
    if ((unsigned)t[mid * 3 + 1] < c)
      lo = mid + 1;
    else
      hi = mid;
  }
  return lo < minihb_unicode_emoji_count && (unsigned)t[lo * 3] <= c;
}
static int regional_indicator(unsigned cp) { return cp >= 0x1F1E6 && cp <= 0x1F1FF; }
/* hb_set_unicode_props continuation: marks, emoji modifiers, paired
 * regional indicators, ZWJ with a following pictograph, halfwidth kana
 * voicing marks and tag characters continue the preceding grapheme. cont
 * receives one flag per entry. */
static void continuation_flags(const hb_buffer_t *b, unsigned char *cont) {
  int n = blen(b);
  for (int i = 0; i < n; i++) {
    unsigned cp = b->info[i].codepoint;
    cont[i] = 0;
    if (unicode_mark(cp) || (cp >= 0x1F3FB && cp <= 0x1F3FF) || (cp >= 0xFF9E && cp <= 0xFF9F) || emoji_tag(cp))
      cont[i] = 1;
    else if (i && regional_indicator(cp))
      cont[i] = regional_indicator(b->info[i - 1].codepoint) && !cont[i - 1];
    else if (cp == 0x200D) {
      cont[i] = 1;
      if (i + 1 < n && extended_pictographic(b->info[i + 1].codepoint))
        cont[++i] = 1;
    }
  }
}
static void reverse_range(hb_buffer_t *b, int start, int end) {
  for (int i = start, j = end - 1; i < j; i++, j--) {
    hb_glyph_info_t t = b->info[i];
    b->info[i] = b->info[j];
    b->info[j] = t;
  }
}
/* hb_form_clusters at the monotone-graphemes level, and
 * _hb_ot_layout_reverse_graphemes for runs shaped against their native
 * direction (which merges each grapheme's clusters at the characters
 * level). Returns 0 on allocation failure. */
static int form_clusters(hb_buffer_t *b, int merge, int reverse) {
  int n = blen(b);
  if (!n)
    return 1;
  unsigned char *cont = malloc((size_t)n);
  if (!cont)
    return 0;
  continuation_flags(b, cont);
  int start = 0;
  for (int i = 1; i <= n; i++) {
    if (i < n && cont[i])
      continue;
    if (merge || reverse)
      merge_clusters(b, start, i);
    if (reverse)
      reverse_range(b, start, i);
    start = i;
  }
  if (reverse)
    reverse_range(b, 0, n);
  free(cont);
  return 1;
}
static unsigned mirrored(unsigned c) {
  const int *t = minihb_unicode_mirroring;
  int lo = 0, hi = minihb_unicode_mirroring_count;
  while (lo < hi) {
    int mid = lo + (hi - lo) / 2;
    if ((unsigned)t[mid * 3] < c)
      lo = mid + 1;
    else
      hi = mid;
  }
  return lo < minihb_unicode_mirroring_count && (unsigned)t[lo * 3] == c ? (unsigned)t[lo * 3 + 1] : c;
}

/* ---- Modern Korean --------------------------------------------------- */
/* hb-ot-shaper-hangul.cc preprocess_text for the modern repertoire: font
 * aware LV/LVT composition, decomposition of unsupported syllables, and the
 * ljmo/vjmo/tjmo feature marks (var1 kinds 4, 5, 6). Compositions merge
 * clusters; other groups merge only at the graphemes level. Archaic Jamo
 * and tone-mark reordering require the historical Hangul shaper. */
static int hangul_l(unsigned c) { return c >= 0x1100 && c <= 0x1112; }
static int hangul_v(unsigned c) { return c >= 0x1161 && c <= 0x1175; }
static int hangul_t(unsigned c) { return c >= 0x11A8 && c <= 0x11C2; }
static int modern_hangul(hb_font_t *font, hb_buffer_t *b, int merge_graphemes) {
  hb_buffer_t *out = scratch_create();
  int ok = 0;
  if (!out) {
    set_error(b, MINIHB_OUT_OF_MEMORY);
    return 0;
  }
  int n = blen(b);
  for (int i = 0; i < n; i++) {
    unsigned cp = b->info[i].codepoint, cluster = b->info[i].cluster;
    if (cp >= 0x1100 && cp <= 0x11FF && !(hangul_l(cp) || hangul_v(cp) || hangul_t(cp))) {
      set_error(b, MINIHB_UNSUPPORTED);
      goto done;
    }
    int start = blen(out), consumed = 1;
    if (hangul_l(cp) && i + 1 < n && hangul_v(b->info[i + 1].codepoint)) {
      /* <L,V,T?> */
      unsigned v = b->info[i + 1].codepoint, t = i + 2 < n && hangul_t(b->info[i + 2].codepoint) ? b->info[i + 2].codepoint : 0;
      consumed = t ? 3 : 2;
      unsigned s = 0xAC00 + (cp - 0x1100) * 588 + (v - 0x1161) * 28 + (t ? t - 0x11A7 : 0);
      for (int j = 1; j < consumed; j++)
        if (b->info[i + j].cluster < cluster)
          cluster = b->info[i + j].cluster;
      if (has_char(font, s))
        scratch_add(out, s, cluster);
      else {
        for (int j = 0; j < consumed; j++) {
          scratch_add(out, b->info[i + j].codepoint, b->info[i + j].cluster);
          if (out->successful)
            VAR1(out, start + j) = (unsigned)(4 + j);
        }
        if (merge_graphemes)
          merge_clusters(out, start, blen(out));
      }
      i += consumed - 1;
    } else if (cp >= 0xAC00 && cp <= 0xD7A3) {
      /* <LV>, <LVT> or <LV,T> */
      int has_glyph = has_char(font, cp);
      unsigned index = cp - 0xAC00, tindex = index % 28;
      unsigned next = i + 1 < n ? b->info[i + 1].codepoint : 0;
      if (!tindex && hangul_t(next) && has_char(font, cp + next - 0x11A7)) {
        unsigned nc = b->info[i + 1].cluster;
        scratch_add(out, cp + next - 0x11A7, nc < cluster ? nc : cluster);
        i++;
      } else if (!has_glyph || (!tindex && hangul_t(next))) {
        unsigned l = 0x1100 + index / 588, v = 0x1161 + index % 588 / 28;
        if (has_char(font, l) && has_char(font, v) && (!tindex || has_char(font, 0x11A7 + tindex))) {
          scratch_add(out, l, cluster);
          scratch_add(out, v, cluster);
          if (tindex)
            scratch_add(out, 0x11A7 + tindex, cluster);
          if (has_glyph && !tindex) {
            /* An LV decomposed because of a following T takes that T. */
            scratch_add(out, next, b->info[i + 1].cluster);
            i++;
          }
          for (int j = start; j < blen(out) && out->successful; j++)
            VAR1(out, j) = (unsigned)(4 + j - start);
          if (merge_graphemes)
            merge_clusters(out, start, blen(out));
        } else
          scratch_add(out, cp, cluster);
      } else
        scratch_add(out, cp, cluster);
    } else
      scratch_add(out, cp, cluster);
    if (buffer_error(out) || blen(out) > 65536) {
      set_error(b, buffer_error(out) ? buffer_error(out) : MINIHB_UNSUPPORTED);
      goto done;
    }
  }
  if (!scratch_reserve(b, out->length))
    goto done;
  for (int i = 0; i < blen(out); i++)
    b->info[i] = out->info[i];
  b->length = out->length;
  ok = 1;
done:
  hb_buffer_destroy(out);
  return ok;
}

/* ---- Variable fonts --------------------------------------------------- */
/* Evaluate a reachable ItemVariationStore row. Bounded by the work budget. */
static int var_delta(const view_t *store, int outer, int inner, const int *coords, int axes,
                     int *budget, float *result) {
  *result = 0.0f;
  if (outer == 65535 && inner == 65535)
    return 0;
  if (view_u16(store, 0) != 1)
    return -1;
  int count = view_u16(store, 6);
  view_t regions, data;
  if (outer >= count || !view_contains(store, 8, count * 4) || !ot_child32(store, 2, 4, &regions) ||
      !ot_child32(store, 8 + outer * 4, 6, &data))
    return -1;
  int na = view_u16(&regions, 0), nr = view_u16(&regions, 2);
  if (na != axes || na > 64 || !view_contains(&regions, 4, na * nr * 6))
    return -1;
  int items = view_u16(&data, 0), words = view_u16(&data, 2), n = view_u16(&data, 4);
  int wide = (words & 32768) != 0;
  words &= 32767;
  int stride = (n + words) * (wide ? 2 : 1), start = 6 + 2 * n;
  if (inner >= items || words > n || !view_contains(&data, 6, 2 * n) ||
      (long)items * stride > 16777216L || !view_contains(&data, start, items * stride))
    return -1;
  int at = start + inner * stride;
  for (int i = 0; i < n; i++) {
    int region = view_u16(&data, 6 + 2 * i);
    if (region >= nr || --*budget < 0)
      return -1;
    float scalar = 1.0f;
    for (int j = 0; j < na; j++) {
      if (--*budget < 0)
        return -1;
      int base = 4 + (region * na + j) * 6;
      int lo = ot_s16(&regions, base), peak = ot_s16(&regions, base + 2), hi = ot_s16(&regions, base + 4);
      int value = coords[j]; /* normalized F2DOT14, after avar */
      if (peak == 0 || lo > peak || peak > hi || (lo < 0 && hi > 0))
        continue;
      if (value == peak)
        continue;
      if (value <= lo || value >= hi)
        scalar = 0.0f;
      else if (value < peak)
        scalar *= (float)(value - lo) / (float)(peak - lo);
      else
        scalar *= (float)(hi - value) / (float)(hi - peak);
    }
    int delta = 0;
    if (wide && i < words) {
      unsigned raw = 0;
      view_u32(&data, at, &raw);
      delta = (int)raw;
      at += 4;
    } else if (wide || i < words) {
      delta = ot_s16(&data, at);
      at += 2;
    } else {
      delta = data.data[at++];
      if (delta >= 128)
        delta -= 256;
    }
    *result += scalar * (float)delta;
  }
  return 0;
}
/* First matching FeatureVariations record wins, even with an empty
 * substitution. */
static int var_features(const view_t *table, const int *coords, int axes, int *budget,
                        view_t *substitutions) {
  substitutions->data = NULL;
  substitutions->length = 0;
  int minor = view_u16(table, 2);
  if (view_u16(table, 0) != 1 || minor < 0 || minor > 1)
    return -2;
  if (minor == 0)
    return 0;
  unsigned offset = 0;
  if (!view_u32(table, 10, &offset))
    return -1;
  if (offset == 0)
    return 0;
  view_t variations;
  if (!view_offset(table, 0, offset, 8, &variations) || view_u16(&variations, 0) != 1 ||
      view_u16(&variations, 2) != 0)
    return -1;
  unsigned count = 0;
  view_u32(&variations, 4, &count);
  if (count > 65536 || !view_contains(&variations, 8, (int)count * 8))
    return -1;
  for (int i = 0; i < (int)count; i++) {
    if (--*budget < 0)
      return -1;
    view_t conditions;
    unsigned condition_offset = 0;
    view_u32(&variations, 8 + i * 8, &condition_offset);
    int match = 1;
    if (condition_offset) {
      if (!view_offset(&variations, 0, condition_offset, 2, &conditions))
        return -1;
      int n = view_u16(&conditions, 0);
      if (!view_contains(&conditions, 2, n * 4))
        return -1;
      for (int j = 0; j < n; j++) {
        if (--*budget < 0)
          return -1;
        view_t condition;
        if (!ot_child32(&conditions, 2 + j * 4, 8, &condition))
          return -1;
        if (view_u16(&condition, 0) != 1)
          return -2;
        int axis = view_u16(&condition, 2), lo = ot_s16(&condition, 4), hi = ot_s16(&condition, 6);
        if (axis >= axes || lo > hi)
          return -1;
        if (coords[axis] < lo || coords[axis] > hi)
          match = 0;
      }
    }
    if (match) {
      unsigned substitution_offset = 0;
      view_u32(&variations, 12 + i * 8, &substitution_offset);
      if (substitution_offset == 0)
        return 0;
      if (!ot_child32(&variations, 12 + i * 8, 6, substitutions) ||
          view_u16(substitutions, 0) != 1 || view_u16(substitutions, 2) != 0)
        return -1;
      int n = view_u16(substitutions, 4);
      return view_contains(substitutions, 6, n * 6) ? 0 : -1;
    }
  }
  return 0;
}

/* ---- AAT lookups, state machines, morx, tracking --------------------- */
/* -1 absent, -2 malformed, -3 unsupported. Offsets are relative to v. */
static int aat_lookup(const view_t *v, int glyph, int glyphs, int *budget) {
  int format = view_u16(v, 0);
  if (format < 0)
    return -2;
  if (format == 0) {
    if (!view_contains(v, 2, glyphs * 2))
      return -2;
    return glyph >= 0 && glyph < glyphs ? view_u16(v, 2 + glyph * 2) : -1;
  }
  if (format == 8) {
    int first = view_u16(v, 2), count = view_u16(v, 4);
    if (count < 0 || !view_contains(v, 6, count * 2))
      return -2;
    return glyph >= first && glyph - first < count ? view_u16(v, 6 + (glyph - first) * 2) : -1;
  }
  if (format != 2 && format != 4 && format != 6)
    return -3;
  int size = view_u16(v, 2), count = view_u16(v, 4);
  if (size != (format == 6 ? 4 : 6) || count < 0 || !view_contains(v, 12, count * size))
    return -2;
  for (int i = 0; i < count; i++) {
    if (--*budget < 0)
      return -2;
    int at = 12 + i * size, last = view_u16(v, at), first = format == 6 ? last : view_u16(v, at + 2);
    if (first > last)
      return -2;
    if (glyph < first || glyph > last)
      continue;
    int value = view_u16(v, at + size - 2);
    if (format == 4) {
      value = view_u16(v, value + (glyph - first) * 2);
      if (value < 0)
        return -2;
    }
    return value;
  }
  return -1;
}
static int aat_machine(const view_t *v, hb_buffer_t *b, int type, int glyphs, int *budget) {
  int classes = aat_u32(v, 0), states = aat_u32(v, 8), entries = aat_u32(v, 12);
  view_t class_table;
  if (classes < 4 || classes > 65536 || states < 16 || states > v->length || entries < 16 ||
      entries > v->length || !ot_child32(v, 4, 2, &class_table))
    return -1;
  int extra = aat_u32(v, 16), components = type == 2 ? aat_u32(v, 20) : 0,
      ligatures = type == 2 ? aat_u32(v, 24) : 0;
  if (extra < 0 || extra > v->length || components < 0 || components > v->length ||
      ligatures < 0 || ligatures > v->length)
    return -1;
  int n = blen(b);
  int *stack = malloc((size_t)(n + 1) * sizeof *stack);
  if (!stack) {
    set_error(b, MINIHB_OUT_OF_MEMORY);
    return -2;
  }
  int result = 0;
  int state = 0, index = 0, mark = 0, count = 0, marked = 0;
  while (index <= n) {
    if (--*budget < 0) {
      result = -2;
      goto done;
    }
    int cls = index == n                          ? 0
              : b->info[index].codepoint == 65535 ? 2
                                                  : aat_lookup(&class_table, (int)b->info[index].codepoint, glyphs, budget);
    if (cls == -3) {
      result = -2;
      goto done;
    }
    if (cls == -2) {
      result = -1;
      goto done;
    }
    if (cls == -1)
      cls = 1;
    if (cls >= classes) {
      result = -1;
      goto done;
    }
    long at = (long)states + ((long)state * classes + cls) * 2L;
    if (at > 2147483647L) {
      result = -1;
      goto done;
    }
    int entry = view_u16(v, (int)at), stride = type == 1 ? 8 : 6;
    if (entry < 0 || !view_contains(v, entries + entry * stride, stride)) {
      result = -1;
      goto done;
    }
    at = entries + entry * stride;
    state = view_u16(v, (int)at);
    int flags = view_u16(v, (int)at + 2);
    if (type == 1) {
      if (index < n || marked) {
        for (int j = 0; j < 2; j++) {
          int lookup = view_u16(v, (int)at + 4 + j * 2),
              target = j == 0 ? mark : index < n ? index : n - 1;
          if (lookup == 65535 || target < 0 || target >= n)
            continue;
          view_t substitutions, table;
          if (!view_offset(v, 0, (unsigned)extra, 4, &substitutions) ||
              !ot_child32(&substitutions, lookup * 4, 2, &table)) {
            result = -1;
            goto done;
          }
          int replacement = aat_lookup(&table, (int)b->info[target].codepoint, glyphs, budget);
          if (replacement == -3) {
            result = -2;
            goto done;
          }
          if (replacement == -2) {
            result = -1;
            goto done;
          }
          if (replacement >= 0)
            b->info[target].codepoint = (unsigned)replacement;
        }
      }
      if (flags & 32768) {
        mark = index;
        marked = 1;
      }
    } else {
      if ((flags & 32768) && index < n) {
        if (count > 0 && stack[count - 1] == index)
          count--;
        if (count >= n) {
          result = -2;
          goto done;
        }
        stack[count++] = index;
      }
      if ((flags & 8192) && index < n && count > 0) {
        int action_index = view_u16(v, (int)at + 4), cursor = count, ligature = 0;
        unsigned action = 0;
        do {
          if (--*budget < 0 || cursor == 0 || !view_u32(v, extra + action_index * 4, &action)) {
            result = -1;
            goto done;
          }
          action_index++;
          int target = stack[--cursor];
          int offset = (int)((action & 0x3fffffffu) << 2) >> 2;
          long component = (long)b->info[target].codepoint + offset;
          if (component < 0L || component > 1073741823L) {
            result = -1;
            goto done;
          }
          int value = view_u16(v, components + (int)component * 2);
          if (value < 0 || ligature > 1073741823 - value) {
            result = -1;
            goto done;
          }
          ligature += value;
          if (action & 0xc0000000u) {
            int glyph = view_u16(v, ligatures + ligature * 2);
            if (glyph < 0) {
              result = -1;
              goto done;
            }
            unsigned cluster = b->info[target].cluster, highest = cluster;
            int end = stack[count - 1];
            for (int j = target; j <= end; j++) {
              if (b->info[j].cluster < cluster)
                cluster = b->info[j].cluster;
              if (b->info[j].cluster > highest)
                highest = b->info[j].cluster;
            }
            for (int j = 0; j < n; j++) {
              if (--*budget < 0) {
                result = -2;
                goto done;
              }
              if (b->info[j].cluster >= cluster && b->info[j].cluster <= highest)
                b->info[j].cluster = cluster;
            }
            b->info[target].codepoint = (unsigned)glyph;
            while (count - 1 > cursor) {
              int removed = stack[--count];
              VAR1(b, removed) = KIND(b, removed) == 1 ? 8u : 7u;
              b->info[removed].codepoint = 65535;
            }
          }
        } while (!(action & 0x80000000u));
      }
    }
    if (index == n)
      break;
    if (!(flags & 16384))
      index++;
  }
done:
  free(stack);
  return result;
}
static void aat_reverse(hb_buffer_t *b) {
  int n = blen(b);
  for (int i = 0; i < n / 2; i++) {
    hb_glyph_info_t info = b->info[i];
    b->info[i] = b->info[n - 1 - i];
    b->info[n - 1 - i] = info;
  }
}
/* Optional version-3 glyph-coverage accelerators do not change semantics. */
static int aat_coverage(const view_t *v, int at, int count, int glyphs) {
  if (count < 0 || count > 65536 || !view_contains(v, at, count * 4))
    return -1;
  for (int i = 0; i < count; i++) {
    unsigned offset = 0;
    view_u32(v, at + i * 4, &offset);
    if (offset == 0 || offset == 0xffffffffu)
      continue;
    view_t bits;
    if (!view_offset(v, at, offset, (glyphs + 7) / 8, &bits))
      return -1;
  }
  return 0;
}
static int aat_morx(const view_t *v, hb_buffer_t *b, int glyphs, int *budget) {
  int version = view_u16(v, 0), chains = aat_u32(v, 4), at = 8;
  if ((version != 2 && version != 3) || chains < 0)
    return -2;
  for (int chain = 0; chain < chains; chain++) {
    if (--*budget < 0)
      return -2;
    view_t c;
    int size = aat_u32(v, at + 4);
    if (size < 16 || !view_slice(v, at, size, &c))
      return -1;
    unsigned flags = 0;
    view_u32(&c, 0, &flags);
    int features = aat_u32(&c, 8), subtables = aat_u32(&c, 12);
    if (features < 0 || features > 65536 || subtables < 0 || !view_contains(&c, 16, features * 12))
      return -1;
    int pos = 16 + features * 12;
    for (int sub = 0; sub < subtables; sub++) {
      if (--*budget < 0)
        return -2;
      int length = aat_u32(&c, pos);
      unsigned coverage = 0, mask = 0;
      if (length < 12 || !view_contains(&c, pos, length) || !view_u32(&c, pos + 4, &coverage) ||
          !view_u32(&c, pos + 8, &mask))
        return -1;
      if ((flags & mask) && ((coverage & 0x20000000u) || !(coverage & 0x80000000u))) {
        int type = (int)(coverage & 255), result = 0;
        view_t table;
        view_slice(&c, pos + 12, length - 12, &table);
        int reverse = (coverage & 0x40000000u) != 0;
        if (reverse)
          aat_reverse(b);
        if (type == 4) {
          for (int i = 0; i < blen(b); i++) {
            int value = aat_lookup(&table, (int)b->info[i].codepoint, glyphs, budget);
            if (value == -3 || value == -2) {
              result = value == -3 ? -2 : -1;
              break;
            }
            if (value >= 0)
              b->info[i].codepoint = (unsigned)value;
          }
        } else if (type == 1 || type == 2)
          result = aat_machine(&table, b, type, glyphs, budget);
        else
          result = -2;
        if (reverse)
          aat_reverse(b);
        if (result < 0)
          return result;
      }
      pos += length;
    }
    if (version >= 3 && aat_coverage(&c, pos, subtables, glyphs) < 0)
      return -1;
    at += size;
  }
  return 0;
}
static void aat_remove_deleted(hb_buffer_t *b, int positions) {
  int out = 0, n = blen(b);
  for (int i = 0; i < n; i++)
    if (b->info[i].codepoint != 65535) {
      b->info[out] = b->info[i];
      if (positions)
        b->pos[out] = b->pos[i];
      out++;
    }
  b->length = (unsigned)out;
}
/* ---- OpenType layout -------------------------------------------------- */
/* VariationIndex deltas remain fractional until positioning is rounded. */
static int ot_device(layout_t *c, const view_t *parent, int offset, float *delta) {
  *delta = 0.0f;
  if (offset == 0)
    return 0;
  view_t device;
  if (!view_slice(parent, offset, 6, &device))
    return -1;
  if (view_u16(&device, 4) != 32768)
    return -2;
  int nonzero = 0;
  for (int i = 0; i < c->axes; i++)
    if (c->coords[i] != 0)
      nonzero = 1;
  if (!nonzero)
    return 0; /* HarfBuzz ignores VariationIndex at the default instance. */
  if (c->var_store.length == 0)
    return -1;
  return var_delta(&c->var_store, view_u16(&device, 0), view_u16(&device, 2), c->coords,
                   c->axes, &c->budget, delta);
}
static int ot_round(float value) {
  float shifted = value + 0.5f;
  int n = (int)shifted;
  return shifted < (float)n ? n - 1 : n;
}
static int ot_class(layout_t *c, unsigned glyph) {
  if (c->gdef.length == 0)
    return 0;
  int offset = view_u16(&c->gdef, 4);
  return offset == 0 ? 0 : offset < 0 ? -1 : ot_glyph_class(&c->gdef, offset, glyph);
}
/* Glyph classes fall back to Unicode properties when a font omits GDEF. */
static int ot_info_class(layout_t *c, int index) {
  int gc = ot_class(c, c->buffer->info[index].codepoint);
  if (gc == 0 && (c->gdef.length == 0 || view_u16(&c->gdef, 4) == 0))
    return KIND(c->buffer, index) == 1 ? 3 : 1;
  return gc;
}
/* 0 match candidate, 1 skipped, 2 skipped unless a matcher names the glyph
 * (upstream SKIP_MAYBE for default ignorables), -1 malformed. */
static int ot_skip(layout_t *c, int index) {
  unsigned kind = KIND(c->buffer, index);
  if (kind == 2)
    return 1;
  int gc = ot_info_class(c, index);
  if (gc < 0)
    return -1;
  int maybe = kind == 3 ? 2 : 0;
  if ((gc == 1 && (c->flags & 2)) || (gc == 2 && (c->flags & 4)) || (gc == 3 && (c->flags & 8)))
    return 1;
  if (gc != 3)
    return maybe;
  if (c->flags & 16) {
    if (view_u16(&c->gdef, 2) < 2)
      return -1;
    view_t sets;
    unsigned offset = 0;
    if (!ot_child(&c->gdef, 12, 4, &sets) || view_u16(&sets, 0) != 1)
      return -1;
    int count = view_u16(&sets, 2);
    if (c->mark_set >= count || !view_contains(&sets, 4, count * 4) ||
        !view_u32(&sets, 4 + c->mark_set * 4, &offset) || offset > 2147483647u)
      return -1;
    int coverage = ot_coverage(&sets, (int)offset, c->buffer->info[index].codepoint);
    return coverage == -2 ? -1 : coverage < 0 ? 1 : maybe;
  }
  if (c->flags & 65280) {
    int offset = view_u16(&c->gdef, 10);
    int cls = offset <= 0 ? 0 : ot_glyph_class(&c->gdef, offset, c->buffer->info[index].codepoint);
    return cls < 0 ? -1 : cls != (c->flags >> 8) ? 1 : maybe;
  }
  return maybe;
}
/* What a context or ligature position expects: a glyph id, a class of the
 * ClassDef at offset in v, or membership of the Coverage at offset in v. */
typedef struct {
  int kind;
  const view_t *v;
  int offset, value;
} matcher_t;
/* 1 match, 0 no match, -1 malformed. */
static int matcher_ok(const matcher_t *m, unsigned glyph) {
  if (m->kind == 0)
    return glyph == (unsigned)m->value;
  if (m->kind == 1) {
    int cls = m->offset <= 0 ? -1 : ot_glyph_class(m->v, m->offset, glyph);
    return cls < 0 ? -1 : cls == m->value;
  }
  int coverage = m->offset <= 0 ? -2 : ot_coverage(m->v, m->offset, glyph);
  return coverage == -2 ? -1 : coverage >= 0;
}
/* The skipping iterator: the next glyph in direction step that is a match
 * candidate. A maybe-skipped glyph is taken only when m names it; without a
 * matcher it is skipped. -1 end of buffer, -2 malformed. */
static int ot_next_m(layout_t *c, int index, int step, const matcher_t *m) {
  for (int i = index + step; i >= 0 && i < blen(c->buffer); i += step) {
    if (--c->budget < 0)
      return -2;
    int skip = ot_skip(c, i);
    if (skip < 0)
      return -2;
    if (skip == 1)
      continue;
    if (skip == 2) {
      if (!m)
        continue;
      int ok = matcher_ok(m, c->buffer->info[i].codepoint);
      if (ok < 0)
        return -2;
      if (!ok)
        continue;
    }
    return i;
  }
  return -1;
}
static int ot_next(layout_t *c, int index, int step) { return ot_next_m(c, index, step, NULL); }
/* Match count items of a context section starting after `from` in direction
 * step. For kind 0 and 2 the values or coverage offsets are read from r at
 * `at`; kind 1 reads class values from r and uses class_offset in v.
 * positions receives the matched indices. 1 match, 0 no match, -1 malformed. */
static int ot_match_section(layout_t *c, const view_t *v, const view_t *r, int at, int count, int kind,
                            int class_offset, int from, int step, int *positions) {
  int pos = from;
  for (int j = 0; j < count; j++) {
    int value = view_u16(r, at + j * 2);
    if (value < 0)
      return -1;
    matcher_t m = {kind, v, kind == 1 ? class_offset : value, value};
    if (kind == 2 && value <= 0)
      return -1;
    int next = ot_next_m(c, pos, step, &m);
    if (next == -2)
      return -1;
    if (next < 0)
      return 0;
    int ok = matcher_ok(&m, c->buffer->info[next].codepoint);
    if (ok < 0)
      return -1;
    if (!ok)
      return 0;
    if (positions)
      positions[j] = next;
    pos = next;
  }
  return 1;
}
#define MAX_CONTEXT 64
static int ot_anchor(layout_t *c, const view_t *parent, int at, float *x, float *y) {
  view_t a;
  if (!ot_child(parent, at, 6, &a))
    return -1;
  int format = view_u16(&a, 0);
  /* Unhinted outlines use design coordinates for format 2 as well. */
  if (format == 2 && !view_contains(&a, 0, 8))
    return -1;
  if (format == 3) {
    if (!view_contains(&a, 0, 10))
      return -1;
  } else if (format != 1 && format != 2)
    return -2;
  int ax = view_u16(&a, 2), ay = view_u16(&a, 4);
  *x = (float)(ax >= 32768 ? ax - 65536 : ax);
  *y = (float)(ay >= 32768 ? ay - 65536 : ay);
  if (c->axes) {
    *x *= c->x_float;
    *y *= c->y_float;
  }
  if (format == 3) {
    float dx = 0.0f, dy = 0.0f;
    int result = ot_device(c, &a, view_u16(&a, 6), &dx);
    if (result < 0)
      return result;
    result = ot_device(c, &a, view_u16(&a, 8), &dy);
    if (result < 0)
      return result;
    *x += (float)ot_round(dx * c->x_float);
    *y += (float)ot_round(dy * c->y_float);
  }
  return 1;
}
static int ot_mark(layout_t *c, const view_t *v, int type, int index, int coverage) {
  if (view_u16(v, 0) != 1)
    return -2;
  hb_buffer_t *b = c->buffer;
  int base = index - 1;
  if (type != 6) {
    while (base >= 0) {
      if (--c->budget < 0)
        return -2;
      int gc = ot_info_class(c, base);
      if (gc < 0)
        return -1;
      if (gc != 3 && KIND(b, base) != 2) {
        unsigned metadata = b->info[base].mask;
        int accept = (metadata & 65535u) == 0;
        if (!accept && type == 4)
          accept = base == 0 || ot_info_class(c, base - 1) == 3 || b->info[base - 1].mask + 1u != metadata;
        if (!accept && type == 5) {
          int coverage_offset = view_u16(v, 4);
          int covered = coverage_offset <= 0 ? -2 : ot_coverage(v, coverage_offset, b->info[base].codepoint);
          if (covered == -2)
            return -1;
          accept = covered >= 0;
        }
        if (accept)
          break;
      }
      base--;
    }
  } else {
    base = ot_next(c, index, -1);
    if (base == -2)
      return -1;
    if (base >= 0 && ot_info_class(c, base) != 3)
      return 0;
    if (base >= 0 && VAR2(b, base) != VAR2(b, index))
      return 0;
  }
  if (base < 0)
    return 0;
  int offset = view_u16(v, 4), classes = view_u16(v, 6);
  int bc = offset <= 0 ? -2 : ot_coverage(v, offset, b->info[base].codepoint);
  if (bc == -2 || classes <= 0)
    return -1;
  if (bc < 0)
    return 0;
  view_t marks, bases;
  if (!ot_child(v, 8, 2, &marks) || !ot_child(v, 10, 2, &bases))
    return -1;
  int count = view_u16(&marks, 0), rows = view_u16(&bases, 0);
  if (coverage >= count || !view_contains(&marks, 2, count * 4) || bc >= rows)
    return -1;
  int cls = view_u16(&marks, 2 + coverage * 4);
  if (cls >= classes)
    return -1;
  if (type == 5) {
    view_t lig;
    if (!view_contains(&bases, 2, rows * 2) || !ot_child(&bases, 2 + bc * 2, 2, &lig))
      return -1;
    bases = lig;
    rows = view_u16(&bases, 0);
    if (rows == 0)
      return 0;
    unsigned mark = VAR2(b, index), owner = VAR2(b, base);
    bc = rows - 1;
    if ((mark >> 16) && (mark >> 16) == (owner >> 16) && (mark & 65535u)) {
      int component = (int)(mark & 65535u);
      bc = (component < rows ? component : rows) - 1;
    }
  }
  long bytes = (long)rows * classes * 2L;
  if (bytes > 2147483647L || !view_contains(&bases, 2, (int)bytes))
    return -1;
  int at = 2 + (bc * classes + cls) * 2;
  if (view_u16(&bases, at) == 0)
    return 0;
  float mx = 0.0f, my = 0.0f, bx = 0.0f, by = 0.0f;
  int result = ot_anchor(c, &marks, 4 + coverage * 4, &mx, &my);
  if (result < 0)
    return result;
  result = ot_anchor(c, &bases, at, &bx, &by);
  if (result < 0)
    return result;
  b->pos[index].x_offset = c->axes ? ot_round(bx - mx)
                                   : (int)(((long)(bx - mx) * c->x_mult + 32768L) >> 16);
  b->pos[index].y_offset = (c->axes ? ot_round(by - my)
                                    : (int)(((long)(by - my) * c->y_mult + 32768L) >> 16)) +
                           b->pos[base].y_offset;
  PVAR(b, index) = (unsigned)(base + 1);
  return 1;
}
static int ot_value_size(int format) {
  if (format < 0 || (format & ~255))
    return -1;
  int n = 0;
  for (int bit = 1; bit <= 128; bit <<= 1)
    if (format & bit)
      n += 2;
  return n;
}
static int ot_value(layout_t *c, const view_t *v, const view_t *parent, int at, int format,
                    int index) {
  int size = ot_value_size(format);
  if (size < 0)
    return -2;
  if (!view_contains(v, at, size))
    return -1;
  hb_glyph_position_t *p = c->buffer->pos + index;
  for (int bit = 1; bit <= 8; bit <<= 1)
    if (format & bit) {
      int raw = view_u16(v, at);
      at += 2;
      int signed_value = raw >= 32768 ? raw - 65536 : raw;
      int value = (int)(((long)signed_value * ((bit & 5) ? c->x_mult : c->y_mult) + 32768L) >> 16);
      if (bit == 1)
        p->x_offset += value;
      else if (bit == 2)
        p->y_offset += value;
      else if (bit == 4)
        p->x_advance += value;
      /* Horizontal shaping ignores yAdvance (OpenType ValueRecord contract). */
    }
  for (int bit = 16; bit <= 128; bit <<= 1)
    if (format & bit) {
      float delta = 0.0f;
      int result = ot_device(c, parent, view_u16(v, at), &delta);
      at += 2;
      if (result < 0)
        return result;
      int value = ot_round(delta * ((bit & 80) ? c->x_float : c->y_float));
      if (bit == 16)
        p->x_offset += value;
      else if (bit == 32)
        p->y_offset += value;
      else if (bit == 64)
        p->x_advance += value;
    }
  return 1;
}
static int ot_lookup(layout_t *c, int lookup, int index, int depth);
static int ot_subtable(layout_t *c, const view_t *v, int type, int index, int depth) {
  if (depth > 16 || --c->budget < 0)
    return -2;
  int format = view_u16(v, 0);
  if (format < 0)
    return -1;
  hb_buffer_t *b = c->buffer;
  FT_Face face = face_of(c->font);
  if (type == (c->positioning ? 9 : 7)) {
    unsigned offset = 0;
    int nested = view_u16(v, 2);
    view_t extension;
    if (format != 1 || !view_u32(v, 4, &offset) || !view_offset(v, 0, offset, 2, &extension))
      return -1;
    if (nested == type)
      return -1;
    return ot_subtable(c, &extension, nested, index, depth + 1);
  }
  /* Contextual and chained formats 1/2/3: glyphs, classes or coverages, then
   * invoke referenced lookups at the recorded match positions. Length
   * changing nested actions are rejected unless there is only one action,
   * avoiding stale sequence indices. */
  if (type == (c->positioning ? 8 : 6) || type == (c->positioning ? 7 : 5)) {
    int chained = type == (c->positioning ? 8 : 6);
    int positions[MAX_CONTEXT];
    if (format == 1 || format == 2) {
      int class_at = 4, sets_at = format == 1 ? 4 : chained ? 10 : 6;
      int offset = view_u16(v, 2), sets = view_u16(v, sets_at);
      int coverage = offset <= 0 ? -2 : ot_coverage(v, offset, b->info[index].codepoint);
      if (coverage == -2 || !view_contains(v, sets_at + 2, sets * 2))
        return -1;
      if (coverage < 0)
        return 0;
      if (format == 2) {
        int class_offset = view_u16(v, chained ? 6 : class_at);
        coverage = class_offset <= 0 ? -1 : ot_glyph_class(v, class_offset, b->info[index].codepoint);
        if (coverage < 0)
          return -1;
      }
      if (coverage >= sets)
        return format == 2 ? 0 : -1;
      if (view_u16(v, sets_at + 2 + coverage * 2) == 0)
        return 0;
      view_t set;
      if (!ot_child(v, sets_at + 2 + coverage * 2, 2, &set))
        return -1;
      int rules = view_u16(&set, 0);
      if (!view_contains(&set, 2, rules * 2))
        return -1;
      int kind = format == 2 ? 1 : 0;
      for (int rule = 0; rule < rules; rule++) {
        view_t r;
        if (!ot_child(&set, 2 + rule * 2, 2, &r))
          return -1;
        int at = 0, input_count = 0, actions = -1, matches = 1, result;
        if (chained) {
          int count = view_u16(&r, at);
          at += 2;
          if (count < 0 || !view_contains(&r, at, count * 2))
            return -1;
          result = ot_match_section(c, v, &r, at, count, kind, view_u16(v, class_at), index, -1, NULL);
          if (result < 0)
            return -1;
          matches &= result;
          at += count * 2;
        }
        input_count = view_u16(&r, at);
        at += 2;
        if (!chained) {
          actions = view_u16(&r, at);
          at += 2;
          if (actions < 0)
            return -1;
        }
        if (input_count <= 0)
          return -1;
        if (input_count > MAX_CONTEXT)
          return -2;
        if (!view_contains(&r, at, (input_count - 1) * 2))
          return -1;
        positions[0] = index;
        if (matches) {
          result = ot_match_section(c, v, &r, at, input_count - 1, kind, view_u16(v, class_at + (chained ? 2 : 0)), index, 1, positions + 1);
          if (result < 0)
            return -1;
          matches &= result;
        }
        at += (input_count - 1) * 2;
        if (chained) {
          int count = view_u16(&r, at);
          at += 2;
          if (count < 0 || !view_contains(&r, at, count * 2))
            return -1;
          if (matches) {
            result = ot_match_section(c, v, &r, at, count, kind, view_u16(v, class_at + 4), positions[input_count - 1], 1, NULL);
            if (result < 0)
              return -1;
            matches &= result;
          }
          at += count * 2;
          actions = view_u16(&r, at);
          at += 2;
        }
        if (actions < 0 || !view_contains(&r, at, actions * 4))
          return -1;
        for (int j = 0; j < actions; j++)
          if (view_u16(&r, at + j * 4) >= input_count)
            return -1;
        if (!matches)
          continue;
        int end_index = positions[input_count - 1], old_length = blen(b);
        for (int j = 0; j < actions; j++) {
          result = ot_lookup(c, view_u16(&r, at + j * 4 + 2), positions[view_u16(&r, at + j * 4)], depth + 1);
          if (result < 0)
            return result;
          if (blen(b) != old_length && actions > 1)
            return -2;
        }
        return end_index - index + 1 + blen(b) - old_length;
      }
      return 0;
    }
    if (format != 3)
      return -2;
    int at = 2, input_count = 0, actions = -1, matches = 1, result;
    if (chained) {
      int count = view_u16(v, at);
      at += 2;
      if (count < 0 || !view_contains(v, at, count * 2))
        return -1;
      result = ot_match_section(c, v, v, at, count, 2, 0, index, -1, NULL);
      if (result < 0)
        return -1;
      matches &= result;
      at += count * 2;
    }
    input_count = view_u16(v, at);
    at += 2;
    if (!chained) {
      actions = view_u16(v, at);
      at += 2;
      if (actions < 0)
        return -1;
    }
    if (input_count <= 0)
      return -1;
    if (input_count > MAX_CONTEXT)
      return -2;
    if (!view_contains(v, at, input_count * 2))
      return -1;
    {
      /* The first input coverage applies to the current glyph itself. */
      int first = view_u16(v, at);
      int coverage = first <= 0 ? -2 : ot_coverage(v, first, b->info[index].codepoint);
      if (coverage == -2)
        return -1;
      if (coverage < 0)
        matches = 0;
    }
    positions[0] = index;
    if (matches) {
      result = ot_match_section(c, v, v, at + 2, input_count - 1, 2, 0, index, 1, positions + 1);
      if (result < 0)
        return -1;
      matches &= result;
    }
    at += input_count * 2;
    if (chained) {
      int count = view_u16(v, at);
      at += 2;
      if (count < 0 || !view_contains(v, at, count * 2))
        return -1;
      if (matches) {
        result = ot_match_section(c, v, v, at, count, 2, 0, positions[input_count - 1], 1, NULL);
        if (result < 0)
          return -1;
        matches &= result;
      }
      at += count * 2;
      actions = view_u16(v, at);
      at += 2;
    }
    if (actions < 0 || !view_contains(v, at, actions * 4))
      return -1;
    for (int j = 0; j < actions; j++)
      if (view_u16(v, at + j * 4) >= input_count)
        return -1;
    if (!matches)
      return 0;
    int end_index = positions[input_count - 1], old_length = blen(b);
    for (int j = 0; j < actions; j++) {
      result = ot_lookup(c, view_u16(v, at + j * 4 + 2), positions[view_u16(v, at + j * 4)], depth + 1);
      if (result < 0)
        return result;
      if (blen(b) != old_length && actions > 1)
        return -2;
    }
    return end_index - index + 1 + blen(b) - old_length;
  }
  int coverage_offset = view_u16(v, 2);
  if (coverage_offset <= 0)
    return -1;
  int coverage = ot_coverage(v, coverage_offset, b->info[index].codepoint);
  if (coverage == -2)
    return -1;
  if (coverage < 0)
    return 0;
  if (!c->positioning && type == 1) {
    int value = view_u16(v, 4);
    if (value < 0)
      return -1;
    if (format == 1)
      value = ((int)b->info[index].codepoint + value) & 65535;
    else if (format == 2) {
      if (coverage >= value || !view_contains(v, 6, value * 2))
        return -1;
      value = view_u16(v, 6 + coverage * 2);
    } else
      return -2;
    if (value >= face->num_glyphs)
      return -1;
    if (ot_class(c, (unsigned)value) < 0)
      return -1;
    b->info[index].codepoint = (unsigned)value;
    return 1;
  }
  if (!c->positioning && (type == 2 || type == 4)) {
    int count = view_u16(v, 4);
    view_t set;
    if (format != 1)
      return -2;
    if (coverage >= count || !view_contains(v, 6, count * 2) || !ot_child(v, 6 + coverage * 2, 2, &set))
      return -1;
    int n = view_u16(&set, 0);
    if (!view_contains(&set, 2, n * 2))
      return -1;
    if (type == 2) {
      if (n == 0)
        return -2;
      if (n > 65536 - blen(b))
        return -2;
      for (int j = 0; j < n; j++) {
        int glyph = view_u16(&set, 2 + j * 2);
        if (glyph >= face->num_glyphs || ot_class(c, (unsigned)glyph) < 0)
          return -1;
      }
      if (!scratch_reserve(b, (unsigned)(blen(b) + n - 1)))
        return -2;
      for (int j = blen(b) - 1; j > index; j--)
        b->info[j + n - 1] = b->info[j];
      hb_glyph_info_t original = b->info[index];
      if (c->lig_id >= 65535u)
        return -2;
      unsigned sequence = ++c->lig_id;
      for (int j = 0; j < n; j++) {
        b->info[index + j] = original;
        b->info[index + j].codepoint = (unsigned)view_u16(&set, 2 + j * 2);
        b->info[index + j].mask = (sequence << 16) | (unsigned)j;
      }
      b->length += (unsigned)(n - 1);
      return n;
    }
    for (int j = 0; j < n; j++) {
      view_t lig;
      if (!ot_child(&set, 2 + j * 2, 4, &lig))
        return -1;
      int glyph = view_u16(&lig, 0), components = view_u16(&lig, 2);
      if (glyph >= face->num_glyphs || components < 2 || !view_contains(&lig, 4, (components - 1) * 2))
        return -1;
      if (components > MAX_CONTEXT)
        return -2;
      int matches = 1, last = index, positions[MAX_CONTEXT];
      positions[0] = index;
      for (int k = 1; k < components; k++) {
        matcher_t m = {0, NULL, 0, view_u16(&lig, 2 + k * 2)};
        last = ot_next_m(c, last, 1, &m);
        if (last == -2)
          return -1;
        if (last < 0 || b->info[last].codepoint != (unsigned)m.value) {
          matches = 0;
          break;
        }
        positions[k] = last;
      }
      if (!matches)
        continue;
      /* Nested ligatures need component remapping for retained marks.
       * Diagnose this bounded implementation's unsupported case before
       * mutation. */
      for (int k = index; k <= last; k++)
        if (VAR2(b, k) != 0 && ot_info_class(c, k) != 3)
          return -2;
      if (c->lig_id >= 65535u)
        return -2;
      unsigned id = ++c->lig_id;
      merge_clusters(b, index, last + 1);
      unsigned cluster = b->info[index].cluster;
      int component = 1, out = index + 1;
      for (int k = index + 1; k <= last; k++) {
        if (component < components && k == positions[component]) {
          component++;
          continue;
        }
        b->info[out] = b->info[k];
        b->info[out].cluster = cluster;
        VAR2(b, out) = (id << 16) | (unsigned)component;
        out++;
      }
      b->info[index].cluster = cluster;
      b->info[index].codepoint = (unsigned)glyph;
      VAR1(b, index) = 0;
      VAR2(b, index) = (id << 16) | (unsigned)components;
      for (int k = last + 1; k < blen(b); k++)
        b->info[out++] = b->info[k];
      b->length = (unsigned)out;
      return 1;
    }
    return 0;
  }
  if (c->positioning && type >= 4 && type <= 6)
    return ot_mark(c, v, type, index, coverage);
  if (c->positioning && type == 1) {
    int value_format = view_u16(v, 4), size = ot_value_size(value_format);
    if (size < 0)
      return -2;
    int at = 6;
    if (format == 2) {
      int count = view_u16(v, 6);
      if (coverage >= count || !view_contains(v, 8, count * size))
        return -1;
      at = 8 + coverage * size;
    } else if (format != 1)
      return -2;
    return ot_value(c, v, v, at, value_format, index);
  }
  if (c->positioning && type == 2) {
    int f1 = view_u16(v, 4), f2 = view_u16(v, 6);
    int s1 = ot_value_size(f1), s2 = ot_value_size(f2);
    if (s1 < 0 || s2 < 0)
      return -2;
    int next = ot_next(c, index, 1);
    if (next == -2)
      return -1;
    if (next < 0)
      return 0;
    view_t data = *v;
    int at = -1;
    if (format == 1) {
      int count = view_u16(v, 8);
      if (coverage >= count || !view_contains(v, 10, count * 2) || !ot_child(v, 10 + coverage * 2, 2, &data))
        return -1;
      int pairs = view_u16(&data, 0), stride = 2 + s1 + s2, previous = -1;
      if (!view_contains(&data, 2, pairs * stride))
        return -1;
      for (int j = 0; j < pairs; j++) {
        int glyph = view_u16(&data, 2 + j * stride);
        if (glyph <= previous)
          return -1;
        previous = glyph;
        if (b->info[next].codepoint == (unsigned)glyph)
          at = 4 + j * stride;
      }
      if (at < 0)
        return 0;
    } else if (format == 2) {
      int o1 = view_u16(v, 8), o2 = view_u16(v, 10);
      int n1 = view_u16(v, 12), n2 = view_u16(v, 14);
      int a = o1 <= 0 ? -1 : ot_glyph_class(v, o1, b->info[index].codepoint);
      int d = o2 <= 0 ? -1 : ot_glyph_class(v, o2, b->info[next].codepoint);
      long length = (long)n1 * n2 * (s1 + s2);
      if (a < 0 || d < 0 || a >= n1 || d >= n2 || length > 2147483647L || !view_contains(v, 16, (int)length))
        return -1;
      at = 16 + (a * n2 + d) * (s1 + s2);
    } else
      return -2;
    int result = ot_value(c, &data, &data, at, f1, index);
    if (result < 0)
      return result;
    result = ot_value(c, &data, &data, at + s1, f2, next);
    return result < 0 ? result : f2 == 0 ? 1 : next - index + 1;
  }
  return -2;
}
static int ot_lookup(layout_t *c, int lookup, int index, int depth) {
  if (depth > 16 || --c->budget < 0)
    return -2;
  if (index < 0 || index >= blen(c->buffer))
    return -1;
  int count = view_u16(&c->lookups, 0);
  view_t view;
  if (lookup < 0 || lookup >= count || !view_contains(&c->lookups, 2, count * 2) ||
      !ot_child(&c->lookups, 2 + lookup * 2, 6, &view))
    return -1;
  int type = view_u16(&view, 0), flags = view_u16(&view, 2), n = view_u16(&view, 4);
  if (flags & 224)
    return -2;
  if (!view_contains(&view, 6, n * 2 + ((flags & 16) ? 2 : 0)))
    return -1;
  int old_flags = c->flags, old_set = c->mark_set, result = 0;
  c->flags = flags;
  c->mark_set = (flags & 16) ? view_u16(&view, 6 + n * 2) : 0;
  int skip = ot_skip(c, index);
  if (skip < 0)
    result = -1;
  else if (skip == 0) {
    for (int i = 0; i < n; i++) {
      view_t sub;
      if (!ot_child(&view, 6 + i * 2, 2, &sub)) {
        result = -1;
        break;
      }
      result = ot_subtable(c, &sub, type, index, depth);
      if (result != 0)
        break;
    }
  }
  c->flags = old_flags;
  c->mark_set = old_set;
  return result;
}
/* Script/default LangSys -> features -> deduplicated lookup order. Latin
 * falls back to DFLT. Required features are included with the first stage. */
static int ot_apply(layout_t *c, const view_t *table, int stage) {
  if (table->length == 0)
    return 0;
  view_t substitutions;
  int variation_result = var_features(table, c->coords, c->axes, &c->budget, &substitutions);
  if (variation_result < 0)
    return variation_result;
  view_t scripts, features, script, lang;
  if (!ot_child(table, 4, 2, &scripts) || !ot_child(table, 6, 2, &features) ||
      !ot_child(table, 8, 2, &c->lookups))
    return -1;
  int count = view_u16(&scripts, 0), chosen = -1, fallback = -1;
  if (!view_contains(&scripts, 2, count * 6))
    return -1;
  for (int i = 0; i < count; i++) {
    unsigned tag = 0;
    view_u32(&scripts, 2 + i * 6, &tag);
    if (tag == c->script)
      chosen = i;
    if (tag == TAG('D', 'F', 'L', 'T'))
      fallback = i;
  }
  if (chosen < 0)
    chosen = fallback;
  if (chosen < 0)
    return 0;
  if (!ot_child(&scripts, 6 + chosen * 6, 4, &script))
    return -1;
  int lang_at = 0, languages = view_u16(&script, 2);
  if (!view_contains(&script, 4, languages * 6))
    return -1;
  for (int i = 0; i < languages; i++) {
    unsigned tag = 0;
    view_u32(&script, 4 + i * 6, &tag);
    if (tag == c->language)
      lang_at = 8 + i * 6;
  }
  if (view_u16(&script, lang_at) == 0)
    return 0;
  if (!ot_child(&script, lang_at, 6, &lang))
    return -1;
  if (view_u16(&lang, 0) != 0)
    return -1;
  int required = view_u16(&lang, 2), feature_count = view_u16(&lang, 4);
  int total = view_u16(&features, 0), lookups = view_u16(&c->lookups, 0);
  if (!view_contains(&lang, 6, feature_count * 2) || !view_contains(&features, 2, total * 6) ||
      !view_contains(&c->lookups, 2, lookups * 2))
    return -1;
  unsigned char *selected = calloc((size_t)lookups + 1, 1);
  if (!selected) {
    set_error(c->buffer, MINIHB_OUT_OF_MEMORY);
    return -2;
  }
  int result = 0;
  int hangul = c->script == TAG('h', 'a', 'n', 'g');
  for (int i = -1; i < feature_count; i++) {
    int feature = i == -1 ? required : view_u16(&lang, 6 + i * 2);
    if (i == -1 && feature == 65535)
      continue;
    if (feature >= total) {
      result = -1;
      goto done;
    }
    unsigned tag = 0;
    view_u32(&features, 2 + feature * 6, &tag);
    int use = stage == 0   ? tag == TAG('c', 'c', 'm', 'p') || tag == TAG('l', 'o', 'c', 'l') || i == -1
              : stage == 1 ? tag == TAG('c', 'a', 'l', 't') || tag == TAG('r', 'l', 'i', 'g') ||
                                 tag == TAG('l', 'i', 'g', 'a') || tag == TAG('c', 'l', 'i', 'g')
                           : tag == TAG('k', 'e', 'r', 'n') || tag == TAG('m', 'a', 'r', 'k') ||
                                 tag == TAG('m', 'k', 'm', 'k') || i == -1;
    int jamo = hangul && stage == 1
                   ? (tag == TAG('l', 'j', 'm', 'o') ? 2 : tag == TAG('v', 'j', 'm', 'o') ? 4
                                                       : tag == TAG('t', 'j', 'm', 'o') ? 8 : 0)
                   : 0;
    if (!use && !jamo)
      continue;
    if (stage == 2 && tag == TAG('k', 'e', 'r', 'n'))
      c->has_kern = 1;
    view_t feature_view;
    if (!ot_child(&features, 6 + feature * 6, 4, &feature_view)) {
      result = -1;
      goto done;
    }
    if (substitutions.length) {
      int n = view_u16(&substitutions, 4);
      for (int k = 0; k < n; k++) {
        if (--c->budget < 0) {
          result = -2;
          goto done;
        }
        if (view_u16(&substitutions, 6 + k * 6) == feature) {
          if (!ot_child32(&substitutions, 8 + k * 6, 4, &feature_view)) {
            result = -1;
            goto done;
          }
          break;
        }
      }
    }
    int n = view_u16(&feature_view, 2);
    if (!view_contains(&feature_view, 4, n * 2)) {
      result = -1;
      goto done;
    }
    for (int j = 0; j < n; j++) {
      int lookup = view_u16(&feature_view, 4 + j * 2);
      if (lookup >= lookups) {
        result = -1;
        goto done;
      }
      selected[lookup] |= (unsigned char)(jamo ? jamo : tag == TAG('c', 'a', 'l', 't') && hangul ? 16 : 1);
    }
  }
  for (int i = 0; i < lookups; i++)
    if (selected[i]) {
      for (int j = 0; j < blen(c->buffer);) {
        unsigned kind = KIND(c->buffer, j);
        int mask = selected[i];
        if (!(mask & 1) && !((mask & 16) && (kind < 4 || kind > 6)) &&
            !(kind >= 4 && kind <= 6 && (mask & (2 << ((int)kind - 4))))) {
          j++;
          continue;
        }
        int r = ot_lookup(c, i, j, 0);
        if (r < 0) {
          result = r;
          goto done;
        }
        j += r == 0 ? 1 : r;
      }
    }
done:
  free(selected);
  return result;
}
/* Horizontal kern v0/v1 format 0 and kerx v2/v3 formats 0/2. State-machine,
 * cross-stream and variation kerning remain unsupported. */
static int aat_kern(layout_t *c, const view_t *v, int extended) {
  int apple = extended || (view_u16(v, 0) == 1 && view_u16(v, 2) == 0);
  if (extended && view_u16(v, 0) != 2 && view_u16(v, 0) != 3)
    return -2;
  if (!apple && view_u16(v, 0) != 0)
    return -2;
  int count = apple ? aat_u32(v, 4) : view_u16(v, 2), at = apple ? 8 : 4;
  if (count < 0)
    return -1;
  hb_buffer_t *b = c->buffer;
  int glyphs = (int)face_of(c->font)->num_glyphs;
  for (int t = 0; t < count; t++) {
    int header = extended ? 12 : apple ? 8 : 6;
    int size = apple ? aat_u32(v, at) : view_u16(v, at + 2), coverage = view_u16(v, at + 4);
    if (size < header || !view_contains(v, at, size))
      return -1;
    if (apple ? (coverage & 32768) != 0 : (coverage & 1) == 0) {
      at += size;
      continue;
    }
    int format = extended ? view_u16(v, at + 6) : 0;
    if (coverage != (apple ? 0 : 1) || (format != 0 && format != 2) ||
        (extended && aat_u32(v, at + 8) != 0))
      return -2;
    view_t table;
    if (!view_slice(v, at, size, &table))
      return -1;
    if (format == 2) {
      view_t left, right;
      int array = aat_u32(&table, 24);
      if (array < 28 || array > table.length || !ot_child32(&table, 16, 2, &left) ||
          !ot_child32(&table, 20, 2, &right))
        return -1;
      c->flags = 8;
      for (int i = 0; i < blen(b); i++) {
        int skip = ot_skip(c, i);
        if (skip < 0)
          return -1;
        if (skip != 0)
          continue;
        int next = ot_next(c, i, 1);
        if (next == -2)
          return -1;
        if (next < 0)
          break;
        int l = aat_lookup(&left, (int)b->info[i].codepoint, glyphs, &c->budget);
        int r = aat_lookup(&right, (int)b->info[next].codepoint, glyphs, &c->budget);
        if (l == -3 || r == -3)
          return -2;
        if (l == -2 || r == -2)
          return -1;
        /* Missing AAT class entries belong to class zero, including
         * morx tombstones retained until positioning is complete. */
        if (l < 0) l = 0;
        if (r < 0) r = 0;
        int raw = view_u16(&table, array + (l + r) * 2);
        if (raw < 0)
          continue; /* Native ignores out-of-range pair entries. */
        int value = (int)(((long)(raw >= 32768 ? raw - 65536 : raw) * c->x_mult + 32768L) >> 16);
        int first = value >> 1, second = value - first;
        b->pos[i].x_advance += first;
        b->pos[next].x_advance += second;
        b->pos[next].x_offset += second;
      }
      c->flags = 0;
      at += size;
      continue;
    }
    int records = header + (extended ? 16 : 8),
        pairs = extended ? aat_u32(&table, header) : view_u16(&table, header);
    if (pairs < 0 || pairs > 1000000 || !view_contains(&table, records, pairs * 6))
      return -1;
    unsigned previous = 0;
    for (int j = 0; j < pairs; j++) {
      unsigned key = 0;
      view_u32(&table, records + j * 6, &key);
      if (j > 0 && key < previous)
        return -1;
      if (j > 0 && key == previous &&
          view_u16(&table, records + j * 6 + 4) != view_u16(&table, records + (j - 1) * 6 + 4))
        return -2;
      previous = key;
    }
    c->flags = 8;
    for (int i = 0; i < blen(b); i++) {
      int skip = ot_skip(c, i);
      if (skip < 0)
        return -1;
      if (skip != 0)
        continue;
      int next = ot_next(c, i, 1);
      if (next == -2)
        return -1;
      if (next < 0)
        break;
      unsigned key = (b->info[i].codepoint << 16) | b->info[next].codepoint;
      int lo = 0, hi = pairs;
      while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        unsigned candidate = 0;
        view_u32(&table, records + mid * 6, &candidate);
        if (candidate < key)
          lo = mid + 1;
        else
          hi = mid;
      }
      unsigned found = 0;
      if (lo == pairs || !view_u32(&table, records + lo * 6, &found) || found != key)
        continue;
      int raw = view_u16(&table, records + 4 + lo * 6);
      int value = (int)(((long)(raw >= 32768 ? raw - 65536 : raw) * c->x_mult + 32768L) >> 16);
      int first = value >> 1, second = value - first;
      b->pos[i].x_advance += first;
      b->pos[next].x_advance += second;
      b->pos[next].x_offset += second;
    }
    c->flags = 0;
    at += size;
  }
  if (extended && view_u16(v, 0) >= 3 && aat_coverage(v, at, count, glyphs) < 0)
    return -1;
  return 0;
}

/* ---- Repertoire ------------------------------------------------------- */
static int space_divisor(unsigned cp) {
  switch (cp) {
  case 0x2000:
  case 0x2002:
    return 2;
  case 0x2001:
  case 0x2003:
    return 1;
  case 0x2004:
    return 3;
  case 0x2005:
    return 4;
  case 0x2006:
    return 6;
  case 0x2009:
    return 5;
  case 0x200A:
    return 16;
  case 0xA0:
  case 0x2007:
  case 0x2008:
  case 0x202F:
  case 0x205F:
    return 0;
  default:
    return -1;
  }
}
static int latin_codepoint(unsigned cp) {
  return cp <= 0x036F || (cp >= 0x1D00 && cp <= 0x1EFF) || (cp >= 0x2000 && cp <= 0x206F) ||
         (cp >= 0x20A0 && cp <= 0x20CF) || cp == 0x2122 || (cp >= 0xA720 && cp <= 0xA7FF) ||
         (cp >= 0xAB30 && cp <= 0xAB6F) || cp == 0xFFFD || variation_selector(cp);
}
/* Supported horizontal repertoires. Zero denotes Common/Inherited. */
unsigned minihb_script_of(unsigned cp) {
  if (cp >= 0x1F000 && cp <= 0x1FAFF)
    return TAG('D', 'F', 'L', 'T');
  if ((cp >= 0x1100 && cp <= 0x11FF) || (cp >= 0xAC00 && cp <= 0xD7A3) || (cp >= 0x3130 && cp <= 0x318F))
    return TAG('h', 'a', 'n', 'g');
  if (cp >= 0x3040 && cp <= 0x30FF)
    return TAG('k', 'a', 'n', 'a');
  if ((cp >= 0x3400 && cp <= 0x9FFF) || (cp >= 0xF900 && cp <= 0xFAFF) || (cp >= 0x20000 && cp <= 0x323AF))
    return TAG('h', 'a', 'n', 'i');
  if ((cp >= 0x0370 && cp <= 0x03FF) || (cp >= 0x1F00 && cp <= 0x1FFF))
    return TAG('g', 'r', 'e', 'k');
  if ((cp >= 0x0400 && cp <= 0x052F) || (cp >= 0x2DE0 && cp <= 0x2DFF) || (cp >= 0xA640 && cp <= 0xA69F))
    return TAG('c', 'y', 'r', 'l');
  if ((cp >= 0x0041 && cp <= 0x005A) || (cp >= 0x0061 && cp <= 0x007A) || (cp >= 0x00C0 && cp <= 0x02FF) ||
      (cp >= 0x1D00 && cp <= 0x1EFF) || (cp >= 0xA720 && cp <= 0xA7FF) || (cp >= 0xAB30 && cp <= 0xAB6F))
    return TAG('l', 'a', 't', 'n');
  return 0;
}
int minihb_horizontal_codepoint(unsigned cp) {
  return emoji_tag(cp) || minihb_default_ignorable(cp) || latin_codepoint(cp) || minihb_script_of(cp) != 0 ||
         (cp >= 0x2070 && cp <= 0x2BFF) || (cp >= 0x3000 && cp <= 0x302D) ||
         (cp >= 0x3030 && cp <= 0x303F) || (cp >= 0xFF01 && cp <= 0xFFEF);
}

/* ---- Geometric mark fallback ---------------------------------------- */
/* Glyph extents in position units. hb-ft fonts load the glyph at the set
 * size exactly as upstream does; other fonts use the public extents API. */
static int glyph_extents(hb_font_t *font, unsigned glyph, hb_glyph_extents_t *e) {
  if (!font->design_units && !font->funcs && !font->parent) {
    FT_Face face = face_of(font);
    if (FT_Load_Glyph(face, glyph, font->flags))
      return 0;
    e->x_bearing = (int)face->glyph->metrics.horiBearingX;
    e->y_bearing = (int)face->glyph->metrics.horiBearingY;
    e->width = (int)face->glyph->metrics.width;
    e->height = -(int)face->glyph->metrics.height;
    return 1;
  }
  return hb_font_get_glyph_extents(font, glyph, e);
}
/* HarfBuzz-style geometric fallback for covered horizontal scripts without
 * GPOS. Combining classes are retained in the high byte of var1. */
static int fallback_marks(hb_font_t *font, hb_buffer_t *b, int yscale) {
  int n = blen(b);
  for (int base = 0; base < n; base++) {
    if (KIND(b, base) == 1 || b->info[base].codepoint == 65535)
      continue;
    int end = base + 1;
    while (end < n && (KIND(b, end) == 1 || KIND(b, end) == 2))
      end++;
    if (end == base + 1)
      continue;
    hb_glyph_extents_t e;
    if (!glyph_extents(font, b->info[base].codepoint, &e))
      return -1;
    int by = e.y_bearing + b->pos[base].y_offset, bh = e.height;
    int bw = hb_font_get_glyph_h_advance(font, b->info[base].codepoint);
    int cy = by, ch = bh, last = -1, pen = -b->pos[base].x_advance;
    int components = (int)(VAR2(b, base) & 65535u);
    unsigned owner = VAR2(b, base) >> 16;
    int component = -1, cx = 0, cw = bw;
    for (int i = base + 1; i < end; i++) {
      int cc = (int)(VAR1(b, i) >> 24);
      if (cc == 0) {
        pen -= b->pos[i].x_advance;
        continue;
      }
      if (components > 1 && owner) {
        unsigned mark = VAR2(b, i);
        int which = (int)(mark & 65535u) - 1;
        if ((mark >> 16) != owner || which < 0 || which >= components)
          which = components - 1;
        if (which != component) {
          component = which;
          last = -1;
          cx = (int)((long)which * bw / components);
          cw = bw / components;
        }
      }
      if (last != cc) {
        last = cc;
        cy = by;
        ch = bh;
      }
      hb_glyph_extents_t m;
      if (!glyph_extents(font, b->info[i].codepoint, &m))
        return -1;
      int mx = m.x_bearing, my = m.y_bearing, mw = m.width, mh = m.height;
      int dx = cx + (cw - mw) / 2 - mx, dy = 0, gap = yscale / 16;
      if (cc == 233 || cc == 234)
        dx = cx + cw - mw / 2 - mx;
      else if (cc == 200 || cc == 218 || cc == 228)
        dx = cx - mx;
      else if (cc == 216 || cc == 222 || cc == 232)
        dx = cx + cw - mw - mx;
      if (cc == 233 || cc == 218 || cc == 220 || cc == 222 || cc == 200 || cc == 202) {
        if (cc != 200 && cc != 202)
          ch -= gap;
        dy = cy + ch - my;
        if (dy > 0) {
          ch -= dy;
          dy = 0;
        }
        ch += mh;
      } else if (cc == 234 || cc == 228 || cc == 230 || cc == 232 || cc == 214 || cc == 216) {
        if (cc != 214 && cc != 216) {
          cy += gap;
          ch -= gap;
        }
        dy = cy - my - mh;
        if (dy <= 0) {
          int correction = -(dy / 2);
          cy += correction;
          ch -= correction;
          dy += correction;
        }
        cy -= mh;
        ch += mh;
      }
      b->pos[i].x_offset = dx + pen;
      b->pos[i].y_offset = dy;
      b->pos[i].x_advance = 0;
      b->pos[i].y_advance = 0;
    }
    base = end - 1;
  }
  return 0;
}

/* ---- Shaping entry --------------------------------------------------- */
static int table_length(FT_Face face, unsigned tag, FT_ULong *length) {
  *length = 0;
  return FT_Load_Sfnt_Table(face, tag, 0, NULL, length);
}
#define FAIL(code)                                                                             \
  do {                                                                                         \
    error = (code);                                                                            \
    goto done;                                                                                 \
  } while (0)

/* Shape an LTR run of a supported script. Returns 0 on success (the buffer
 * then holds glyphs) or a MINIHB_* code with the buffer's Unicode content
 * intact. script and language are OpenType tags; language 0 is the default
 * LangSys. */
int minihb_shape_script(hb_font_t *font, hb_buffer_t *b, unsigned script, unsigned language) {
  int error = 0;
  hb_buffer_t *scratch = NULL;
  table_t *morx = NULL, *gsub = NULL, *gpos = NULL, *gdef = NULL, *kern = NULL, *kerx = NULL;
  long *pens = NULL;
  FT_Face face = face_of(font);
  if (!FT_IS_SCALABLE(face) || b->length > 65536 ||
      (b->direction != HB_DIRECTION_LTR && b->direction != HB_DIRECTION_RTL))
    return MINIHB_UNSUPPORTED;
  /* Every supported script is natively left to right: a backward run is
   * mirrored, reversed grapheme by grapheme, shaped in that native direction, as hb_ensure_native_direction does. */
  int backward = b->direction == HB_DIRECTION_RTL;
  int merge_graphemes = b->cluster_level != HB_BUFFER_CLUSTER_LEVEL_MONOTONE_CHARACTERS;
  int preserve = (b->flags & HB_BUFFER_FLAG_PRESERVE_DEFAULT_IGNORABLES) != 0;
  scratch = scratch_create();
  if (!scratch)
    return MINIHB_OUT_OF_MEMORY;
  scratch->direction = b->direction;
  scratch->cluster_level = b->cluster_level;
  for (int i = 0; i < blen(b); i++) {
    unsigned cp = b->info[i].codepoint;
    int supported = minihb_horizontal_codepoint(cp);
    if (cp >= 0x1100 && cp <= 0x11ff &&
        !(cp <= 0x1112 || (cp >= 0x1161 && cp <= 0x1175) || (cp >= 0x11a8 && cp <= 0x11c2)))
      supported = 0;
    if (!supported)
      FAIL(MINIHB_UNSUPPORTED);
    scratch_add(scratch, cp, b->info[i].cluster);
  }
  if (buffer_error(scratch))
    FAIL(buffer_error(scratch));
  scratch->direction = HB_DIRECTION_LTR;
  if (backward)
    for (int i = 0; i < blen(scratch); i++) {
      unsigned m = mirrored(scratch->info[i].codepoint);
      if (m != scratch->info[i].codepoint && has_char(font, m))
        scratch->info[i].codepoint = m;
    }
  if ((merge_graphemes || backward) && !form_clusters(scratch, merge_graphemes, backward))
    FAIL(MINIHB_OUT_OF_MEMORY);
  if (aat_table(font, TAG('m', 'o', 'r', 'x'), &morx))
    FAIL(MINIHB_FONT_ERROR);
  if (!morx && !modern_hangul(font, scratch, merge_graphemes))
    FAIL(buffer_error(scratch));
  if (!buffer_normalize(font, scratch))
    FAIL(buffer_error(scratch));
  if (blen(scratch) > 65536)
    FAIL(MINIHB_UNSUPPORTED);
  for (int i = 0; i < blen(scratch); i++) {
    unsigned cp = scratch->info[i].codepoint;
    if (cp == 0x200C)
      FAIL(MINIHB_UNSUPPORTED);
    if (i + 1 < blen(scratch) && variation_selector(scratch->info[i + 1].codepoint)) {
      unsigned glyph = FT_Face_GetCharVariantIndex(face, cp, scratch->info[i + 1].codepoint);
      if (glyph) {
        scratch->info[i].codepoint = glyph;
        for (int j = i + 2; j < blen(scratch); j++)
          scratch->info[j - 1] = scratch->info[j];
        scratch->length--;
        continue;
      }
    }
    if (minihb_default_ignorable(cp) && !preserve) {
      /* Upstream keeps the nominal glyph (or 0) through substitution and
       * skips the glyph unless a lookup names it; Mongolian selectors, tags
       * and CGJ are "hidden" and never skipped. All become invisible after
       * substitution. */
      int hidden = emoji_tag(cp) || (cp >= 0x180B && cp <= 0x180D) || cp == 0x180F || cp == 0x034F;
      VAR1(scratch, i) = hidden ? 9 : 3;
      if (!hb_font_get_nominal_glyph(font, cp, &scratch->info[i].codepoint))
        scratch->info[i].codepoint = 0;
      continue;
    }
    if (VAR1(scratch, i) < 4)
      VAR1(scratch, i) = unicode_mark(cp) ? 1 : 0;
    VAR1(scratch, i) |= (unsigned)unicode_cc(cp) << 24;
    if (!hb_font_get_nominal_glyph(font, cp, &scratch->info[i].codepoint)) {
      if (space_divisor(cp) != -1 && hb_font_get_nominal_glyph(font, 32, &scratch->info[i].codepoint))
        VAR1(scratch, i) = cp;
      else if (cp == 0x2011)
        hb_font_get_nominal_glyph(font, 0x2010, &scratch->info[i].codepoint);
    }
  }
  static const unsigned tags[3] = {TAG('G', 'S', 'U', 'B'), TAG('G', 'P', 'O', 'S'), TAG('G', 'D', 'E', 'F')};
  for (int i = 0; i < 3; i++) {
    FT_ULong length;
    int e = table_length(face, tags[i], &length);
    if (e && e != FT_Err_Table_Missing)
      FAIL(MINIHB_FONT_ERROR);
    if (!e && (length == 0 || length > 16777216))
      FAIL(MINIHB_FONT_ERROR);
  }
  gsub = font_reference_table(font, tags[0]);
  gpos = font_reference_table(font, tags[1]);
  gdef = font_reference_table(font, tags[2]);
  for (int i = 0; i < 3; i++) {
    FT_ULong length;
    if (!(i == 0 ? gsub : i == 1 ? gpos : gdef) && !table_length(face, tags[i], &length))
      FAIL(MINIHB_FONT_ERROR);
  }
  view_t empty = {NULL, 0};
  layout_t c;
  memset(&c, 0, sizeof c);
  c.font = font;
  c.buffer = scratch;
  c.budget = 1000000;
  c.language = language;
  c.script = script;
  c.merge_graphemes = merge_graphemes;
  c.gdef = gdef ? gdef->view : empty;
  if (FT_HAS_MULTIPLE_MASTERS(face)) {
    FT_MM_Var *mm = NULL;
    if (FT_Get_MM_Var(face, &mm))
      FAIL(MINIHB_FONT_ERROR);
    c.axes = (int)mm->num_axis;
    FT_Done_MM_Var(face->glyph->library, mm);
    if (FT_Load_Glyph(face, 0, FT_LOAD_NO_SCALE | FT_LOAD_NO_HINTING))
      FAIL(MINIHB_FONT_ERROR);
    if (c.axes > 64)
      FAIL(MINIHB_UNSUPPORTED);
    FT_Fixed coords[64];
    if (FT_Get_Var_Blend_Coordinates(face, (FT_UInt)c.axes, coords))
      FAIL(MINIHB_FONT_ERROR);
    for (int i = 0; i < c.axes; i++)
      c.coords[i] = (int)((coords[i] + 2) >> 2);
  }
  if (gdef && view_u16(&c.gdef, 2) >= 3) {
    unsigned offset = 0;
    if (!view_u32(&c.gdef, 14, &offset) || (offset && !view_offset(&c.gdef, 0, offset, 8, &c.var_store)))
      FAIL(MINIHB_FONT_ERROR);
  }
  if (gdef && (view_u16(&c.gdef, 0) != 1 || !view_contains(&c.gdef, 0, 12)))
    FAIL(MINIHB_FONT_ERROR);
  for (int i = 0; i < blen(scratch); i++)
    if (ot_class(&c, scratch->info[i].codepoint) < 0)
      FAIL(MINIHB_FONT_ERROR);
  view_t sub = gsub ? gsub->view : empty, pos = gpos ? gpos->view : empty;
  int result = morx ? aat_morx(&morx->view, scratch, (int)face->num_glyphs, &c.budget) : ot_apply(&c, &sub, 0);
  if (result >= 0 && !morx)
    result = ot_apply(&c, &sub, 1);
  /* Keep morx tombstones through kerx positioning, as upstream does. */
  FT_ULong kerx_length = 0;
  int has_kerx = !table_length(face, TAG('k', 'e', 'r', 'x'), &kerx_length) && kerx_length > 0;
  int apply_kerx = has_kerx && !(!morx && gsub && gpos);
  if (result >= 0 && morx && gpos && !apply_kerx)
    aat_remove_deleted(scratch, 0);
  if (result < 0)
    FAIL(buffer_error(scratch) ? buffer_error(scratch) : result == -1 ? MINIHB_FONT_ERROR : MINIHB_UNSUPPORTED);
  unsigned invisible = b->invisible;
  int has_invisible = invisible != 0 || hb_font_get_nominal_glyph(font, 32, &invisible);
  if (!has_invisible) {
    int out = 0, n = blen(scratch);
    for (int i = 0; i < n; i++) {
      if (KIND(scratch, i) == 3 || KIND(scratch, i) == 9) {
        unsigned cluster = scratch->info[i].cluster;
        if (i + 1 < n && scratch->info[i + 1].cluster == cluster)
          continue;
        if (out > 0) {
          unsigned previous = scratch->info[out - 1].cluster;
          if (cluster < previous)
            for (int j = out - 1; j >= 0 && scratch->info[j].cluster == previous; j--)
              scratch->info[j].cluster = cluster;
        } else if (i + 1 < n) {
          unsigned next = scratch->info[i + 1].cluster;
          if (cluster < next)
            for (int j = i + 1; j < n && scratch->info[j].cluster == next; j++)
              scratch->info[j].cluster = cluster;
        }
        continue;
      }
      scratch->info[out++] = scratch->info[i];
    }
    scratch->length = (unsigned)out;
  }
  for (int i = 0; i < blen(scratch); i++) {
    if (KIND(scratch, i) == 3 || KIND(scratch, i) == 9) {
      VAR1(scratch, i) = 2;
      scratch->info[i].codepoint = invisible;
    }
    if (ot_class(&c, scratch->info[i].codepoint) < 0)
      FAIL(MINIHB_FONT_ERROR);
    memset(scratch->pos + i, 0, sizeof scratch->pos[i]);
    if (scratch->info[i].codepoint != 65535)
      scratch->pos[i].x_advance = hb_font_get_glyph_h_advance(font, scratch->info[i].codepoint);
  }
  int upem = face->units_per_EM & 65535;
  if (upem == 0)
    FAIL(MINIHB_FONT_ERROR);
  long x = font->x_scale, y = font->y_scale;
  if (x <= 0L || y <= 0L)
    FAIL(MINIHB_UNSUPPORTED);
  c.x_mult = x * 65536L / upem;
  c.y_mult = y * 65536L / upem;
  c.positioning = 1;
  c.x_float = (float)x / (float)upem;
  c.y_float = (float)y / (float)upem;
  /* Space fallback establishes advances before pair positioning. */
  for (int i = 0; i < blen(scratch); i++) {
    unsigned cp = KIND(scratch, i);
    int divisor = space_divisor(cp);
    if (divisor < 0 || VAR2(scratch, i) != 0)
      continue;
    if (divisor > 0)
      scratch->pos[i].x_advance = (int)((x + divisor / 2) / divisor);
    else if (cp == 0x202F)
      scratch->pos[i].x_advance /= 2;
    else if (cp == 0x205F)
      scratch->pos[i].x_advance = (int)(x * 4L / 18L);
    else if (cp == 0x2007 || cp == 0x2008) {
      unsigned glyph = 0;
      int found = 0;
      if (cp == 0x2007) {
        for (unsigned digit = 48; digit <= 57 && !found; digit++)
          found = hb_font_get_nominal_glyph(font, digit, &glyph);
      } else
        found = hb_font_get_nominal_glyph(font, 46, &glyph) || hb_font_get_nominal_glyph(font, 44, &glyph);
      if (found)
        scratch->pos[i].x_advance = hb_font_get_glyph_h_advance(font, glyph);
    }
  }
  result = apply_kerx ? 0 : ot_apply(&c, &pos, 2);
  if (result < 0)
    FAIL(buffer_error(scratch) ? buffer_error(scratch) : result == -1 ? MINIHB_FONT_ERROR : MINIHB_UNSUPPORTED);
  int kerx_plan = apply_kerx || (has_kerx && !c.has_kern);
  if (!c.has_kern && !kerx_plan) {
    FT_ULong length;
    int load_error = table_length(face, TAG('k', 'e', 'r', 'n'), &length);
    if (load_error && load_error != FT_Err_Table_Missing)
      FAIL(MINIHB_FONT_ERROR);
    kern = font_reference_table(font, TAG('k', 'e', 'r', 'n'));
    if (!load_error && !kern)
      FAIL(MINIHB_FONT_ERROR);
    if (kern) {
      result = aat_kern(&c, &kern->view, 0);
      if (result < 0)
        FAIL(result == -1 ? MINIHB_FONT_ERROR : MINIHB_UNSUPPORTED);
    }
  }
  if (apply_kerx && aat_table(font, TAG('k', 'e', 'r', 'x'), &kerx))
    FAIL(MINIHB_FONT_ERROR);
  if (kerx) {
    result = aat_kern(&c, &kerx->view, 1);
    if (result < 0)
      FAIL(result == -1 ? MINIHB_FONT_ERROR : MINIHB_UNSUPPORTED);
  }
  for (int i = 0; i < blen(scratch); i++) {
    if (!gpos && !kerx_plan && !morx && ot_info_class(&c, i) == 3)
      scratch->pos[i].x_offset -= scratch->pos[i].x_advance;
    if ((!kerx_plan && ot_info_class(&c, i) == 3) || KIND(scratch, i) == 2) {
      scratch->pos[i].x_advance = 0;
      scratch->pos[i].y_advance = 0;
    }
  }
  /* AAT tracking is not applied: it needs a point size, which hb-ft fonts
   * and this library's callers never set, so upstream skips it as well. */
  if (!gpos && !apply_kerx && fallback_marks(font, scratch, (int)y) < 0)
    FAIL(MINIHB_FONT_ERROR);
  /* Attachments point backwards. Prefix advances avoid quadratic work for
   * long combining sequences; glyph metadata is private to this call. */
  pens = malloc((size_t)(blen(scratch) + 1) * sizeof *pens);
  if (!pens)
    FAIL(MINIHB_OUT_OF_MEMORY);
  pens[0] = 0L;
  for (int i = 0; i < blen(scratch); i++)
    pens[i + 1] = pens[i] + scratch->pos[i].x_advance;
  for (int i = 0; i < blen(scratch); i++) {
    int parent = (int)PVAR(scratch, i) - 1;
    if (parent >= 0) {
      long offset = (long)scratch->pos[i].x_offset + scratch->pos[parent].x_offset - (pens[i] - pens[parent]);
      scratch->pos[i].x_offset = offset < INT_MIN ? INT_MIN : offset > INT_MAX ? INT_MAX : (int)offset;
    }
    PVAR(scratch, i) = 0;
    scratch->info[i].mask = 0;
    VAR1(scratch, i) = 0;
    VAR2(scratch, i) = 0;
  }
  if (morx)
    aat_remove_deleted(scratch, 1);
  {
    hb_glyph_info_t *old_info = b->info;
    hb_glyph_position_t *old_pos = b->pos;
    b->info = scratch->info;
    b->pos = scratch->pos;
    b->length = scratch->length;
    b->capacity = scratch->capacity;
    b->content = HB_BUFFER_CONTENT_TYPE_GLYPHS;
    scratch->info = old_info;
    scratch->pos = old_pos;
  }
done:
  free(pens);
  table_destroy(kerx);
  table_destroy(kern);
  table_destroy(gdef);
  table_destroy(gpos);
  table_destroy(gsub);
  table_destroy(morx);
  hb_buffer_destroy(scratch);
  if (error == MINIHB_OUT_OF_MEMORY)
    b->successful = 0;
  return error;
}

/* ---- Tag mapping for the public API ---------------------------------- */
/* ISO 15924 script (hb_script_t) to the OpenType script tag this shaper
 * handles; 0 for Common/Inherited/unknown (derive from the text) and
 * 0xffffffff for scripts outside the supported repertoire. */
unsigned minihb_ot_script(hb_script_t script) {
  switch (script) {
  case HB_SCRIPT_LATIN:
    return TAG('l', 'a', 't', 'n');
  case HB_SCRIPT_GREEK:
    return TAG('g', 'r', 'e', 'k');
  case HB_SCRIPT_CYRILLIC:
    return TAG('c', 'y', 'r', 'l');
  case HB_SCRIPT_HAN:
    return TAG('h', 'a', 'n', 'i');
  case HB_SCRIPT_HIRAGANA:
  case HB_SCRIPT_KATAKANA:
    return TAG('k', 'a', 'n', 'a');
  case HB_SCRIPT_HANGUL:
    return TAG('h', 'a', 'n', 'g');
  case HB_SCRIPT_COMMON:
  case HB_SCRIPT_INHERITED:
  case HB_SCRIPT_UNKNOWN:
  case HB_SCRIPT_INVALID:
    return 0;
  default:
    return 0xffffffffu;
  }
}
/* BCP 47 language to an OpenType LangSys tag for the languages whose
 * localized forms matter in the supported scripts. Unknown languages use
 * the default LangSys, as HarfBuzz does when a font lacks the tag. */
unsigned minihb_ot_language(hb_language_t language) {
  static const struct {
    const char *bcp47;
    const char tag[5];
  } table[] = {
      {"af", "AFK"}, {"az", "AZE"}, {"be", "BEL"}, {"bg", "BGR"}, {"ca", "CAT"}, {"crh", "CRT"},
      {"cs", "CSY"}, {"cy", "WEL"}, {"da", "DAN"}, {"de", "DEU"}, {"el", "ELL"}, {"en", "ENG"},
      {"es", "ESP"}, {"et", "ETI"}, {"eu", "EUQ"}, {"fi", "FIN"}, {"fil", "PIL"}, {"fr", "FRA"},
      {"ga", "IRI"}, {"gl", "GAL"}, {"hr", "HRV"}, {"hu", "HUN"}, {"id", "IND"}, {"is", "ISL"},
      {"it", "ITA"}, {"ja", "JAN"}, {"kk", "KAZ"}, {"ko", "KOR"}, {"lt", "LTH"}, {"lv", "LVI"},
      {"mk", "MKD"}, {"mo", "MOL"}, {"ms", "MLY"}, {"nb", "NOR"}, {"nl", "NLD"}, {"nn", "NYN"},
      {"no", "NOR"}, {"pl", "PLK"}, {"pt", "PTG"}, {"ro", "ROM"}, {"ru", "RUS"}, {"sk", "SKY"},
      {"sl", "SLV"}, {"sr", "SRB"}, {"sv", "SVE"}, {"tl", "PIL"}, {"tr", "TRK"}, {"tt", "TAT"},
      {"uk", "UKR"}, {"vi", "VIT"}, {"zh-cn", "ZHS"}, {"zh-hans", "ZHS"}, {"zh-sg", "ZHS"},
      {"zh-tw", "ZHT"}, {"zh-hant", "ZHT"}, {"zh-hk", "ZHH"}, {"zh-mo", "ZHH"}, {"zh", "ZHS"},
  };
  const char *s = hb_language_to_string(language);
  if (!s)
    return 0;
  size_t n = strlen(s);
  for (size_t i = 0; i < sizeof table / sizeof table[0]; i++) {
    size_t m = strlen(table[i].bcp47);
    if (n >= m && !strncmp(s, table[i].bcp47, m) && (n == m || s[m] == '-')) {
      const char *t = table[i].tag;
      /* Longer entries (zh-cn) precede the bare language (zh) in the table
       * scan only when they match, so a plain prefix match is correct. */
      return TAG(t[0], t[1], t[2], t[3] ? t[3] : ' ');
    }
  }
  return 0;
}
