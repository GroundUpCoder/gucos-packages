#ifndef MINIHB_H
#define MINIHB_H
#include <hb.h>
/* Local integration API, deliberately outside the HarfBuzz namespace.
 * A caller requesting a font transform/variation unsupported by MiniHB can
 * require a checked shaping failure instead of silently rendering differently. */
void minihb_font_reject_shaping(hb_font_t *font);
#endif
