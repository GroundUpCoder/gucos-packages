# SDL_image 3.2.6 for wasm-posix

Pinned to the maintained SDL3 3.2 family (archive URL/digest in ORIGIN.json).
The archive's source, public headers, build metadata and tests are preserved;
VisualC/Xcode platform projects and prebuilt foreign binaries are omitted.

Builds real upstream IMG.c dispatch and format entry points. PNG/JPEG decoding
uses the vendored stb_image backend; PNG/JPEG saving uses upstream miniz/tinyjpeg.
There is no dependency on a host codec or the compiler's builtin image veneer.
The installed library depends only on the real packaged SDL3 runtime.

C wrapper files include stdbool.h before unchanged upstream translation units;
`__inline=inline` adapts the compiler spelling. One marked upstream change makes
disabled SVG loading set an explicit error. The upstream SDL-specific stb backend
already propagates decoder failures through SDL_SetError.

PNG/JPEG loading and saving and the upstream LOAD_BMP dispatch are enabled.
BMP decoding delegates unchanged to SDL_LoadBMP_IO, so pygame's imageext path
accepts BMP files and typed/untyped streams too. LOAD_BMP also enables upstream
ICO/CUR sibling entry points; this package's acceptance focuses on BMP.
Other disabled image/animation codecs return failure. The upstream single-frame
animation behavior for supported still images is preserved. The BMP wrapper
supplies canonical SDL surface hotspot property keys for the ICO/CUR code.

Acceptance runs installed shared/static consumers using unchanged upstream
sample.png/sample.jpg and sample.bmp pixel oracles, with the same JPEG squared
RGB tolerance (100) as upstream test/main.c. It exercises file, typed and untyped
memory loading for PNG/JPEG/BMP, detection/seek preservation, caller-owned IO, PNG alpha and JPEG
file/memory saving, missing/truncated PNG and BMP input, unsupported SVG/GIF animation, and
host pngjs verification of every encoded PNG pixel. This is a focused adaptation
of upstream fixtures, not a claim that SDL's complete SDLTest runner executes.
