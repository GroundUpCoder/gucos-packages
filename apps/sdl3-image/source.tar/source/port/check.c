#include <stdbool.h>
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void check(bool ok,const char *what){if(!ok){fprintf(stderr,"SDL_image check failed: %s: %s\n",what,SDL_GetError());exit(1);}}
static void compare(SDL_Surface *a,SDL_Surface *b,int tolerance){
 check(a&&b,"surface exists");check(a->w==b->w&&a->h==b->h,"dimensions");
 for(int y=0;y<a->h;y++)for(int x=0;x<a->w;x++){
  Uint8 ar,ag,ab,aa,br,bg,bb,ba;
  check(SDL_ReadSurfacePixel(a,x,y,&ar,&ag,&ab,&aa),"read actual pixel");
  check(SDL_ReadSurfacePixel(b,x,y,&br,&bg,&bb,&ba),"read reference pixel");
  int dr=(int)ar-br,dg=(int)ag-bg,db=(int)ab-bb;
  if(dr*dr+dg*dg+db*db>tolerance||aa!=ba){fprintf(stderr,"pixel %d,%d: %u,%u,%u,%u != %u,%u,%u,%u\n",x,y,ar,ag,ab,aa,br,bg,bb,ba);exit(2);}
 }
}
static unsigned char *readfile(const char *name,size_t *len){FILE*f=fopen(name,"rb");check(f!=NULL,"open fixture");check(!fseek(f,0,SEEK_END),"seek fixture");long n=ftell(f);check(n>0,"fixture size");rewind(f);unsigned char*p=malloc(n);check(p!=NULL,"allocate fixture");check(fread(p,1,n,f)==(size_t)n,"read fixture");fclose(f);*len=n;return p;}
static void upstream(const char *dir,const char *kind,int tolerance,SDL_Surface *reference){
 char path[512];snprintf(path,sizeof(path),"%s/sample.%s",dir,kind);SDL_Surface*s=IMG_Load(path);compare(s,reference,tolerance);SDL_DestroySurface(s);
 size_t len;unsigned char *data=readfile(path,&len);SDL_IOStream*io=SDL_IOFromConstMem(data,len);check(io!=NULL,"memory IO");
 check(!strcmp(kind,"png")?IMG_isPNG(io):!strcmp(kind,"bmp")?IMG_isBMP(io):IMG_isJPG(io),"format detection");check(SDL_TellIO(io)==0,"detection preserves position");
 s=IMG_LoadTyped_IO(io,false,!strcmp(kind,"png")?"PNG":!strcmp(kind,"bmp")?"BMP":"JPG");compare(s,reference,tolerance);check(SDL_TellIO(io)>=0,"caller-owned IO remains open");SDL_CloseIO(io);SDL_DestroySurface(s);
 io=SDL_IOFromConstMem(data,len);s=IMG_Load_IO(io,true);compare(s,reference,tolerance);SDL_DestroySurface(s);free(data);
}
static void known_bmp(void){
 const unsigned char bmp[]={66,77,70,0,0,0,0,0,0,0,54,0,0,0,40,0,0,0,2,0,0,0,2,0,0,0,1,0,24,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,255,255,255,0,0,0,0,255,0,255,0,0,0};
 SDL_IOStream *io=SDL_IOFromConstMem(bmp,sizeof bmp);SDL_Surface *surface=IMG_Load_IO(io,true);check(surface&&surface->w==2&&surface->h==2,"BMP dimensions and dispatch");
 const Uint8 colors[4][3]={{255,0,0},{0,255,0},{0,0,255},{255,255,255}};
 for(int y=0;y<2;y++)for(int x=0;x<2;x++){Uint8 r,g,b,a;check(SDL_ReadSurfacePixel(surface,x,y,&r,&g,&b,&a),"BMP sample");const Uint8 *want=colors[y*2+x];check(r==want[0]&&g==want[1]&&b==want[2]&&a==255,"BMP BGR order, bottom-up rows and padding");}
 SDL_DestroySurface(surface);
}
int main(int argc,char**argv){
 known_bmp();
 check(argc==2,"fixture directory");check(IMG_Version()==SDL_IMAGE_VERSION,"installed version");
 char path[512];snprintf(path,sizeof(path),"%s/sample.bmp",argv[1]);SDL_Surface*reference=SDL_LoadBMP(path);check(reference&&reference->w==23&&reference->h==42,"upstream reference BMP");
 // PNG exact pixels and JPEG squared RGB tolerance 100 match upstream test/main.c.
 upstream(argv[1],"bmp",0,reference);upstream(argv[1],"png",0,reference);upstream(argv[1],"jpg",100,reference);SDL_DestroySurface(reference);
 SDL_Surface*s=SDL_CreateSurface(16,16,SDL_PIXELFORMAT_RGBA32);check(s!=NULL,"create surface");
 for(int y=0;y<16;y++)for(int x=0;x<16;x++)check(SDL_WriteSurfacePixel(s,x,y,x*15,y*15,(x+y)*7,(x*17+y*11)&255),"RGBA pattern");
 check(IMG_SavePNG(s,"roundtrip.png"),"save PNG file");SDL_Surface*r=IMG_Load("roundtrip.png");compare(r,s,0);SDL_DestroySurface(r);
 unsigned char encoded[32768];SDL_IOStream*io=SDL_IOFromMem(encoded,sizeof encoded);check(io!=NULL,"output memory IO");
 check(IMG_SavePNG_IO(s,io,false),"save PNG memory");Sint64 n=SDL_TellIO(io);check(n>0&&n<(Sint64)sizeof encoded,"PNG memory length");SDL_CloseIO(io);io=SDL_IOFromConstMem(encoded,n);r=IMG_LoadTyped_IO(io,true,"PNG");compare(r,s,0);SDL_DestroySurface(r);
 check(SDL_FillSurfaceRect(s,NULL,SDL_MapSurfaceRGBA(s,80,120,160,255)),"solid JPEG source");
 check(IMG_SaveJPG(s,"roundtrip.jpg",95),"save JPEG file");r=IMG_Load("roundtrip.jpg");compare(r,s,100);SDL_DestroySurface(r);
 io=SDL_IOFromMem(encoded,sizeof encoded);check(IMG_SaveJPG_IO(s,io,false,95),"save JPEG memory");n=SDL_TellIO(io);check(n>0&&n<(Sint64)sizeof encoded,"JPEG memory length");SDL_CloseIO(io);io=SDL_IOFromConstMem(encoded,n);r=IMG_LoadTyped_IO(io,true,"JPG");compare(r,s,100);SDL_DestroySurface(r);SDL_DestroySurface(s);
 const unsigned char invalid_bmp[]={'B','M',0,0,0,0};io=SDL_IOFromConstMem(invalid_bmp,sizeof invalid_bmp);SDL_ClearError();check(!IMG_LoadTyped_IO(io,false,"BMP")&&*SDL_GetError(),"truncated BMP error");check(SDL_TellIO(io)>=0,"failed BMP leaves caller IO open");SDL_CloseIO(io);
 SDL_ClearError();check(!IMG_Load("missing-image.png")&&*SDL_GetError(),"missing file error");
 const unsigned char bad[]={137,'P','N','G',13,10,26,10,0,0,0,13};io=SDL_IOFromConstMem(bad,sizeof bad);SDL_ClearError();check(!IMG_Load_IO(io,true)&&*SDL_GetError(),"truncated PNG error");
 snprintf(path,sizeof(path),"%s/svg.svg",argv[1]);io=SDL_IOFromFile(path,"rb");SDL_ClearError();check(!IMG_LoadSizedSVG_IO(io,16,16)&&strstr(SDL_GetError(),"without SVG"),"explicit unsupported SVG");SDL_CloseIO(io);
 snprintf(path,sizeof(path),"%s/palette.gif",argv[1]);SDL_ClearError();check(!IMG_LoadAnimation(path)&&*SDL_GetError(),"explicit unsupported animation");
 puts("SDL3-IMAGE-CONSUMER-PASS");return 0;
}
