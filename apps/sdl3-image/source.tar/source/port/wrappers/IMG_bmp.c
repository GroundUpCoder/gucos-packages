/* Supply C boolean definitions without changing upstream sources. */
#include <stdbool.h>
/* Canonical SDL property keys used by the upstream ICO/CUR sibling loader. */
#ifndef SDL_PROP_SURFACE_HOTSPOT_X_NUMBER
#define SDL_PROP_SURFACE_HOTSPOT_X_NUMBER "SDL.surface.hotspot.x"
#define SDL_PROP_SURFACE_HOTSPOT_Y_NUMBER "SDL.surface.hotspot.y"
#endif
#include "../../upstream/src/IMG_bmp.c"
