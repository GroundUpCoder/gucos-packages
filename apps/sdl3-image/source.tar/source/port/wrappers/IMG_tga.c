/* Supply C boolean definitions without changing upstream sources. */
#include <stdbool.h>
#include "../../upstream/src/IMG_tga.c"
