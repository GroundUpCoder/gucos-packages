import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
import {PNG} from 'pngjs';
import {writeFile} from 'node:fs/promises';
const {page,errors,output,close}=await appBrowser('sdl3-image',600000);
try {
 const result=await runCached(page,`set -e
gucman install sdl3-image
mkdir -p /tmp/sdl3-image-shared /tmp/sdl3-image-static
cc /usr/src/sdl3-image/port/check.c -I/usr/local/include -lSDL3_image -lSDL3 -lm -o /tmp/image-shared
cc -static /usr/src/sdl3-image/port/check.c -I/usr/local/include -lSDL3_image -lSDL3 -lm -o /tmp/image-static
cd /tmp/sdl3-image-shared
/tmp/image-shared /usr/src/sdl3-image/upstream/test
base64 roundtrip.png > /tmp/sdl3-image-png.b64
cd /tmp/sdl3-image-static
/tmp/image-static /usr/src/sdl3-image/upstream/test
gucman install sdl3-image
echo SDL3-IMAGE-PACKAGE-PASS
`,{packages:['sdl3-image'],fresh:['sdl3-image']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);assert.equal((log.match(/SDL3-IMAGE-CONSUMER-PASS/g)||[]).length,2);assert.match(log,/SDL3-IMAGE-PACKAGE-PASS/);
 const bytes=Buffer.from(await page.evaluate(async()=>new TextDecoder().decode(await shell.busybox.read('/tmp/sdl3-image-png.b64'))),'base64');await writeFile(output+'/rgba.png',bytes);
 const png=PNG.sync.read(bytes);assert.equal(png.width,16);assert.equal(png.height,16);
 for(let y=0;y<16;y++)for(let x=0;x<16;x++)assert.deepEqual([...png.data.subarray((y*16+x)*4,(y*16+x+1)*4)],[x*15,y*15,(x+y)*7,(x*17+y*11)&255]);
 assert.deepEqual(errors,[]);
 console.log('PASS SDL3_image upstream PNG/JPEG/BMP fixtures, shared/static file and IO load/save, alpha pixels, decoder failures and explicit optional-format errors');
}finally{await close();}
