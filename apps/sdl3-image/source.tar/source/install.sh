#!/bin/sh
set -e
stage=$1
cd /usr/src/sdl3-image
mkdir -p "$stage/lib" "$stage/include/SDL3_image" "$stage/lib/pkgconfig" "$stage/objects"
objects=
for source in port/wrappers/*.c; do
 name=$(basename "$source" .c)
 cc -Iupstream/include -DUSE_STBIMAGE -DLOAD_PNG -DLOAD_JPG -DLOAD_BMP -D__inline=inline -c "$source" -o "$stage/objects/$name.o"
 objects="$objects $stage/objects/$name.o"
done
ar rcs "$stage/lib/libSDL3_image.a" $objects
cc -shared $objects -lSDL3 -lm -Wl,-soname,libSDL3_image.so -o "$stage/lib/libSDL3_image.so"
cp upstream/include/SDL3_image/SDL_image.h "$stage/include/SDL3_image/"
cp port/sdl3-image.pc "$stage/lib/pkgconfig/"
rm -r "$stage/objects"
