import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const name="doom";
const {page,errors,output,close}=await appBrowser(name,1700000);
try {
 const install=await runCached(page,'set -e\ngucman install '+name+'\n',{packages:[name],fresh:[name]});
 assert.equal(install.code,0,await page.evaluate(()=>shell.busybox.log));
 await page.evaluate(command=>{window.acceptanceResult=null;window.acceptanceRun=shell.command('sh -c '+JSON.stringify(command));window.acceptanceRun.then(result=>window.acceptanceResult=result,error=>window.acceptanceResult={error:String(error)});},"doom");
 const screen=page.locator('.screen:not([hidden])').last(),canvas=screen.locator('canvas');
 await canvas.waitFor({state:'visible',timeout:60000});
 let accepted=false,frame;
 const deadline=Date.now()+60000;
 while(Date.now()<deadline){
  frame=await canvas.screenshot();const png=PNG.sync.read(frame),colors=new Set();
  let red=0,blue=0,total=png.width*png.height;
  for(let i=0;i<png.data.length;i+=4){const r=png.data[i],g=png.data[i+1],b=png.data[i+2];colors.add((r<<16)|(g<<8)|b);if(r>200&&g<60&&b<60)red++;if(b>150&&r<120)blue++;}
  if(colors.size>50){accepted=true;break;}
  await page.waitForTimeout(250);
 }
 await writeFile(output+'/'+name+'-frame.png',frame);
 assert.ok(accepted,name+' renders expected application output');
 await canvas.click();
 // Original title -> menu -> new game -> episode -> skill -> level sequence.
 for(let i=0;i<4;i++){await page.keyboard.press('Enter',{delay:100});await page.waitForTimeout(500);}
 await page.waitForTimeout(1500);
 const level=await canvas.screenshot();
 await writeFile(output+'/doom-level.png',level);
 assert.notDeepEqual(level,frame,'new game differs from title frame');
 await page.keyboard.down('ArrowUp');await page.waitForTimeout(1000);await page.keyboard.up('ArrowUp');
 await page.keyboard.down('Control');await page.waitForTimeout(500);await page.keyboard.up('Control');
 const played=await canvas.screenshot();
 await writeFile(output+'/doom-played.png',played);
 assert.notDeepEqual(played,level,'movement/fire changes rendered game');
 await page.keyboard.press('Escape');await page.waitForTimeout(250);
 await writeFile(output+'/doom-menu.png',await canvas.screenshot());
 await screen.getByRole('button',{name:'Close process'}).click();
 await page.waitForFunction(()=>window.acceptanceResult!==null,null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.acceptanceResult.error),undefined);
 assert.deepEqual(errors,[]);
 console.log(name+' title, new game, movement/fire, menu and close acceptance passed');
} finally {await close();}
