#include <cairo-gobject.h>
#include <glib-object.h>
int main(void) {
  cairo_surface_t *surface=cairo_image_surface_create(CAIRO_FORMAT_ARGB32,32,24);
  cairo_t *cr=cairo_create(surface);
  GValue value=G_VALUE_INIT;
  g_value_init(&value,CAIRO_GOBJECT_TYPE_CONTEXT);
  g_value_set_boxed(&value,cr);
  g_assert_cmpuint(cairo_get_reference_count(cr),==,2);
  cairo_t *copy=g_value_dup_boxed(&value);
  g_assert_true(copy==cr);
  g_assert_cmpuint(cairo_get_reference_count(cr),==,3);
  cairo_destroy(copy);g_value_unset(&value);
  g_assert_cmpuint(cairo_get_reference_count(cr),==,1);
  g_value_init(&value,CAIRO_GOBJECT_TYPE_SURFACE);
  g_value_set_boxed(&value,surface);
  g_assert_true(g_value_get_boxed(&value)==surface);
  g_value_unset(&value);
  GEnumClass *klass=g_type_class_ref(CAIRO_GOBJECT_TYPE_FORMAT);
  GEnumValue *format=g_enum_get_value(klass,CAIRO_FORMAT_ARGB32);
  g_assert_nonnull(format);
  g_assert_cmpstr(format->value_name,==,"CAIRO_FORMAT_ARGB32");
  g_type_class_unref(klass);
  cairo_destroy(cr);cairo_surface_destroy(surface);
  g_print("CAIRO-GOBJECT-PASS\n");return 0;
}
