set -e
gucman install cairo-gobject pkgconf
cc /usr/src/cairo-gobject/port/check.c $(pkg-config --cflags --libs cairo-gobject) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
