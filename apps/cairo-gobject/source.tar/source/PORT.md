Upstream Cairo 1.18.4 util/cairo-gobject sources provide enum GTypes and boxed
types using this port's Cairo feature configuration. gucman installs shared
and static libraries, cairo-gobject.h and cairo-gobject.pc.

port/check.c verifies enum lookup and boxed context/surface lifetime through
GValue copy/unset operations. It is a local integration check, not an
upstream Cairo test suite. ORIGIN.json identifies the unmodified source.
