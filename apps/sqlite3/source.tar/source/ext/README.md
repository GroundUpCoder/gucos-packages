series.c is unmodified SQLite 3.53.1 upstream source (public domain).
Source: https://github.com/sqlite/sqlite/blob/version-3.53.1/ext/misc/series.c
SHA-256: f21cef287c84d39063d8779055417c86a344b3d5d86e3b7f945aef623af3f654
