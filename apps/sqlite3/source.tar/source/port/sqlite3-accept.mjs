import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('sqlite3',1700000);
try {
 const script=await readFile(new URL('./sqlite3-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['sqlite3'],fresh:['sqlite3']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.ok(log.includes('SQLITE3-ACCEPTANCE-PASS'),log);
 // Abrupt reload while a spilled rollback-journal transaction is open.
 await page.evaluate(()=>{
  const sql=".bail on\nPRAGMA cache_size=10;\nBEGIN;\nUPDATE item SET value=99;\nUPDATE payload SET data=randomblob(1024);\n.shell echo SQLITE-CRASH-WRITER-READY\n";
  shell.ui.save('/tmp/sqlite-crash.sql',sql);
  window.sqliteCrash=shell.command("sh -c '{ cat /tmp/sqlite-crash.sql; sleep 60; } | sqlite3 /home/user/sqlite-acceptance.db'").catch(()=>{});
 });
 await page.waitForFunction(()=>shell.busybox?.log.includes('SQLITE-CRASH-WRITER-READY'));
 await page.reload();
 await page.waitForFunction(()=>window.shell?.ready);
 const recovered=await page.evaluate(async()=>{
  const result=await shell.command("sh -c "+JSON.stringify("set -e; sqlite3 /home/user/sqlite-acceptance.db 'SELECT count(*),sum(value) FROM item; SELECT count(*),sum(length(data)),sum(data=zeroblob(1024)) FROM payload; PRAGMA integrity_check;'"));
  return {result,log:shell.busybox.log};
 });
 assert.equal(recovered.result.code,0,recovered.log);
 assert.match(recovered.log,/3\|42\n1024\|1048576\|1024\nok/);
 console.log('SQLITE3-RECOVERY-PASS');
 assert.deepEqual(errors,[]);
} finally {await close();}
