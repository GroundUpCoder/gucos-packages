/* SQLite under pthreads: one connection shared by several threads in
   serialized mode (SQLITE_THREADSAFE=1), then one connection per thread with
   a busy handler, all against a file database on the shared disk. */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "sqlite3.h"

#define THREADS 4
#define ROWS 200
static sqlite3 *shared;

static void *shared_writer(void *arg) {
  long id = (long)arg;
  sqlite3_stmt *st = 0;
  if (sqlite3_prepare_v2(shared, "INSERT INTO t(thread, n) VALUES(?, ?)", -1, &st, 0) != SQLITE_OK) return (void *)1;
  for (int i = 0; i < ROWS; i++) {
    sqlite3_bind_int(st, 1, (int)id); sqlite3_bind_int(st, 2, i);
    if (sqlite3_step(st) != SQLITE_DONE) { sqlite3_finalize(st); return (void *)2; }
    sqlite3_reset(st);
  }
  sqlite3_finalize(st);
  return 0;
}

static void *own_connection(void *arg) {
  long id = (long)arg;
  sqlite3 *db = 0;
  if (sqlite3_open("/tmp/threadtest.db", &db) != SQLITE_OK) return (void *)1;
  sqlite3_busy_timeout(db, 20000);
  char sql[128];
  for (int i = 0; i < 50; i++) {
    snprintf(sql, sizeof sql, "INSERT INTO u(thread, n) VALUES(%ld, %d)", id, i);
    char *err = 0;
    int rc;
    while ((rc = sqlite3_exec(db, sql, 0, 0, &err)) == SQLITE_BUSY) { sqlite3_free(err); usleep(1000); }
    if (rc != SQLITE_OK) { fprintf(stderr, "thread %ld: %s\n", id, err ? err : "?"); sqlite3_free(err); sqlite3_close(db); return (void *)2; }
  }
  sqlite3_close(db);
  return 0;
}

static int count(sqlite3 *db, const char *sql) {
  sqlite3_stmt *st; int n = -1;
  if (sqlite3_prepare_v2(db, sql, -1, &st, 0) == SQLITE_OK && sqlite3_step(st) == SQLITE_ROW) n = sqlite3_column_int(st, 0);
  sqlite3_finalize(st);
  return n;
}

int main(void) {
  pthread_t t[THREADS]; void *r;
  printf("sqlite %s threadsafe=%d\n", sqlite3_libversion(), sqlite3_threadsafe());
  unlink("/tmp/threadtest.db");
  if (sqlite3_open("/tmp/threadtest.db", &shared) != SQLITE_OK) return 1;
  if (sqlite3_exec(shared, "PRAGMA journal_mode=MEMORY; CREATE TABLE t(thread INT, n INT); CREATE TABLE u(thread INT, n INT);", 0, 0, 0) != SQLITE_OK) return 1;
  for (long i = 0; i < THREADS; i++) if (pthread_create(&t[i], 0, shared_writer, (void *)i) != 0) return 1;
  for (int i = 0; i < THREADS; i++) { pthread_join(t[i], &r); if (r) { printf("shared writer failed: %ld\n", (long)r); return 1; } }
  int rows = count(shared, "SELECT count(*) FROM t"), sum = count(shared, "SELECT sum(n) FROM t");
  printf("shared connection: rows=%d sum=%d\n", rows, sum);
  if (rows != THREADS * ROWS || sum != THREADS * (ROWS * (ROWS - 1) / 2)) return 1;
  sqlite3_close(shared);
  for (long i = 0; i < THREADS; i++) if (pthread_create(&t[i], 0, own_connection, (void *)i) != 0) return 1;
  for (int i = 0; i < THREADS; i++) { pthread_join(t[i], &r); if (r) { printf("own connection failed: %ld\n", (long)r); return 1; } }
  if (sqlite3_open("/tmp/threadtest.db", &shared) != SQLITE_OK) return 1;
  rows = count(shared, "SELECT count(*) FROM u");
  printf("per-thread connections: rows=%d\n", rows);
  sqlite3_close(shared);
  if (rows != THREADS * 50) return 1;
  printf("SQLITE-THREADS-PASS\n");
  return 0;
}
