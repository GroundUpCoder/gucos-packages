/* Storage policy regression workload. Historical filename retained for SDK users.
   WAL is unavailable; exercise rollback journals, locks, threaded connections,
   growth and recovery after terminating an uncommitted writer. */
#include "sqlite3.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <pthread.h>
#define CHECK(x) do { if (!(x)) { fprintf(stderr, "FAIL storage line %d\n", __LINE__); return 70; } } while (0)
static int run(sqlite3 *db, const char *s) { int rc = sqlite3_exec(db, s, 0, 0, 0); if (rc) fprintf(stderr, "SQL: %d %s\n", rc, sqlite3_errmsg(db)); return rc; }
static int value(sqlite3 *db, const char *s) { sqlite3_stmt *st = 0; int n = -1; if (!sqlite3_prepare_v2(db, s, -1, &st, 0) && sqlite3_step(st) == SQLITE_ROW) n = sqlite3_column_int(st, 0); sqlite3_finalize(st); return n; }
static void mark(const char *s) { int fd = open(s, O_CREAT | O_WRONLY, 0600); if (fd >= 0) close(fd); }
static int waitfor(const char *s) { for (int i = 0; i < 3000; i++) { if (!access(s, F_OK)) return 0; usleep(10000); } return 1; }
static void *writer(void *unused) {
    (void)unused;
    sqlite3 *db = 0; if (sqlite3_open("storage-test.db", &db)) return (void *)1;
    sqlite3_busy_timeout(db, 10000);
    for (int i = 0; i < 10; i++) if (run(db, "INSERT INTO t VALUES(1);")) { sqlite3_close(db); return (void *)2; }
    sqlite3_close(db); return 0;
}
static int storage_test(void) {
    unlink("storage-test.db"); unlink("storage-test.db-journal");
    unlink("storage-ready"); unlink("storage-write-lock"); unlink("storage-end-write");
    /* Fork before opening either connection: SQLite connections cannot cross fork. */
    pid_t child = fork(); CHECK(child >= 0);
    if (!child) {
        sqlite3 *db = 0; CHECK(!waitfor("storage-ready")); CHECK(!sqlite3_open("storage-test.db", &db));
        CHECK(!run(db, "BEGIN IMMEDIATE;INSERT INTO t VALUES(2);")); mark("storage-write-lock");
        CHECK(!waitfor("storage-end-write")); CHECK(!run(db, "COMMIT;")); CHECK(!sqlite3_close(db)); _exit(0);
    }
    sqlite3 *db = 0; CHECK(!sqlite3_open("storage-test.db", &db));
    CHECK(sqlite3_compileoption_used("OMIT_WAL"));
    sqlite3_stmt *st = 0;
    CHECK(!sqlite3_prepare_v2(db, "PRAGMA journal_mode=WAL", -1, &st, 0));
    CHECK(sqlite3_step(st) == SQLITE_ROW);
    CHECK(!strcmp((const char *)sqlite3_column_text(st, 0), "delete"));
    CHECK(!sqlite3_finalize(st));
    CHECK(!run(db, "CREATE TABLE t(n);INSERT INTO t VALUES(1);")); mark("storage-ready");
    CHECK(!waitfor("storage-write-lock"));
    CHECK(value(db, "SELECT sum(n) FROM t") == 1); /* Uncommitted writes remain invisible. */
    CHECK(sqlite3_exec(db, "BEGIN IMMEDIATE", 0, 0, 0) == SQLITE_BUSY); mark("storage-end-write");
    int status; CHECK(waitpid(child, &status, 0) == child && status == 0);
    CHECK(value(db, "SELECT sum(n) FROM t") == 3);
    CHECK(!run(db, "BEGIN;INSERT INTO t VALUES(100);ROLLBACK;"));
    CHECK(value(db, "SELECT sum(n) FROM t") == 3);
    pthread_t threads[3]; for (int i = 0; i < 3; i++) CHECK(!pthread_create(&threads[i], 0, writer, 0));
    for (int i = 0; i < 3; i++) { void *out = 0; CHECK(!pthread_join(threads[i], &out) && !out); }
    CHECK(value(db, "SELECT sum(n) FROM t") == 33);
    CHECK(!sqlite3_close(db)); puts("PASS SQLite storage: WAL unavailable, process writer contention, rollback and threaded connections"); return 0;
}
static int storage_crash(void) {
    sqlite3 *db = 0; unlink("storage-crash.db"); unlink("storage-crash.db-journal");
    CHECK(!sqlite3_open("storage-crash.db", &db));
    CHECK(!run(db, "PRAGMA page_size=1024;PRAGMA journal_mode=DELETE;PRAGMA cache_size=3;CREATE TABLE t(n,p);INSERT INTO t VALUES(42,x'00');BEGIN;WITH RECURSIVE s(n) AS (VALUES(1) UNION ALL SELECT n+1 FROM s WHERE n<100) INSERT INTO t SELECT n,zeroblob(2000) FROM s;"));
    puts("sqlite rollback crash writer ready"); fflush(stdout); for (;;) usleep(100000);
}
static int storage_growth(void) {
    sqlite3 *db = 0; unlink("storage-growth.db"); CHECK(!sqlite3_open("storage-growth.db", &db));
    CHECK(!run(db, "PRAGMA page_size=512;CREATE TABLE t(n,p);BEGIN;WITH RECURSIVE s(n) AS (VALUES(1) UNION ALL SELECT n+1 FROM s WHERE n<600) INSERT INTO t SELECT n,zeroblob(4096) FROM s;COMMIT;"));
    CHECK(!sqlite3_close(db)); CHECK(!sqlite3_open("storage-growth.db", &db));
    CHECK(value(db, "SELECT count(*) FROM t") == 600);
    CHECK(!sqlite3_close(db)); puts("PASS SQLite storage: large transaction persists after reopen"); return 0;
}
int main(int argc, char **argv) {
    const char *mode = argc > 1 ? argv[1] : "--storage";
    if (!strcmp(mode, "--storage")) return storage_test();
    if (!strcmp(mode, "--growth")) return storage_growth();
    if (!strcmp(mode, "--crash")) return storage_crash();
    fprintf(stderr, "usage: walcheck --storage | --growth | --crash\n"); return 2;
}
