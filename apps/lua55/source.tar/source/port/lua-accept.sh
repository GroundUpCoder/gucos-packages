set -e
gucman install lua
cat > /tmp/closure.lua <<'EOF'
local function counter(n)
 return function(delta) n=n+delta; return n end
end
local c=counter(10)
assert(c(2)==12 and c(30)==42)
assert(string.match("abc123", "%d+")=="123")
print("LUA-CLOSURE-42")
EOF
lua /tmp/closure.lua > /tmp/lua-output
grep '^LUA-CLOSURE-42$' /tmp/lua-output

echo LUA-ACCEPTANCE-PASS
