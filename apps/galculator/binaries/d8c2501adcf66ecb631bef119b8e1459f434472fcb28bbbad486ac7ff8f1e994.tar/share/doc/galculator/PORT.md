# galculator 2.1.4

Upstream GTK3 scientific calculator, built with the upstream double-precision
configuration (no optional libquadmath). The maintained install recipe uses
our existing binary GTK SDK. Upstream implementation and UI files are retained; the compatibility fixes below are the only source edits.
The flex scanner is generated on the development host and checked in under
port/: `flex -o vendor/galculator/port/flex_parser.c vendor/galculator/src/flex_parser.l`.
Dynamic executable exports are needed for GtkBuilder's named signal callbacks.
# Source compatibility

`src/ui.h` gives `ui_formula_entry_state` its existing `gboolean` parameter
type. The upstream empty parameter list cannot describe a cross-translation-unit
call to this function for the WebAssembly compiler.

The two object-data setup calls in `src/ui.c` omit their unused argument,
matching the parameterless definitions (which read `button_box_xml` globally).

`src/config_file.c` declares `prefs` extern; its storage is defined in main.c.
This removes reliance on the old GCC common-symbol merging default.
