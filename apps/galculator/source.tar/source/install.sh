#!/bin/sh
set -e
stage=$1
cd /usr/src/galculator
mkdir -p "$stage/bin" "$stage/libexec" "$stage/share/galculator/ui" "$stage/share/doc/galculator" "$stage/share/pixmaps" "$stage/share/applications"
cc -DHAVE_CONFIG_H -Iport -Isrc src/main.c src/math_functions.c src/display.c src/general_functions.c src/calc_basic.c src/config_file.c src/callbacks.c src/ui.c port/flex_parser.c $(pkg-config --cflags --libs gtk+-3.0) -lgmodule-2.0 -lintl -lm -rdynamic -o "$stage/libexec/galculator"
cp ui/*.ui "$stage/share/galculator/ui/"
sed 's/@VERSION@/2.1.4/g' ui/about.ui.in > "$stage/share/galculator/ui/about.ui"
cp COPYING PORT.md "$stage/share/doc/galculator/"
cp pixmaps/galculator.png "$stage/share/pixmaps/"
cat > "$stage/bin/galculator" <<'LAUNCH'
#!/bin/sh
export WASM_POSIX_SURFACES=1
exec /usr/local/libexec/galculator "$@"
LAUNCH
chmod +x "$stage/bin/galculator"

cat > "$stage/share/applications/galculator.desktop" <<'APP'
[Desktop Entry]
Type=Application
Name=Scientific Calculator
Exec=galculator
Icon=galculator
Categories=Utility;Calculator;
Terminal=false
APP
