#!/bin/sh
set -e
stage=$1
cd /usr/src/nyancat
mkdir -p "$stage/bin" "$stage/share/doc/nyancat"
cc -O2 nyancat.c -o "$stage/bin/nyancat"
cp README.md UPSTREAM.json "$stage/share/doc/nyancat/"
cp nyancat.c "$stage/share/doc/nyancat/"
mkdir -p "$stage/share/man/man1"
cp nyancat.1 "$stage/share/man/man1/"
