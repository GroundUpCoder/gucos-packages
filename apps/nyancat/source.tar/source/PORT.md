# Nyan Cat

Unchanged upstream C sources from klange/nyancat. UPSTREAM.json pins the
revision and checksums. The NCSA license is in nyancat.c and retained both in
the source bundle and installed documentation; README.md credits the animation.

`gucman install nyancat`, then `nyancat`. Ctrl-C exits. For a bounded animation
use `nyancat -f 20`. `npm run test:entertainment` checks rendered terminal frames
and interruption. This port tests local terminal mode, not telnet serving.
