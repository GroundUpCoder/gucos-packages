import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('nyancat',1700000);
try {
 const script=await readFile(new URL('./nyancat-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['nyancat'],fresh:['nyancat']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.ok(log.includes('NYANCAT-ACCEPTANCE-PASS'),log);
 await page.evaluate(()=>shell.terminal.focus());
 await page.keyboard.type('sh');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>shell.busybox?.ready&&shell.ui.session===shell.busybox);
 await page.keyboard.type('nyancat -I -s');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>shell.busybox.log.includes('You have nyaned for'));
 const backgrounds=await page.evaluate(()=>{
  const b=shell.terminal.buffer.active,colors=new Set();
  for(let y=0;y<b.length;y++){
   const row=b.getLine(y);if(!row)continue;
   for(let x=0;x<row.length;x++){const c=row.getCell(x);if(c?.getBgColorMode())colors.add(c.getBgColor());}
  }
  return [...colors];
 });
 assert.ok(backgrounds.length>=5,'rendered multicolor frame');
 await page.keyboard.press('Control+c');
 await page.keyboard.type('echo NYANCAT-INTERACTIVE-PASS');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>shell.busybox.log.includes('\nNYANCAT-INTERACTIVE-PASS\n'));
 await page.keyboard.type('exit');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>!shell.ui.session&&!shell.ui.busy);
 assert.deepEqual(errors,[]);
} finally {await close();}
