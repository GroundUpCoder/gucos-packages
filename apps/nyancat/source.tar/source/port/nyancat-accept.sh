set -e
gucman install nyancat
TERM=xterm nyancat -I -s -n -e -r 20 -R 40 -c 15 -C 50 -f 1 > /tmp/nyan-one
TERM=xterm nyancat -I -s -n -e -r 20 -R 40 -c 15 -C 50 -f 2 > /tmp/nyan-two
test "$(wc -c < /tmp/nyan-one)" -gt 100
test "$(wc -c < /tmp/nyan-two)" -gt "$(wc -c < /tmp/nyan-one)"

cmp /tmp/nyan-one /usr/src/nyancat/port/native-1.ansi
cmp /tmp/nyan-two /usr/src/nyancat/port/native-2.ansi
echo NYANCAT-ACCEPTANCE-PASS
