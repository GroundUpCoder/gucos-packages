proc check {actual expected} {if {$actual ne $expected} {error "expected <$expected>, got <$actual>"}}
check [package require Tk] 8.6.16
check [tk windowingsystem] x11
wm title . TK_PORT
wm geometry . 500x420+20+20
option add *Font fixed
entry .entry -textvariable typed
button .button -text Run -command {set clicked 1}
text .text -height 3 -width 30
.text insert end "Tk text widget\nsecond line"
check [.text get 1.0 1.end] {Tk text widget}
canvas .canvas -width 200 -height 80 -background white
set r [.canvas create rectangle 10 10 80 60 -fill red]
check [.canvas itemcget $r -fill] red
check [.canvas coords $r] {10.0 10.0 80.0 60.0}
image create photo sample -width 2 -height 2
sample put {{red blue} {green white}}
check [sample get 0 0] {255 0 0}
sample write /tmp/tk-image.png -format png
image create photo restored -file /tmp/tk-image.png
check [restored get 1 0] {0 0 255}
ttk::notebook .tabs
ttk::frame .tabs.one
.tabs add .tabs.one -text First
ttk::treeview .tree -columns value
.tree insert {} end -id row -text Test -values 42
check [.tree set row value] 42
pack .entry .button .text .canvas .tabs .tree -fill x
clipboard clear
clipboard append {Tk clipboard}
check [clipboard get] {Tk clipboard}
update
check [winfo ismapped .entry] 1
focus -force .entry
bind .entry <Return> {
    if {$typed ne "hello 123/A_!"} {puts stderr "wrong input: $typed"; exit 1}
    puts TK-INPUT-PASS
    flush stdout
    destroy .
}
after 60000 {puts stderr "browser input timeout"; exit 1}
puts TK-INPUT-READY
flush stdout
