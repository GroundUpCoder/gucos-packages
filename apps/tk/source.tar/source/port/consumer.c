#include <stdio.h>
#include <tcl.h>
#include <tk.h>
int main(int argc, char **argv) {
    Tcl_FindExecutable(argv[0]);
    Tcl_Interp *interp = Tcl_CreateInterp();
    if (Tcl_Init(interp) != TCL_OK || Tk_Init(interp) != TCL_OK ||
        Tcl_Eval(interp, "label .test -text {Installed Tk SDK}; pack .test; update; if {![winfo ismapped .test]} {error unmapped}; destroy .") != TCL_OK) {
        fprintf(stderr, "%s\n", Tcl_GetStringResult(interp));
        return 1;
    }
    Tcl_DeleteInterp(interp);
    Tcl_Finalize();
    puts("TK-CONSUMER-PASS");
    return 0;
}
