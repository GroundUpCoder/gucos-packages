#!/bin/sh
set -e
stage=$1
cd /usr/src/twm
mkdir -p "$stage/bin" "$stage/share/X11/twm" "$stage/share/doc/twm" /tmp/twm-build
for file in twm-1.0.13.1/src/*.c; do
 name=${file##*/}
 cc -O2 -DHAVE_CONFIG_H -DAPP_VERSION='"1.0.13.1"' -DDATADIR='"/usr/local/share"' -I. -I/usr/local/include -c "$file" -o "/tmp/twm-build/${name%.c}.o"
done
cc /tmp/twm-build/*.o -L/usr/local/lib -lXrandr -lXrender -lXmu -lXt -lSM -lICE -lXext -lX11 -lxcb -lXau -o "$stage/bin/twm"
cp twm-1.0.13.1/src/system.twmrc "$stage/share/X11/twm/"
cp twm-1.0.13.1/COPYING "$stage/share/doc/twm/"
cp wasm.twmrc "$stage/share/X11/twm/"
