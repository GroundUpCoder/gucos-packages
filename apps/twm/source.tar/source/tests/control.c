#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/XTest.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static Display *d;
static Window root;
static Window find(Window w,const char *name){
 char *s=NULL;Window r,p,*children=NULL,result=0;unsigned count=0;
 if(XFetchName(d,w,&s)&&s){int same=!strcmp(s,name);XFree(s);if(same)return w;}
 if(XQueryTree(d,w,&r,&p,&children,&count)){for(unsigned i=0;i<count&&!result;i++)result=find(children[i],name);if(children)XFree(children);}
 return result;
}
static Window parent(Window w){Window r,p,*c=NULL;unsigned n;assert(XQueryTree(d,w,&r,&p,&c,&n));if(c)XFree(c);return p;}
static XWindowAttributes attr(Window w){XWindowAttributes a;assert(XGetWindowAttributes(d,w,&a));return a;}
static void pause_ms(int n){XSync(d,False);usleep(n*1000);}
static void motion(int x,int y){XTestFakeMotionEvent(d,-1,x,y,0);pause_ms(100);}
static void button(int b,int down){XTestFakeButtonEvent(d,b,down,0);pause_ms(150);}
static void click(int x,int y,int b){motion(x,y);button(b,1);button(b,0);}
static Window wait_name(const char *name){Window w;for(int i=0;i<200;i++){w=find(root,name);if(w)return w;pause_ms(100);}fprintf(stderr,"Missing %s\n",name);exit(1);}
static void marker(const char *s){FILE *f=fopen("/tmp/twm-stage","w");assert(f);fputs(s,f);fclose(f);printf("TWM %s\n",s);fflush(stdout);}
static long state(Window w,Window *icon){Atom actual;int format;unsigned long n,left;unsigned char *v=NULL;long result=-1;XGetWindowProperty(d,w,XInternAtom(d,"WM_STATE",False),0,2,False,AnyPropertyType,&actual,&format,&n,&left,&v);if(n>=2){result=((long*)v)[0];if(icon)*icon=((long*)v)[1];}if(v)XFree(v);return result;}
int main(void){
 d=XOpenDisplay(NULL);assert(d);root=DefaultRootWindow(d);XTestGrabControl(d,True);
 Window a=wait_name("TWM_TERMINAL"),b=wait_name("TWM_WIDGETS");
 for(int i=0;i<100&&(parent(a)==root||parent(b)==root);i++)pause_ms(100);
 Window frame=parent(a);assert(frame!=root&&parent(b)!=root&&frame!=parent(b));
 XWindowAttributes ca=attr(a),fa=attr(frame);assert(fa.height>ca.height&&ca.y>0);assert(state(a,NULL)==NormalState);marker("decorated");
 /* Real browser input drives title-bar move. */
 FILE *f=fopen("/tmp/twm-geometry","w");fprintf(f,"%d %d %d %d %d",fa.x,fa.y,fa.width,fa.height,ca.y);fclose(f);
 for(int i=0;i<200;i++){XWindowAttributes now=attr(frame);if(now.x!=fa.x||now.y!=fa.y)break;pause_ms(100);}
 XWindowAttributes moved=attr(frame);assert(moved.x>fa.x+40&&moved.y>fa.y+20);marker("moved");
 /* f.resize starts at title, then crosses the bottom-right frame edge. */
 motion(moved.x+moved.width/2,moved.y+ca.y/2);button(3,1);
 motion(moved.x+moved.width-3,moved.y+moved.height-3);
 motion(moved.x+moved.width+90,moved.y+moved.height+55);button(3,0);
 XWindowAttributes resized=attr(a);printf("RESIZED %dx%d -> %dx%d\n",ca.width,ca.height,resized.width,resized.height);assert(resized.width>ca.width&&resized.height>ca.height);marker("resized");
 /* Pointer focus must reach both independent clients through twm. */
 XWindowAttributes fb=attr(parent(b));motion(fb.x+50,fb.y+60);Window focus;int revert;XGetInputFocus(d,&focus,&revert);assert(focus==b||parent(focus)==b);
 motion(moved.x+60,moved.y+80);XGetInputFocus(d,&focus,&revert);assert(focus==a||parent(focus)==a);marker("focused");
 click(moved.x+100,moved.y+ca.y/2,2);Window icon=0;
 for(int i=0;i<100&&state(a,&icon)!=IconicState;i++)pause_ms(100);
 assert(state(a,&icon)==IconicState&&icon);assert(attr(frame).map_state==IsUnmapped);assert(attr(icon).map_state==IsViewable);marker("iconified");
 XWindowAttributes ia=attr(icon);click(ia.x+ia.width/2,ia.y+ia.height/2,1);
 for(int i=0;i<100&&state(a,NULL)!=NormalState;i++)pause_ms(100);
 assert(state(a,NULL)==NormalState&&attr(frame).map_state==IsViewable);marker("restored");
 /* Root menu: select its second row to launch a real xterm via f.exec. */
 motion(950,100);button(1,1);motion(970,120);button(1,0);
 Window menuclient=wait_name("MENU_TERMINAL");for(int i=0;i<100&&parent(menuclient)==root;i++)pause_ms(100);assert(parent(menuclient)!=root);marker("screenshot");
 for(int i=0;i<300&&access("/tmp/twm-captured",F_OK);i++)pause_ms(100);
 assert(access("/tmp/twm-captured",F_OK)==0);
 motion(950,100);button(1,1);motion(970,135);button(1,0);
 for(int i=0;i<100&&parent(a)!=root;i++)pause_ms(100);
 assert(parent(a)==root&&parent(b)==root);assert(attr(a).map_state==IsViewable);marker("quit");
 XCloseDisplay(d);return 0;
}
