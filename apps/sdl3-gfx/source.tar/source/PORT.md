# SDL3 surface drawing primitives

This package provides the SDL_gfx 2.0.23 surface primitives bundled with the
pinned pygame-ce source in `apps/pygame-ce/UPSTREAM.json`, adapted to SDL3 in
commit c318f09a. It installs static and shared libraries, a public header and
pkg-config metadata. LGPL terms are in LICENSE. The C sources remain available
alongside the recipe for rebuilding and relinking.

This is pygame's surface-based fork: pixels, lines, circles, ellipses, polygons,
Bezier curves and textured polygons. It is not the renderer-based SDL2_gfx API.
Font/string routines, FPS management and rotozoom are not included. pygame's
transform module supplies its own transforms. SDL3 clip, format, palette, lock
and blit adaptations are retained; the installed header always selects SDL3.

Acceptance exercises installed shared and static consumers, exact opaque pixels,
clipping, alpha blending, geometry and repeated drawing timings. Source and
binary phases both run on fresh disks. Timing samples are recorded separately
from correctness and can be compared using the same host/browser configuration.
