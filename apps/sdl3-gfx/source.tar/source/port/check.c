#include <SDL3_gfx/SDL_gfxPrimitives.h>
#include <assert.h>
#include <stdio.h>
static void pixel(SDL_Surface *s,int x,int y,int r,int g,int b){
 Uint8 R,G,B,A;assert(SDL_ReadSurfacePixel(s,x,y,&R,&G,&B,&A));assert(R==r&&G==g&&B==b);
}
int main(void){
 SDL_Surface *s=SDL_CreateSurface(128,128,SDL_PIXELFORMAT_RGBA32); assert(s);
 assert(SDL_FillSurfaceRect(s,NULL,SDL_MapSurfaceRGBA(s,0,0,0,255)));
 assert(boxRGBA(s,2,2,10,10,255,0,0,255)==0);pixel(s,2,2,255,0,0);pixel(s,10,10,255,0,0);pixel(s,11,10,0,0,0);
 SDL_Rect clip={20,20,4,4};assert(SDL_SetSurfaceClipRect(s,&clip));
 assert(boxRGBA(s,18,18,25,25,0,255,0,255)==0);pixel(s,20,20,0,255,0);pixel(s,19,20,0,0,0);pixel(s,24,20,0,0,0);
 assert(SDL_SetSurfaceClipRect(s,NULL));
 assert(pixelRGBA(s,30,30,255,0,0,128)==0);
 Uint8 r,g,b,a;assert(SDL_ReadSurfacePixel(s,30,30,&r,&g,&b,&a));assert(r>=127&&r<=128&&g==0&&b==0);
 assert(filledCircleRGBA(s,60,60,8,0,0,255,255)==0);pixel(s,60,60,0,0,255);pixel(s,69,60,0,0,0);
 Sint16 x[]={80,100,90},y[]={80,80,100};assert(filledPolygonRGBA(s,x,y,3,255,255,0,255)==0);pixel(s,90,85,255,255,0);
 SDL_Surface *indexed=SDL_CreateSurface(4,4,SDL_PIXELFORMAT_INDEX8);assert(indexed);
 SDL_Palette *palette=SDL_CreateSurfacePalette(indexed);assert(palette);
 SDL_Color colors[2]={{0,0,0,255},{255,0,0,255}};assert(SDL_SetPaletteColors(palette,colors,0,2));
 assert(pixelRGBA(indexed,1,1,255,0,0,255)==0);pixel(indexed,1,1,255,0,0);SDL_DestroySurface(indexed);
 for(int sample=-1;sample<5;sample++){
  Uint64 start=SDL_GetPerformanceCounter();
  for(int i=0;i<500;i++){
   assert(boxRGBA(s,0,0,127,127,0,0,0,255)==0);
   assert(aacircleRGBA(s,64,64,35,255,0,0,255)==0);
   assert(filledPolygonRGBA(s,x,y,3,0,255,0,160)==0);
  }
  double ms=1000.0*(SDL_GetPerformanceCounter()-start)/SDL_GetPerformanceFrequency();
  if(sample>=0)printf("SDL3-GFX-BENCH %.6f\n",ms);
 }
 SDL_DestroySurface(s);puts("SDL3-GFX-PASS");return 0;
}
