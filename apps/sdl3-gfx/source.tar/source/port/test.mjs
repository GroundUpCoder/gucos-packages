import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,output,close}=await appBrowser('sdl3-gfx',600000);
try {
 const result=await runCached(page,`set -e
gucman install sdl3-gfx
cd /tmp
cc /usr/src/sdl3-gfx/port/check.c -lSDL3_gfx -lSDL3 -lm -o gfx-shared
./gfx-shared
cc /usr/src/sdl3-gfx/port/check.c /usr/local/lib/libSDL3_gfx.a -lSDL3 -lm -o gfx-static
./gfx-static
`,{packages:['sdl3-gfx'],fresh:['sdl3-gfx']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log.slice(-6000));
 assert.equal((log.match(/SDL3-GFX-PASS/g)||[]).length,2,log);
 const samples=[...log.matchAll(/SDL3-GFX-BENCH ([\d.]+)/g)].map(m=>Number(m[1]));
 assert.equal(samples.length,10);assert.ok(samples.every(x=>Number.isFinite(x)&&x>0));
 await writeFile(output+'/performance.json',JSON.stringify({browser:await page.context().browser().version(),shared_ms:samples.slice(0,5),static_ms:samples.slice(5)},null,2));
 assert.deepEqual(errors,[]);
 console.log('PASS SDL3_gfx installed static/shared primitives, clipping, palette, alpha and performance samples');
} finally {await close();}
