/* Sample-only dynamic bindings. The installed headers are upstream FreeType.
 * Define FT_DLOPEN to exercise explicit plugin loading instead of normal linking. */
#ifndef SAMPLE_FREETYPE_LOAD_H
#define SAMPLE_FREETYPE_LOAD_H
#include <stdio.h>
#include <stdlib.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_OUTLINE_H
#include FT_FONT_FORMATS_H
#ifdef FT_DLOPEN
#include <dlfcn.h>
#define FT_API(ret, name, args) static ret (*p_##name) args
FT_API(FT_Error, FT_Init_FreeType, (FT_Library *));
FT_API(FT_Error, FT_Done_FreeType, (FT_Library));
FT_API(void, FT_Library_Version, (FT_Library, FT_Int *, FT_Int *, FT_Int *));
FT_API(FT_Error, FT_New_Face, (FT_Library, const char *, FT_Long, FT_Face *));
FT_API(FT_Error, FT_New_Memory_Face, (FT_Library, const FT_Byte *, FT_Long, FT_Long, FT_Face *));
FT_API(FT_Error, FT_Done_Face, (FT_Face));
FT_API(FT_Error, FT_Set_Pixel_Sizes, (FT_Face, FT_UInt, FT_UInt));
FT_API(FT_UInt, FT_Get_Char_Index, (FT_Face, FT_ULong));
FT_API(FT_Error, FT_Load_Char, (FT_Face, FT_ULong, FT_Int32));
FT_API(FT_Error, FT_Get_Kerning, (FT_Face, FT_UInt, FT_UInt, FT_UInt, FT_Vector *));
FT_API(FT_Error, FT_Outline_Decompose, (FT_Outline *, const FT_Outline_Funcs *, void *));
FT_API(const char *, FT_Get_Font_Format, (FT_Face));
#undef FT_API
#define FT_Init_FreeType p_FT_Init_FreeType
#define FT_Done_FreeType p_FT_Done_FreeType
#define FT_Library_Version p_FT_Library_Version
#define FT_New_Face p_FT_New_Face
#define FT_New_Memory_Face p_FT_New_Memory_Face
#define FT_Done_Face p_FT_Done_Face
#define FT_Set_Pixel_Sizes p_FT_Set_Pixel_Sizes
#define FT_Get_Char_Index p_FT_Get_Char_Index
#define FT_Load_Char p_FT_Load_Char
#define FT_Get_Kerning p_FT_Get_Kerning
#define FT_Outline_Decompose p_FT_Outline_Decompose
#define FT_Get_Font_Format p_FT_Get_Font_Format
static void *ft_module;
#endif
static void check(int ok, const char *what) {
  if (!ok) { fprintf(stderr, "FreeType sample failed: %s\n", what); exit(1); }
}
static void ft_open(void) {
#ifdef FT_DLOPEN
  ft_module = dlopen("libfreetype.so", RTLD_NOW | RTLD_LOCAL);
  if (!ft_module) { fprintf(stderr, "dlopen: %s\nRun gucman install freetype first.\n", dlerror()); exit(1); }
#define LOAD(name) do { p_##name = dlsym(ft_module, #name); check(p_##name != NULL, #name); } while (0)
  LOAD(FT_Init_FreeType); LOAD(FT_Done_FreeType); LOAD(FT_Library_Version);
  LOAD(FT_New_Face); LOAD(FT_New_Memory_Face); LOAD(FT_Done_Face);
  LOAD(FT_Set_Pixel_Sizes); LOAD(FT_Get_Char_Index); LOAD(FT_Load_Char);
  LOAD(FT_Get_Kerning); LOAD(FT_Outline_Decompose); LOAD(FT_Get_Font_Format);
#undef LOAD
#endif
}
static void ft_close(void) {
#ifdef FT_DLOPEN
  check(dlclose(ft_module) == 0, "dlclose");
#endif
}
#endif
