/* Render an ASCII sample to a portable grayscale (PGM) image.
 * This demonstrates rasterization, not Unicode text shaping/layout. */
#include "load.h"
#include <string.h>
#define WIDTH 720
#define HEIGHT 180
static unsigned char pixels[WIDTH * HEIGHT];
int main(int argc, char **argv) {
  FT_Library lib; FT_Face face;
  const char *text = "FreeType in wasm-posix!";
  int sizes[] = {16, 28, 40};
  check(argc == 3, "usage: ft-render FONT OUTPUT.pgm");
  ft_open(); check(!FT_Init_FreeType(&lib), "init");
  check(!FT_New_Face(lib, argv[1], 0, &face), "load font");
  memset(pixels, 255, sizeof pixels);
  for (int line = 0; line < 3; line++) {
    int pen = 16, baseline = 32 + 60 * line; FT_UInt previous = 0;
    check(!FT_Set_Pixel_Sizes(face, 0, sizes[line]), "set size");
    for (const char *p = text; *p; p++) {
      FT_UInt glyph = FT_Get_Char_Index(face, (unsigned char)*p); FT_Vector kern;
      check(!FT_Get_Kerning(face, previous, glyph, FT_KERNING_DEFAULT, &kern), "kerning");
      pen += kern.x / 64;
      check(!FT_Load_Char(face, (unsigned char)*p, FT_LOAD_RENDER), "render");
      FT_GlyphSlot g = face->glyph;
      check(g->bitmap.pixel_mode == FT_PIXEL_MODE_GRAY, "grayscale bitmap");
      for (unsigned y = 0; y < g->bitmap.rows; y++) for (unsigned x = 0; x < g->bitmap.width; x++) {
        int dx = pen + g->bitmap_left + x, dy = baseline - g->bitmap_top + y;
        if (dx >= 0 && dx < WIDTH && dy >= 0 && dy < HEIGHT) {
          unsigned value = 255 - g->bitmap.buffer[(int)y * g->bitmap.pitch + x];
          if (value < pixels[dy * WIDTH + dx]) pixels[dy * WIDTH + dx] = value;
        }
      }
      pen += g->advance.x / 64; previous = glyph;
    }
  }
  FILE *f = fopen(argv[2], "wb"); check(f != NULL, "open output");
  check(fprintf(f, "P5\n%d %d\n255\n", WIDTH, HEIGHT) > 0, "write header");
  check(fwrite(pixels, 1, sizeof pixels, f) == sizeof pixels, "write pixels");
  check(!fclose(f), "close output");
  check(!FT_Done_Face(face), "done face"); check(!FT_Done_FreeType(lib), "done library");
  ft_close(); puts("FREETYPE-RENDER-PASS"); return 0;
}
