/* Upstream's standalone tool omits the header declaring FT_Outline_Get_CBox.
 * Supply it without changing the test source. */
#include <ft2build.h>
#include FT_OUTLINE_H
#include "../src/tools/test_bbox.c"
