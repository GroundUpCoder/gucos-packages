set -eu
mkdir -p "$DESTDIR/bin"
cc /usr/src/sdk-freetype/consumer.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o "$DESTDIR/bin/sdk-freetype-consumer"
