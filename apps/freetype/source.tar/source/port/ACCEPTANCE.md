# Independent FreeType acceptance

`node tools/package-job.mjs run freetype` runs `port/test.mjs` against a source
build and a separate binary-only disk. The guest only compiles test consumers
against installed headers and the installed shared/static libraries. It exercises
TrueType and CFF fonts, memory faces, invalid input, glyph metrics, raster output,
outline callbacks, and persisted loading after a browser reload.

The unchanged upstream issue-1063 and trigonometry tests run against the installed
library. The unchanged upstream bounding-box tool is included through the existing
header wrapper. Host-native builds of the same vendored sources provide independent
metric, pixel, and upstream-output oracles in each phase; they never populate the
guest package cache. Bounding-box timings are excluded from output comparisons.
The issue-1063 font is downloaded into the private test output directory and its
archive SHA-256 is verified, as in the original top-level acceptance test.

The manifest lists every guest test source and font needed on the binary-only disk.
No pkgconf dependency is needed: the consumers use explicit installed include and
library paths. Package rebuild/failure-injection testing remains in the original
integration suite because binary acceptance forbids package source builds.
