/* Glyph metrics, raster checksums, memory faces and outline callbacks.
 * Output is also compared with a native build by tests/freetype.mjs. */
#include "load.h"
#include <stdint.h>
static int move_to(const FT_Vector *v, void *user) { (*(int *)user)++; return 0; }
static int line_to(const FT_Vector *v, void *user) { (*(int *)user)++; return 0; }
static int conic_to(const FT_Vector *a, const FT_Vector *b, void *user) { (*(int *)user)++; return 0; }
static int cubic_to(const FT_Vector *a, const FT_Vector *b, const FT_Vector *c, void *user) { (*(int *)user)++; return 0; }
int main(int argc, char **argv) {
  FT_Library lib; FT_Face face, memory_face, bad_face;
  FT_Int major, minor, patch;
  unsigned char bad[32] = {0};
  int sizes[] = {12, 24, 48};
  FT_Int32 modes[] = {FT_LOAD_RENDER, FT_LOAD_RENDER | FT_LOAD_FORCE_AUTOHINT,
                       FT_LOAD_RENDER | FT_LOAD_TARGET_MONO | FT_LOAD_MONOCHROME};
  check(argc == 2, "usage: ft-inspect FONT");
  ft_open(); check(!FT_Init_FreeType(&lib), "init");
  FT_Library_Version(lib, &major, &minor, &patch);
  printf("FreeType %d.%d.%d\n", major, minor, patch);
  check(!FT_New_Face(lib, argv[1], 0, &face), "file face");
  printf("%s / %s: %s, %ld glyphs\n", face->family_name, face->style_name,
         FT_Get_Font_Format(face), face->num_glyphs);
  FILE *f = fopen(argv[1], "rb"); check(f != NULL, "open font");
  check(!fseek(f, 0, SEEK_END), "seek"); long length = ftell(f);
  check(length > 0 && !fseek(f, 0, SEEK_SET), "font length");
  unsigned char *data = malloc(length); check(data != NULL, "font allocation");
  check(fread(data, 1, length, f) == (size_t)length, "read font"); fclose(f);
  check(!FT_New_Memory_Face(lib, data, length, 0, &memory_face), "memory face");
  check(memory_face->num_glyphs == face->num_glyphs, "memory/file agreement");
  check(FT_New_Memory_Face(lib, bad, sizeof bad, 0, &bad_face) != 0, "invalid font rejected");
  check(FT_New_Memory_Face(lib, data, 16, 0, &bad_face) != 0, "truncated font rejected");
  check(FT_New_Face(lib, "/no-such-font.ttf", 0, &bad_face) != 0, "missing font rejected");
  check(FT_Get_Char_Index(face, 0x10ffff) == 0, "missing character");
  for (int s = 0; s < 3; s++) for (int m = 0; m < 3; m++) {
    uint32_t hash = 2166136261u; long advances = 0; int ink = 0;
    check(!FT_Set_Pixel_Sizes(face, 0, sizes[s]), "set size");
    check(!FT_Set_Pixel_Sizes(memory_face, 0, sizes[s]), "memory size");
    for (unsigned ch = 32; ch <= 126; ch++) {
      check(!FT_Load_Char(face, ch, modes[m]), "render character");
      check(!FT_Load_Char(memory_face, ch, modes[m]), "render memory character");
      FT_GlyphSlot g = face->glyph, other = memory_face->glyph;
      check(g->advance.x == other->advance.x && g->bitmap.width == other->bitmap.width &&
            g->bitmap.rows == other->bitmap.rows, "memory glyph metrics");
      advances += g->advance.x;
      hash = (hash ^ (uint32_t)g->bitmap_left) * 16777619u;
      hash = (hash ^ (uint32_t)g->bitmap_top) * 16777619u;
      for (unsigned y = 0; y < g->bitmap.rows; y++) for (unsigned x = 0; x < g->bitmap.width; x++) {
        unsigned char *row = g->bitmap.buffer + (int)y * g->bitmap.pitch;
        unsigned char *other_row = other->bitmap.buffer + (int)y * other->bitmap.pitch;
        unsigned pixel = m == 2 ? ((row[x / 8] >> (7 - x % 8)) & 1) * 255 : row[x];
        unsigned other_pixel = m == 2 ? ((other_row[x / 8] >> (7 - x % 8)) & 1) * 255 : other_row[x];
        check(pixel == other_pixel, "memory glyph pixels");
        hash = (hash ^ pixel) * 16777619u; ink += pixel != 0;
      }
    }
    check(ink > 0, "nonempty raster");
    printf("size=%d mode=%d advances=%ld ink=%d hash=%08x\n", sizes[s], m, advances, ink, hash);
  }
  FT_Vector kern; check(!FT_Get_Kerning(face, FT_Get_Char_Index(face, 'A'),
                    FT_Get_Char_Index(face, 'V'), FT_KERNING_DEFAULT, &kern), "kerning");
  printf("AV kerning=%ld,%ld\n", kern.x, kern.y);
  check(!FT_Load_Char(face, 'S', FT_LOAD_NO_BITMAP), "outline glyph");
  int callbacks = 0; FT_Outline_Funcs funcs = {move_to, line_to, conic_to, cubic_to, 0, 0};
  check(!FT_Outline_Decompose(&face->glyph->outline, &funcs, &callbacks), "outline callbacks");
  check(callbacks > 0, "outline callback count"); printf("outline callbacks=%d\n", callbacks);
  check(!FT_Done_Face(memory_face), "done memory face"); free(data);
  check(!FT_Done_Face(face), "done face"); check(!FT_Done_FreeType(lib), "done library");
  ft_close(); puts("FREETYPE-INSPECT-PASS"); return 0;
}
