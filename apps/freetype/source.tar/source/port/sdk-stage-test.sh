set -eu
/usr/local/bin/sdk-freetype-consumer
