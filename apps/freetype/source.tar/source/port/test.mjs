import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
// Build/install the real shared library in browser processes, then compare
// metrics and every rendered pixel with the same sources compiled natively.
import assert from 'node:assert/strict';
import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const {page,errors,output:out,close}=await appBrowser('freetype',900000);
try {
const root=resolve('vendor/freetype');
await mkdir(out,{recursive:true});
const manifest=JSON.parse(await readFile(root+'/lib.json','utf8'));
const compiler=process.env.CC||'cc';
for(const sample of ['inspect','render']) {
 execFileSync(compiler,['-O2','-DFT2_BUILD_LIBRARY','-DFT_NATIVE','-I'+root+'/include',
   ...manifest.sources.map(s=>root+'/'+s),root+'/port/'+sample+'.c','-o',out+'/native-'+sample],{stdio:'inherit'});
}
const fonts=['ABeeZee-Regular.ttf','SourceCodePro-Regular.otf'];
for(const font of fonts) {
 await writeFile(out+'/'+font+'.expected.txt',execFileSync(out+'/native-inspect',[root+'/port/fonts/'+font]));
 execFileSync(out+'/native-render',[root+'/port/fonts/'+font,out+'/'+font+'.expected.pgm']);
}
// Upstream's Meson suite registers issue-1063. Fetch its exact fixture for
// testing only; it is not redistributed in the boot image.
const zipPath=out+'/issue-1063.zip';
let zip;try{zip=await readFile(zipPath);}catch{
 const response=await fetch('https://github.com/python-pillow/Pillow/files/6622147/As.I.Lay.Dying.zip');
 if(!response.ok)throw new Error('FreeType test font download: '+response.status);
 zip=Buffer.from(await response.arrayBuffer());await writeFile(zipPath,zip);
}
assert.equal(createHash('sha256').update(zip).digest('hex'),'09fceee7c335975a454500b000f75ee7f7b5c4f14b2dc241d6416f77967e9d1b');
const regressionFont=execFileSync('unzip',['-p',zipPath,'As I Lay Dying.ttf']);
await writeFile(out+'/As.I.Lay.Dying.ttf',regressionFont);
const upstream=[['issue-1063','tests/issue-1063/main.c'],['trig','src/tools/test_trig.c'],['bbox','port/test-bbox.c']];
const expectedUpstream={};
for(const [name,source] of upstream){
 execFileSync(compiler,['-O2','-Wno-implicit-int','-Wno-implicit-function-declaration','-DFT2_BUILD_LIBRARY','-I'+root+'/include',...manifest.sources.map(s=>root+'/'+s),root+'/'+source,'-o',out+'/native-'+name],{stdio:'inherit'});
 const result=spawnSync(out+'/native-'+name,[],{encoding:'utf8',env:{...process.env,FREETYPE_TESTS_DATA_DIR:out}});
 assert.equal(result.status,name==='trig'?1:0,result.stderr); // upstream trig returns 1 on success
 if(name==='issue-1063')assert.equal(result.stdout,'');
 if(name==='trig')assert.match(result.stdout,/trigonometry test ok/);
 expectedUpstream[name]=result.stdout;
}
// The upstream tool multiplies clock_t by 10000 before dividing. That
// overflows 32-bit long; timings (including negative ones) are not an oracle.
const normalizeBBox=text=>text.replace(/time =\s*[+-]?[0-9.]+/g,'time = <elapsed>');
const script=`set -e
gucman install freetype
test -f /usr/local/lib/libfreetype.so
test -f /usr/local/lib/libfreetype.a
test -f /usr/local/include/freetype2/ft2build.h
gucman list
cc /usr/src/freetype/port/inspect.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o /tmp/ft-inspect
cc /usr/src/freetype/port/render.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o /tmp/ft-render
cc -static /usr/src/freetype/port/inspect.c -I/usr/local/include/freetype2 /usr/local/lib/libfreetype.a -o /tmp/ft-inspect-static
/tmp/ft-inspect-static /usr/src/freetype/port/fonts/ABeeZee-Regular.ttf > /tmp/static-inspect.txt
/tmp/ft-inspect /usr/src/freetype/port/fonts/ABeeZee-Regular.ttf > /tmp/shared-inspect.txt
cmp /tmp/static-inspect.txt /tmp/shared-inspect.txt
for font in ${fonts.join(' ')}; do
 /tmp/ft-inspect /usr/src/freetype/port/fonts/$font > /tmp/$font.txt
 cat /tmp/$font.txt
 /tmp/ft-render /usr/src/freetype/port/fonts/$font /tmp/$font.pgm
 base64 /tmp/$font.pgm > /tmp/$font.b64
done
base64 -d /tmp/regression-font.b64 > /tmp/As.I.Lay.Dying.ttf
cc /usr/src/freetype/tests/issue-1063/main.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o /tmp/ft-issue-1063
FREETYPE_TESTS_DATA_DIR=/tmp /tmp/ft-issue-1063 > /tmp/issue-1063.txt
cc --allow-implicit-int /usr/src/freetype/src/tools/test_trig.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o /tmp/ft-trig
status=0
/tmp/ft-trig > /tmp/trig.txt || status=$?
test "$status" -eq 1
cc /usr/src/freetype/port/test-bbox.c -I/usr/local/include/freetype2 -L/usr/local/lib -lfreetype -o /tmp/ft-bbox
/tmp/ft-bbox > /tmp/bbox.txt
gucman install freetype
echo FREETYPE-PASS
`;
await page.evaluate(font=>{shell.files['/tmp/regression-font.b64']=font;},regressionFont.toString('base64'));
 const result=await runCached(page,script,{packages:['freetype'],fresh:['freetype']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);assert.match(log,/FREETYPE-PASS/);assert.match(log,/freetype\s+installed/);
 for(const font of fonts) {
   const files=await page.evaluate(async font=>({metrics:new TextDecoder().decode(await shell.busybox.read('/tmp/'+font+'.txt')),image:new TextDecoder().decode(await shell.busybox.read('/tmp/'+font+'.b64'))}),font);
   assert.equal(files.metrics,await readFile(out+'/'+font+'.expected.txt','utf8'));
   const pgm=Buffer.from(files.image,'base64');await writeFile(out+'/'+font+'.pgm',pgm);
   assert.deepEqual(pgm,await readFile(out+'/'+font+'.expected.pgm'));

 }
 for(const [name] of upstream){
   const actual=await page.evaluate(async name=>new TextDecoder().decode(await shell.busybox.read('/tmp/'+name+'.txt')),name);
   await writeFile(out+'/'+name+'.actual.txt',actual);
   await writeFile(out+'/'+name+'.expected.txt',expectedUpstream[name]);
   assert.equal(name==='bbox'?normalizeBBox(actual):actual,name==='bbox'?normalizeBBox(expectedUpstream[name]):expectedUpstream[name]);
 }
 // A fresh process after reload must load the persisted library without a rebuild.
 await page.reload();await page.waitForFunction(()=>window.shell?.ready);
 const reload=await page.evaluate(()=>shell.command('sh -c "gucman install freetype && /tmp/ft-inspect /usr/src/freetype/port/fonts/ABeeZee-Regular.ttf"'));
 assert.equal(reload.code,0);
 const reloadLog=await page.evaluate(()=>shell.busybox.log);
 assert.match(reloadLog,/FREETYPE-INSPECT-PASS/);
 assert.doesNotMatch(reloadLog,/Building freetype/);
 assert.deepEqual(errors,[]);
 console.log('PASS FreeType installed shared/static consumers, unchanged upstream issue-1063/trig/bbox, reload reuse, TrueType/CFF native metric and pixel comparisons');
} finally {await close();}
