#include <stdio.h>
#include <ft2build.h>
#include FT_FREETYPE_H
int main(void) {
  FT_Library library; FT_Face face;
  if (FT_Init_FreeType(&library)) return 1;
  if (FT_New_Face(library, "/usr/src/sdk-freetype/font.ttf", 0, &face)) return 2;
  if (FT_Set_Pixel_Sizes(face, 0, 16) || FT_Load_Char(face, 'A', FT_LOAD_RENDER)) return 3;
  if (!face->glyph->bitmap.width || !face->glyph->bitmap.rows) return 4;
  FT_Done_Face(face); FT_Done_FreeType(library);
  puts("SDK-DEPENDENCY-PASS"); return 0;
}
