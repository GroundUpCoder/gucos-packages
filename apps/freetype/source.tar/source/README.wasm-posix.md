# FreeType 2.14.1 for wasm-posix

The upstream `include/`, `src/`, `docs/`, selected `tests/` files, `README` and `LICENSE.TXT` files
are retained unchanged from tag VER-2-14-1. `lib.json`, `install.sh` and
`port/` are local additions. Download URLs and SHA-256 hashes are recorded
in `port/sources.json`. Fonts are redistributed under their accompanying
SIL Open Font Licenses.

The project uses FreeType under the FreeType License in `docs/FTL.TXT`.
See the repository's `docs/FREETYPE.md` for configuration, installation,
sample commands and test coverage.
