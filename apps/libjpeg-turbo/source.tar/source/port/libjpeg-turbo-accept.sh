set -e
gucman install libjpeg-turbo pkgconf
cc /usr/src/libjpeg-turbo/port/libjpeg-turbo-accept.c -I/usr/local/include/jpeg-turbo -ljpeg-turbo -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
