#include <stdio.h>
#include <stdlib.h>
#include <jpeglib.h>
#include <assert.h>
int main(void){struct jpeg_compress_struct c;struct jpeg_error_mgr e;unsigned char *buf=0;unsigned long size=0;c.err=jpeg_std_error(&e);jpeg_create_compress(&c);jpeg_mem_dest(&c,&buf,&size);c.image_width=2;c.image_height=2;c.input_components=3;c.in_color_space=JCS_RGB;jpeg_set_defaults(&c);jpeg_start_compress(&c,1);unsigned char pixels[]={255,0,0,255,0,0};JSAMPROW row=pixels;while(c.next_scanline<2)jpeg_write_scanlines(&c,&row,1);jpeg_finish_compress(&c);jpeg_destroy_compress(&c);struct jpeg_decompress_struct d;d.err=jpeg_std_error(&e);jpeg_create_decompress(&d);jpeg_mem_src(&d,buf,size);assert(jpeg_read_header(&d,1)==JPEG_HEADER_OK);jpeg_start_decompress(&d);assert(d.output_width==2&&d.output_height==2);while(d.output_scanline<2){jpeg_read_scanlines(&d,&row,1);assert(pixels[0]>240&&pixels[1]<10&&pixels[2]<10);}jpeg_finish_decompress(&d);jpeg_destroy_decompress(&d);free(buf);return 0;}
