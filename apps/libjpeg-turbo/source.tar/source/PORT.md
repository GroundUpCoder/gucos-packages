libjpeg-turbo 3.1.4.1 is built as portable C, without SIMD or the TurboJPEG
wrapper API. All 8/12/16-bit libjpeg source groups are included; sources.json
records the list from upstream CMake with WITH_SIMD=OFF, WITH_TURBOJPEG=OFF.
Generated jconfig.h and jconfigint.h use 32-bit size_t for this target.

The package installs libjpeg-turbo.so/.a, headers in include/jpeg-turbo, and
libjpeg-turbo.pc. The distinct name/header path avoids replacing the existing
IJG 9f libjpeg ABI. GdkPixbuf selects this package explicitly. The current
runtime validation is GdkPixbuf's JPEG fixture tests, not the entire upstream
libjpeg-turbo suite. ORIGIN.json records the release archive and hash.
