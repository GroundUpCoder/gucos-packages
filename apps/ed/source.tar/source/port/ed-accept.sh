set -e
gucman install ed
mkdir /tmp/ed-upstream
cd /tmp/ed-upstream
ln -s /usr/local/lib/wasm-posix/ed ed
sh /usr/src/ed/testsuite/check.sh /usr/src/ed/testsuite 1.22.2
printf 'alpha\nbeta\n' > /tmp/edit.txt
printf '1s/alpha/ALPHA/\n$a\ngamma\n.\nw\nq\n' | ed /tmp/edit.txt
printf 'ALPHA\nbeta\ngamma\n' > /tmp/expected
cmp /tmp/expected /tmp/edit.txt

echo ED-ACCEPTANCE-PASS
