# GNU ed 1.22.2

Unmodified upstream sources, configure, Makefile, documentation and complete
testsuite from https://ftp.gnu.org/gnu/ed/ed-1.22.2.tar.lz.
SHA-256: `f58d15242056e15af76f13f34c60d890fa2a2d5cb0abef91c115e4d83794ffe3`.
License: GPL-2.0-or-later; see COPYING and individual file notices. The
manual includes its GNU Free Documentation License in doc/fdl.texi.

bin.json and this README.md are local additions. No upstream C source
patches are required. `ed` compiles the manifest on first use; `red` uses
the same binary with `-r` for upstream's restricted mode.

The browser build also runs the upstream configure and Makefile:
`sh configure CC=cc`, `make -j4`, `chmod +x testsuite/check.sh`, `make check`.
The chmod is needed because bundled source files are seeded as data files.
All upstream regression inputs, including non-UTF-8 binary data, are kept
byte-exact. `npm run test:utilities` checks this build and full test script,
plus the installed launchers. The shell-escape test exposed and regresses
a libc bug: `_IONBF` input must avoid read-ahead even if FILE owns a buffer.
