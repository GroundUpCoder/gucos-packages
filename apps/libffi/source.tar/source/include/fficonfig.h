/* wasm-posix raw scalar ABI: no assembly, closures or variadic calls. */
#define HAVE_ALLOCA_H 1
#define HAVE_MEMCPY 1
#define STDC_HEADERS 1
#define SIZEOF_SIZE_T 4
#define SIZEOF_DOUBLE 8
#define SIZEOF_LONG_DOUBLE 8
#define SIZEOF_LONG 4
#define FFI_HIDDEN
