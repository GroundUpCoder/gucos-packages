#include <ffi.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <setjmp.h>
static double mixed(int32_t a,double b,float c,int64_t d,int *e){return a+b+c+(double)d+*e;}
static int64_t wide(int64_t n){return n-123;}
static int prefix(int n){return n+1;}
static int no_arguments(void){return 42;}
static float single(float n){return n*1.5f;}
static void *pointer(void *p){return p;}
static signed char narrow(signed char a,short b){return a+b;}
static jmp_buf escape;
static void jumping(void){longjmp(escape,17);}
static ffi_cif nested_cif;
static void nested(void){ffi_call(&nested_cif,jumping,NULL,NULL);}
int main(void){
 ffi_cif cif;ffi_type *types[]={&ffi_type_sint32,&ffi_type_double,&ffi_type_float,&ffi_type_sint64,&ffi_type_pointer};
 int32_t a=-7;double b=3.25;float c=1.5f;int64_t d=123456789012LL;int e=11;int *ptr=&e;
 void *args[]={&a,&b,&c,&d,&ptr};double result=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,5,&ffi_type_double,types)==FFI_OK);
 ffi_call(&cif,FFI_FN(mixed),&result,args);assert(result==mixed(a,b,c,d,&e));
 ffi_type *wide_types[]={&ffi_type_sint64};void *wide_args[]={&d};int64_t wide_result=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,1,&ffi_type_sint64,wide_types)==FFI_OK);
 ffi_call(&cif,FFI_FN(wide),&wide_result,wide_args);assert(wide_result==d-123);
 ffi_type *float_types[]={&ffi_type_float};void *float_args[]={&c};float float_result=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,1,&ffi_type_float,float_types)==FFI_OK);
 ffi_call(&cif,FFI_FN(single),&float_result,float_args);assert(float_result==c*1.5f);
 ffi_type *pointer_types[]={&ffi_type_pointer};void *pointer_args[]={&ptr};void *pointer_result=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,1,&ffi_type_pointer,pointer_types)==FFI_OK);
 ffi_call(&cif,FFI_FN(pointer),&pointer_result,pointer_args);assert(pointer_result==ptr);
 ffi_type *small_types[]={&ffi_type_sint8,&ffi_type_sint16};signed char x=-9;short y=-7;void *small_args[]={&x,&y};ffi_sarg small=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint8,small_types)==FFI_OK);
 ffi_call(&cif,FFI_FN(narrow),&small,small_args);assert(small==-16);
 assert(ffi_prep_cif(&nested_cif,FFI_DEFAULT_ABI,0,&ffi_type_void,NULL)==FFI_OK);
 int jumped=setjmp(escape);if(!jumped){ffi_call(&nested_cif,nested,NULL,NULL);assert(0);}assert(jumped==17);
 /* GObject permits callbacks with unused trailing arguments. */
 ffi_type *extra_types[]={&ffi_type_sint32,&ffi_type_sint32,&ffi_type_sint32};
 int extra=13;void *extra_args[]={&extra,&extra,&extra};int extra_result=0;
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,3,&ffi_type_sint32,extra_types)==FFI_OK);
 ffi_call(&cif,FFI_FN(prefix),&extra_result,extra_args);assert(extra_result==14);
 ffi_call(&cif,FFI_FN(no_arguments),&extra_result,extra_args);assert(extra_result==42);
 ffi_type *elements[]={&ffi_type_sint32,NULL};ffi_type structure={0,0,FFI_TYPE_STRUCT,elements};
 assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,0,&structure,NULL)==FFI_BAD_TYPEDEF);
 assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,1,&ffi_type_void,types)!=FFI_OK);
 puts("FFI-PASS");return 0;
}
