set -e
gucman install libffi pkgconf
cc /usr/src/libffi/port/check.c $(pkg-config --cflags --libs libffi) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
