/* wasm-posix raw scalar ABI backend for libffi. */
#include <ffi.h>
#include <ffi_common.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* Compiler intrinsic. Keep an indirect call in the fallback so the effect
 * analyzer treats this entry and its callers as potentially suspending.
 * The continuation backend replaces its body. */
void __wasm_posix_ffi_call(unsigned target, unsigned nargs,
                         const uint64_t *slots, uint64_t *result) {
    void (*volatile unsupported)(void) = 0;
    unsupported();
}
static int scalar(const ffi_type *type) {
    switch(type->type) {
    case FFI_TYPE_VOID: return type->size==1;
    case FFI_TYPE_UINT8: case FFI_TYPE_SINT8: return type->size==1;
    case FFI_TYPE_UINT16: case FFI_TYPE_SINT16: return type->size==2;
    case FFI_TYPE_INT: case FFI_TYPE_UINT32: case FFI_TYPE_SINT32:
    case FFI_TYPE_FLOAT: case FFI_TYPE_POINTER: return type->size==4;
    case FFI_TYPE_UINT64: case FFI_TYPE_SINT64: case FFI_TYPE_DOUBLE: return type->size==8;
    default: return 0;
    }
}
ffi_status ffi_prep_cif_machdep(ffi_cif *cif) {
    if(cif->abi!=FFI_WASM32)return FFI_BAD_ABI;
    if(cif->nargs>1024 || !scalar(cif->rtype))return FFI_BAD_TYPEDEF;
    for(unsigned i=0;i<cif->nargs;i++)
        if(!scalar(cif->arg_types[i]) || cif->arg_types[i]->type==FFI_TYPE_VOID)return FFI_BAD_TYPEDEF;
    cif->nfixedargs=cif->nargs;
    return FFI_OK;
}
ffi_status ffi_prep_cif_machdep_var(ffi_cif *cif,unsigned fixed,unsigned total) {
    return FFI_BAD_ABI;
}
void ffi_call(ffi_cif *cif,void (*fn)(void),void *rvalue,void **avalue) {
    if(!fn || ffi_prep_cif_machdep(cif)!=FFI_OK)abort();
    uint64_t *slots=alloca((cif->nargs?cif->nargs:1)*sizeof(*slots));
    for(unsigned i=0;i<cif->nargs;i++) {
        slots[i]=0;
        switch(cif->arg_types[i]->type) {
        case FFI_TYPE_SINT8: slots[i]=(uint32_t)(int32_t)*(int8_t *)avalue[i];break;
        case FFI_TYPE_SINT16: slots[i]=(uint32_t)(int32_t)*(int16_t *)avalue[i];break;
        default: memcpy(&slots[i],avalue[i],cif->arg_types[i]->size);break;
        }
    }
    uint64_t result=0;
    __wasm_posix_ffi_call((unsigned)(uintptr_t)fn,cif->nargs,slots,&result);
    if(rvalue && cif->rtype->type!=FFI_TYPE_VOID) {
        size_t size=cif->rtype->size;
        if(size<sizeof(ffi_arg))size=sizeof(ffi_arg);
        memcpy(rvalue,&result,size);
    }
}
