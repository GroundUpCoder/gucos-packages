#!/bin/sh
set -eu
stage=$1
build=/tmp/jwm-build
mkdir -p "$build" "$stage/bin" "$stage/share/jwm" "$stage/share/doc/jwm"
cp -R /usr/src/jwm/jwm-2.4.6/src "$build/"
cp /usr/src/jwm/config.h "$build/config.h"
for file in "$build"/src/*.c; do
 name=${file##*/}
 cc -O2 --enable-fork -I/usr/local/include -c "$file" -o "$build/${name%.c}.o"
done
cc --enable-fork "$build"/*.o -L/usr/local/lib -lXpm -lXmu -lXt -lSM -lICE -lXrender -lXext -lX11 -lxcb -lXau -lm -o "$stage/bin/jwm"
cp /usr/src/jwm/wasm.jwmrc "$stage/share/jwm/system.jwmrc"
cp /usr/src/jwm/wasm.jwmrc "$stage/share/jwm/wasm.jwmrc"
cp /usr/src/jwm/app-menu.sh "$stage/share/jwm/app-menu.sh"
cp /usr/src/jwm/licenses/JWM "$stage/share/doc/jwm/LICENSE"
