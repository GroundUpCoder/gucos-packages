#include <cairo.h>
#include <assert.h>
#include <stdint.h>
int main(void){cairo_surface_t *s=cairo_image_surface_create(CAIRO_FORMAT_ARGB32,32,32);cairo_t *c=cairo_create(s);cairo_set_source_rgb(c,1,0,0);cairo_paint(c);cairo_set_source_rgb(c,0,0,1);cairo_rectangle(c,8,8,16,16);cairo_fill(c);cairo_surface_flush(s);uint32_t *p=(uint32_t*)cairo_image_surface_get_data(s);assert(p[0]==0xffff0000&&p[10*32+10]==0xff0000ff);assert(cairo_surface_write_to_png(s,"/tmp/check.png")==CAIRO_STATUS_SUCCESS);cairo_surface_t *r=cairo_image_surface_create_from_png("/tmp/check.png");assert(cairo_surface_status(r)==0&&cairo_image_surface_get_width(r)==32);cairo_surface_destroy(r);cairo_destroy(c);cairo_surface_destroy(s);return 0;}
