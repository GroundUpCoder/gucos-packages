set -e
gucman install cairo pkgconf
cc /usr/src/cairo/port/cairo-accept.c $(pkg-config --cflags --libs cairo) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
