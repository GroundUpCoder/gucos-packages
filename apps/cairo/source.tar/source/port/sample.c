/* Cairo image/FreeType sample. With --window, present via existing SDL3. */
#include <cairo.h>
#include <cairo-ft.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#ifndef CAIRO_SAMPLE_NATIVE
#include <SDL3/SDL.h>
#endif
#define WIDTH 640
#define HEIGHT 360
int main(int argc, char **argv) {
    const char *font = argc > 1 ? argv[1] : "/usr/src/freetype/port/fonts/ABeeZee-Regular.ttf";
    FT_Library ft; FT_Face face;
    if (FT_Init_FreeType(&ft) || FT_New_Face(ft, font, 0, &face)) return 1;
    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, WIDTH, HEIGHT);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_rgb(cr, 0.06, 0.09, 0.14); cairo_paint(cr);
    cairo_pattern_t *gradient = cairo_pattern_create_linear(30, 0, 610, 0);
    cairo_pattern_add_color_stop_rgb(gradient, 0, 0.15, 0.75, 0.7);
    cairo_pattern_add_color_stop_rgb(gradient, 1, 0.35, 0.4, 0.95);
    cairo_set_source(cr, gradient);
    cairo_rectangle(cr, 30, 30, 580, 100); cairo_fill(cr);
    cairo_pattern_destroy(gradient);
    cairo_set_source_rgba(cr, 1, 1, 1, 0.7);
    cairo_set_line_width(cr, 5);
    cairo_move_to(cr, 40, 270); cairo_curve_to(cr, 160, 110, 370, 370, 590, 170); cairo_stroke(cr);
    cairo_arc(cr, 530, 255, 48, 0, 6.283185307179586); cairo_stroke(cr);
    cairo_font_face_t *cf = cairo_ft_font_face_create_for_ft_face(face, 0);
    cairo_set_font_face(cr, cf); cairo_set_font_size(cr, 34);
    cairo_set_source_rgb(cr, 1, 1, 1); cairo_move_to(cr, 50, 94);
    cairo_show_text(cr, "Cairo + Pixman + FreeType");
    cairo_set_font_size(cr, 19); cairo_move_to(cr, 40, 330);
    cairo_show_text(cr, "Portable C, shared libraries, browser display");
    if (cairo_status(cr) || cairo_surface_status(surface)) return 2;
    const char *output = argc > 2 ? argv[2] : "/home/user/cairo.ppm";
    size_t output_length = strlen(output);
    char *png_path = malloc(output_length + 5);
    if (!png_path) return 3;
    strcpy(png_path, output);
    if (output_length >= 4 && !strcmp(png_path + output_length - 4, ".ppm"))
        strcpy(png_path + output_length - 4, ".png");
    else strcat(png_path, ".png");
    if (cairo_surface_write_to_png(surface, png_path) != CAIRO_STATUS_SUCCESS) return 4;
    free(png_path);
    cairo_surface_flush(surface);
    unsigned char *data = cairo_image_surface_get_data(surface);
    int stride = cairo_image_surface_get_stride(surface);
    FILE *fp = fopen(argc > 2 ? argv[2] : "/home/user/cairo.ppm", "wb");
    if (!fp) return 3;
    fprintf(fp, "P6\n%d %d\n255\n", WIDTH, HEIGHT);
    for (int y = 0; y < HEIGHT; y++) for (int x = 0; x < WIDTH; x++) {
        uint32_t p = ((uint32_t *)(data + y * stride))[x];
        unsigned char rgb[3] = {p >> 16, p >> 8, p};
        if (fwrite(rgb, 1, 3, fp) != 3) return 4;
    }
    if (fclose(fp)) return 5;
#ifndef CAIRO_SAMPLE_NATIVE
    if (argc > 3 && !strcmp(argv[3], "--window")) {
        if (!SDL_Init(SDL_INIT_VIDEO)) return 6;
        SDL_Window *window = SDL_CreateWindow("Cairo shared-library sample", WIDTH, HEIGHT, 0);
        if (!window) return 7;
        SDL_Surface *screen = SDL_GetWindowSurface(window);
        if (!screen || screen->format != SDL_PIXELFORMAT_RGBA32) return 8;
        for (int y = 0; y < HEIGHT; y++) for (int x = 0; x < WIDTH; x++) {
            uint32_t p = ((uint32_t *)(data + y * stride))[x];
            unsigned char *dst = (unsigned char *)screen->pixels + y * screen->pitch + x * 4;
            dst[0] = p >> 16; dst[1] = p >> 8; dst[2] = p; dst[3] = 255;
        }
        SDL_UpdateWindowSurface(window);
        puts("CAIRO-WINDOW-READY"); fflush(stdout);
        int running = 1;
        while (running) {
            SDL_Event event;
            while (SDL_PollEvent(&event)) if (event.type == SDL_EVENT_QUIT || event.type == SDL_EVENT_KEY_DOWN) running = 0;
            SDL_Delay(16);
        }
        SDL_DestroyWindow(window); SDL_Quit();
    }
#endif
    cairo_destroy(cr); cairo_surface_destroy(surface); cairo_font_face_destroy(cf);
    /* Cairo caches scaled fonts; release them before their borrowed FT_Face. */
    cairo_debug_reset_static_data(); FT_Done_Face(face); FT_Done_FreeType(ft);
    puts("CAIRO-SAMPLE-PASS"); return 0;
}
