# Selected GTK 3 demos

Fourteen retained byte-exact demo sources from GTK 3.24.43, LGPL-2.1-or-later (COPYING).
UPSTREAM.json records their checksums. main.c is a local launcher, not the
upstream full gtk3-demo application. It uses the installed shared GTK library.
Thirteen demos compile unchanged. colorsel-browser.c adds an explicit queue_draw
after accepting a color: independent browser canvases retain their pixels when
a dialog closes, so the upstream callback cannot rely on uncovering the parent
to repaint it. The unchanged colorsel.c remains beside the adapted copy.

Run `gucman install gtk3-demo`, then `gtk3-demo` for the gallery or
`gtk3-demo --run drawingarea`. `--list` lists all fourteen demos. Escape closes a
demo. Closing the gallery exits the process and its remaining windows.
The installed shell launcher sets WASM_POSIX_SURFACES=1 before starting the
libexec binary (the runtime selects its frontend before C main). It selects
per-window browser surfaces so child dialogs have their
own canvases. This package does not establish arbitrary GTK desktop support.

The sources live outside gtk3 so updating a demo does not invalidate the GTK
library artifact. The package is built/tested independently with
`npm run test:gtk-apps`; see docs/GTK.md for the platform limitations.

The added upstream examples exercise combo-box models, completion popups,
expandable message dialogs, text-tag hyperlink navigation, timed search/cancel
controls, sortable/toggleable list models, hierarchical tree models and flow-box
layout. Their original C sources are unchanged. The local launcher scrolls
its longer menu. Browser tests observe widget/model state in a separate diagnostic
executable and drive real pointer/keyboard input; no observer code ships in the
installed application.
