/* Browser launcher for a selected set of GTK 3.24.43 demos. */
#include <gtk/gtk.h>
#include <string.h>

GtkWidget *do_drawingarea(GtkWidget *);
GtkWidget *do_panes(GtkWidget *);
GtkWidget *do_editable_cells(GtkWidget *);
GtkWidget *do_button_box(GtkWidget *);
GtkWidget *do_entry_buffer(GtkWidget *);
GtkWidget *do_colorsel(GtkWidget *);
GtkWidget *do_combobox(GtkWidget *);
GtkWidget *do_entry_completion(GtkWidget *);
GtkWidget *do_expander(GtkWidget *);
GtkWidget *do_hypertext(GtkWidget *);
GtkWidget *do_search_entry(GtkWidget *);
GtkWidget *do_list_store(GtkWidget *);
GtkWidget *do_tree_store(GtkWidget *);
GtkWidget *do_flowbox(GtkWidget *);


static const struct {
  const char *name, *title;
  GtkWidget *(*open)(GtkWidget *);
} demos[] = {
  {"drawingarea", "Drawing Area: draw with the mouse", do_drawingarea},
  {"editable_cells", "Editable Cells: edit a shopping list", do_editable_cells},
  {"panes", "Panes: resize split views", do_panes},
  {"entry_buffer", "Entry Buffer: linked text fields", do_entry_buffer},
  {"button_box", "Button Boxes: explore layouts", do_button_box},
  {"colorsel", "Color Chooser: mix colors", do_colorsel},
  {"combobox", "Combo Boxes: choose from lists and trees", do_combobox},
  {"entry_completion", "Entry Completion: type suggested words", do_entry_completion},
  {"expander", "Expander: reveal additional details", do_expander},
  {"hypertext", "Hypertext: follow links in text", do_hypertext},
  {"search_entry", "Search Entry: search and cancel", do_search_entry},
  {"list_store", "List Store: toggle and sort bug reports", do_list_store},
  {"tree_store", "Tree Store: explore a holiday calendar", do_tree_store},
  {"flowbox", "Flow Box: resize a wrapping color grid", do_flowbox}
};

static gboolean close_on_escape(GtkWidget *window, GdkEventKey *event, gpointer data) {
  if (event->keyval != GDK_KEY_Escape) return FALSE;
  gtk_widget_destroy(window);
  return TRUE;
}

static GtkWidget *open_demo(GtkWidget *parent, unsigned index) {
  GtkWidget *window = demos[index].open(parent);
  if (window) g_signal_connect(window, "key-press-event", G_CALLBACK(close_on_escape), NULL);
  return window;
}

static void selected(GtkButton *button, gpointer index) {
  open_demo(GTK_WIDGET(button), GPOINTER_TO_UINT(index));
}

int main(int argc, char **argv) {
  int selected_index = -1;
  if (argc == 2 && (!strcmp(argv[1], "--list") || !strcmp(argv[1], "--help"))) {
    g_print("Usage: gtk3-demo [--run NAME | --list]\nSelected upstream GTK 3.24.43 demos; Escape closes a demo.\n");
    for (unsigned i = 0; i < G_N_ELEMENTS(demos); i++) g_print("  %s: %s\n", demos[i].name, demos[i].title);
    return 0;
  }
  if (argc != 1) {
    if (argc == 3 && !strcmp(argv[1], "--run"))
      for (unsigned i = 0; i < G_N_ELEMENTS(demos); i++)
        if (!strcmp(argv[2], demos[i].name)) selected_index = i;
    if (selected_index < 0) { g_printerr("Use gtk3-demo --list for available demos.\n"); return 2; }
  }
  if (!gtk_init_check(&argc, &argv)) { g_printerr("GTK display unavailable\n"); return 1; }
  GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  if (selected_index >= 0) {
    GtkWidget *demo = open_demo(window, selected_index);
    g_signal_connect(demo, "destroy", G_CALLBACK(gtk_main_quit), NULL);
  } else {
    gtk_window_set_title(GTK_WINDOW(window), "GTK 3 Demo Gallery");
    gtk_container_set_border_width(GTK_CONTAINER(window), 16);
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_window_set_default_size(GTK_WINDOW(window), 540, 620);
    GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(window), scroll);
    gtk_container_add(GTK_CONTAINER(scroll), box);
    gtk_box_pack_start(GTK_BOX(box), gtk_label_new("GTK 3.24.43 - selected upstream demos"), FALSE, FALSE, 0);
    for (unsigned i = 0; i < G_N_ELEMENTS(demos); i++) {
      GtkWidget *button = gtk_button_new_with_label(demos[i].title);
      g_signal_connect(button, "clicked", G_CALLBACK(selected), GUINT_TO_POINTER(i));
      gtk_box_pack_start(GTK_BOX(box), button, FALSE, FALSE, 0);
    }
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    g_signal_connect(window, "key-press-event", G_CALLBACK(close_on_escape), NULL);
    gtk_widget_show_all(window);
  }
  gtk_main();
  return 0;
}
