#!/bin/sh
set -e
stage=$1
cd /usr/src/gtk3-demo
mkdir -p "$stage/bin" "$stage/libexec" "$stage/share/doc/gtk3-demo"
cc -O2 main.c drawingarea.c panes.c editable_cells.c button_box.c entry_buffer.c colorsel-browser.c combobox.c entry_completion.c expander.c hypertext.c search_entry.c list_store.c tree_store.c flowbox.c $(pkg-config --cflags --libs gtk+-3.0) -lintl -o "$stage/libexec/gtk3-demo"
cp COPYING UPSTREAM.json PORT.md "$stage/share/doc/gtk3-demo/"
# The runtime selects its window frontend before main(), at process startup.
cat > "$stage/bin/gtk3-demo" <<'EOF'
#!/bin/sh
export WASM_POSIX_SURFACES=1
exec /usr/local/libexec/gtk3-demo "$@"
EOF
chmod +x "$stage/bin/gtk3-demo"
