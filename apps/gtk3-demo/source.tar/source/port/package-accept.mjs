import {acceptInstalledApp} from '../../../vendor/gtk3/port/installed-app.mjs';
await acceptInstalledApp("gtk3-demo","gtk3-demo --run drawingarea");
