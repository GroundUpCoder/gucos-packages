# libxfce4util 4.20.0

Source: https://archive.xfce.org/src/xfce/libxfce4util/4.20/libxfce4util-4.20.0.tar.bz2
SHA-256: 21493f9c9995a282823db93839f6b9f06ae31edb094191ba9acf04d932a2b592
License: COPYING.

Upstream C is unchanged. A manual configuration selects the browser POSIX
profile and existing GLib/GIO. The private port header supplies growable line
reading and supplementary-group queries for our single-root virtual user model.
These do not expose host users or claim host permission enforcement.

The package includes all 17 library translation units, static/shared libraries,
headers and pkg-config metadata. ConsoleKit and systemd clients retain their
normal D-Bus failure paths; those host services are not provided by the browser.
Browser validation passed: a separately linked shared-library consumer checks
public version data, string replacement, settings persistence including a 64 KiB
value, configuration resource lookup and package reuse. Host power management
and general signal-delivery behavior are not covered by these tests.
