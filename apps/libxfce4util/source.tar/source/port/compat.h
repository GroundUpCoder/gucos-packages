#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <limits.h>
/* The virtual process model has one root user and group, not host identities. */
static inline int xfce_browser_getgroups(int size, gid_t *groups) {
  if (size < 0) { errno = EINVAL; return -1; }
  if (size == 0) return 1;
  if (!groups) { errno = EFAULT; return -1; }
  groups[0] = 0;
  return 1;
}
/* Byte-preserving growable input for the upstream configuration parser. */
static inline ssize_t xfce_browser_getline(char **line, size_t *capacity, FILE *stream) {
  if (!line || !capacity || !stream) { errno = EINVAL; return -1; }
  flockfile(stream);
  size_t used = 0;
  for (;;) {
    if (!*line || *capacity <= used + 1) {
      size_t next = !*line || *capacity < 128 ? 128 : *capacity;
      if (next <= used + 1) {
        if (next > (size_t)LONG_MAX / 2) {
          errno = EOVERFLOW; funlockfile(stream); return -1;
        }
        next *= 2;
      }
      char *grown = realloc(*line, next);
      if (!grown) { errno = ENOMEM; funlockfile(stream); return -1; }
      *line = grown; *capacity = next;
    }
    int ch = getc_unlocked(stream);
    if (ch == EOF) {
      (*line)[used] = 0;
      int failed = ferror(stream);
      funlockfile(stream);
      return failed || !used ? -1 : (ssize_t)used;
    }
    (*line)[used++] = (char)ch;
    if (ch == '\n') { (*line)[used] = 0; funlockfile(stream); return (ssize_t)used; }
  }
}
#define getgroups xfce_browser_getgroups
#define getline xfce_browser_getline
