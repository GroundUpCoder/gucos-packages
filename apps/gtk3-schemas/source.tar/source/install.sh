#!/bin/sh
set -e
stage=$1
cd /usr/src/gtk3-schemas
mkdir -p "$stage/objects" "$stage/share/glib-2.0/schemas" "$stage/share/doc/gtk3-schemas"
cc -I/usr/src/gio-core -I/usr/src/glib -I/usr/src/glib/glib -I/usr/src/gio-core/gvdb /usr/src/gio-core/gio/glib-compile-schemas.c /usr/src/gio-core/port/gvdb-builder-sync.c $(pkg-config --cflags --libs gio-core) -lintl -o "$stage/objects/glib-compile-schemas"
cp *.gschema.xml "$stage/share/glib-2.0/schemas/"
"$stage/objects/glib-compile-schemas" --strict "$stage/share/glib-2.0/schemas"
cp COPYING UPSTREAM.json PORT.md "$stage/share/doc/gtk3-schemas/"
