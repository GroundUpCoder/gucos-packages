set -e
gucman install gtk3-schemas pkgconf
cc /usr/src/gtk3-schemas/port/gtk3-schemas-accept.c $(pkg-config --cflags --libs gio-core) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
