import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('gtk3-schemas',1200000);
try {const r=await runCached(page,await readFile(new URL('./gtk3-schemas-accept.sh',import.meta.url),'utf8'),{packages:['gtk3-schemas','pkgconf'],fresh:['gtk3-schemas']});const log=await page.evaluate(()=>shell.busybox.log);assert.equal(r.code,0,log);assert.match(log,/PACKAGE-ACCEPT-PASS/);assert.deepEqual(errors,[]);console.log('PASS gtk3-schemas installed consumer behavior');}finally{await close();}
