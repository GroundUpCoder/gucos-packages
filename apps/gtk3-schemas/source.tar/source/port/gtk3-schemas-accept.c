#include <gio/gio.h>
#include <assert.h>
int main(void){GSettingsSchemaSource *s=g_settings_schema_source_get_default();assert(s);GSettingsSchema *schema=g_settings_schema_source_lookup(s,"org.gtk.Settings.FileChooser",1);assert(schema);assert(g_settings_schema_has_key(schema,"show-hidden"));g_settings_schema_unref(schema);return 0;}
