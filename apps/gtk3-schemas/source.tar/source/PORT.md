# GTK settings schemas

Four unchanged upstream GTK 3.24.43 XML schemas (ColorChooser, EmojiChooser,
FileChooser and Debug), licensed under GTK's LGPL terms. UPSTREAM.json records
checksums. The recipe compiles the database with upstream glib-compile-schemas
on the guest, using the existing GIO library and synchronous GVDB writer.

Installs /usr/local/share/glib-2.0/schemas, discoverable by GIO's normal XDG
lookup. This data package is separate from GTK's libraries, so schema edits
can be rebuilt without recompiling GTK. gtk3-demo explicitly depends on it
also for browser disks with a GTK library installed before schemas existed.

This package currently owns the database in that directory. Future packages
with additional schemas must use their own XDG data directories or introduce
a shared schema compilation trigger, rather than overwrite gschemas.compiled.
