#!/bin/sh
set -eu
stage=$1
src=/usr/src/x11-apps
objects=
for file in "$src"/libXft/src/*.c; do
 object="$stage/objects/xft-${file##*/}.o"
 cc -O2 -DHAVE_CONFIG_H -I"$src/xft-config" -I"$src/libXft/include/X11/Xft" -I/usr/local/include -I/usr/local/include/freetype2 -c "$file" -o "$object"
 objects="$objects $object"
done
ar rcs "$stage/lib/libXft.a" $objects
mkdir -p "$stage/include/X11/Xft"
cp "$src/libXft/include/X11/Xft/Xft.h" "$src/libXft/include/X11/Xft/XftCompat.h" "$stage/include/X11/Xft/"
cat > "$stage/lib/pkgconfig/xft.pc" <<'PC'
prefix=/usr/local
libdir=${prefix}/lib
includedir=${prefix}/include
Name: Xft
Description: X FreeType rendering library
Version: 2.3.8
Requires: xrender fontconfig freetype2
Libs: -L${libdir} -lXft
Cflags: -I${includedir}
PC
