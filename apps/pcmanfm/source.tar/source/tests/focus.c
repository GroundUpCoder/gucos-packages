#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
static Window scan(Display *d,Window w,unsigned *count){
 XClassHint h;XWindowAttributes a;Window root,parent,*children=0,got=0;unsigned n=0;
 if(XGetClassHint(d,w,&h)){
  int ok=h.res_class&&!strcmp(h.res_class,"Pcmanfm");
  if(h.res_name)XFree(h.res_name);if(h.res_class)XFree(h.res_class);
  if(ok&&XGetWindowAttributes(d,w,&a)&&a.map_state==IsViewable&&a.width>100&&a.height>100){(*count)++;got=w;}
 }
 if(XQueryTree(d,w,&root,&parent,&children,&n)){
  for(unsigned i=0;i<n;i++){Window child=scan(d,children[i],count);if(child)got=child;}
  if(children)XFree(children);
 }
 return got;
}
int main(int argc,char **argv){
 Display*d=XOpenDisplay(0);assert(d);
 if(argc>1&&!strcmp(argv[1],"close")){
  Atom protocols=XInternAtom(d,"WM_PROTOCOLS",False),close=XInternAtom(d,"WM_DELETE_WINDOW",False);
  for(int i=0;i<100;i++){
   unsigned count=0;Window w=scan(d,DefaultRootWindow(d),&count);if(!w){XCloseDisplay(d);puts("PCMANFM-WINDOWS-CLOSED");return 0;}
   XEvent e;memset(&e,0,sizeof e);e.xclient.type=ClientMessage;e.xclient.window=w;e.xclient.message_type=protocols;e.xclient.format=32;e.xclient.data.l[0]=close;e.xclient.data.l[1]=CurrentTime;
   XSendEvent(d,w,False,NoEventMask,&e);XFlush(d);usleep(100000);
  }
  assert(!"PCManFM windows did not close");
 }
 Window w=0;unsigned count=0;unsigned needed=argc>1?atoi(argv[1]):1;
 for(int i=0;i<200;i++){count=0;w=scan(d,DefaultRootWindow(d),&count);if(count>=needed)break;usleep(100000);}
 assert(w&&count>=needed);XRaiseWindow(d,w);XSetInputFocus(d,w,RevertToPointerRoot,CurrentTime);XSync(d,False);XCloseDisplay(d);
 puts(needed>1?"PCMANFM-SECOND-WINDOW-PASS":"PCMANFM-READY");return 0;
}
