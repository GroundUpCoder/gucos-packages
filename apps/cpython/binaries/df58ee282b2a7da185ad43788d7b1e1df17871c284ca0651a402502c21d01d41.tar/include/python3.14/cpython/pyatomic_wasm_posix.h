// wasm-posix: 32-bit Wasm atomics; other widths share one interpreter lock.
// All orders are strengthened to sequential consistency. Never use the partial
// stdatomic.h implementation for 8/16/64-bit read-modify-write operations.
PyAPI_FUNC(void) _Py_wasm_atomic_lock(void);
PyAPI_FUNC(void) _Py_wasm_atomic_unlock(void);


static inline int
_Py_atomic_add_int(int *obj, int value)
{
    int old;
    if (sizeof(int) == 4) return (int)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    *((int *)obj) = (int)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int8_t
_Py_atomic_add_int8(int8_t *obj, int8_t value)
{
    int8_t old;
    if (sizeof(int8_t) == 4) return (int8_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int8_t *)obj);
    *((int8_t *)obj) = (int8_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int16_t
_Py_atomic_add_int16(int16_t *obj, int16_t value)
{
    int16_t old;
    if (sizeof(int16_t) == 4) return (int16_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int16_t *)obj);
    *((int16_t *)obj) = (int16_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int32_t
_Py_atomic_add_int32(int32_t *obj, int32_t value)
{
    int32_t old;
    if (sizeof(int32_t) == 4) return (int32_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int32_t *)obj);
    *((int32_t *)obj) = (int32_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int64_t
_Py_atomic_add_int64(int64_t *obj, int64_t value)
{
    int64_t old;
    if (sizeof(int64_t) == 4) return (int64_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int64_t *)obj);
    *((int64_t *)obj) = (int64_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline intptr_t
_Py_atomic_add_intptr(intptr_t *obj, intptr_t value)
{
    intptr_t old;
    if (sizeof(intptr_t) == 4) return (intptr_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((intptr_t *)obj);
    *((intptr_t *)obj) = (intptr_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned int
_Py_atomic_add_uint(unsigned int *obj, unsigned int value)
{
    unsigned int old;
    if (sizeof(unsigned int) == 4) return (unsigned int)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((unsigned int *)obj);
    *((unsigned int *)obj) = (unsigned int)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_add_uint8(uint8_t *obj, uint8_t value)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    *((uint8_t *)obj) = (uint8_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_add_uint16(uint16_t *obj, uint16_t value)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    *((uint16_t *)obj) = (uint16_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_add_uint32(uint32_t *obj, uint32_t value)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    *((uint32_t *)obj) = (uint32_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_add_uint64(uint64_t *obj, uint64_t value)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    *((uint64_t *)obj) = (uint64_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_add_uintptr(uintptr_t *obj, uintptr_t value)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    *((uintptr_t *)obj) = (uintptr_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline Py_ssize_t
_Py_atomic_add_ssize(Py_ssize_t *obj, Py_ssize_t value)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) return (Py_ssize_t)__builtin(atomic_add32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    *((Py_ssize_t *)obj) = (Py_ssize_t)((uint64_t)old + (uint64_t)value);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int
_Py_atomic_compare_exchange_int(int *obj, int *expected, int desired)
{
    int old;
    if (sizeof(int) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    int equal = old == *((int *)expected);
    if (equal) *((int *)obj) = desired;
    else *((int *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_int8(int8_t *obj, int8_t *expected, int8_t desired)
{
    int8_t old;
    if (sizeof(int8_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((int8_t *)obj);
    int equal = old == *((int8_t *)expected);
    if (equal) *((int8_t *)obj) = desired;
    else *((int8_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_int16(int16_t *obj, int16_t *expected, int16_t desired)
{
    int16_t old;
    if (sizeof(int16_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((int16_t *)obj);
    int equal = old == *((int16_t *)expected);
    if (equal) *((int16_t *)obj) = desired;
    else *((int16_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_int32(int32_t *obj, int32_t *expected, int32_t desired)
{
    int32_t old;
    if (sizeof(int32_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((int32_t *)obj);
    int equal = old == *((int32_t *)expected);
    if (equal) *((int32_t *)obj) = desired;
    else *((int32_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_int64(int64_t *obj, int64_t *expected, int64_t desired)
{
    int64_t old;
    if (sizeof(int64_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((int64_t *)obj);
    int equal = old == *((int64_t *)expected);
    if (equal) *((int64_t *)obj) = desired;
    else *((int64_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_intptr(intptr_t *obj, intptr_t *expected, intptr_t desired)
{
    intptr_t old;
    if (sizeof(intptr_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((intptr_t *)obj);
    int equal = old == *((intptr_t *)expected);
    if (equal) *((intptr_t *)obj) = desired;
    else *((intptr_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uint(unsigned int *obj, unsigned int *expected, unsigned int desired)
{
    unsigned int old;
    if (sizeof(unsigned int) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((unsigned int *)obj);
    int equal = old == *((unsigned int *)expected);
    if (equal) *((unsigned int *)obj) = desired;
    else *((unsigned int *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uint8(uint8_t *obj, uint8_t *expected, uint8_t desired)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    int equal = old == *((uint8_t *)expected);
    if (equal) *((uint8_t *)obj) = desired;
    else *((uint8_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uint16(uint16_t *obj, uint16_t *expected, uint16_t desired)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    int equal = old == *((uint16_t *)expected);
    if (equal) *((uint16_t *)obj) = desired;
    else *((uint16_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uint32(uint32_t *obj, uint32_t *expected, uint32_t desired)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    int equal = old == *((uint32_t *)expected);
    if (equal) *((uint32_t *)obj) = desired;
    else *((uint32_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uint64(uint64_t *obj, uint64_t *expected, uint64_t desired)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    int equal = old == *((uint64_t *)expected);
    if (equal) *((uint64_t *)obj) = desired;
    else *((uint64_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_uintptr(uintptr_t *obj, uintptr_t *expected, uintptr_t desired)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    int equal = old == *((uintptr_t *)expected);
    if (equal) *((uintptr_t *)obj) = desired;
    else *((uintptr_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_ssize(Py_ssize_t *obj, Py_ssize_t *expected, Py_ssize_t desired)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    int equal = old == *((Py_ssize_t *)expected);
    if (equal) *((Py_ssize_t *)obj) = desired;
    else *((Py_ssize_t *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_compare_exchange_ptr(void *obj, void *expected, void *desired)
{
    void * old;
    if (sizeof(void *) == 4) {
        int wanted = *((int *)expected);
        int seen = __builtin(atomic_cmpxchg32, (int *)obj, wanted, (int)desired);
        if (seen == wanted) return 1;
        *((int *)expected) = seen;
        return 0;
    }
    _Py_wasm_atomic_lock();
    old = *((void * *)obj);
    int equal = old == *((void * *)expected);
    if (equal) *((void * *)obj) = desired;
    else *((void * *)expected) = old;
    _Py_wasm_atomic_unlock();
    return equal;
}

static inline int
_Py_atomic_exchange_int(int *obj, int value)
{
    int old;
    if (sizeof(int) == 4) return (int)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    *((int *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int8_t
_Py_atomic_exchange_int8(int8_t *obj, int8_t value)
{
    int8_t old;
    if (sizeof(int8_t) == 4) return (int8_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int8_t *)obj);
    *((int8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int16_t
_Py_atomic_exchange_int16(int16_t *obj, int16_t value)
{
    int16_t old;
    if (sizeof(int16_t) == 4) return (int16_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int16_t *)obj);
    *((int16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int32_t
_Py_atomic_exchange_int32(int32_t *obj, int32_t value)
{
    int32_t old;
    if (sizeof(int32_t) == 4) return (int32_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int32_t *)obj);
    *((int32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int64_t
_Py_atomic_exchange_int64(int64_t *obj, int64_t value)
{
    int64_t old;
    if (sizeof(int64_t) == 4) return (int64_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((int64_t *)obj);
    *((int64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline intptr_t
_Py_atomic_exchange_intptr(intptr_t *obj, intptr_t value)
{
    intptr_t old;
    if (sizeof(intptr_t) == 4) return (intptr_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((intptr_t *)obj);
    *((intptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned int
_Py_atomic_exchange_uint(unsigned int *obj, unsigned int value)
{
    unsigned int old;
    if (sizeof(unsigned int) == 4) return (unsigned int)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((unsigned int *)obj);
    *((unsigned int *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_exchange_uint8(uint8_t *obj, uint8_t value)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    *((uint8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_exchange_uint16(uint16_t *obj, uint16_t value)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    *((uint16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_exchange_uint32(uint32_t *obj, uint32_t value)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    *((uint32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_exchange_uint64(uint64_t *obj, uint64_t value)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    *((uint64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_exchange_uintptr(uintptr_t *obj, uintptr_t value)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    *((uintptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline Py_ssize_t
_Py_atomic_exchange_ssize(Py_ssize_t *obj, Py_ssize_t value)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) return (Py_ssize_t)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    *((Py_ssize_t *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void*
_Py_atomic_exchange_ptr(void *obj, void *value)
{
    void * old;
    if (sizeof(void *) == 4) return (void*)__builtin(atomic_xchg32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((void * *)obj);
    *((void * *)obj) = value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_and_uint8(uint8_t *obj, uint8_t value)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_and32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    *((uint8_t *)obj) = old & value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_and_uint16(uint16_t *obj, uint16_t value)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_and32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    *((uint16_t *)obj) = old & value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_and_uint32(uint32_t *obj, uint32_t value)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_and32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    *((uint32_t *)obj) = old & value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_and_uint64(uint64_t *obj, uint64_t value)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_and32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    *((uint64_t *)obj) = old & value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_and_uintptr(uintptr_t *obj, uintptr_t value)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_and32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    *((uintptr_t *)obj) = old & value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_or_uint8(uint8_t *obj, uint8_t value)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_or32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    *((uint8_t *)obj) = old | value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_or_uint16(uint16_t *obj, uint16_t value)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_or32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    *((uint16_t *)obj) = old | value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_or_uint32(uint32_t *obj, uint32_t value)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_or32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    *((uint32_t *)obj) = old | value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_or_uint64(uint64_t *obj, uint64_t value)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_or32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    *((uint64_t *)obj) = old | value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_or_uintptr(uintptr_t *obj, uintptr_t value)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_or32, (int *)obj, (int)value);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    *((uintptr_t *)obj) = old | value;
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int
_Py_atomic_load_int(const int *obj)
{
    int old;
    if (sizeof(int) == 4) return (int)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int8_t
_Py_atomic_load_int8(const int8_t *obj)
{
    int8_t old;
    if (sizeof(int8_t) == 4) return (int8_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int8_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int16_t
_Py_atomic_load_int16(const int16_t *obj)
{
    int16_t old;
    if (sizeof(int16_t) == 4) return (int16_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int16_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int32_t
_Py_atomic_load_int32(const int32_t *obj)
{
    int32_t old;
    if (sizeof(int32_t) == 4) return (int32_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int32_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int64_t
_Py_atomic_load_int64(const int64_t *obj)
{
    int64_t old;
    if (sizeof(int64_t) == 4) return (int64_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int64_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline intptr_t
_Py_atomic_load_intptr(const intptr_t *obj)
{
    intptr_t old;
    if (sizeof(intptr_t) == 4) return (intptr_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((intptr_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_load_uint8(const uint8_t *obj)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_load_uint16(const uint16_t *obj)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_load_uint32(const uint32_t *obj)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_load_uint64(const uint64_t *obj)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_load_uintptr(const uintptr_t *obj)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned int
_Py_atomic_load_uint(const unsigned int *obj)
{
    unsigned int old;
    if (sizeof(unsigned int) == 4) return (unsigned int)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((unsigned int *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline Py_ssize_t
_Py_atomic_load_ssize(const Py_ssize_t *obj)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) return (Py_ssize_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void*
_Py_atomic_load_ptr(const void *obj)
{
    void* old;
    if (sizeof(void*) == 4) return (void*)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((void* *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int
_Py_atomic_load_int_relaxed(const int *obj)
{
    int old;
    if (sizeof(int) == 4) return (int)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline char
_Py_atomic_load_char_relaxed(const char *obj)
{
    char old;
    if (sizeof(char) == 4) return (char)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((char *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned char
_Py_atomic_load_uchar_relaxed(const unsigned char *obj)
{
    unsigned char old;
    if (sizeof(unsigned char) == 4) return (unsigned char)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((unsigned char *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline short
_Py_atomic_load_short_relaxed(const short *obj)
{
    short old;
    if (sizeof(short) == 4) return (short)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((short *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned short
_Py_atomic_load_ushort_relaxed(const unsigned short *obj)
{
    unsigned short old;
    if (sizeof(unsigned short) == 4) return (unsigned short)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((unsigned short *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline long
_Py_atomic_load_long_relaxed(const long *obj)
{
    long old;
    if (sizeof(long) == 4) return (long)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((long *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline float
_Py_atomic_load_float_relaxed(const float *obj)
{
    float old;
    
    _Py_wasm_atomic_lock();
    old = *((float *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline double
_Py_atomic_load_double_relaxed(const double *obj)
{
    double old;
    
    _Py_wasm_atomic_lock();
    old = *((double *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int8_t
_Py_atomic_load_int8_relaxed(const int8_t *obj)
{
    int8_t old;
    if (sizeof(int8_t) == 4) return (int8_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int8_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int16_t
_Py_atomic_load_int16_relaxed(const int16_t *obj)
{
    int16_t old;
    if (sizeof(int16_t) == 4) return (int16_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int16_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int32_t
_Py_atomic_load_int32_relaxed(const int32_t *obj)
{
    int32_t old;
    if (sizeof(int32_t) == 4) return (int32_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int32_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline int64_t
_Py_atomic_load_int64_relaxed(const int64_t *obj)
{
    int64_t old;
    if (sizeof(int64_t) == 4) return (int64_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int64_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline intptr_t
_Py_atomic_load_intptr_relaxed(const intptr_t *obj)
{
    intptr_t old;
    if (sizeof(intptr_t) == 4) return (intptr_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((intptr_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint8_t
_Py_atomic_load_uint8_relaxed(const uint8_t *obj)
{
    uint8_t old;
    if (sizeof(uint8_t) == 4) return (uint8_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint8_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint16_t
_Py_atomic_load_uint16_relaxed(const uint16_t *obj)
{
    uint16_t old;
    if (sizeof(uint16_t) == 4) return (uint16_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint16_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_load_uint32_relaxed(const uint32_t *obj)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint64_t
_Py_atomic_load_uint64_relaxed(const uint64_t *obj)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_load_uintptr_relaxed(const uintptr_t *obj)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned int
_Py_atomic_load_uint_relaxed(const unsigned int *obj)
{
    unsigned int old;
    if (sizeof(unsigned int) == 4) return (unsigned int)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((unsigned int *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline Py_ssize_t
_Py_atomic_load_ssize_relaxed(const Py_ssize_t *obj)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) return (Py_ssize_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void*
_Py_atomic_load_ptr_relaxed(const void *obj)
{
    void* old;
    if (sizeof(void*) == 4) return (void*)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((void* *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline unsigned long long
_Py_atomic_load_ullong_relaxed(const unsigned long long *obj)
{
    unsigned long long old;
    if (sizeof(unsigned long long) == 4) return (unsigned long long)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((unsigned long long *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline long long
_Py_atomic_load_llong_relaxed(const long long *obj)
{
    long long old;
    if (sizeof(long long) == 4) return (long long)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((long long *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void
_Py_atomic_store_int(int *obj, int value)
{

    if (sizeof(int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int8(int8_t *obj, int8_t value)
{

    if (sizeof(int8_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int16(int16_t *obj, int16_t value)
{

    if (sizeof(int16_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int32(int32_t *obj, int32_t value)
{

    if (sizeof(int32_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int64(int64_t *obj, int64_t value)
{

    if (sizeof(int64_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_intptr(intptr_t *obj, intptr_t value)
{

    if (sizeof(intptr_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((intptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint8(uint8_t *obj, uint8_t value)
{

    if (sizeof(uint8_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint16(uint16_t *obj, uint16_t value)
{

    if (sizeof(uint16_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint32(uint32_t *obj, uint32_t value)
{

    if (sizeof(uint32_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint64(uint64_t *obj, uint64_t value)
{

    if (sizeof(uint64_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uintptr(uintptr_t *obj, uintptr_t value)
{

    if (sizeof(uintptr_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uintptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint(unsigned int *obj, unsigned int value)
{

    if (sizeof(unsigned int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ptr(void *obj, void *value)
{

    if (sizeof(void*) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((void* *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ssize(Py_ssize_t *obj, Py_ssize_t value)
{

    if (sizeof(Py_ssize_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((Py_ssize_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int_relaxed(int *obj, int value)
{

    if (sizeof(int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int8_relaxed(int8_t *obj, int8_t value)
{

    if (sizeof(int8_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int16_relaxed(int16_t *obj, int16_t value)
{

    if (sizeof(int16_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int32_relaxed(int32_t *obj, int32_t value)
{

    if (sizeof(int32_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int64_relaxed(int64_t *obj, int64_t value)
{

    if (sizeof(int64_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_intptr_relaxed(intptr_t *obj, intptr_t value)
{

    if (sizeof(intptr_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((intptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint8_relaxed(uint8_t *obj, uint8_t value)
{

    if (sizeof(uint8_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint8_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint16_relaxed(uint16_t *obj, uint16_t value)
{

    if (sizeof(uint16_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint16_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint32_relaxed(uint32_t *obj, uint32_t value)
{

    if (sizeof(uint32_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint64_relaxed(uint64_t *obj, uint64_t value)
{

    if (sizeof(uint64_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uintptr_relaxed(uintptr_t *obj, uintptr_t value)
{

    if (sizeof(uintptr_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uintptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint_relaxed(unsigned int *obj, unsigned int value)
{

    if (sizeof(unsigned int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ptr_relaxed(void *obj, void *value)
{

    if (sizeof(void*) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((void* *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ssize_relaxed(Py_ssize_t *obj, Py_ssize_t value)
{

    if (sizeof(Py_ssize_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((Py_ssize_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ullong_relaxed(unsigned long long *obj,
                                unsigned long long value)
{

    if (sizeof(unsigned long long) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned long long *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_char_relaxed(char *obj, char value)
{

    if (sizeof(char) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((char *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uchar_relaxed(unsigned char *obj, unsigned char value)
{

    if (sizeof(unsigned char) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned char *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_short_relaxed(short *obj, short value)
{

    if (sizeof(short) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((short *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ushort_relaxed(unsigned short *obj, unsigned short value)
{

    if (sizeof(unsigned short) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned short *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_long_relaxed(long *obj, long value)
{

    if (sizeof(long) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((long *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_float_relaxed(float *obj, float value)
{

    
    _Py_wasm_atomic_lock();
    *((float *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_double_relaxed(double *obj, double value)
{

    
    _Py_wasm_atomic_lock();
    *((double *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_llong_relaxed(long long *obj, long long value)
{

    if (sizeof(long long) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((long long *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void *
_Py_atomic_load_ptr_acquire(const void *obj)
{
    void* old;
    if (sizeof(void*) == 4) return (void *)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((void* *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uintptr_t
_Py_atomic_load_uintptr_acquire(const uintptr_t *obj)
{
    uintptr_t old;
    if (sizeof(uintptr_t) == 4) return (uintptr_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uintptr_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void
_Py_atomic_store_ptr_release(void *obj, void *value)
{

    if (sizeof(void*) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((void* *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uintptr_release(uintptr_t *obj, uintptr_t value)
{

    if (sizeof(uintptr_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uintptr_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_int_release(int *obj, int value)
{

    if (sizeof(int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint_release(unsigned int *obj, unsigned int value)
{

    if (sizeof(unsigned int) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((unsigned int *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_ssize_release(Py_ssize_t *obj, Py_ssize_t value)
{

    if (sizeof(Py_ssize_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((Py_ssize_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline int
_Py_atomic_load_int_acquire(const int *obj)
{
    int old;
    if (sizeof(int) == 4) return (int)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((int *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void
_Py_atomic_store_uint32_release(uint32_t *obj, uint32_t value)
{

    if (sizeof(uint32_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint32_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline void
_Py_atomic_store_uint64_release(uint64_t *obj, uint64_t value)
{

    if (sizeof(uint64_t) == 4) { __builtin(atomic_store32, (int *)obj, (int)value); return; }
    _Py_wasm_atomic_lock();
    *((uint64_t *)obj) = value;
    _Py_wasm_atomic_unlock();
}

static inline uint64_t
_Py_atomic_load_uint64_acquire(const uint64_t *obj)
{
    uint64_t old;
    if (sizeof(uint64_t) == 4) return (uint64_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint64_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline uint32_t
_Py_atomic_load_uint32_acquire(const uint32_t *obj)
{
    uint32_t old;
    if (sizeof(uint32_t) == 4) return (uint32_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((uint32_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline Py_ssize_t
_Py_atomic_load_ssize_acquire(const Py_ssize_t *obj)
{
    Py_ssize_t old;
    if (sizeof(Py_ssize_t) == 4) return (Py_ssize_t)__builtin(atomic_load32, (int *)obj);
    _Py_wasm_atomic_lock();
    old = *((Py_ssize_t *)obj);
    _Py_wasm_atomic_unlock();
    return old;
}

static inline void
_Py_atomic_fence_seq_cst(void)
{
    __builtin(atomic_fence);
}

static inline void
_Py_atomic_fence_acquire(void)
{
    __builtin(atomic_fence);
}

static inline void
_Py_atomic_fence_release(void)
{
    __builtin(atomic_fence);
}
