"""Fresh-process subprocess backend for the wasm-posix port.

All child setup uses spawn actions. Never change the parent's cwd, environment,
signal dispositions or descriptor inheritance to prepare a child.
"""

import errno
import fcntl
import os
import signal
import stat


def spawn(args, executable, env, cwd, close_fds, pass_fds,
          preexec_fn, restore_signals, start_new_session, process_group,
          gid, gids, uid, umask,
          p2cread, p2cwrite, c2pread, c2pwrite, errread, errwrite):
    unsupported = {
        "preexec_fn": preexec_fn is not None,
        "pass_fds": bool(pass_fds),
        "start_new_session": start_new_session,
        "group": gid is not None,
        "extra_groups": gids is not None,
        "user": uid is not None,
        "umask": umask >= 0,
    }
    for name, requested in unsupported.items():
        if requested:
            raise NotImplementedError(
                name + " is not supported by wasm-posix subprocess spawning")

    actions = []
    if cwd is not None:
        # Report an invalid directory using its own filename, as Popen does.
        # The spawn action validates it again when constructing the child.
        if not stat.S_ISDIR(os.stat(cwd).st_mode):
            raise NotADirectoryError(errno.ENOTDIR, os.strerror(errno.ENOTDIR), cwd)
        actions.append((os.POSIX_SPAWN_CHDIR, cwd))

    attributes = {}
    if process_group != -1:
        attributes["setpgroup"] = process_group
    if restore_signals:
        attributes["setsigdef"] = [getattr(signal, name)
                                   for name in ("SIGPIPE", "SIGXFZ", "SIGXFSZ")
                                   if hasattr(signal, name)]

    original_executable = os.fspath(executable)
    executable = os.fsencode(executable)
    if os.path.dirname(executable):
        candidates = (executable,)
    else:
        # Use the supplied environment's PATH, matching Popen rather than the
        # parent's PATH used by libc posix_spawnp. Relative entries resolve
        # against the child's directory through the chdir spawn action.
        candidates = tuple(os.path.join(os.fsencode(directory), executable)
                           for directory in os.get_exec_path(env))

    temporary = []
    try:
        # Snapshot all redirection sources before assigning 0, 1 and 2.
        # This also handles closed standard descriptors and crossed mappings.
        redirects = []
        for source, target in ((p2cread, 0), (c2pwrite, 1), (errwrite, 2)):
            if source != -1:
                copy = fcntl.fcntl(source, fcntl.F_DUPFD_CLOEXEC, 3)
                temporary.append(copy)
                redirects.append((os.POSIX_SPAWN_DUP2, copy, target))
        for fd in sorted({p2cwrite, c2pread, errread} - {-1}):
            actions.append((os.POSIX_SPAWN_CLOSE, fd))
        actions.extend(redirects)
        if close_fds:
            actions.append((os.POSIX_SPAWN_CLOSEFROM, 3))
        else:
            actions.extend((os.POSIX_SPAWN_CLOSE, fd) for fd in temporary)

        first_error = None
        last_error = None
        for candidate in candidates:
            try:
                return os.posix_spawn(candidate, args,
                                      os.environ if env is None else env,
                                      file_actions=actions, **attributes)
            except OSError as error:
                last_error = error
                if first_error is None and error.errno not in (errno.ENOENT, errno.ENOTDIR):
                    first_error = error
        error = first_error or last_error
        code = error.errno if error is not None else errno.ENOENT
        raise OSError(code, os.strerror(code), original_executable)
    finally:
        for fd in temporary:
            os.close(fd)
