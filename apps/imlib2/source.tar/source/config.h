#define BUILD_X11 1
#define ENABLE_TEXT 1
#define ENABLE_FILTERS 1
#define BUILD_PNG_LOADER 1
#define BUILD_JPEG_LOADER 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_DLFCN_H 1
#define HAVE_UNISTD_H 1
#define HAVE_WCHAR_H 1
#define HAVE_VISIBILITY 0
#define PACKAGE "imlib2"
#define PACKAGE_VERSION "1.6.1"
#define VERSION "1.6.1"
#define PACKAGE_LIB_DIR "/usr/local/lib"
#define PACKAGE_DATA_DIR "/usr/local/share/imlib2"
#define __EXPORT__
#define __PACKED__ __attribute__((packed))
