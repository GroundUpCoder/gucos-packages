import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('2048',1700000);
try {
 const script=await readFile(new URL('./2048-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['2048'],fresh:['2048']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.ok(log.includes('2048-ACCEPTANCE-PASS'),log);
 await page.evaluate(()=>shell.terminal.focus());
 await page.keyboard.type('sh');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>shell.busybox?.ready&&shell.ui.session===shell.busybox);
 await page.keyboard.type('2048');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>{
  const b=shell.terminal.buffer.active;
  return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)).join('\n').includes('2048');
 });
 for(const key of ['a','d','w','s']){await page.keyboard.type(key);await page.waitForTimeout(200);}
 await page.keyboard.type('r');
 await page.waitForFunction(()=>shell.busybox.log.includes('RESTART? (y/n)'));
 await page.keyboard.type('y');await page.waitForTimeout(200);
 await page.keyboard.type('q');
 await page.waitForFunction(()=>shell.busybox.log.includes('QUIT? (y/n)'));
 await page.keyboard.type('y');await page.waitForTimeout(200);
 await page.keyboard.type('echo 2048-INTERACTIVE-PASS');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>shell.busybox.log.includes('\n2048-INTERACTIVE-PASS\n'));
 const finalLog=await page.evaluate(()=>shell.busybox.log);
 assert.ok(finalLog.includes('\x1b[?25h'),'cursor restored');
 await page.keyboard.type('exit');await page.keyboard.press('Enter');
 await page.waitForFunction(()=>!shell.ui.session&&!shell.ui.busy);
 assert.deepEqual(errors,[]);
} finally {await close();}
