#!/bin/sh
set -e
stage=$1
cd /usr/src/2048
mkdir -p "$stage/bin" "$stage/share/doc/2048"
cc -O2 2048.c -o "$stage/bin/2048"
cp README.md UPSTREAM.json "$stage/share/doc/2048/"
cp LICENSE "$stage/share/doc/2048/"
