# 2048

Unchanged upstream 2048.c 1.0.3, MIT licensed; pinned revision and source
checksums in UPSTREAM.json. Built with the guest C compiler against libc.

`gucman install 2048`, then `2048`. Use arrows or WASD, r then y to restart,
q then y to quit. `2048 test` runs the 13 upstream merge/score cases.
`npm run test:entertainment` also tests browser terminal keyboard input and
terminal restoration after quitting. No curses dependency or network required.
