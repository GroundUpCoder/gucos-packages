#pragma once
#include <netinet/in.h>
#include <netdb.h>
/* Libevent supplies its own address conversion routines. */
#include <stdio.h>
static inline char *inet_ntoa(struct in_addr address){
 static _Thread_local char text[16];
 const unsigned char *p=(const unsigned char *)&address.s_addr;
 snprintf(text,sizeof(text),"%u.%u.%u.%u",p[0],p[1],p[2],p[3]);return text;
}
