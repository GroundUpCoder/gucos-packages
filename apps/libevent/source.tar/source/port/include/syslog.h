#pragma once
/* These upstream files include syslog.h but do not use its API. */
