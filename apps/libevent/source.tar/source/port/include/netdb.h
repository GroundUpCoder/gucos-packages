#pragma once
#include <sys/socket.h>
#include <errno.h>
/* DNS is not exposed by wasm-posix. Numeric addresses use Libevent's parser. */
struct hostent { char *h_name; char **h_aliases; int h_addrtype; int h_length; char **h_addr_list; };
#define TRY_AGAIN 2
#define NO_RECOVERY 3
static _Thread_local int h_errno;
static inline struct hostent *gethostbyname(const char *name){(void)name;h_errno=NO_RECOVERY;errno=ENOSYS;return 0;}
static inline struct hostent *gethostbyaddr(const void *address,socklen_t length,int type){(void)address;(void)length;(void)type;h_errno=NO_RECOVERY;errno=ENOSYS;return 0;}

#define HOST_NOT_FOUND 1
#define NO_ADDRESS 4
#define NO_DATA NO_ADDRESS
