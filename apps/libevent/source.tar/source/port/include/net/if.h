#pragma once
#include <errno.h>
/* No host network interfaces are exposed by this platform. */
static inline unsigned if_nametoindex(const char *name) { (void)name; errno=ENXIO; return 0; }
