#include <event2/event.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){struct event_base *base=event_base_new();assert(base);assert(!strcmp(event_base_get_method(base),"poll"));event_base_free(base);puts("LIBEVENT-PASS");return 0;}
