# libevent 2.1.12-stable

Source: https://github.com/libevent/libevent/releases/download/release-2.1.12-stable/libevent-2.1.12-stable.tar.gz

Archive SHA-256: `92e6de1be9ec176428fd2367677e61ceffc2ee1cb119035037a27d346b0403bb`

Upstream C sources are unchanged. The explicit target configuration selects poll, pthreads and the ILP32 ABI. The archive includes core, buffers, DNS, HTTP and RPC code; OpenSSL is excluded. The private compatibility headers describe internet addresses but DNS lookup reports ENOSYS. AF_INET/AF_INET6 sockets are not implemented by the platform, so network DNS/HTTP services are not supported. Unix-domain streams, timers and pthread notification use the real kernel.
