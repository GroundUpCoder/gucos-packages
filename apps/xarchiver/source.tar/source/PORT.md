# Xarchiver 0.5.4.22

Source: https://github.com/ib/xarchiver/archive/refs/tags/0.5.4.22.tar.gz
SHA-256: 425b203f59a5e3d0747e80cbbe0af0beb0f9b77bbe29a9b233e85c54a4ff6193
Licenses: COPYING and the dual-license notices in src/xdgmime.

Targets the existing GTK3 browser backend using a local configuration header.
All 37 upstream C files compile unchanged. Installed execution is pending.
Archive format support depends on the external programs installed in the guest;
listing a format in the upstream UI does not supply its compressor.
