#!/bin/sh
set -e
stage=$1
cd /usr/src/xarchiver
mkdir -p "$stage/bin" "$stage/libexec" "$stage/share/pixmaps/xarchiver" "$stage/share/doc/xarchiver" "$stage/share/applications"
cc -DHAVE_CONFIG_H -D__unix__ -Iport -Isrc -Isrc/xdgmime src/7zip.c src/add_dialog.c src/ar.c src/archive.c src/arj.c src/cpio.c src/date_utils.c src/exe.c src/extract_dialog.c src/gzip_et_al.c src/interface.c src/iso.c src/lha.c src/main.c src/mime.c src/new_dialog.c src/open-with-dlg.c src/pref_dialog.c src/rar.c src/rpm.c src/socket.c src/squashfs.c src/string_utils.c src/tar.c src/unar.c src/utf8-fnmatch.c src/window.c src/zip.c src/zpaq.c src/xdgmime/xdgmime.c src/xdgmime/xdgmimealias.c src/xdgmime/xdgmimecache.c src/xdgmime/xdgmimeglob.c src/xdgmime/xdgmimeicon.c src/xdgmime/xdgmimeint.c src/xdgmime/xdgmimemagic.c src/xdgmime/xdgmimeparent.c $(pkg-config --cflags --libs gtk+-3.0) -lintl -o "$stage/libexec/xarchiver"
cp pixmaps/*.png "$stage/share/pixmaps/xarchiver/"
cp icons/48x48/xarchiver.png "$stage/share/pixmaps/"
cp COPYING PORT.md "$stage/share/doc/xarchiver/"
cat > "$stage/bin/xarchiver" <<'LAUNCH'
#!/bin/sh
export WASM_POSIX_SURFACES=1
exec /usr/local/libexec/xarchiver "$@"
LAUNCH
chmod +x "$stage/bin/xarchiver"
cat > "$stage/share/applications/xarchiver.desktop" <<'APP'
[Desktop Entry]
Type=Application
Name=Archive Manager
Exec=xarchiver %f
Icon=xarchiver
Categories=Utility;Archiving;
Terminal=false
APP
