BEGIN {
	n = 5
