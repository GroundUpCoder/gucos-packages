getline $1+++++++
