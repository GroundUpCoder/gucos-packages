	print n
}
