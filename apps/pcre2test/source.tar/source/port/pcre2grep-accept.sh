set -e
gucman install pcre2grep
mkdir /tmp/pcre2grep-upstream
cd /tmp/pcre2grep-upstream
export srcdir=/usr/src/pcre2-cli/port/cli-fixtures
ln -s /usr/local/lib/wasm-posix/pcre2test pcre2test
ln -s /usr/local/lib/wasm-posix/pcre2grep pcre2grep
sh "$srcdir/RunGrepTest" 
printf 'abc123\nxyz\ndef456\n' > /tmp/regex-input
pcre2grep -o '(?<=abc)[0-9]+' /tmp/regex-input > /tmp/regex-output
test "$(cat /tmp/regex-output)" = 123

echo PCRE2GREP-ACCEPTANCE-PASS
