set -e
gucman install pcre2test
mkdir /tmp/pcre2test-upstream
cd /tmp/pcre2test-upstream
export srcdir=/usr/src/pcre2-cli/port/cli-fixtures
ln -s /usr/local/lib/wasm-posix/pcre2test pcre2test
sh "$srcdir/RunTest" -8 -nojit
cat > /tmp/regex-test <<'EOF'
/^(ab+)([0-9]+)$/
abb42
wrong

EOF
pcre2test /tmp/regex-test > /tmp/regex-result
grep '1: abb' /tmp/regex-result
grep '2: 42' /tmp/regex-result
grep 'No match' /tmp/regex-result

echo PCRE2TEST-ACCEPTANCE-PASS
