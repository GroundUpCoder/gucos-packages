# PCRE2 command-line packages

The pcre2grep and pcre2test packages compile unchanged PCRE2 10.46 sources from
vendor/pcre2 through an explicit sourceTrees dependency. Licensing and source
provenance remain there; LICENCE.md is copied verbatim for this ownership unit.
The library package remains separately owned and its build inputs are unchanged.
The historical vendor/pcre2 project manifests remain available for reproduction.

The CLI recipes select the compiler's existing --no-native-functions mode.
Native WebAssembly calls exhaust Chromium's host call stack in upstream test8's
hundreds-deep recursive pattern compilation. Disabling inlining alone still
fails; framed calls pass the unchanged test. No pattern-depth limit or test is
reduced. Calls use the existing bounded linear-memory frames: O(depth) space
and O(1) work per call, with different constant costs. The test executable probe
increased from 944643 native bytes to 5147230 framed bytes. This is not a claim
of equal speed or footprint; the complete acceptance results record execution.
No compiler/runtime or upstream C source was patched for this configuration.

Only the configured 8-bit API is built, with UTF/UCP support. Existing exclusions
remain: no JIT, readline/editline, grep script callouts or compressed-file input.
The untouched upstream RunTest and RunGrepTest plus their data are copied into
explicit test fixtures. Source and binary phases run those scripts; original
locale/16-bit/32-bit/JIT/disabled-feature skips and unchecked coverage cases stay
visible. The optional environment-specific heap test is not selected. Test-only
pcre2test is an exact dependency of pcre2grep acceptance, not its runtime closure.

The separate source unit prevents CLI build-configuration changes from silently
changing the already published library's source hash. The final combined-bundle
key audit must preserve the existing published library/dependent pins. Failed
native and no-inline attempts remain evidence, never selected release candidates.
