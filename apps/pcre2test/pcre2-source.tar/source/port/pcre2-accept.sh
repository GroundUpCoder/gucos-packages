set -e
gucman install pcre2 pkgconf
cc /usr/src/pcre2/port/pcre2-accept.c $(pkg-config --cflags --libs libpcre2-8) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
