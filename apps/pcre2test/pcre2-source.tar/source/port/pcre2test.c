/* The manifest shares library flags across sources; the upstream test driver
 * selects width 0 itself to exercise all configured libraries. */
#undef PCRE2_CODE_UNIT_WIDTH
#include "../src/pcre2test.c"
