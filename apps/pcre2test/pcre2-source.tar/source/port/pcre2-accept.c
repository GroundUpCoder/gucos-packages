#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>
#include <assert.h>
int main(void){int error;PCRE2_SIZE pos; pcre2_code *re=pcre2_compile((PCRE2_SPTR)"^(?<word>\\p{L}+)([0-9]+)$",PCRE2_ZERO_TERMINATED,PCRE2_UTF|PCRE2_UCP,&error,&pos,0); assert(re);pcre2_match_data *m=pcre2_match_data_create_from_pattern(re,0);assert(pcre2_match(re,(PCRE2_SPTR)"café42",7,0,0,m,0)==3);PCRE2_UCHAR *word=0;PCRE2_SIZE size;assert(pcre2_substring_get_byname(m,(PCRE2_SPTR)"word",&word,&size)==0&&size==5);pcre2_substring_free(word);assert(pcre2_match(re,(PCRE2_SPTR)"!",1,0,0,m,0)==PCRE2_ERROR_NOMATCH);pcre2_match_data_free(m);pcre2_code_free(re);return 0;}
