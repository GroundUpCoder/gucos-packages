# PCRE2 10.46 for wasm-posix

Pinned source archive:
https://github.com/PCRE2Project/pcre2/releases/download/pcre2-10.46/pcre2-10.46.tar.bz2

SHA-256: `15fbc5aba6beee0b17aecb04602ae39432393aba1ebd8e39b7cabf7db883299f`

The upstream src/ and testdata/ trees, RunTest, RunGrepTest and licensing files
are copied unchanged. Local additions are the manifests, Makefile, port/ wrapper,
this document and three generated/copied configuration files:

- src/pcre2.h is the unmodified pcre2.h.generic.
- src/pcre2_chartables.c is the unmodified pcre2_chartables.c.dist.
- src/config.h starts with config.h.generic, enabling SUPPORT_PCRE2_8,
  SUPPORT_UNICODE and the available standard header/memmove/strerror features.
  Compare the two files for the complete configuration delta.

Only the 8-bit library is configured; UTF-8 and Unicode properties are enabled.
JIT, readline/editline, grep script callouts and compressed-file support are off.
This follows upstream NON-AUTOTOOLS-BUILD, not a successful configure/Meson run.
The local Makefile uses separate objects and an archive. The project test driver
wrapper undefines the library-wide code-unit-width flag before including the
upstream test driver, which selects width 0 itself.

`gucman install pcre2grep pcre2test` explicitly builds the two executables.
Sources and tests are available in /usr/src/pcre2. The library manifest is
lib.json; gucman currently manages executables, not installed library packages.

`npm run test:pcre2` runs the unchanged upstream RunTest and RunGrepTest scripts
against both gucman-built executables and separately compiled objects/archive.
Expected outputs and binary fixtures are preserved byte-for-byte. The runner's
locale, 16/32-bit, JIT and disabled-backslash-C skips remain visible. Test 0 and
some grep argument exercises are explicitly unchecked upstream coverage cases.
The optional environment-specific heap test is not selected. See
../../docs/PCRE2-GLIB.md for commands, results and remaining platform gaps.
