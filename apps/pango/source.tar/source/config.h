/* wasm-posix: FreeType/Fontconfig/Cairo; no platform backends. */
#define HAVE_FREETYPE 1
#define HAVE_CAIRO 1
#define HAVE_CAIRO_FREETYPE 1
#define HAVE_CAIRO_PNG 1
#define HAVE_FCWEIGHTFROMOPENTYPEDOUBLE 1
#define HAVE_UNISTD_H 1
#define HAVE_DIRENT_H 1
#define PANGO_VERSION_MAJOR 1
#define PANGO_VERSION_MINOR 50
#define PANGO_VERSION_MICRO 14
#define PANGO_VERSION_STRING "1.50.14"
#define PANGO_BINARY_AGE 5014
#define PANGO_INTERFACE_AGE 0
#define GETTEXT_PACKAGE "pango"
#define SYSCONFDIR "/etc"
#define LIBDIR "/usr/local/lib"
