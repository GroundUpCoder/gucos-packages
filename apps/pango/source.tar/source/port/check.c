#include <assert.h>
#include <gio/gio.h>
#include <fontconfig/fontconfig.h>
#include <pango/pangocairo.h>
#include <pango/pangofc-fontmap.h>
#include <stdio.h>
#include <hb.h>
#ifndef PANGO_TEST_CJK_FONT
#define PANGO_TEST_CJK_FONT "/usr/src/pango/port/fonts/cjk-subset.otf"
#endif
int main(void) {
  assert(hb_version_atleast(14, 5, 0));
  PangoCoverage *coverage = pango_coverage_new();
  pango_coverage_set(coverage, 'A', PANGO_COVERAGE_EXACT);
  pango_coverage_set(coverage, 'A', PANGO_COVERAGE_NONE);
  PangoCoverage *copy = pango_coverage_copy(coverage);
  assert(pango_coverage_get(copy, 'A') == PANGO_COVERAGE_NONE);
  pango_coverage_unref(copy);
  pango_coverage_unref(coverage);
  FcConfig *config = FcInitLoadConfigAndFonts();
  assert(config);
  FcFontSet *fonts = FcConfigGetFonts(config, FcSetSystem);
  assert(fonts && fonts->nfont >= 2);
  printf("Fontconfig fonts: %d\n", fonts->nfont);
  cairo_surface_t *surface =
      cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 640, 240);
  cairo_t *cr = cairo_create(surface);
  cairo_set_source_rgb(cr, 1, 1, 1);
  cairo_paint(cr);
  PangoLayout *layout = pango_cairo_create_layout(cr);
  assert(layout);
  GListModel *families = G_LIST_MODEL(pango_cairo_font_map_get_default());
  assert(g_list_model_get_n_items(families) > 0);
  GObject *family = g_list_model_get_object(families, 0);
  assert(PANGO_IS_FONT_FAMILY(family)); g_object_unref(family);
  PangoFontDescription *desc = pango_font_description_from_string("ABeeZee 22");
  pango_layout_set_font_description(layout, desc);
  pango_layout_set_width(layout, 590 * PANGO_SCALE);
  pango_layout_set_wrap(layout, PANGO_WRAP_WORD_CHAR);
  pango_layout_set_markup(
      layout,
      "<b>Pango on wasm-posix</b>\n<span foreground='#1854b8'>Fontconfig + "
      "FreeType + Cairo</span>\nManual packages, shared libraries, and wrapped "
      "text.",
      -1);
  int w, h;
  pango_layout_get_pixel_size(layout, &w, &h);
  printf("Layout: %d x %d, lines=%d, unknown=%d\n", w, h,
         pango_layout_get_line_count(layout),
         pango_layout_get_unknown_glyphs_count(layout));
  assert(w > 100 && w <= 590 && h > 40 && h < 240);
  assert(pango_layout_get_unknown_glyphs_count(layout) == 0);
  cairo_move_to(cr, 20, 20);
  cairo_set_source_rgb(cr, .12, .12, .12);
  pango_cairo_show_layout(cr, layout);
  assert(cairo_status(cr) == CAIRO_STATUS_SUCCESS);
  assert(cairo_surface_write_to_png(surface, "/tmp/pango.png") ==
         CAIRO_STATUS_SUCCESS);
  pango_layout_set_attributes(layout, NULL);
  pango_layout_set_text(layout, "a\314\201", -1);
  assert(pango_layout_get_unknown_glyphs_count(layout) == 0);
  pango_layout_set_text(layout, "Open… café Ångström × – —", -1);
  assert(pango_layout_get_unknown_glyphs_count(layout) == 0);
  /* Add the pinned CJK fixture through Fontconfig and exercise Pango's
   * itemization and font callbacks, the installed HarfBuzz library. */
  assert(FcConfigAppFontAddFile(NULL, (const FcChar8 *)
      PANGO_TEST_CJK_FONT));
  pango_fc_font_map_config_changed(PANGO_FC_FONT_MAP(pango_cairo_font_map_get_default()));
  pango_layout_set_text(layout, "한글 한국어 안녕하세요", -1);
  assert(pango_layout_get_unknown_glyphs_count(layout) == 0);
  pango_layout_set_text(layout, "العربية", -1);
  assert(pango_layout_get_unknown_glyphs_count(layout) > 0);
  /* A real Arabic-capable font must shape through Pango, not missing boxes. */
  assert(FcConfigAppFontAddFile(NULL, (const FcChar8 *)
      "/usr/src/pango/tests/fonts/DejaVuSans.ttf"));
  pango_fc_font_map_config_changed(PANGO_FC_FONT_MAP(pango_cairo_font_map_get_default()));
  pango_font_description_set_family(desc, "DejaVu Sans");
  pango_layout_set_font_description(layout, desc);
  pango_layout_set_text(layout, "سلام", -1);
  assert(pango_layout_get_unknown_glyphs_count(layout) == 0);
  PangoLayoutLine *line = pango_layout_get_line_readonly(layout, 0);
  int glyph_count = 0;
  for (GSList *run = line->runs; run; run = run->next)
    glyph_count += ((PangoGlyphItem *)run->data)->glyphs->num_glyphs;
  /* Lam-alef contracts four Unicode characters into three glyphs. */
  assert(glyph_count == 3);
  puts("PANGO-HARFBUZZ-ARABIC-PASS");
  g_object_unref(layout);
  pango_font_description_free(desc);
  cairo_destroy(cr);
  cairo_surface_destroy(surface);
  pango_cairo_font_map_set_default(NULL);
  FcConfigDestroy(config);
  puts("PANGO-PASS");
  return 0;
}
