#include <cairo-ft.h>
#include <hb.h>
#include <hb-ot.h>
#include <stdio.h>
#if !CAIRO_HAS_FC_FONT
#error Pango requires the Cairo Fontconfig backend; run gucman rebuild cairo
#endif
/* Link check only: catches an older installed HarfBuzz or shared libc. */
int main(void) {
  flockfile(stdin);
  funlockfile(stdin);
  if (!hb_version_atleast(14, 5, 0)) return 1;
  hb_blob_destroy(hb_blob_create_from_file("/not-used"));
  hb_font_funcs_destroy(hb_font_funcs_create());
  cairo_font_face_destroy(cairo_ft_font_face_create_for_pattern(NULL));
  return 0;
}
