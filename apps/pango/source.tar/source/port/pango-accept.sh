set -e
gucman install pango pkgconf
cc '-DPANGO_TEST_CJK_FONT="/usr/src/pango/port/fonts/cjk-subset.otf"' /usr/src/pango/port/check.c $(pkg-config --cflags --libs pangocairo) -o /tmp/package-check
/tmp/package-check
for name in test-coverage testcolor testscript testlanguage testmatrix testtabs testboundaries testcontext; do
cc -I/usr/src/pango/tests /usr/src/pango/tests/$name.c $(pkg-config --cflags --libs pangocairo) -o /tmp/$name
G_TEST_SRCDIR=/usr/src/pango/tests /tmp/$name
done
echo PACKAGE-ACCEPT-PASS
