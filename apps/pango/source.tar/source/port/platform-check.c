#include <assert.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdio.h>
#include <sys/time.h>
static FILE *stream;
static atomic_int started, acquired;
static void *reader(void *unused) {
  atomic_store(&started, 1);
  flockfile(stream);
  atomic_store(&acquired, 1);
  assert(getc_unlocked(stream) == 'B');
  funlockfile(stream);
  return NULL;
}
int main(void) {
  struct timeval a = {2147483648LL, 10}, b = {2147483648LL, 11};
  assert(timercmp(&a, &b, <)); assert(timercmp(&a, &b, !=));
  assert(!timercmp(&a, &b, ==)); b.tv_sec++;
  assert(timercmp(&a, &b, <=)); assert(!timercmp(&a, &b, >=));
  b = a; assert(timercmp(&a, &b, ==)); assert(timercmp(&a, &b, >=));
  stream = tmpfile(); assert(stream); fputs("AB", stream); rewind(stream);
  flockfile(stream); flockfile(stream);
  assert(fgetc(stream) == 'A');
  pthread_t thread; assert(!pthread_create(&thread, NULL, reader, NULL));
  while (!atomic_load(&started)) sched_yield();
  assert(!atomic_load(&acquired));
  funlockfile(stream);
  for (int i = 0; i < 10; i++) sched_yield();
  assert(!atomic_load(&acquired));
  funlockfile(stream);
  assert(!pthread_join(thread, NULL)); assert(atomic_load(&acquired));
  fclose(stream); puts("TEXT-PLATFORM-PASS"); return 0;
}
