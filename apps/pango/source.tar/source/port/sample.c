/* cc sample.c $(pkg-config --cflags --libs pangocairo) -o pango-demo */
#include <pango/pangocairo.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifndef PANGO_SAMPLE_NATIVE
#include <SDL3/SDL.h>
#endif
#define WIDTH 720
#define HEIGHT 340
int main(int argc, char **argv) {
  const char *output = argc > 1 ? argv[1] : "/home/user/pango.png";
  cairo_surface_t *surface =
      cairo_image_surface_create(CAIRO_FORMAT_ARGB32, WIDTH, HEIGHT);
  cairo_t *cr = cairo_create(surface);
  cairo_set_source_rgb(cr, .96, .97, .99);
  cairo_paint(cr);
  PangoLayout *layout = pango_cairo_create_layout(cr);
  PangoFontDescription *font = pango_font_description_from_string("ABeeZee 21");
  pango_layout_set_font_description(layout, font);
  pango_layout_set_width(layout, (WIDTH - 64) * PANGO_SCALE);
  pango_layout_set_spacing(layout, 9 * PANGO_SCALE);
  pango_layout_set_wrap(layout, PANGO_WRAP_WORD_CHAR);
  pango_layout_set_markup(
      layout,
      "<span size='xx-large' foreground='#174a80'>Pango in the browser</span>\n"
      "Font discovery, styled text, and automatic line wrapping.\n"
      "<span foreground='#097b65'>Fontconfig + FreeType + Cairo</span>\n"
      "<span size='small'>This C-only shaping backend currently supports "
      "printable ASCII. "
      "Complex text uses visible missing-glyph boxes.</span>",
      -1);
  cairo_move_to(cr, 32, 24);
  cairo_set_source_rgb(cr, .12, .16, .23);
  pango_cairo_show_layout(cr, layout);
  if (cairo_status(cr) || cairo_surface_write_to_png(surface, output))
    return 1;
  printf("Wrote %s (%d lines)\n", output, pango_layout_get_line_count(layout));
#ifndef PANGO_SAMPLE_NATIVE
  if (argc > 2 && !strcmp(argv[2], "--window")) {
    if (!SDL_Init(SDL_INIT_VIDEO))
      return 2;
    SDL_Window *window = SDL_CreateWindow("Pango + Cairo", WIDTH, HEIGHT, 0);
    if (!window)
      return 3;
    SDL_Surface *screen = SDL_GetWindowSurface(window);
    if (!screen || screen->format != SDL_PIXELFORMAT_RGBA32)
      return 4;
    cairo_surface_flush(surface);
    unsigned char *data = cairo_image_surface_get_data(surface);
    int stride = cairo_image_surface_get_stride(surface);
    for (int y = 0; y < HEIGHT; y++)
      for (int x = 0; x < WIDTH; x++) {
        uint32_t p = ((uint32_t *)(data + y * stride))[x];
        unsigned char *dst =
            (unsigned char *)screen->pixels + y * screen->pitch + x * 4;
        dst[0] = p >> 16;
        dst[1] = p >> 8;
        dst[2] = p;
        dst[3] = 255;
      }
    SDL_UpdateWindowSurface(window);
    puts("PANGO-WINDOW-READY");
    fflush(stdout);
    int running = 1;
    while (running) {
      SDL_Event event;
      while (SDL_PollEvent(&event))
        if (event.type == SDL_EVENT_QUIT || event.type == SDL_EVENT_KEY_DOWN)
          running = 0;
      SDL_Delay(16);
    }
    SDL_DestroyWindow(window);
    SDL_Quit();
  }
#endif
  g_object_unref(layout);
  pango_font_description_free(font);
  cairo_destroy(cr);
  cairo_surface_destroy(surface);
  pango_cairo_font_map_set_default(NULL);
  return 0;
}
