import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const name="quake";
const {page,errors,output,close}=await appBrowser(name,1700000);
try {
 const pakSha=createHash('sha256').update(await readFile(new URL('../data/id1/pak0.pak',import.meta.url))).digest('hex');
 const install=await runCached(page,'set -e\ngucman install quake\nsha256sum /usr/local/share/quake/id1/pak0.pak > /tmp/quake-pak.sha\ngrep '+pakSha+' /tmp/quake-pak.sha\nrm -rf /usr/src/quake/data\n',{packages:[name],fresh:[name]});
 assert.equal(install.code,0,await page.evaluate(()=>shell.busybox.log));
 await page.evaluate(command=>{window.acceptanceResult=null;window.acceptanceRun=shell.command('sh -c '+JSON.stringify(command));window.acceptanceRun.then(result=>window.acceptanceResult=result,error=>window.acceptanceResult={error:String(error)});},"quake -nosound +map e1m1");
 const screen=page.locator('.screen:not([hidden])').last(),canvas=screen.locator('canvas');
 await canvas.waitFor({state:'visible',timeout:60000});
 let accepted=false,frame;
 const deadline=Date.now()+60000;
 while(Date.now()<deadline){
  frame=await canvas.screenshot();const png=PNG.sync.read(frame),colors=new Set();
  let red=0,blue=0,total=png.width*png.height;
  for(let i=0;i<png.data.length;i+=4){const r=png.data[i],g=png.data[i+1],b=png.data[i+2];colors.add((r<<16)|(g<<8)|b);if(r>200&&g<60&&b<60)red++;if(b>150&&r<120)blue++;}
  if(colors.size>50){accepted=true;break;}
  await page.waitForTimeout(250);
 }
 await writeFile(output+'/'+name+'-frame.png',frame);
 assert.ok(accepted,name+' renders expected application output');
 await page.waitForTimeout(4000);
 await canvas.click();
 const level=await canvas.screenshot();await writeFile(output+'/quake-level.png',level);
 await page.keyboard.down('w');await page.waitForTimeout(1000);await page.keyboard.up('w');
 await page.keyboard.down('/');await page.waitForTimeout(500);await page.keyboard.up('/');
 const played=await canvas.screenshot();await writeFile(output+'/quake-played.png',played);
 assert.notDeepEqual(PNG.sync.read(played).data,PNG.sync.read(level).data,'movement/fire changes the rendered level');
 await page.keyboard.press('Escape');await page.waitForTimeout(250);
 await writeFile(output+'/quake-menu.png',await canvas.screenshot());
 await screen.getByRole('button',{name:'Close process'}).click();
 await page.waitForFunction(()=>window.acceptanceResult!==null,null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.acceptanceResult.error),undefined);
 assert.deepEqual(errors,[]);
 console.log(name+' render and close acceptance passed');
} finally {await close();}
