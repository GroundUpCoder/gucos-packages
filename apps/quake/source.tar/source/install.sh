#!/bin/sh
set -e
stage=$1
mkdir -p "$stage/lib/wasm-posix" "$stage/share/quake/id1"
cc --project /usr/src/quake/bin.json -o "$stage/lib/wasm-posix/quake"
cp /usr/src/quake/data/id1/pak0.pak /usr/src/quake/data/id1/autoexec.cfg "$stage/share/quake/id1/"
cp /usr/src/quake/data/SHAREWARE-LICENSE.txt "$stage/share/quake/"
