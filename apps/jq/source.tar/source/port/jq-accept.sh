set -e
gucman install jq
printf '%s\n' '{"items":[{"n":7},{"n":14},{"n":21}]}' > /tmp/input.json
jq -c '[.items[].n | select(. > 10)] | {values: ., sum: add}' /tmp/input.json > /tmp/output.json
test "$(cat /tmp/output.json)" = '{"values":[14,21],"sum":35}'

echo JQ-ACCEPTANCE-PASS
