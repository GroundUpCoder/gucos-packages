/* wasm-posix portable C configuration; SIMD deliberately disabled. */
#define PACKAGE "pixman"
#define TLS _Thread_local
#define HAVE_PTHREADS 1
#define HAVE_STDINT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_GETTIMEOFDAY 1
#ifdef __wasm__
#define SIZEOF_LONG 4
#else
#define SIZEOF_LONG __SIZEOF_LONG__
#endif
