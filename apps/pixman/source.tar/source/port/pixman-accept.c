#include <pixman.h>
#include <assert.h>
int main(void){uint32_t pixels[4]={0};pixman_image_t *dst=pixman_image_create_bits(PIXMAN_a8r8g8b8,2,2,pixels,8);pixman_color_t red={65535,0,0,65535};pixman_image_t *src=pixman_image_create_solid_fill(&red);pixman_region32_t clip;pixman_region32_init_rect(&clip,1,0,1,2);assert(pixman_image_set_clip_region32(dst,&clip));pixman_image_composite32(PIXMAN_OP_SRC,src,0,dst,0,0,0,0,0,0,2,2);assert(pixels[0]==0&&pixels[1]==0xffff0000&&pixels[2]==0&&pixels[3]==0xffff0000);pixman_region32_fini(&clip);pixman_image_unref(src);pixman_image_unref(dst);return 0;}
