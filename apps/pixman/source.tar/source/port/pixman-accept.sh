set -e
gucman install pixman pkgconf
cc /usr/src/pixman/port/pixman-accept.c $(pkg-config --cflags --libs pixman-1) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
