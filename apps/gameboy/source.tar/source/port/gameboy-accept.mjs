import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const name="gameboy";
const {page,errors,output,close}=await appBrowser(name,1700000);
try {
 const install=await runCached(page,'set -e\ngucman install '+name+'\n',{packages:[name],fresh:[name]});
 assert.equal(install.code,0,await page.evaluate(()=>shell.busybox.log));
 await page.evaluate(command=>{window.acceptanceResult=null;window.acceptanceRun=shell.command('sh -c '+JSON.stringify(command));window.acceptanceRun.then(result=>window.acceptanceResult=result,error=>window.acceptanceResult={error:String(error)});},"gameboy");
 const screen=page.locator('.screen:not([hidden])').last(),canvas=screen.locator('canvas');
 await canvas.waitFor({state:'visible',timeout:60000});
 let accepted=false,frame;
 const deadline=Date.now()+60000;
 while(Date.now()<deadline){
  frame=await canvas.screenshot();const png=PNG.sync.read(frame),colors=new Set();
  let red=0,blue=0,total=png.width*png.height;
  for(let i=0;i<png.data.length;i+=4){const r=png.data[i],g=png.data[i+1],b=png.data[i+2];colors.add((r<<16)|(g<<8)|b);if(r>200&&g<60&&b<60)red++;if(b>150&&r<120)blue++;}
  if(colors.size>=3){accepted=true;break;}
  await page.waitForTimeout(250);
 }
 await writeFile(output+'/'+name+'-frame.png',frame);
 assert.ok(accepted,name+' renders expected application output');
 const pixels=PNG.sync.read(frame).data;
 // Original palette RGB values, independent of window integer byte order.
 const expected=['155,188,15','139,172,15','48,98,48','15,56,15'];
 const counts=new Map();
 for(let i=0;i<pixels.length;i+=4){const rgb=[...pixels.subarray(i,i+3)].join(',');counts.set(rgb,(counts.get(rgb)||0)+1);}
 await writeFile(output+'/palette-counts.json',JSON.stringify({expected,counts:Object.fromEntries(counts)},null,2)+'\n');
 for(const rgb of expected)assert.ok((counts.get(rgb)||0)>100,'original palette color '+rgb+' is rendered');
 assert.ok(expected.reduce((n,rgb)=>n+(counts.get(rgb)||0),0)/(pixels.length/4)>0.95,'original palette covers the emulated frame');
 let animated=false;
 for(let i=0;i<20;i++){
  await page.waitForTimeout(137);
  const next=await canvas.screenshot();
  if(!PNG.sync.read(next).data.equals(PNG.sync.read(frame).data)){
   await writeFile(output+'/'+name+'-animated.png',next);animated=true;break;
  }
 }
 assert.ok(animated,'built-in ROM continues scrolling across frames');
 await screen.getByRole('button',{name:'Close process'}).click();
 await page.waitForFunction(()=>window.acceptanceResult!==null,null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.acceptanceResult.error),undefined);
 assert.deepEqual(errors,[]);
 console.log(name+' render and close acceptance passed');
} finally {await close();}
