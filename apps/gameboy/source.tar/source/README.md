# Game Boy Emulator

> **wasm-posix packaging.** `gucman install gameboy` builds this tree; `gameboy [ROM.gb]` runs it in an SDL window with audio, and the built-in test ROM is used when no file is given. No ROM files are bundled. The `targets/` manifests and `roms/` directory mentioned below belong to the sibling compiler repository and are not vendored here.

Game Boy emulator using [Peanut-GB](https://github.com/deltabeard/Peanut-GB)
(MIT license, commit 8e65698) with a custom APU implementation and SDL frontend.

If no ROM is provided, a built-in test ROM draws a scrolling checkerboard.

## Controls

- Arrow keys = D-pad
- Z = A button
- X = B button
- Enter = Start
- Right Shift = Select

## Usage

Build standalone (uses built-in test ROM):

    node compiler.js vendor/gameboy/bin.json -a compile -o gameboy.html

Build with a ROM:

    node compiler.js vendor/gameboy/targets/pokemon.json -a compile -o pokemon.html

Place ROM files in `roms/` (gitignored).

## Installed acceptance and palette correction

Version0.1.0-2 packs the original palette RGB values as 0xAARRGGBB for the
actual window surface. The old ABGR constants swapped red/blue in the two
lightest shades. Only constant values change; no extra pixel work or buffers.
Source/binary acceptance checks all four exact RGB colors, palette coverage,
scrolling between decoded frames and clean closure. The original test ROM and
Peanut-GB core are unchanged. Controls,audio,external games and CPU conformance
remain outside this built-in-ROM acceptance scope.
