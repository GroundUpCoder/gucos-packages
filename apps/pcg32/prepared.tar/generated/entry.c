#include <stdio.h>
int run_tests(void);
int main(void){int r=run_tests(); printf("PCG32-result=%d\n",r); return r ? 1 : 0;}
