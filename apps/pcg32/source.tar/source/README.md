# pcg32 LLVM-to-C acceptance

This is a small real-library acceptance workload for the host C++ translator,
not a published wasm-posix package. The unchanged scalar header from
[wjakob/pcg32](https://github.com/wjakob/pcg32) is pinned at
`70099eadb86d3999c38cf69d2c55f8adc1f7fe34`. `provenance.json` records the
download URLs and SHA-256 hashes. Upstream sources retain their Apache 2.0 notices;
`upstream/LICENSE` supplies the license text. The SIMD companion is outside scope.

`samples.cpp` and `shuffle.cpp` are our acceptance adapters. `api.h` is the ordinary
C interface; `translation-api.h` additionally declares the wasm32 libc import
`memcpy`. The upstream demo and its output are retained as reference material;
the demo executable itself is **not** translated by this acceptance.

## Run

Use the translator's pinned llvmlite environment and Python 3.12 or newer:

```sh
node tools/libc-gates.mjs test-results/cpp-translator/venv/bin/python apps/pcg32/check.py
```

The script downloads the official WASI SDK 30 sysroot archive to ignored
`test-results/cpp-translator/toolchains/`, verifies its pinned SHA-256 and safely
extracts a fresh tree for each run. It uses the real libc++ and WASI C headers,
not stub replacements. Clang supplies only frontend lowering; the generated C
links against wasm-posix libc, not the WASI SDK runtime. Native reference builds
use the host C++ headers. The initial download is approximately 70 MB.

Compilation uses the translator's wasm32 C++17 O0 profile with exceptions and
RTTI disabled. `NDEBUG` selects upstream release behavior, including disabling
the distance operator's assertions. Inputs respect its same-stream precondition;
bounded generation always uses a positive bound and shuffle a nonempty range.

Each of four seeds produces 70 scalar samples and a 52-element permutation.
Native C++ O0 and O2 must agree on all 488 outputs. Six known outputs also check
the published upstream seed-42 example. The ordinary C caller checks every value
after translation, including exact float/double bits, rejection sampling,
constructors, default state, jump-ahead, rewind, distance and equality. It runs
through whole-source, separate-object and archive links with both compiler
backend modes. A nonzero result identifies the mismatching output index.
Optimized Python is rejected so it cannot disable the checks. Failed runs retain
their work directory; successful reports include implementation hashes and a
digest of the native reference values. A separate shuffle-only manifest check
ensures generated memory accesses declare their synthesized `memcpy` dependency.

The two independently translated units share four PCG methods. Their manifests
must resolve each shared method once; the shuffle specialization and libc++
`iter_swap`/`swap`/`move` helpers remain separately emitted definitions. This
demonstrates real header/template code within the existing bounded importer;
it does not establish arbitrary standard-library or cross-version ABI support.

Keep this workload separate from routine compiler gates. Extend coverage only
when another actual port exposes a missing requirement. HarfBuzz, general build
capture, public aggregate interfaces, RTTI and exceptions remain later work.
