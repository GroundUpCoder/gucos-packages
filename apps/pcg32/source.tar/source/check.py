#!/usr/bin/env python3
"""Small upstream acceptance; deliberately separate from routine compiler gates."""
import hashlib
import json
import os
from contextlib import contextmanager
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / 'test-results/cpp-translator'
TRANSLATOR = ROOT / 'tools/cpp-translator/translate.py'
CLANG = os.environ.get('CLANG', 'clang')
SDK_URL = 'https://github.com/WebAssembly/wasi-sdk/releases/download/wasi-sdk-30/wasi-sysroot-30.0.tar.gz'
SDK_SHA256 = '0c8f3e0acab6d3061834395a16550c359766909fda046af3d9b8cf3bfdb1c2cc'
SEEDS = [42, 0, 0xFFFFFFFFFFFFFFFF, 0x853c49e6748fea9b]


def run(*args):
    p = subprocess.run([str(x) for x in args], text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stdout + p.stderr)
    return p.stdout


def input_hashes():
    paths = {*HERE.glob('*.cpp'), *HERE.glob('*.h'), Path(__file__),
             HERE/'provenance.json', * (HERE/'upstream').glob('*'), TRANSLATOR,
             * (ROOT/'tools/cpp-translator').glob('*.py'), * (ROOT/'tools/cpp-translator').glob('*.hpp'),
             ROOT/'tools/cpp-translator/tests/run-generated.mjs', ROOT/'tools/compiler-context.mjs',
             * (ROOT/'src').glob('*.js'), * (ROOT/'libc').rglob('*')}
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths) if p.is_file()}


@contextmanager
def workspace():
    work = Path(tempfile.mkdtemp(prefix='pcg32-', dir=BASE))
    try:
        yield work
    except BaseException:
        print('Failure artifacts retained at '+str(work), file=sys.stderr)
        raise
    else:
        shutil.rmtree(work)


def main():
    if not __debug__:
        raise RuntimeError('Acceptance requires assertions; unset PYTHONOPTIMIZE and omit -O')
    if sys.version_info < (3, 12):
        raise RuntimeError('Use Python 3.12+ for safe tar extraction')
    provenance = json.loads((HERE/'provenance.json').read_text())
    for name, row in provenance['files'].items():
        assert hashlib.sha256((HERE/'upstream'/name).read_bytes()).hexdigest() == row['sha256'], name
    BASE.mkdir(parents=True, exist_ok=True)
    with workspace() as work:
        inputs = input_hashes()
        (work/'inputs-sha256.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n')
        # Always hash and extract the archive afresh; an existing extracted tree
        # is not evidence that the compilation headers match the pinned release.
        archive = BASE/'toolchains/wasi-sysroot-30.0.tar.gz'
        archive.parent.mkdir(parents=True, exist_ok=True)
        if not archive.exists():
            with tempfile.NamedTemporaryFile(dir=archive.parent, delete=False) as f:
                download = Path(f.name)
            try:
                urllib.request.urlretrieve(SDK_URL, download)
                assert hashlib.sha256(download.read_bytes()).hexdigest() == SDK_SHA256
                download.replace(archive)
            finally:
                download.unlink(missing_ok=True)
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == SDK_SHA256
        with tarfile.open(archive) as tar:
            tar.extractall(work, filter='data')
        headers = work/'wasi-sysroot-30.0/include/wasm32-wasi'
        manifests = []
        for unit in ['samples', 'shuffle']:
            destination = work/unit
            run(sys.executable, TRANSLATOR, 'translate', HERE/(unit+'.cpp'),
                '--unit-key', 'pcg32/'+unit+'.cpp', '--api-header', HERE/'translation-api.h',
                '--clang', CLANG, '--clang-arg=-DNDEBUG',
                '--clang-arg=-I'+str(headers/'c++/v1'), '--clang-arg=-I'+str(headers),
                '-o', destination)
            manifests.append(destination/'manifest.json')
        joined = work/'joined'
        run(sys.executable, TRANSLATOR, 'link', *manifests, '--root', 'pcg_samples',
            '--root', 'pcg_shuffle', '-o', joined)
        a, b = [json.loads(p.read_text()) for p in manifests]
        shared = {r['symbol'] for r in a['artifacts'] if r['shareable']} & {r['symbol'] for r in b['artifacts'] if r['shareable']}
        merged = json.loads((joined/'manifest.json').read_text())
        assert shared and len(merged['artifacts']) == len(a['artifacts']) + len(b['artifacts']) - len(shared)
        assert [r['symbol'] for r in merged['externals']] == ['memcpy']
        assert any('shuffle' in r['original'] and r['shareable'] for r in b['artifacts'])
        shuffle_only = work/'shuffle-only'
        run(sys.executable, TRANSLATOR, 'link', manifests[1], '--root', 'pcg_shuffle', '-o', shuffle_only)
        standalone = json.loads((shuffle_only/'manifest.json').read_text())
        assert standalone['externals'] == [{'symbol': 'memcpy',
            'signature': 'void * memcpy(void *, const void *, unsigned long)'}]
        oracle = work/'oracle.cpp'
        oracle.write_text('#include <cstdio>\n#include "api.h"\nint main(){\n' + ''.join(
            '{ unsigned long long a[70]; unsigned b[52]; pcg_samples('+str(seed)+'ULL,a); pcg_shuffle('+str(seed)+'ULL,b); '
            'for(int i=0;i<70;++i) std::printf("%llu\\n",a[i]); for(int i=0;i<52;++i) std::printf("%u\\n",b[i]); }\n'
            for seed in SEEDS) + '}\n')
        references = []
        for opt in ['-O0', '-O2']:
            run(CLANG, '-std=c++17', '-DNDEBUG', '-fno-exceptions', '-fno-rtti', opt,
                '-I'+str(HERE), HERE/'samples.cpp', HERE/'shuffle.cpp', oracle, '-o', work/'oracle')
            references.append([int(x) for x in run(work/'oracle').splitlines()])
        assert references[0] == references[1] and len(references[0]) == 488
        values = references[0]
        (work/'native-values.json').write_text(json.dumps(values)+'\n')
        # First six published upstream demo outputs for seed 42, stream 54.
        assert values[:6] == [int(x,16) for x in ['a15c02b7','7b47f409','ba1d3330','83d2f293','bfa4784b','cbed606e']]
        for i in range(4):
            row = values[i*122:(i+1)*122]
            assert row[16:20] == [1,1000000007,1,1]
            assert sorted(row[70:]) == list(range(52))
        client = work/'client.c'
        # Compile the actual public header into the ordinary C caller, while
        # emitting one check per output so failure returns its exact index.
        checks = [(HERE/'api.h').read_text(), 'int run_tests(void){unsigned long long a[70]; unsigned b[52];']
        for j, seed in enumerate(SEEDS):
            checks.append(f'pcg_samples({seed}ULL,a); pcg_shuffle({seed}ULL,b);')
            for i in range(122):
                expr = f'a[{i}]' if i < 70 else f'b[{i-70}]'
                checks.append(f'if({expr}!={values[j*122+i]}ULL)return {j*122+i+1};')
        client.write_text('\n'.join(checks + ['return 0;}']))
        results = json.loads(run('node', ROOT/'tools/cpp-translator/tests/run-generated.mjs', joined, client))
        assert len(results) == 6 and all(r['result'] == 0 for r in results), results
        assert input_hashes() == inputs, 'Acceptance inputs changed during execution; rerun from stable sources'
        print(json.dumps({'upstream_revision': provenance['revision'], 'sysroot_sha256': SDK_SHA256,
                          'clang': run(CLANG,'--version').splitlines()[0],
                          'native_optimizations': ['O0','O2'], 'outputs_compared_per_mode':len(values),
                          'native_values_sha256': hashlib.sha256(json.dumps(values).encode()).hexdigest(),
                          'inputs_sha256': inputs,
                          'definition_files':len(merged['artifacts']), 'shared_symbols':sorted(shared),
                          'execution':results}, indent=2), flush=True)


if __name__ == '__main__':
    main()
