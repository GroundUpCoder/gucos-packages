#include "api.h"
#include "upstream/pcg32.h"

void pcg_shuffle(unsigned long long seed, unsigned int *output) {
    pcg32 rng(seed, 54);
    for (unsigned i = 0; i < 52; ++i) output[i] = i;
    rng.shuffle(output, output + 52);
}
