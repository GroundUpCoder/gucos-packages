#ifndef PCG_ACCEPTANCE_API_H
#define PCG_ACCEPTANCE_API_H
#ifdef __cplusplus
extern "C" {
#endif
void pcg_samples(unsigned long long seed, unsigned long long *output);
void pcg_shuffle(unsigned long long seed, unsigned int *output);
#ifdef __cplusplus
}
#endif
#endif
