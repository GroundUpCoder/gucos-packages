/* Public bridge plus the wasm32 libc call used by samples.cpp. */
#include "api.h"
void *memcpy(void *destination, const void *source, unsigned long length);
