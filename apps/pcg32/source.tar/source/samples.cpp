#include "api.h"
#include "upstream/pcg32.h"
#include <cstring>

void pcg_samples(unsigned long long seed, unsigned long long *output) {
    pcg32 rng(seed, 54), initial = rng;
    for (int i = 0; i < 16; ++i) output[i] = rng.nextUInt();
    rng.advance(-16);
    output[16] = rng == initial;
    rng.advance(1000000007);
    output[17] = rng - initial;
    output[18] = rng != initial;
    rng.advance(-1000000007);
    output[19] = rng == initial;
    for (int i = 0; i < 16; ++i) {
        float f = rng.nextFloat();
        uint32_t bits;
        std::memcpy(&bits, &f, sizeof(bits));
        output[20+i] = bits;
        double d = rng.nextDouble();
        uint64_t wide;
        std::memcpy(&wide, &d, sizeof(wide));
        output[36+i] = wide;
        output[52+i] = rng.nextUInt(2147483649u);
    }
    pcg32 defaults;
    output[68] = defaults.nextUInt();
    output[69] = rng.nextUInt(1);
}
