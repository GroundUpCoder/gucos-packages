#include <libfm/fm.h>
#include <menu-cache.h>
#include <glib/gstdio.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
static void operation(FmFileOpType type,const char *from,const char *to){
 FmPathList *list=fm_path_list_new();FmPath *src=fm_path_new_for_path(from);fm_path_list_push_tail(list,src);fm_path_unref(src);
 FmFileOpsJob *job=fm_file_ops_job_new(type,list);fm_path_list_unref(list);
 if(to){FmPath *dest=fm_path_new_for_path(to);fm_file_ops_job_set_dest(job,dest);fm_path_unref(dest);}
 assert(fm_job_run_sync(FM_JOB(job)));g_object_unref(job);
}
int main(void){
 assert(fm_init(NULL));
 FmPath *p=fm_path_new_for_path("/tmp/fm-files/source/nested/../hello.txt");char *s=fm_path_to_str(p);assert(!strcmp(s,"/tmp/fm-files/source/hello.txt"));g_free(s);fm_path_unref(p);
 p=fm_path_new_for_path("/tmp/fm-files/source");FmDirListJob *ls=fm_dir_list_job_new2(p,FM_DIR_LIST_JOB_DETAILED);fm_path_unref(p);
 assert(fm_job_run_sync(FM_JOB(ls)));assert(fm_file_info_list_get_length(fm_dir_list_job_get_files(ls))==2);g_object_unref(ls);
 operation(FM_FILE_OP_COPY,"/tmp/fm-files/source","/tmp/fm-files/copied");
 gsize n;char *text=NULL;assert(g_file_get_contents("/tmp/fm-files/copied/source/nested/data.txt",&text,&n,NULL));assert(n==12&&!memcmp(text,"nested data\n",12));g_free(text);
 operation(FM_FILE_OP_MOVE,"/tmp/fm-files/copied/source","/tmp/fm-files/moved");
 assert(!g_file_test("/tmp/fm-files/copied/source",G_FILE_TEST_EXISTS));assert(g_file_test("/tmp/fm-files/moved/source/hello.txt",G_FILE_TEST_IS_REGULAR));
 operation(FM_FILE_OP_DELETE,"/tmp/fm-files/moved/source",NULL);assert(!g_file_test("/tmp/fm-files/moved/source",G_FILE_TEST_EXISTS));
 puts("LIBFM-FILE-OPERATIONS-PASS");fflush(stdout);
 alarm(30);menu_cache_init(0);MenuCache *cache=menu_cache_lookup_sync("test.menu");assert(cache);MenuCacheDir *root=menu_cache_dup_root_dir(cache);assert(root);
 MenuCacheItem *item=menu_cache_find_child_by_id(root,"fixture.desktop");assert(item);assert(!strcmp(menu_cache_item_get_name(item),"File Manager Fixture"));menu_cache_item_unref(item);menu_cache_item_unref((MenuCacheItem*)root);menu_cache_unref(cache);alarm(0);
 fm_finalize();puts("LIBFM-MENU-CACHE-PASS");return 0;
}
