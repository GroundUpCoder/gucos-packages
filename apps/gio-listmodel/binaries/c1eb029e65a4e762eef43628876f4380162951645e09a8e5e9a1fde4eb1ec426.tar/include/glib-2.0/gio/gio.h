/* Deliberately limited GIO entry point: list model interface only. */
#ifndef WASM_POSIX_GIO_LISTMODEL_H
#define WASM_POSIX_GIO_LISTMODEL_H
#define __GIO_GIO_H_INSIDE__
#include <gio/glistmodel.h>
#undef __GIO_GIO_H_INSIDE__
#endif
