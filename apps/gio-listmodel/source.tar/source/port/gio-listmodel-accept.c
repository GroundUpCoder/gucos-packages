#include <gio/gio.h>
#include <assert.h>
typedef struct {GObject parent;GObject *item;} TestModel;
typedef struct {GObjectClass parent;} TestModelClass;
static void list_init(GListModelInterface *iface);
G_DEFINE_TYPE_WITH_CODE(TestModel,test_model,G_TYPE_OBJECT,G_IMPLEMENT_INTERFACE(G_TYPE_LIST_MODEL,list_init))
static GType item_type(GListModel *model){return G_TYPE_OBJECT;}
static guint count(GListModel *model){return ((TestModel*)model)->item?1:0;}
static gpointer item(GListModel *model,guint position){GObject *o=((TestModel*)model)->item;return position==0&&o?g_object_ref(o):NULL;}
static void list_init(GListModelInterface *iface){iface->get_item_type=item_type;iface->get_n_items=count;iface->get_item=item;}
static void finalize(GObject *o){g_clear_object(&((TestModel*)o)->item);G_OBJECT_CLASS(test_model_parent_class)->finalize(o);}
static void test_model_class_init(TestModelClass *c){G_OBJECT_CLASS(c)->finalize=finalize;}
static void test_model_init(TestModel *m){m->item=g_object_new(G_TYPE_OBJECT,NULL);}
static int changes;static void changed(GListModel*m,guint p,guint r,guint a,void*u){assert(p==0&&r==1&&a==0);changes++;}
int main(void){TestModel *m=g_object_new(test_model_get_type(),NULL);GListModel *list=G_LIST_MODEL(m);assert(g_list_model_get_item_type(list)==G_TYPE_OBJECT);assert(g_list_model_get_n_items(list)==1);GObject *o=g_list_model_get_item(list,0);assert(o==m->item);g_object_unref(o);assert(g_list_model_get_item(list,1)==NULL);g_signal_connect(list,"items-changed",G_CALLBACK(changed),NULL);g_clear_object(&m->item);g_list_model_items_changed(list,0,1,0);assert(changes==1&&g_list_model_get_n_items(list)==0);g_object_unref(m);return 0;}
