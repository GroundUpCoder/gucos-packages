set -e
gucman install gio-listmodel pkgconf
cc /usr/src/gio-listmodel/port/gio-listmodel-accept.c $(pkg-config --cflags --libs gio-listmodel) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
