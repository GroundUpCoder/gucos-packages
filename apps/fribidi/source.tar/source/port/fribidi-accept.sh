set -e
gucman install fribidi pkgconf
cc /usr/src/fribidi/port/fribidi-accept.c $(pkg-config --cflags --libs fribidi) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
