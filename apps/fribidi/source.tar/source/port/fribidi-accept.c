#include <fribidi.h>
#include <assert.h>
int main(void){FriBidiChar in[]={0x05d0,0x05d1,0x05d2},out[3];FriBidiParType base=FRIBIDI_PAR_ON;FriBidiStrIndex map[3];assert(fribidi_log2vis(in,3,&base,out,map,0,0));assert(base==FRIBIDI_PAR_RTL);assert(out[0]==0x05d2&&out[2]==0x05d0);assert(map[0]==2&&map[2]==0);return 0;}
