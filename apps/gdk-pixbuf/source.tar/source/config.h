/* Built-in PNG/JPEG loaders; use format signatures, not host MIME databases. */
#define GETTEXT_PACKAGE "gdk-pixbuf"
#define GDK_PIXBUF_LOCALEDIR "/usr/share/locale"
#define GDK_PIXBUF_PREFIX "/usr/local"
#define GDK_PIXBUF_LIBDIR "/usr/local/lib"
#define GDK_PIXBUF_BINARY_VERSION "2.10.0"
#define PIXBUF_LIBDIR "/usr/local/lib/gdk-pixbuf-2.0/2.10.0/loaders"
#define HAVE_UNISTD_H 1
#define HAVE_SIGSETJMP 1
#define HAVE_LRINT 1
#define HAVE_ROUND 1
#define HAVE_ISINF 1
#define HAVE_ISNAN 1
#define INCLUDE_png 1
#define INCLUDE_jpeg 1
