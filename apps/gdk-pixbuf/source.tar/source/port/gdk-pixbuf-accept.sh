set -e
gucman install gdk-pixbuf pkgconf
cc /usr/src/gdk-pixbuf/port/gdk-pixbuf-accept.c $(pkg-config --cflags --libs gdk-pixbuf-2.0) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
