#include <gdk-pixbuf/gdk-pixbuf.h>
#include <assert.h>
int main(void){GError*e=0;GdkPixbuf*p=gdk_pixbuf_new(GDK_COLORSPACE_RGB,1,8,4,4);gdk_pixbuf_fill(p,0xff0000ff);assert(gdk_pixbuf_save(p,"/tmp/pixbuf.png","png",&e,NULL));GdkPixbuf*q=gdk_pixbuf_new_from_file("/tmp/pixbuf.png",&e);assert(q&&!e&&gdk_pixbuf_get_width(q)==4);guchar *b=gdk_pixbuf_get_pixels(q);assert(b[0]==255&&b[1]==0&&b[2]==0&&b[3]==255);GdkPixbuf*r=gdk_pixbuf_scale_simple(q,8,8,GDK_INTERP_BILINEAR);assert(r&&gdk_pixbuf_get_height(r)==8);g_object_unref(r);g_object_unref(q);g_object_unref(p);return 0;}
