GdkPixbuf 2.42.12 has built-in PNG and JPEG loaders. Dynamic loader modules,
GIO MIME database detection, TIFF, GIF, BMP, ICO and SVG are not enabled.
Format signatures select the built-in loaders. Headers, pkg-config metadata,
libgdk_pixbuf-2.0.so and the static archive are installed by gucman.

JPEG uses the separate libjpeg-turbo package, including its own header path.
The pre-existing IJG 9f API remains available through the libjpeg package.
They must not be mixed: their ABI/configuration and some CMYK decisions differ.
The upstream premature-end.jpg fixture produces the expected [1,50,1] RGB
pixel with libjpeg-turbo, but [255,136,255] with IJG 9f, including native IJG.

io-png-wasm-posix.c retains upstream io-png.c and adds an explicit cast for a
borrowed PNG text key. port/test-common.c removes only GFile-based fixture
enumeration helpers; the selected test programs and their assertions are
upstream. Tests use byte-exact upstream binary fixtures.

The test runner selects construction, JPEG, DPI, ICC, save and scale tests.
Unsupported formats skip through upstream format_supported(). JPEG issue205
is explicitly excluded: its enormous dimensions hit the wasm process memory
limit before the corrupt JPEG can be reported as CORRUPT_IMAGE. This is a
known behavioral difference, not a successful upstream test.
