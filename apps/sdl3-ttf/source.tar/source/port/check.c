#include <SDL3_ttf/SDL_ttf.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv) {
    assert(argc == 2);
    assert(TTF_Init());
    assert(TTF_Version() == SDL_TTF_VERSION);
    TTF_Font *font = TTF_OpenFont(argv[1], 18);
    assert(font);
    int w1, h1, w2, h2;
    assert(TTF_GetStringSize(font, "Hello", 0, &w1, &h1));
    assert(w1 > 0 && h1 > 0);
    assert(TTF_SetFontSize(font, 36));
    assert(TTF_GetStringSize(font, "Hello", 0, &w2, &h2));
    assert(w2 > w1 && h2 > h1);
    SDL_Color white = {255,255,255,255};
    SDL_Surface *surface = TTF_RenderText_Blended(font, "Hello", 0, white);
    assert(surface && surface->pixels && surface->w == w2 && surface->h == h2);
    assert(surface->format == SDL_PIXELFORMAT_ARGB8888);
    int visible = 0, transparent = 0;
    for (int y = 0; y < surface->h; ++y) {
        const Uint32 *row = (const Uint32 *)((const unsigned char *)surface->pixels + y * surface->pitch);
        for (int x = 0; x < surface->w; ++x) {
            visible += (row[x] >> 24) != 0;
            transparent += (row[x] >> 24) == 0;
        }
    }
    assert(visible > 0 && transparent > 0);
    SDL_DestroySurface(surface);
    /* Exercise cached software text drawing and font refresh, not only rendering. */
    TTF_TextEngine *engine=TTF_CreateSurfaceTextEngine();assert(engine);
    TTF_Text *text=TTF_CreateText(engine,font,"Hello",0);assert(text);
    int tw,th;assert(TTF_GetTextSize(text,&tw,&th));assert(tw==w2&&th==h2);
    SDL_Surface *target=SDL_CreateSurface(tw+8,th+8,SDL_PIXELFORMAT_RGBA32);assert(target);
    assert(TTF_SetTextColor(text,230,70,20,255));
    assert(TTF_DrawSurfaceText(text,4,4,target));
    int painted=0;for(int y=0;y<target->h;y++)for(int x=0;x<target->w;x++){
        Uint8 r,g,b,a;assert(SDL_ReadSurfacePixel(target,x,y,&r,&g,&b,&a));
        if(a){assert(x>=4&&y>=4);painted++;}
    }assert(painted>0);
    assert(TTF_SetTextString(text,"Cafe",0));assert(TTF_SetFontSize(font,18));
    assert(TTF_GetTextSize(text,&tw,&th));assert(th<h2);
    TTF_DestroyText(text);TTF_DestroySurfaceTextEngine(engine);SDL_DestroySurface(target);
    SDL_Surface *wrapped=TTF_RenderText_Blended_Wrapped(font,"Hello world Hello world",0,white,w1);
    assert(wrapped&&wrapped->h>h1);SDL_DestroySurface(wrapped);
    /* Borrowed IO remains live after a font closes; owned IO closes with font. */
    FILE *file=fopen(argv[1],"rb");assert(file);assert(!fseek(file,0,SEEK_END));long size=ftell(file);assert(size>0);rewind(file);
    void *bytes=malloc(size);assert(bytes&&fread(bytes,1,size,file)==(size_t)size);fclose(file);
    SDL_IOStream *io=SDL_IOFromConstMem(bytes,size);assert(io);
    TTF_Font *memoryfont=TTF_OpenFontIO(io,0,18);assert(memoryfont);
    assert(TTF_GetStringSize(memoryfont,"Hello",0,&tw,&th));assert(tw==w1&&th==h1);
    TTF_CloseFont(memoryfont);assert(SDL_SeekIO(io,0,SDL_IO_SEEK_SET)==0);assert(SDL_CloseIO(io));
    io=SDL_IOFromConstMem(bytes,size);memoryfont=TTF_OpenFontIO(io,1,18);assert(memoryfont);TTF_CloseFont(memoryfont);free(bytes);
    int hb_major, hb_minor, hb_patch;
    TTF_GetHarfBuzzVersion(&hb_major, &hb_minor, &hb_patch);
    assert(hb_major == 14 && hb_minor == 5 && hb_patch == 0);
    assert(TTF_GetGlyphScript('A') == TTF_StringToTag("Latn"));
    TTF_CloseFont(font);
    TTF_Quit();
    puts("SDL3-TTF-PASS");
    return 0;
}
