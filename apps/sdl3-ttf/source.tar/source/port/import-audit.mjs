// Read actual imports from the successful upstream object compilation.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const root=path.resolve(import.meta.dirname,'../../..');
const report=JSON.parse(fs.readFileSync(`${root}/test-results/sdl3-ttf/upstream-headers.json`));
const functions=Object.entries(report.results).filter(([n])=>n!=='consumer.c').flatMap(([,r])=>r.symbols.funcSymbols);
const own=new Set(functions.filter(s=>s.flags&1).map(s=>s.name));
const imports=[...new Set(functions.filter(s=>(s.flags&4)&&!own.has(s.name)).map(s=>s.name))].sort();
const ctx=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});ctx.self=ctx;
for(const n of ['path','compiler','trampoline','objects','compile'])vm.runInContext(fs.readFileSync(`${root}/src/${n}.js`,'utf8'),ctx);
const src=ctx.CompilerJS.getStdlibSources();
const provider=ctx.compileObject({'/sdl.c':src['__SDL.c']},'/sdl.c',[],console.error);
const sdl=new Set(ctx.WasmObjects.readObject(provider.bytes,'sdl').info.funcSymbols.filter(s=>s.flags&1).map(s=>s.name));
// MiniHB matching is source-level, not a link result. Headers can declare APIs
// that the limited implementation has never defined.
const hb=fs.readdirSync(`${root}/vendor/minihb`).filter(n=>n.endsWith('.c')).map(n=>fs.readFileSync(`${root}/vendor/minihb/${n}`,'utf8')).join('\n');
const hbMissing=imports.filter(n=>n.startsWith('hb_')&&!new RegExp('\\b'+n+'\\s*\\(').test(hb));
const result={
  upstream:'SDL_ttf release-3.2.2',
  configured:{harfbuzz:true,plutosvg:false,rendererTextEngine:false,gpuTextEngine:false},
  objectBytes:Object.fromEntries(Object.entries(report.results).map(([n,r])=>[n,r.bytes])),
  imports,
  sdlImportsAbsentFromCompiledProvider:imports.filter(n=>n.startsWith('SDL_')&&!sdl.has(n)),
  hbImportsAbsentFromImplementationSource:hbMissing,
  caveat:'Imports are from compiled upstream objects; SDL comparison uses the compiled __SDL.c provider. This is not a linked or runtime-tested SDL_ttf library. FreeType imports have not been link-validated here.'
};
fs.writeFileSync(`${root}/apps/sdl3-ttf/port/import-audit.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
