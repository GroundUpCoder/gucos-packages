#include <SDL3_ttf/SDL_ttf.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static SDL_Color white={255,255,255,255};
static double now(void){struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return t.tv_sec*1000.0+t.tv_nsec/1000000.0;}
static unsigned u16(const unsigned char *b){return b[0]*256u+b[1];}
static unsigned u32(const unsigned char *b){return (u16(b)<<16)|u16(b+2);}
static TTF_Font *openfont(const char *path,const void *bytes,size_t n,int memory,int size){
 TTF_Font *f=memory?TTF_OpenFontIO(SDL_IOFromConstMem(bytes,n),1,size):TTF_OpenFont(path,size);assert(f);return f;
}
static SDL_Surface *render(TTF_Font *f){SDL_Surface *s=TTF_RenderText_Blended(f,"QSO7",0,white);assert(s);return s;}
static void equal(SDL_Surface *a,SDL_Surface *b){
 assert(a->w==b->w && a->h==b->h && a->format==b->format);
 for(int y=0;y<a->h;y++)assert(!memcmp((char*)a->pixels+y*a->pitch,(char*)b->pixels+y*b->pitch,a->w*4));
}
static unsigned pixels(SDL_Surface *s){unsigned h=2166136261u;for(int y=0;y<s->h;y++)for(int x=0;x<s->w*4;x++)h=(h^((unsigned char*)s->pixels)[y*s->pitch+x])*16777619u;return h;}
static void putfile(const char *path,void *bytes,size_t n){FILE *f=fopen(path,"wb");assert(f && fwrite(bytes,1,n,f)==n && !fclose(f));}
int main(int argc,char **argv){
 assert(argc==2 && TTF_Init());FILE *file=fopen(argv[1],"rb");assert(file && !fseek(file,0,SEEK_END));
 long n=ftell(file);assert(n>0);rewind(file);unsigned char *bytes=malloc(n);assert(bytes && fread(bytes,1,n,file)==n);fclose(file);
 // Repeated opens, a cold glyph cache, and the font's warm glyph/layout caches
 // must all produce the exact same pixels as FreeType's memory stream.
 for(int size=99;size<=100;size++){
  TTF_Font *m=openfont(0,bytes,n,1,size);SDL_Surface *reference=render(m);
  for(int pass=0;pass<3;pass++){TTF_Font *f=openfont(argv[1],bytes,n,0,size);
   for(int warm=0;warm<2;warm++){SDL_Surface *s=render(f);equal(s,reference);SDL_DestroySurface(s);}TTF_CloseFont(f);}
  for(int alpha=1;alpha<=255;alpha+=127){
   SDL_Color color={53,170,223,alpha};
   SDL_Surface *a=TTF_RenderText_Blended(m,"AVfj QSO7",0,color);assert(a);
   TTF_Font *f=openfont(argv[1],bytes,n,0,size);
   SDL_Surface *b=TTF_RenderText_Blended(f,"AVfj QSO7",0,color);assert(b);equal(a,b);
   printf("TTF-FONT-HASH %d %d %d %d %u\n",size,alpha,a->w,a->h,pixels(a));
   SDL_DestroySurface(a);SDL_DestroySurface(b);TTF_CloseFont(f);
  }
  SDL_DestroySurface(reference);TTF_CloseFont(m);
 }
 const char *changed="/tmp/ttf-mutated.ttf";putfile(changed,bytes,n);
 TTF_Font *old=openfont(changed,bytes,n,0,100);SDL_Surface *before=render(old);TTF_CloseFont(old);
 // Same-length, same-path mutation changes unitsPerEm. No mtime-resolution
 // assumption: compare the new on-disk face against those exact new bytes.
 unsigned head=0;for(unsigned i=0;i<u16(bytes+4);i++){unsigned p=12+16*i;assert(p+16<=n);if(!memcmp(bytes+p,"head",4))head=u32(bytes+p+8);}
 assert(head && head+20<=n);unsigned units=u16(bytes+head+18),changedUnits=units+units/4;
 bytes[head+18]=changedUnits>>8;bytes[head+19]=changedUnits;putfile(changed,bytes,n);
 TTF_Font *f=openfont(changed,bytes,n,0,100),*m=openfont(0,bytes,n,1,100);
 SDL_Surface *a=render(f),*b=render(m);equal(a,b);assert(a->w!=before->w || a->h!=before->h);
 SDL_DestroySurface(a);SDL_DestroySurface(b);SDL_DestroySurface(before);TTF_CloseFont(f);TTF_CloseFont(m);
 putfile(changed,"invalid",7);assert(!TTF_OpenFont(changed,100));
 bytes[head+18]=units>>8;bytes[head+19]=units;putfile(changed,bytes,n);
 f=openfont(changed,bytes,n,0,100);m=openfont(0,bytes,n,1,100);a=render(f);b=render(m);equal(a,b);
 SDL_DestroySurface(a);SDL_DestroySurface(b);TTF_CloseFont(f);TTF_CloseFont(m);remove(changed);
 puts("TTF-FONT-PIXELS-PASS file/memory cold/warm repeated opens same-size mutation truncate restore");
 // Seven independent samples, excluding one warmup. Include no memory-stream
 // construction or pixel comparisons in render timings. File mode includes all
 // real fopen/FreeType input work. Memory mode is a diagnostic reference only.
 for(int memory=0;memory<2;memory++) for(int sample=-1;sample<7;sample++){
  double create=0,draw=0,close=0;const int count=64;
  for(int i=0;i<count;i++){
   double start=now();f=openfont(argv[1],bytes,n,memory,99+i%2);double opened=now();
   a=render(f);double rendered=now();SDL_DestroySurface(a);TTF_CloseFont(f);double closed=now();
   create+=opened-start;draw+=rendered-opened;close+=closed-rendered;
  }
  if(sample>=0)printf("TTF-FONT-BENCH {\"mode\":\"%s\",\"sample\":%d,\"count\":%d,\"create_ms\":%.6f,\"render_ms\":%.6f,\"close_ms\":%.6f}\n",memory?"memory":"file",sample,count,create/count,draw/count,close/count);
 }
 f=openfont(argv[1],bytes,n,0,100);a=render(f);SDL_DestroySurface(a);double start=now();
 for(int i=0;i<256;i++){a=render(f);SDL_DestroySurface(a);}printf("TTF-FONT-WARM %.6f ms/render\n",(now()-start)/256);TTF_CloseFont(f);
 free(bytes);TTF_Quit();return 0;
}
