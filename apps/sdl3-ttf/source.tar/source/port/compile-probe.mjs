import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const root=path.resolve(import.meta.dirname,'../../..');
const out=path.join(root,'test-results/sdl3-ttf');
fs.mkdirSync(out,{recursive:true});
const ctx=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});ctx.self=ctx;
for(const name of ['path','compiler','trampoline','objects','compile'])vm.runInContext(fs.readFileSync(`${root}/src/${name}.js`,'utf8'),ctx);
const files={};
function add(local,guest){for(const entry of fs.readdirSync(local,{withFileTypes:true})){const p=path.join(local,entry.name),g=guest+'/'+entry.name;if(entry.isDirectory())add(p,g);else if(/\.(c|h)$/.test(entry.name))files[g]=fs.readFileSync(p,'utf8');}}
add(`${root}/apps/sdl3-ttf/upstream`,'/ttf');
add(`${root}/vendor/freetype/include`,'/freetype');
add(`${root}/vendor/minihb/include`,'/minihb');
files['/ttf/src/consumer.c']=fs.readFileSync(`${root}/apps/sdl3-ttf/port/check.c`,'utf8');
const mode=process.argv[2]||'platform';
const headers=ctx.CompilerJS.getStdlibHeaders();
for(const name of Object.keys(headers))if(name.startsWith('SDL3_ttf/'))delete headers[name];
// These probes compile upstream sources, never the compiler's TTF veneer.
const includes=['/ttf/include','/freetype','/minihb'];
if(mode==='upstream-headers'){
  add(`${out}/sdl/include/SDL3`,'/sdl/SDL3');
  // compile.js rewrites SDL3/SDL.h to SDL.h; make that alias load upstream too.
  for(const name of Object.keys(headers))if(name==='SDL.h'||name.startsWith('SDL3/'))delete headers[name];
  files['/sdl/SDL.h']=files['/sdl/SDL3/SDL.h'];
  includes.unshift('/sdl','/sdl/SDL3');
}
const variant=process.argv.includes('--minihb')?'-minihb':'';
const report={mode,variant,results:{}};
for(const source of ['SDL_ttf.c','SDL_hashtable.c','SDL_hashtable_ttf.c','SDL_surface_textengine.c','consumer.c']){
  if(!files['/ttf/src/'+source])continue;
  const diagnostics=[];
  try{
    const result=ctx.compileObject(files,'/ttf/src/'+source,includes,s=>diagnostics.push(s),{defines:['TTF_USE_HARFBUZZ=1','TTF_USE_PLUTOSVG=0',...(process.argv.includes('--minihb')?['TTF_USE_MINIHB=1']:[])]});
    fs.writeFileSync(`${out}/${source}.o`,result.bytes);
    const obj=ctx.WasmObjects.readObject(result.bytes,source);
    report.results[source]={compiled:true,bytes:result.bytes.length,symbols:obj.info,diagnostics};
  }catch(e){report.results[source]={compiled:false,error:String(e),diagnostics};}
}
fs.writeFileSync(`${out}/${mode}${variant}.json`,JSON.stringify(report,null,2));
for(const [name,result] of Object.entries(report.results))console.log(name,result.compiled?'compiled':result.error,result.diagnostics.slice(0,8).join(''));

if(mode==='upstream-headers' && Object.values(report.results).some(r=>!r.compiled))process.exitCode=1;
