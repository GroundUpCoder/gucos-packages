import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('sdl3-ttf',1200000);
try {
 const result=await runCached(page,`set -e
gucman install sdl3-ttf
cc /usr/src/sdl3-ttf/port/check.c -I/usr/local/include -lSDL3_ttf -lSDL3 -lharfbuzz -lharfbuzz-runtime -lglib-2.0 -lpcre2-8 -lintl -liconv -lz -lfreetype -lm -lpthread -o /tmp/ttf-check
/tmp/ttf-check /usr/src/sdl3-ttf/port/fonts/NotoSans-Regular.ttf
cc /usr/src/sdl3-ttf/port/check.c -I/usr/local/include /usr/local/lib/libSDL3_ttf.a -lSDL3 -lharfbuzz -lharfbuzz-runtime -lglib-2.0 -lpcre2-8 -lintl -liconv -lz -lfreetype -lm -lpthread -o /tmp/ttf-check-static
/tmp/ttf-check-static /usr/src/sdl3-ttf/port/fonts/NotoSans-Regular.ttf
cc /usr/src/sdl3-ttf/port/font-performance.c -I/usr/local/include -lSDL3_ttf -lSDL3 -lharfbuzz -lharfbuzz-runtime -lglib-2.0 -lpcre2-8 -lintl -liconv -lz -lfreetype -lm -lpthread -o /tmp/ttf-font-performance
/tmp/ttf-font-performance /usr/src/sdl3-ttf/port/fonts/NotoSans-Regular.ttf
echo SDL3-TTF-PACKAGE-PASS
`,{packages:['sdl3-ttf'],fresh:['sdl3-ttf']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);assert.match(log,/SDL3-TTF-PASS/);
 assert.match(log,/TTF-FONT-PIXELS-PASS/);assert.match(log,/TTF-FONT-WARM/);
 // Canonical visible-pixel hashes from the previously accepted scalar build.
 const hashes=log.split('\n').filter(l=>l.startsWith('TTF-FONT-HASH ')).map(l=>l.slice(14).split(' ').map(Number));
 assert.deepEqual(hashes,[[99,1,469,135,1717412826],[99,128,469,135,3645098871],[99,255,469,135,1661761607],[100,1,474,137,3111033474],[100,128,474,137,1174286984],[100,255,474,137,4265778157]], 'scalar/SSE2 font pixels changed');
 const timings=log.split('\n').filter(l=>l.startsWith('TTF-FONT-BENCH ')).map(l=>JSON.parse(l.slice(15)));
 assert.equal(timings.length,14,log);
 const median=a=>a.sort((a,b)=>a-b)[Math.floor(a.length/2)];
 const cost=mode=>median(timings.filter(t=>t.mode===mode).map(t=>t.create_ms+t.render_ms));
 assert.ok(cost('file')<=Math.max(2,14*cost('memory')), 'font file IO regression: '+JSON.stringify(timings));
 console.log('FONT-PERFORMANCE',JSON.stringify({file_ms:cost('file'),memory_ms:cost('memory'),samples:timings}));
 assert.match(log,/SDL3-TTF-PACKAGE-PASS/);assert.deepEqual(errors,[]);
} finally {await close();}
