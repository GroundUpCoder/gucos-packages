// Fetch reference SDL headers for the compile-only probe. These are not an SDL
// implementation and are never installed into a package or release.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'../../..');
const out=path.join(root,'test-results/sdl3-ttf');
fs.mkdirSync(out,{recursive:true});
const archive=path.join(out,'sdl.tar.gz');
const expected='8a6ddc3e70de897f7921da275ac71e375de89dad802aa2932649d1fea9068478';
if(!fs.existsSync(archive)){
 const response=await fetch('https://codeload.github.com/libsdl-org/SDL/tar.gz/refs/tags/release-3.2.10');
 assert.ok(response.ok,`SDL source download: ${response.status}`);
 const bytes=Buffer.from(await response.arrayBuffer());
 assert.equal(createHash('sha256').update(bytes).digest('hex'),expected);
 fs.writeFileSync(archive,bytes);
}
assert.equal(createHash('sha256').update(fs.readFileSync(archive)).digest('hex'),expected);
fs.mkdirSync(path.join(out,'sdl'),{recursive:true});
execFileSync('tar',['-xzf',archive,'-C',path.join(out,'sdl'),'--strip-components=1']);
console.log('Verified SDL 3.2.10 reference headers for compile-only probes');
