# SDL_ttf 3.2.2 software-text port

This package builds upstream SDL_ttf's core and software text engine with the
custom compiler, linking installed SDL3, FreeType and MiniHB dependencies.
It is separate from the compiler's older built-in SDL_ttf veneer.

The independent package recipe installs shared/static libraries and upstream
headers. Source and binary acceptance passed on 2026-09-30 using the approved
SDL3/FreeType/MiniHB artifacts. Both linkage modes exercise font loading,
resizing and metrics; visible and transparent rendered pixels; wrapped text;
cached software text drawing and font refresh; and owned/borrowed memory IO.
The binary phase restores the exact artifact without rebuilding the library.

## Supported configuration

The four upstream translation units are SDL_ttf.c, SDL_hashtable.c,
SDL_hashtable_ttf.c and SDL_surface_textengine.c. GPU/renderer text engines and
PlutoSVG emoji rendering are not included; their entry points are unavailable.

MiniHB is a bounded shaping implementation, not the complete HarfBuzz runtime.
The explicit TTF_USE_MINIHB adaptation calls hb_shape_full and reports unsupported
shaping as an SDL error instead of treating Unicode code points as glyph IDs.
TTF_GetGlyphScript reports an error and zero because Unicode-script introspection
is unavailable. TTF_GetHarfBuzzVersion reports zero rather than claiming a real
HarfBuzz version. Feature/script limitations of MiniHB remain applicable.

## Validation and history

Run `node tools/package-job.mjs run sdl3-ttf` in a package lane, or use the
integration coordinator's documented --integration mode after merging changes.
The initial runtime test found SDL's aligned surface ownership flag was not
honored on destruction. The platform fix and a focused regression are committed
separately (6291ce06); the final tests include successful cleanup.

The earlier compile/import probes in port/ document the original missing APIs.
They are historical scope evidence, not the current support or acceptance result.
