set -e
gucman install libiconv pkgconf
cc /usr/src/libiconv/port/test.c -I/usr/local/include -liconv -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
