#include <iconv.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#define CHECK(x) do {if(!(x)){printf("iconv FAIL line %d errno %d\n",__LINE__,errno);return 1;}}while(0)
int main(void){
 iconv_t cd=iconv_open("UTF-16LE","UTF-8"); CHECK(cd!=(iconv_t)-1);
 char input[]="A\xc3\xa9\xf0\x9f\x98\x80", out[32]; char *in=input,*op=out; size_t il=sizeof(input)-1,ol=2;
 CHECK(iconv(cd,&in,&il,&op,&ol)==(size_t)-1 && errno==E2BIG);
 CHECK(in==input+1 && il==6 && op==out+2 && ol==0);
 ol=30;CHECK(iconv(cd,&in,&il,&op,&ol)==0 && il==0);
 CHECK(op-out==8 && memcmp(out,"A\0\xe9\0\x3d\xd8\0\xde",8)==0);
 char bad[]="\xc3(";in=bad;il=2;op=out;ol=32;
 CHECK(iconv(cd,&in,&il,&op,&ol)==(size_t)-1 && errno==EILSEQ && in==bad && il==2);
 in=bad;il=1;CHECK(iconv(cd,&in,&il,&op,&ol)==(size_t)-1 && errno==EINVAL && in==bad && il==1);
 CHECK(iconv(cd,0,0,&op,&ol)==0);CHECK(iconv_close(cd)==0);
 cd=iconv_open("UTF-8","ISO-8859-1");CHECK(cd!=(iconv_t)-1);char latin[]="caf\xe9";in=latin;il=4;op=out;ol=32;
 CHECK(iconv(cd,&in,&il,&op,&ol)==0 && op-out==5 && memcmp(out,"caf\xc3\xa9",5)==0);CHECK(iconv_close(cd)==0);
 cd=iconv_open("UTF-8","ISO-2022-JP");CHECK(cd!=(iconv_t)-1);char jp[]="\x1b$B$\x22\x1b(B";in=jp;il=8;op=out;ol=32;
 CHECK(iconv(cd,&in,&il,&op,&ol)==0 && op-out==3 && memcmp(out,"\xe3\x81\x82",3)==0);CHECK(iconv_close(cd)==0);
 CHECK(iconv_open("not-an-encoding","UTF-8")== (iconv_t)-1 && errno==EINVAL);
 puts("ICONV-PASS");return 0;
}
