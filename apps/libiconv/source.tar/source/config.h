/* Explicit wasm32 configuration; library sources are unmodified. */
#define ICONV_CONST
#define HAVE_MBRTOWC 1
#define HAVE_WCRTOMB 1
#define HAVE_LANGINFO_CODESET 1
#define HAVE_SETLOCALE 1
#define HAVE_STDDEF_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define WORDS_LITTLEENDIAN 1
#define ENABLE_EXTRA 1
#define HAVE_VISIBILITY 0

#define _GL_CONFIG_H_INCLUDED 1
#define _GL_INLINE static inline
#define _GL_INLINE_HEADER_BEGIN
#define _GL_INLINE_HEADER_END
#define _GL_UNUSED

/* wasm-posix has no text/binary descriptor distinction. */
#define O_BINARY 0
#define O_TEXT 0
