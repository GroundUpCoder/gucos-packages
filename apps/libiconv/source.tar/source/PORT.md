# GNU libiconv 1.18 for wasm-posix

Source: https://ftp.gnu.org/gnu/libiconv/libiconv-1.18.tar.gz
SHA-256: 3b08f5f4f9b4eb82f151a7040bfd6fe6c6fb922efe4b1659c66ea933276965e8

The upstream lib/, libcharset/, include/ and tests/ trees are copied unchanged.
Local additions: config.h (explicit wasm32/POSIX configuration), generated
include/iconv.h and include/localcharset.h, lib.json, install.sh and port/.
port/binary-io.h is an unmodified upstream srclib header for upstream tests.
The public iconv header uses the POSIX char** interface; extra encodings are
included. wchar_t conversion uses the platform's UTF-8 mbrtowc/wcrtomb path.

`gucman install libiconv` builds independent objects and libiconv.a, installs
iconv.h/localcharset.h in /usr/local/include and the archive in /usr/local/lib.
`cc program.c -liconv` consumes the installed library. Sources are never checked
on application launch; rebuilding is explicit with `gucman rebuild libiconv`.
`cc -shared --project /usr/src/libiconv/lib.json -o /tmp/libiconv.so` builds a
wasm-posix shared library for explicit dlopen loading.

This is the upstream conversion engine, not NetSurf's permissive shim. It
preserves iconv's strict error and pointer-update behavior. The iconv CLI and
the native autoconf/libtool build have not been ported. License: COPYING.LIB,
with per-file notices; the bundled upstream distribution also includes COPYING.
