# Tcl 8.6.16 browser port

Source: https://prdownloads.sourceforge.net/tcl/tcl8.6.16-src.tar.gz
SHA-256: 91cb8fa61771c63c262efb553059b7c7ad6757afa5857af6265e4b0bdc2a14a5
License: license.terms.

Manual wasm32 little-endian configuration, derived from upstream configure probes
and corrected against the browser headers. The upstream object lists select the
174 C files. This configuration uses upstream bundled zlib and libtommath,
fixed arithmetic cutoffs, and a single-threaded Tcl interpreter. The ABI-5 executable uses the default no-fork contract. The NO_FORK profile
uses posix_spawnp without a fork fallback, mirrors standard-channel redirection
with spawn actions, and propagates the returned POSIX error code. Pinned package paths are
/usr/local/lib/tcl8.6 and /usr/local/include/tcl8.6.

Source adaptations: copying named FIFOs returns ENOTSUP; legacy DNS helpers return
NULL/ENOTSUP (numeric address paths use the existing getaddrinfo implementation);
IPv4 formatting uses inet_ntop and IPv6 equality compares address bytes. General
Internet sockets remain unavailable in this runtime.

The package installs tclsh, the script library, public headers (including TomMath headers) and a static archive.
Browser acceptance passed: arithmetic/bignums, list/dict/regex, binary file I/O,
zlib, timers, subprocess execution and errors. Four selected unchanged upstream
files (expr/list/string/dict) report 15,185 passes, 54 skips, zero failures.
The skips require optional test commands/math bindings and utf16; they are not
counted as passes. This does not establish the entire upstream suite passes. Tk, the optional Thread extension and binary
Tcl extensions are not yet validated.
