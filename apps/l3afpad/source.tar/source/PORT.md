# L3afpad 0.8.18.1.11

Pinned upstream GTK3 editor, with a maintained configuration equivalent to
--disable-print --disable-xinput2 --enable-search-history. No PDF/print backend
or XInput server is available in the browser GTK profile. Upstream sources
are preserved. The unused gtkprint.c translation unit is omitted explicitly.
Builds use the installed binary GTK SDK, without requiring upstream Autotools.
