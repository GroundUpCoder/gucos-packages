#define PACKAGE "l3afpad"
#define PACKAGE_NAME "L3afpad"
#define PACKAGE_VERSION "0.8.18.1.11"
#define PACKAGE_STRING "L3afpad 0.8.18.1.11"
#define GETTEXT_PACKAGE "l3afpad"
#define LOCALEDIR "/usr/local/share/locale"
#define ICONDIR "/usr/local/share/pixmaps"
#define ENABLE_PRINT 0
#define ENABLE_XINPUT2 0
#define ENABLE_NLS 1
#define SEARCH_HISTORY 1
#define HAVE_LOCALE_H 1
