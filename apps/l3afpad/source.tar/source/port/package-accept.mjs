import {acceptInstalledApp} from '../../../vendor/gtk3/port/installed-app.mjs';
await acceptInstalledApp("l3afpad","l3afpad");
