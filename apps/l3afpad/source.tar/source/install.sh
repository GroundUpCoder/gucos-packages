#!/bin/sh
set -e
stage=$1
cd /usr/src/l3afpad
mkdir -p "$stage/bin" "$stage/libexec" "$stage/share/applications" "$stage/share/pixmaps" "$stage/share/doc/l3afpad"
cc -DHAVE_CONFIG_H -Iport -Isrc src/main.c src/window.c src/menu.c src/callback.c src/view.c src/undo.c src/font.c src/linenum.c src/indent.c src/hlight.c src/selector.c src/file.c src/encoding.c src/search.c src/dialog.c src/dnd.c src/utils.c src/emacs.c src/gtksourceiter.c $(pkg-config --cflags --libs gtk+-3.0) -lintl -o "$stage/libexec/l3afpad"
cp data/l3afpad.png "$stage/share/pixmaps/"
cp COPYING PORT.md "$stage/share/doc/l3afpad/"
cat > "$stage/bin/l3afpad" <<'LAUNCH'
#!/bin/sh
export WASM_POSIX_SURFACES=1
exec /usr/local/libexec/l3afpad "$@"
LAUNCH
chmod +x "$stage/bin/l3afpad"
cat > "$stage/share/applications/l3afpad.desktop" <<'APP'
[Desktop Entry]
Type=Application
Name=L3afpad
Exec=l3afpad %f
Icon=l3afpad
MimeType=text/plain;
Categories=Utility;TextEditor;
Terminal=false
APP
