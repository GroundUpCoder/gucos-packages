# Ncurses and terminfo

This experimental port builds upstream ncurses 6.5 inside wasm-posix. It installs
static ncurses, tinfo, panel, menu and form libraries, public headers, pkg-config
metadata, the terminfo tools, and the upstream terminal database. The same package also builds the wide-character ncursesw, tinfow, panelw, menuw
and formw libraries in a separate build directory with `--enable-widec`. Only
wide libraries, `ncursesw/` headers and wide pkg-config files are copied from
that staging tree; narrow libraries, tools and headers retain their original
build. One package fits the shared upstream source, version, license and terminal
database and avoids competing ownership of the tools and database.

## Use

```sh
gucman install ncurses
export TERM=xterm-256color
tput colors
infocmp xterm-256color
cc -I/usr/local/include/ncurses app.c -L/usr/local/lib -lncurses -ltinfo -o app
```

The default database is `/usr/local/share/terminfo`. `TERMINFO` and
`TERMINFO_DIRS` retain their upstream meanings. `tic -x` can compile a private
database. `tic`, `infocmp` and `tput` are package aliases; other installed tools
are available under `/usr/local/bin`.

Wide consumers use `-I/usr/local/include/ncursesw -lncursesw -ltinfow`.

## Build adaptations

`sources.lock.json` records the official archive and its digest. The guest runs
upstream configure and make, using `/bin/sh` explicitly for the imported install
script. The optional `lib/terminfo` directory symlink is omitted because package
inventories accept files rather than directory aliases; the canonical database
path remains intact.

`MKlib_gen.sh` uses a legal identifier as its temporary code marker instead of
`@@`. The compiler rejects `@@return` during preprocessing. Upstream's script
suppresses that diagnostic and otherwise produces a library missing generated
function wrappers. The marker is removed before compilation, preserving the
upstream wrapper bodies. No libc or runtime behavior is emulated by this port.

## Acceptance

```sh
node tools/package-job.mjs run ncurses
```

The same tests run after source compilation and after installation of the binary
artifact on a fresh disk. They verify 256-color capabilities, `infocmp`/`tic`
round-tripping, `tparm` cursor addressing, and an independently compiled consumer
that creates, colors, draws, reads and refreshes a curses window. Interactive
keyboard use through a real PTY is additionally covered by x11-apps acceptance.
Acceptance and local artifact promotion do not publish a website or release.

Wide acceptance exercises CJK `add_wch`/`addwstr`, a combining acute accent,
an emoji, column positions and cell readback. The x11-apps consumer additionally
checks `get_wch` of a non-ASCII key through the xterm PTY, avoiding a circular
ncurses test dependency on x11-apps (which itself requires ncurses).
