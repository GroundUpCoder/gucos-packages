#!/bin/sh
set -e
stage=$1
mkdir -p "$stage/lib/wasm-posix" "$stage/share/vim/vim91"
cc --project /usr/src/vim/bin.json -o "$stage/lib/wasm-posix/vim"
cp -R /usr/src/vim/runtime/. "$stage/share/vim/vim91/"
