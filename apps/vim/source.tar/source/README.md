# Vim 9.1.0000

Upstream: https://github.com/vim/vim/tree/v9.1.0000
Archive: https://github.com/vim/vim/archive/refs/tags/v9.1.0000.tar.gz
SHA-256: `8d2a74e358be9cf260174e15e2e29dba4773f2670718b5bf728db6f54b90e25d`

Vim's license is in LICENSE (upstream runtime/doc/uganda.txt). Source files
and runtime scripts retain their individual notices, including the xdiff
library. This is a pinned release, not a claim to track current Vim patches.

The browser manifest builds FEAT_NORMAL with the upstream BASIC_SRC and
XDIFF_SRC lists. src/auto/config.h is a target configuration, not output from
running Vim's configure in the browser. FEAT_XTERM_SAVE enables xterm's
alternate screen for the built-in terminal description. src/auto/pathdef.c locates the
bundled runtime under /usr/src/vim/runtime; src/auto/osdef.h is empty because
the runtime's headers provide the required declarations.

One upstream C change: src/term.c defines term_set_winsize outside the
HAVE_TGETENT guard. Its built-in tgoto supports the same escape; os_unix.c
calls this function even without an external terminal library.

The runtime includes Vim scripts and text documentation, including help
tags. Binary spelling dictionaries, translated message catalogs, GUI assets,
and external programs are not bundled. GUI, external termcap/terminfo,
gettext, Python/Perl/Ruby/Lua interfaces, and embedded :terminal are disabled.
See docs/VIM.md in the repository for use, tests and limits.
