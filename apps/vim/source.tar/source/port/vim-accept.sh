set -e
gucman install vim
printf 'alpha\nbeta\n' > /tmp/edit.txt
cat > /tmp/edit.vim <<'EOF'
set nomore
%s/alpha/ALPHA/
call append('$', 'gamma')
wq
EOF
vim -Nu NONE -n -es -S /tmp/edit.vim /tmp/edit.txt
printf 'ALPHA\nbeta\ngamma\n' > /tmp/expected
cmp /tmp/expected /tmp/edit.txt

echo VIM-ACCEPTANCE-PASS
