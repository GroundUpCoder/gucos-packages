import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('vim',1700000);
const line=async text=>{await page.keyboard.type(text);await page.keyboard.press('Enter');};
try {
 const script=await readFile(new URL('./vim-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['vim'],fresh:['vim']});
 const initialLog=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,initialLog);
 assert.ok(initialLog.includes('VIM-ACCEPTANCE-PASS'),initialLog);
 page.setDefaultTimeout(45000);
 await page.evaluate(()=>shell.terminal.focus());await line('sh');await page.waitForFunction(()=>shell.busybox?.ready&&shell.ui.session===shell.busybox);
 await line('vim /home/user/interactive.c');
 await page.waitForFunction(()=>shell.terminal.buffer.active.type==='alternate');
 // Switching buffers happens before Vim finishes terminal initialization;
 // typing at that point can be consumed by its startup input flush.
 await page.waitForFunction(()=>{
  const b=shell.terminal.buffer.active;
  return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)).some(s=>s.includes('interactive.c')&&s.includes('[New]'))&&shell.busybox.log.includes('\x1b[?4m');
 });
 await page.waitForTimeout(200);
 await page.keyboard.type('iint main(void) { return 42; }');await page.keyboard.press('Enter');await page.keyboard.type('second line');await page.keyboard.press('Escape');
 await page.waitForFunction(()=>{const b=shell.terminal.buffer.active;return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)).join('\n').includes('second line');});
 // Assert actual rendered C token colors, not merely loaded highlight definitions.
 await page.waitForFunction(()=>{
  const row=shell.terminal.buffer.active.getLine(0);
  return row?.translateToString(true).startsWith('int main(void) { return 42; }');
 });
 const colors=await page.evaluate(()=>[0,4,17,24].map(i=>{
  const cell=shell.terminal.buffer.active.getLine(0).getCell(i);
  return {text:cell.getChars(),mode:cell.getFgColorMode(),color:cell.getFgColor()};
 }));
 assert.deepEqual(colors.map(c=>c.text),['i','m','r','4']);
 for(const i of [0,2,3])assert.notEqual(colors[i].mode,0,'C syntax token must have a foreground color');
 assert.ok(new Set(colors.map(c=>`${c.mode}:${c.color}`)).size>=3,'C types, statements and literals render distinct colors');
 await line(':call writefile([&filetype, get(b:, "current_syntax", "missing"), synIDattr(synIDtrans(hlID("Statement")), "fg", "cterm")], "/home/user/vim-syntax")');
 await line(':set number');await line(':vsplit');
 await page.setViewportSize({width:1100,height:750});
 await page.waitForTimeout(300);
 await line(':call writefile([string(&lines), string(&columns), string(winnr("$"))], "/home/user/vim-size")');
 const size=await page.evaluate(()=>({rows:shell.terminal.rows,cols:shell.terminal.cols}));
 await line(':wqa');await page.waitForFunction(()=>shell.terminal.buffer.active.type==='normal');
 // Read the diagnostic files through the shell after Vim has finished writing,
 // rather than racing owner-side reads against the active editor's filesystem.
 await line('cat /home/user/interactive.c; cat /home/user/vim-size; cat /home/user/vim-syntax; echo VIM-INTERACTIVE-PASS');
 await page.waitForFunction(()=>shell.busybox.log.includes('\nVIM-INTERACTIVE-PASS\n'));
 const log=await page.evaluate(()=>shell.busybox.log);assert.match(log,/int main\(void\) \{ return 42; \}\nsecond line/);assert.ok(log.includes(`\n${size.rows}\n${size.cols}\n2\n`),log);
 assert.match(log,/\nc\nc\n[^\n]+\n/,'default startup enables C syntax and colors');
 await line('exit');await page.waitForFunction(()=>!shell.ui.session&&!shell.ui.busy);assert.deepEqual(errors,[]);
 console.log('PASS installed Vim rendered C syntax, editing, splits, resize, save and terminal restoration');

} finally {await close();}
