/* wasm-posix backend for GLib's atomic API. SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * All Wasm atomic instructions are sequentially consistent. The public API
 * remains out-of-line, allowing existing clients to use the same symbols.
 * Do not define GCC feature macros: this compiler has its own intrinsics.
 */
#include "gatomic.h"

G_STATIC_ASSERT (sizeof (gint) == 4);
G_STATIC_ASSERT (sizeof (gpointer) == 4);
G_STATIC_ASSERT (sizeof (gintptr) == 4);

#define LOAD(p) __builtin(atomic_load32, (p))
#define STORE(p, v) __builtin(atomic_store32, (p), (v))
#define RMW(op, p, v) __builtin(op, (p), (v))
#define CAS(p, old, val) __builtin(atomic_cmpxchg32, (p), (old), (val))

gint (g_atomic_int_get) (const volatile gint *p) { return LOAD(p); }
void (g_atomic_int_set) (volatile gint *p, gint v) { STORE(p, v); }
void (g_atomic_int_inc) (volatile gint *p) { RMW(atomic_add32, p, 1); }
gboolean (g_atomic_int_dec_and_test) (volatile gint *p) { return RMW(atomic_sub32, p, 1) == 1; }
gboolean (g_atomic_int_compare_and_exchange) (volatile gint *p, gint old, gint v) { return CAS(p, old, v) == old; }
gboolean (g_atomic_int_compare_and_exchange_full) (gint *p, gint old, gint v, gint *prev) {
  gint observed = CAS(p, old, v);
  *prev = observed;
  return observed == old;
}
gint (g_atomic_int_exchange) (gint *p, gint v) { return RMW(atomic_xchg32, p, v); }
gint (g_atomic_int_add) (volatile gint *p, gint v) { return RMW(atomic_add32, p, v); }
guint (g_atomic_int_and) (volatile guint *p, guint v) { return RMW(atomic_and32, p, v); }
guint (g_atomic_int_or) (volatile guint *p, guint v) { return RMW(atomic_or32, p, v); }
guint (g_atomic_int_xor) (volatile guint *p, guint v) { return RMW(atomic_xor32, p, v); }
gint (g_atomic_int_exchange_and_add) (volatile gint *p, gint v) { return RMW(atomic_add32, p, v); }

gpointer (g_atomic_pointer_get) (const volatile void *p) { return (gpointer) LOAD(p); }
void (g_atomic_pointer_set) (volatile void *p, gpointer v) { STORE(p, v); }
gboolean (g_atomic_pointer_compare_and_exchange) (volatile void *p, gpointer old, gpointer v) {
  return (gpointer) CAS(p, old, v) == old;
}
gboolean (g_atomic_pointer_compare_and_exchange_full) (void *p, gpointer old, gpointer v, void *prev) {
  gpointer observed = (gpointer) CAS(p, old, v);
  *(gpointer *) prev = observed;
  return observed == old;
}
gpointer (g_atomic_pointer_exchange) (void *p, gpointer v) { return (gpointer) RMW(atomic_xchg32, p, v); }
/* Pointer arithmetic here is on pointer-sized integers, in bytes, with no
 * C pointee scaling. RMW results are the values BEFORE the operation. */
gintptr (g_atomic_pointer_add) (volatile void *p, gssize v) { return RMW(atomic_add32, p, v); }
guintptr (g_atomic_pointer_and) (volatile void *p, gsize v) { return RMW(atomic_and32, p, v); }
guintptr (g_atomic_pointer_or) (volatile void *p, gsize v) { return RMW(atomic_or32, p, v); }
guintptr (g_atomic_pointer_xor) (volatile void *p, gsize v) { return RMW(atomic_xor32, p, v); }
