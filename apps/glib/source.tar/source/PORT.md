# Core GLib 2.84.4 for wasm-posix

Source: https://download.gnome.org/sources/glib/2.84/glib-2.84.4.tar.xz
SHA-256: 8a9ea10943c36fc117e253f80c91e477b673525ae45762942858aef57631bb90

The glib/ and gmodule/ source/header trees are copied from that release. Only
core GLib's 95 selected translation units are built. Original C sources are
unchanged. Generated grefstring-wasm-posix.c and glib-init-wasm-posix.c select
our existing GNU alignment and new constructor support, respectively, without
spoofing GCC. gconstructor-wasm-posix.h is the corresponding local header.
gatomic-wasm-posix.c supplies the complete public atomic API using the compiler's
32-bit Wasm atomic intrinsics, with sequentially consistent ordering and static
width checks. The install recipe selects it instead of the upstream mutex
fallback in gatomic.c; public headers and symbols remain compatible. The shipped
glibconfig.h enables G_ATOMIC_LOCK_FREE for this backend (the exploratory probe
script alone still describes the upstream compiler feature probes).
Library and upstream test builds retain upstream's G_LOG_DOMAIN="GLib" setting.
config.h and glib/glibconfig.h are explicit wasm32 configurations, generated
using tools/port-recipes/glib-probe.py; version/visibility headers are generated
by GLib's upstream script. Symlinked COPYING files are materialized copies.

`gucman install glib` installs prebuilt dependencies and
libglib-2.0.so and libglib-2.0.a. Use `--source` to permit a source build. Headers are installed in /usr/local/include/glib-2.0. Example:

```
cc -I/usr/local/include/glib-2.0 /usr/src/glib/port/test.c \
  -lglib-2.0 -lpcre2-8 -lintl -liconv -o /tmp/glib-test
/tmp/glib-test
```

The separate `gobject` package now builds the GObject implementation and Unicode
enumeration unit, with a scalar libffi backend. See docs/GOBJECT.md. GIO, GModule,
introspection and a complete Meson build are not included. See docs/PCRE2-GLIB.md for runtime validation and limits.

GMappedFile now enables HAVE_MMAP and uses the existing POSIX mapping runtime.
All seven upstream glib/tests/mappedfile.c cases pass, including writable
private mappings and GBytes lifetime. The GTK resource integration also checks
534 mapped resource payloads against their original bytes. Existing installed
GLib libraries need an explicit `gucman rebuild glib` for this configuration.
The separate gio-core package adds selected GIO APIs; see docs/GTK.md.
