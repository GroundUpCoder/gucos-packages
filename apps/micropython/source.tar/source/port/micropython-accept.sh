set -e
gucman install micropython
cat > /tmp/closure.py <<'EOF'
def counter(n):
    def step(delta):
        nonlocal n
        n += delta
        return n
    return step
c = counter(10)
assert c(2) == 12 and c(30) == 42
assert [x*x for x in range(4)] == [0,1,4,9]
print('MICROPYTHON-CLOSURE-42')
EOF
micropython /tmp/closure.py > /tmp/micropython-output
grep '^MICROPYTHON-CLOSURE-42$' /tmp/micropython-output

cd /tmp/micropython-upstream
for test in *.py; do
  echo "MICROPYTHON-UPSTREAM: $test"
  micropython "$test" > actual
  cmp actual "${test%.py}.exp"
done
micropython -c 'import json,struct,re; assert json.loads(json.dumps([1,2,3])) == [1,2,3]; assert struct.unpack("<I",struct.pack("<I",123456))[0] == 123456; assert re.match("a(b+)","abbb").group(1) == "bbb"'
micropython -c 'f=open("/tmp/micropython-io","w"); f.write("persist42"); f.flush(); f.close()'
micropython -c 'f=open("/tmp/micropython-io"); assert f.read() == "persist42"; f.close()'
if micropython -c 'raise ValueError("intentional rejection")' > /tmp/micropython-error 2>&1; then
  echo 'micropython accepted a throwing program'
  exit 1
fi
grep 'ValueError: intentional rejection' /tmp/micropython-error
echo MICROPYTHON-ACCEPTANCE-PASS
