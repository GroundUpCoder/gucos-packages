ATK 2.38.0 is built from the upstream C sources as libatk-1.0.so and
libatk-1.0.a. Generated enum and marshal files use upstream GLib generators.
`gucman install atk` installs headers and atk.pc, depending on GObject.

The upstream testrole, testrelation, teststateset, testvalue and testdocument
programs run unchanged. This provides ATK's object model, not an AT-SPI bus or
a bridge from canvas widgets to browser accessibility APIs.
