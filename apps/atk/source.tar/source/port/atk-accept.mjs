import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('atk',1200000);
try {const r=await runCached(page,await readFile(new URL('./atk-accept.sh',import.meta.url),'utf8'),{packages:['atk','pkgconf'],fresh:['atk']});const log=await page.evaluate(()=>shell.busybox.log);assert.equal(r.code,0,log);assert.match(log,/PACKAGE-ACCEPT-PASS/);assert.deepEqual(errors,[]);console.log('PASS atk installed consumer behavior');}finally{await close();}
