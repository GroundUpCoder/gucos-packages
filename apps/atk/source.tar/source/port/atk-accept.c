#include <atk/atk.h>
#include <assert.h>
int main(void){AtkStateSet*s=atk_state_set_new();assert(atk_state_set_add_state(s,ATK_STATE_FOCUSED));assert(atk_state_set_contains_state(s,ATK_STATE_FOCUSED));assert(atk_state_set_remove_state(s,ATK_STATE_FOCUSED));assert(atk_state_set_is_empty(s));AtkRelationSet*r=atk_relation_set_new();assert(atk_relation_set_get_n_relations(r)==0);assert(atk_role_for_name("push button")==ATK_ROLE_PUSH_BUTTON);g_object_unref(r);g_object_unref(s);return 0;}
