set -e
gucman install atk pkgconf
cc /usr/src/atk/port/atk-accept.c $(pkg-config --cflags --libs atk) -o /tmp/package-check
/tmp/package-check
echo PACKAGE-ACCEPT-PASS
