#define GETTEXT_PACKAGE "atk10"
#define ATK_LOCALEDIR "/usr/share/locale"
#define VERSION "2.38.0"
