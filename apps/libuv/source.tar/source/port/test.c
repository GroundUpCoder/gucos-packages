#include <uv.h>
#include <assert.h>
#include <unistd.h>
#include <stdio.h>
static uv_poll_t watcher;
static uv_timer_t timer;
static int fds[2],seen;
static void read_ready(uv_poll_t *w,int status,int events){
 assert(status==0);assert(events&UV_READABLE);char c;assert(read(fds[0],&c,1)==1&&c=='x');
 seen++;uv_poll_stop(w);uv_close((uv_handle_t *)w,0);
}
static void tick(uv_timer_t *t){assert(write(fds[1],"x",1)==1);uv_close((uv_handle_t *)t,0);}
int main(void){assert(!pipe(fds));uv_loop_t *loop=uv_default_loop();assert(loop);
 assert(!uv_poll_init(loop,&watcher,fds[0]));assert(!uv_poll_start(&watcher,UV_READABLE,read_ready));
 assert(!uv_timer_init(loop,&timer));assert(!uv_timer_start(&timer,tick,10,0));
 assert(!uv_run(loop,UV_RUN_DEFAULT));assert(seen==1);assert(!uv_loop_close(loop));close(fds[0]);close(fds[1]);puts("LIBUV-PASS");return 0;}
