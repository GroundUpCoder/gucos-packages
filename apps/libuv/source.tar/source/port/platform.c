#include "uv.h"
#include "internal.h"
#include <errno.h>
#include <unistd.h>
#include <time.h>
/* Host machine statistics and network interfaces are not exposed. */
void uv_loadavg(double avg[3]){avg[0]=avg[1]=avg[2]=0;}
int uv_exepath(char *buf,size_t *size){
 if(!buf||!size||!*size)return UV_EINVAL;
 ssize_t n=readlink("/proc/self/exe",buf,*size-1);
 if(n<0)return UV__ERR(errno);buf[n]=0;*size=n;return 0;
}
uint64_t uv_get_free_memory(void){return 0;}
uint64_t uv_get_total_memory(void){return 0;}
uint64_t uv_get_constrained_memory(void){return 0;}
uint64_t uv_get_available_memory(void){return 0;}
int uv_resident_set_memory(size_t *rss){(void)rss;return UV_ENOSYS;}
int uv_uptime(double *uptime){(void)uptime;return UV_ENOSYS;}
int uv_cpu_info(uv_cpu_info_t **info,int *count){*info=0;*count=0;return UV_ENOSYS;}
int uv_interface_addresses(uv_interface_address_t **addresses,int *count){*addresses=0;*count=0;return UV_ENOSYS;}
void uv_free_interface_addresses(uv_interface_address_t *addresses,int count){(void)addresses;(void)count;}
