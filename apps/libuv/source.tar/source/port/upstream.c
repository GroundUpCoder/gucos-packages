#ifndef TEST_NAME
#error TEST_NAME required
#endif
#define CAT_(a,b) a##b
#define CAT(a,b) CAT_(a,b)
int CAT(run_test_,TEST_NAME)(void);
int main(void){return CAT(run_test_,TEST_NAME)();}
