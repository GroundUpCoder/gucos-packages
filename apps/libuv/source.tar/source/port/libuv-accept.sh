set -e
gucman install libuv
cat > /tmp/uv-consumer.c <<'EOF'
#include <uv.h>
#include <assert.h>
static int calls;
static void timer(uv_timer_t *t){calls++;uv_close((uv_handle_t*)t,0);}
int main(void){uv_loop_t loop;uv_timer_t t;assert(uv_loop_init(&loop)==0);
 assert(uv_timer_init(&loop,&t)==0);assert(uv_timer_start(&t,timer,1,0)==0);
 assert(uv_run(&loop,UV_RUN_DEFAULT)==0);assert(calls==1);assert(uv_loop_close(&loop)==0);return 0;}
EOF
# Match the fork-capable libuv ABI documented in docs/PROCESSES.md.
cc --enable-fork /tmp/uv-consumer.c $(pkg-config --cflags --libs libuv) -o /tmp/uv-consumer
/tmp/uv-consumer

echo LIBUV-ACCEPTANCE-PASS
