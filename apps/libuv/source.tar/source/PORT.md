# libuv 1.51.0

Source: https://dist.libuv.org/dist/v1.51.0/libuv-v1.51.0-dist.tar.gz

Archive SHA-256: `2ceca1a7577633cf92794db5bf5512370f6cd45a5746d6e14f8c20aeab0a547b`

Uses upstream POSIX poll, high-resolution clock, no-fsevents and no-proctitle implementations. `port/platform.c` supplies the remaining target hooks; unavailable host statistics, interfaces and DNS report ENOSYS or the documented unknown value. TCP/UDP, descriptor passing, file-event watching, scheduling controls remain unavailable. The port uses the system `sched_param`
declaration and `ttyname_r`; browser terminals have no named device node and
report ENODEV.

Source adaptations: uv/unix.h selects the POSIX backend for wasm and private network declarations; uv.h includes private platform declarations. The compiled C sources express `_Atomic int` and `_Atomic uintptr_t` as `_Atomic(int)` and `_Atomic(uintptr_t)`, retaining actual atomic_* operations. udp.c uses an enum for a fixed array bound instead of a static const int. The latter avoids a C VLA without changing its size. The compiler does not yet provide general C11 atomic-qualified lvalue semantics.

`port/upstream.c` runs a selected upstream test function unchanged, one case per process. This is not the full libuv test runner or a claim that every libuv API is supported.
