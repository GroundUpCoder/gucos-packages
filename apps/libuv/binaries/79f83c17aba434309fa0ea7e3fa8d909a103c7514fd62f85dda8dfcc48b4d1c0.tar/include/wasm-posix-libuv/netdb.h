#ifndef WASM_POSIX_LIBUV_NETDB_H
#define WASM_POSIX_LIBUV_NETDB_H
#include <sys/socket.h>
#include <errno.h>
/* DNS is not exposed by wasm-posix. Numeric addresses use Libevent's parser. */
struct hostent { char *h_name; char **h_aliases; int h_addrtype; int h_length; char **h_addr_list; };
#define TRY_AGAIN 2
#define NO_RECOVERY 3
static _Thread_local int h_errno;
static inline struct hostent *gethostbyname(const char *name){(void)name;h_errno=NO_RECOVERY;errno=ENOSYS;return 0;}
static inline struct hostent *gethostbyaddr(const void *address,socklen_t length,int type){(void)address;(void)length;(void)type;h_errno=NO_RECOVERY;errno=ENOSYS;return 0;}

#define HOST_NOT_FOUND 1
struct addrinfo { int ai_flags,ai_family,ai_socktype,ai_protocol; socklen_t ai_addrlen; struct sockaddr *ai_addr; char *ai_canonname; struct addrinfo *ai_next; };
#define EAI_ADDRFAMILY -9
#define EAI_AGAIN -3
#define EAI_BADFLAGS -1
#define EAI_FAIL -4
#define EAI_FAMILY -6
#define EAI_MEMORY -10
#define EAI_NODATA -5
#define EAI_NONAME -2
#define EAI_OVERFLOW -12
#define EAI_SERVICE -8
#define EAI_SOCKTYPE -7
#define EAI_SYSTEM -11
#define AI_CANONNAME 2
#define NI_MAXHOST 1025
#define NI_MAXSERV 32
static inline int getaddrinfo(const char *n,const char *s,const struct addrinfo *h,struct addrinfo **r){(void)n;(void)s;(void)h;*r=0;errno=ENOSYS;return EAI_SYSTEM;}
static inline void freeaddrinfo(struct addrinfo *r){(void)r;}
static inline int getnameinfo(const struct sockaddr *a,socklen_t l,char *h,socklen_t hl,char *s,socklen_t sl,int f){(void)a;(void)l;(void)h;(void)hl;(void)s;(void)sl;(void)f;errno=ENOSYS;return EAI_SYSTEM;}

#endif
