#ifndef WASM_POSIX_LIBUV_IFADDRS_H
#define WASM_POSIX_LIBUV_IFADDRS_H
#include <sys/socket.h>
#include <errno.h>
struct ifaddrs { struct ifaddrs *ifa_next; char *ifa_name; unsigned ifa_flags; struct sockaddr *ifa_addr,*ifa_netmask,*ifa_dstaddr; void *ifa_data; };
static inline int getifaddrs(struct ifaddrs **a){*a=0;errno=ENOSYS;return -1;}
static inline void freeifaddrs(struct ifaddrs *a){(void)a;}

#endif
