#ifndef WASM_POSIX_LIBUV_NET_IF_H
#define WASM_POSIX_LIBUV_NET_IF_H
#include <errno.h>
/* No host network interfaces are exposed by this platform. */
static inline unsigned if_nametoindex(const char *name) { (void)name; errno=ENXIO; return 0; }
#define IF_NAMESIZE 16
static inline char *if_indextoname(unsigned i,char *name){(void)i;(void)name;errno=ENXIO;return 0;}

#endif
