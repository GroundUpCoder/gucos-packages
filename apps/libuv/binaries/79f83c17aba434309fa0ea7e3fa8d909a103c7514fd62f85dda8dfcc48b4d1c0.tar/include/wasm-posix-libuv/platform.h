#ifndef WASM_POSIX_LIBUV_PLATFORM_H
#define WASM_POSIX_LIBUV_PLATFORM_H
#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include <unistd.h>
#include <grp.h>
#include <sys/resource.h>
#define O_ACCMODE 3
#define PRIO_PROCESS 0
static inline int getpriority(int which,int who){(void)which;(void)who;errno=ENOSYS;return -1;}
static inline int setpriority(int which,int who,int value){(void)which;(void)who;(void)value;errno=ENOSYS;return -1;}
static inline int pthread_getschedparam(pthread_t t,int *policy,struct sched_param *p){(void)t;(void)policy;(void)p;return ENOTSUP;}
static inline int pthread_setschedparam(pthread_t t,int policy,const struct sched_param *p){(void)t;(void)policy;(void)p;return ENOTSUP;}
static inline int sched_get_priority_min(int policy){(void)policy;errno=ENOSYS;return -1;}
static inline int sched_get_priority_max(int policy){(void)policy;errno=ENOSYS;return -1;}
static inline int getgrgid_r(gid_t gid,struct group *g,char *buf,size_t n,struct group **result){(void)gid;(void)g;(void)buf;(void)n;*result=0;return ENOSYS;}
static inline int setgroups(size_t n,const gid_t *g){(void)n;(void)g;errno=ENOSYS;return -1;}
#define O_NOCTTY 0x100

#endif
