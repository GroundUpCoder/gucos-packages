pkgconf 2.3.0, unmodified upstream C sources plus target config.h and bin.json.
Source: https://distfiles.ariadne.space/pkgconf/pkgconf-2.3.0.tar.xz
SHA256: 3a9080ac51d03615e7c1910a0a2a8df08424892b5f13b0628a204d3fcce0ea8b

`gucman install pkgconf` provides pkgconf and the pkg-config alias.
