import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('pkgconf',600000);
try{
 await page.evaluate(()=>{shell.files['/tmp/acceptance.pc']='Name: acceptance\nDescription: package test\nVersion: 1.2.3\nLibs: -L/test/lib -ltest\nCflags: -I/test/include\n';});
 const result=await runCached(page,`set -e
gucman install pkgconf
pkgconf --version
PKG_CONFIG_PATH=/tmp pkg-config --exists acceptance
PKG_CONFIG_PATH=/tmp pkg-config --atleast-version=1.2 acceptance
if PKG_CONFIG_PATH=/tmp pkg-config --atleast-version=2 acceptance; then exit 1; fi
PKG_CONFIG_PATH=/tmp pkg-config --cflags --libs acceptance
echo PKGCONF-PACKAGE-PASS
`,{packages:['pkgconf'],fresh:['pkgconf']});
 const log=await page.evaluate(()=>shell.busybox.log);assert.equal(result.code,0,log);assert.match(log,/-I\/test\/include/);assert.match(log,/-ltest/);assert.match(log,/PKGCONF-PACKAGE-PASS/);assert.deepEqual(errors,[]);
}finally{await close();}
