set -e
gucman install pkgconf
mkdir -p /tmp/pkgconf-check
cat > /tmp/pkgconf-check/check.pc <<'PC'
prefix=/test
Name: check
Description: dependency query fixture
Version: 1.2.3
Libs: -L${prefix}/lib -lcheck
Cflags: -I${prefix}/include
PC
PKG_CONFIG_PATH=/tmp/pkgconf-check pkg-config --modversion check | grep '^1.2.3$'
PKG_CONFIG_PATH=/tmp/pkgconf-check pkg-config --libs check | grep -- '-lcheck'
if PKG_CONFIG_PATH=/tmp/pkgconf-check pkg-config --exists 'check >= 2'; then exit 1; fi
echo PACKAGE-ACCEPT-PASS
