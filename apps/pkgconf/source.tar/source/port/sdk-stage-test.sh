set -eu
export PKG_CONFIG_LIBDIR=/usr/src/pkgconf/port
export PKG_CONFIG_PATH=
test "$(/usr/local/bin/pkgconf --modversion sdk-check)" = 1.2.3
/usr/local/bin/pkgconf --libs sdk-check | grep -- -lcheck
if /usr/local/bin/pkgconf --exists 'sdk-check >= 2'; then exit 1; fi
echo SDK-STAGED-PKGCONF-PASS
