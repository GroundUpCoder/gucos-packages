set -eu
mkdir -p "$DESTDIR/bin"
cc --project /usr/src/pkgconf/bin.json -o "$DESTDIR/bin/pkgconf"
