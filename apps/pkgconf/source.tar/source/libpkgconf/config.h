/* wasm-posix target configuration. Upstream C sources are unmodified. */
#define PACKAGE "pkgconf"
#define PACKAGE_NAME "pkgconf"
#define PACKAGE_VERSION "2.3.0"
#define PACKAGE_STRING "pkgconf 2.3.0"
#define VERSION "2.3.0"
#define STDC_HEADERS 1
#define PKG_DEFAULT_PATH "/usr/local/lib/pkgconfig:/usr/local/share/pkgconfig:/usr/lib/pkgconfig:/usr/share/pkgconfig"
#define SYSTEM_INCLUDEDIR "/usr/include"
#define SYSTEM_LIBDIR "/usr/lib"
#define PERSONALITY_PATH "/usr/local/share/pkgconfig/personality.d"

#define PACKAGE_BUGREPORT "https://github.com/pkgconf/pkgconf/issues"
#define PACKAGE_URL "https://pkgconf.org/"
#define HAVE_DECL_STRLCPY 1
#define HAVE_DECL_STRLCAT 1
