#!/bin/sh
set -e
stage=$1
cd /usr/src/fontconfig
mkdir -p "$stage/objects" "$stage/include/fontconfig" "$stage/pkgconfig"
objects=
for source in src/fcatomic.c src/fccache.c src/fccfg.c src/fccharset.c src/fccompat.c src/fcdbg.c src/fcdefault.c src/fcdir.c src/fcformat.c src/fcfreetype.c src/fcfs.c src/fcptrlist.c src/fchash.c src/fcinit.c src/fclang.c src/fclist.c src/fcmatch.c src/fcmatrix.c src/fcname.c src/fcobjs.c src/fcpat.c src/fcrange.c src/fcserialize.c src/fcstat.c src/fcstr.c src/fcweight.c src/fcxml.c src/ftglue.c; do
  object="$stage/objects/${source##*/}.o"
  cc -DHAVE_CONFIG_H -I. -Isrc -I/usr/local/include/freetype2 -I/usr/local/include -c "$source" -o "$object"
  objects="$objects $object"
done
ar rcs "$stage/libfontconfig.a" $objects
cc -shared $objects -L/usr/local/lib -lfreetype -lexpat -Wl,-soname,libfontconfig.so -o "$stage/libfontconfig.so"
cp fontconfig/fontconfig.h fontconfig/fcfreetype.h "$stage/include/fontconfig/"
cp port/fontconfig.pc "$stage/pkgconfig/"

# Runtime font discovery must not depend on build source trees.
mkdir -p "$stage/etc/fonts" "$stage/share/fonts/wasm-posix"
cp port/fonts.conf "$stage/etc/fonts/fonts.conf"
cp /usr/src/freetype/port/fonts/ABeeZee-Regular.ttf /usr/src/freetype/port/fonts/SourceCodePro-Regular.otf "$stage/share/fonts/wasm-posix/"
