set -e
gucman install fontconfig pkgconf
cc /usr/src/fontconfig/test/test-name-parse.c $(pkg-config --cflags --libs fontconfig) -o /tmp/package-check
/tmp/package-check
cc /usr/src/fontconfig/test/test-family-matching.c $(pkg-config --cflags --libs fontconfig) -o /tmp/family-check
/tmp/family-check
cc /usr/src/fontconfig/port/installed-fonts.c $(pkg-config --cflags --libs fontconfig) -o /tmp/installed-fonts
/tmp/installed-fonts
echo PACKAGE-ACCEPT-PASS
