#include <fontconfig/fontconfig.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>
int main(void){
 FcConfig *c=FcInitLoadConfigAndFonts();assert(c);
 FcFontSet *fonts=FcConfigGetFonts(c,FcSetSystem);assert(fonts&&fonts->nfont>=2);
 FcPattern *p=FcPatternCreate();FcPatternAddString(p,FC_FAMILY,(const FcChar8*)"monospace");
 assert(FcConfigSubstitute(c,p,FcMatchPattern));FcDefaultSubstitute(p);
 FcResult result;FcPattern *match=FcFontMatch(c,p,&result);assert(match);
 FcChar8 *file=NULL;assert(FcPatternGetString(match,FC_FILE,0,&file)==FcResultMatch);
 assert(strstr((const char*)file,"/usr/local/share/fonts/wasm-posix/")== (const char*)file);
 assert(strstr((const char*)file,"SourceCodePro-Regular.otf"));assert(access((const char*)file,R_OK)==0);
 FcPatternDestroy(match);FcPatternDestroy(p);FcConfigDestroy(c);return 0;
}
