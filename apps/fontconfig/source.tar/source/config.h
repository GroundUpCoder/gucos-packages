/* Explicit wasm-posix configuration. */
#define HAVE_STDLIB_H 1
#define HAVE_STDIO_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define STDC_HEADERS 1
#define ALIGNOF_DOUBLE 8
#ifdef __wasm__
#define ALIGNOF_VOID_P 4
#else
#define ALIGNOF_VOID_P __SIZEOF_POINTER__
#endif
#define SIZEOF_CHAR 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#ifdef __wasm__
#define SIZEOF_LONG 4
#else
#define SIZEOF_LONG __SIZEOF_LONG__
#endif
#ifdef __wasm__
#define SIZEOF_VOID_P 4
#define SIZEOF_VOIDP 4
#else
#define SIZEOF_VOID_P __SIZEOF_POINTER__
#define SIZEOF_VOIDP __SIZEOF_POINTER__
#endif
#define FC_DEFAULT_FONTS "/usr/local/share/fonts/wasm-posix"
#define FC_CACHEDIR "/tmp/fontconfig-cache"
#define FONTCONFIG_PATH "/usr/local/etc/fonts"
#define FC_TEMPLATEDIR "/usr/local/share/fontconfig/conf.avail"
#define CONFIGDIR "/usr/local/etc/fonts"
#define FC_GPERF_SIZE_T unsigned int
#define FLEXIBLE_ARRAY_MEMBER
#define PACKAGE "fontconfig"
#define VERSION "2.15.0"
#define PACKAGE_VERSION "2.15.0"
#define HAVE_DIRENT_H 1
#define HAVE_FCNTL_H 1
#define HAVE_FT_DONE_MM_VAR 1
#define HAVE_FT_GET_BDF_PROPERTY 1
#define HAVE_FT_GET_PS_FONT_INFO 1
#define HAVE_FT_GET_X11_FONT_FORMAT 1
#define HAVE_FT_HAS_PS_GLYPH_NAMES 1
#define HAVE_GETPAGESIZE 1
#define HAVE_LSTAT 1
#define HAVE_MKSTEMP 1
/* HAVE_MMAP disabled: use upstream file-read fallback. */
#define HAVE_PTHREAD 1
#define HAVE_RAND 1
#define HAVE_READLINK 1
#define HAVE_STDATOMIC_PRIMITIVES 1
#define HAVE_STRERROR 1
#define HAVE_VPRINTF 1
#define HAVE_XML_SETDOCTYPEDECLHANDLER 1
