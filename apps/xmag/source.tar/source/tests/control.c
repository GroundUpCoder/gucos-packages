#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
int main(int argc,char **argv){Display*d=XOpenDisplay(NULL);if(!d)return 1;Window root=DefaultRootWindow(d);if(argc>1&&!strcmp(argv[1],"paint")){GC gc=XCreateGC(d,root,0,NULL);XSetForeground(d,gc,0xff0000);XFillRectangle(d,root,gc,0,0,80,80);XSync(d,False);XCloseDisplay(d);return 0;}
for(int t=0;t<100;t++){Window r,p,*cs=NULL;unsigned n=0;XQueryTree(d,root,&r,&p,&cs,&n);for(unsigned i=0;i<n;i++){XClassHint h={0};if(XGetClassHint(d,cs[i],&h)){int match=h.res_class&&!strcmp(h.res_class,"Xmag");if(h.res_name)XFree(h.res_name);if(h.res_class)XFree(h.res_class);if(match){XWindowAttributes a;XGetWindowAttributes(d,cs[i],&a);if(a.map_state==IsViewable){XImage*im=XGetImage(d,cs[i],0,0,a.width,a.height,AllPlanes,ZPixmap);unsigned red=0;if(im){for(int y=0;y<a.height;y++)for(int x=0;x<a.width;x++)if((XGetPixel(im,x,y)&0xffffff)==0xff0000)red++;XDestroyImage(im);}if(red>1000){XSetInputFocus(d,cs[i],RevertToPointerRoot,CurrentTime);XSync(d,False);printf("XMAG-PIXELS %u\n",red);XFree(cs);XCloseDisplay(d);return 0;}}}}}if(cs)XFree(cs);usleep(100000);}fprintf(stderr,"magnified red source pixels missing\n");return 2;}
