#!/bin/sh
set -eu
stage=$1
src=/usr/src/xmag
up=$src/xmag-1.0.8
build=/tmp/xmag-build
mkdir -p "$build" "$stage/bin" "$stage/share/X11/app-defaults" "$stage/share/doc/xmag"
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig
pc=/usr/local/lib/wasm-posix/pkgconf
flags="$($pc --cflags xaw7 xmu xt x11) -D_CONST_X_STRING -DHAVE_NANOSLEEP=1 -DHAVE_LRINT=1"
libs="$($pc --static --libs xaw7 xmu xt x11) -lm"
objects=
for file in CutPaste RootWin Scale xmag; do
 cc -O2 '-DPACKAGE_STRING="xmag 1.0.8"' $flags -c "$up/$file.c" -o "$build/$file.o"
 objects="$objects $build/$file.o"
done
cc $objects $libs -o "$stage/bin/xmag"
cp "$up/app-defaults/Xmag" "$stage/share/X11/app-defaults/"
cp "$up/COPYING" "$stage/share/doc/xmag/"
