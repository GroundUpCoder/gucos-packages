# wasm-posix integration

Copied byte-for-byte from `c-compiler/vendor/cjson` at commit
`b80908d1d2ca3673187573bb233fcc144a19ff21`. This is the existing vendored
port, including its configuration, source-library header metadata and test
fixtures; it is not claimed to be an unmodified upstream release. Upstream
licensing is preserved in LICENSE. Local integration is documented in
`docs/PROJECT-WORKLOADS.md`.
