# SDL_mixer 3.2.4

The package builds the pinned, unchanged upstream sources into installed shared
and static libraries. Local wrappers include standard C headers; the recipe
selects scalar mixing and the upstream raw, sinewave, WAV, stb Vorbis, dr_mp3 and
dr_flac decoders. SDL3 is the only package dependency. Optional MIDI, module,
Opus and game-music decoders are not enabled; unsupported inputs fail to load.

The package-local acceptance test runs against installed headers and libraries
in both source-build and binary-only phases. Shared and static consumers check
sample-by-sample track summing, gain, pause/resume, looping, seeking and end of
playback. WAV and FLAC decoding must reproduce the generated PCM reference for
all 8,000 stereo frames. Ogg Vorbis and MP3 decoding must preserve the distinct
440 Hz and 660 Hz channel tones, bounded frame counts and finite sample energy.
The fixture directory records how the original test audio was generated.

The unchanged upstream `docs/hello.c`, retained as `port/upstream-hello.c`,
exercises device playback. A local test wrapper includes `stdbool.h` because
the platform SDL umbrella header leaves boolean macros to consumers. Browser instrumentation observes the real
`AudioBufferSourceNode.start` calls and requires nonzero decoded PCM to reach
Web Audio; track state or a successful process exit alone does not satisfy this
check. Platform audio streams, conversion, callbacks and browser transport are
provided by the separately accepted SDL3 dependency and runtime.

Acceptance results and exact dependency pins belong to the package job's
candidate metadata. This document describes the supported contract, not release
approval or promotion status.
