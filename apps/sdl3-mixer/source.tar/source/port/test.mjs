import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('sdl3-mixer',600000);
try{
 await page.mouse.click(10,10);
 await page.evaluate(()=>{
  window.mixerOutput={buffers:0,nonzero:0,peak:0};
  const start=AudioBufferSourceNode.prototype.start;
  AudioBufferSourceNode.prototype.start=function(...args){
   if(this.buffer){window.mixerOutput.buffers++;for(let ch=0;ch<this.buffer.numberOfChannels;ch++)for(const sample of this.buffer.getChannelData(ch)){if(Math.abs(sample)>0.01)window.mixerOutput.nonzero++;window.mixerOutput.peak=Math.max(window.mixerOutput.peak,Math.abs(sample));}}
   return start.apply(this,args);
  };
 });
 const r=await runCached(page,`set -e
gucman install sdl3-mixer
cc /usr/src/sdl3-mixer/port/check.c -I/usr/local/include -lSDL3_mixer -lSDL3 -lm -lpthread -o /tmp/mixer-check
/tmp/mixer-check /usr/src/sdl3-mixer/port/fixtures
cc /usr/src/sdl3-mixer/port/check.c -I/usr/local/include /usr/local/lib/libSDL3_mixer.a -lSDL3 -lm -lpthread -o /tmp/mixer-static
/tmp/mixer-static /usr/src/sdl3-mixer/port/fixtures
cc /usr/src/sdl3-mixer/port/hello-wrapper.c -I/usr/local/include -lSDL3_mixer -lSDL3 -o /tmp/mixer-upstream-hello
/tmp/mixer-upstream-hello /usr/src/sdl3-mixer/port/fixtures/tone.wav
echo SDL3-MIXER-PACKAGE-PASS
`,{packages:['sdl3-mixer'],fresh:['sdl3-mixer']});
 const log=await page.evaluate(()=>shell.busybox.log);assert.equal(r.code,0,log);assert.match(log,/SDL3-MIXER-PACKAGE-PASS/);assert.deepEqual(errors,[]);
 const pcm=await page.evaluate(()=>window.mixerOutput);
 assert(pcm.buffers>0&&pcm.nonzero>100&&pcm.peak>0.05&&pcm.peak<=1,JSON.stringify(pcm));
 console.log('PASS upstream mixer device playback delivers nonzero PCM to WebAudio',pcm);
}finally{await close();}
