#include <stdbool.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <assert.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
static void near(float a,float b){assert(fabsf(a-b)<0.00001f);}
static void decoder(const char *path){
 MIX_AudioDecoder *d=MIX_CreateAudioDecoder(path,0);if(!d)puts(SDL_GetError());assert(d);
 SDL_AudioSpec spec={SDL_AUDIO_F32,2,32000};float buf[512];double power=0,energy[2]={0},sine[2]={0},cosine[2]={0};int total=0,n;
 const int lossless=strstr(path,".wav")!=NULL||strstr(path,".flac")!=NULL;
 while((n=MIX_DecodeAudio(d,buf,sizeof(buf),&spec))>0){
  assert(n%8==0);
  for(int i=0;i<n/8;i++)for(int ch=0;ch<2;ch++){
   float sample=buf[i*2+ch];assert(isfinite(sample));
   double angle=2*3.141592653589793*(ch?660:440)*(total+i)/32000;
   power+=sample*sample;energy[ch]+=sample*sample;sine[ch]+=sample*sin(angle);cosine[ch]+=sample*cos(angle);
   if(lossless){double reference=floor((ch?7000:10000)*sin(angle)+0.5)/32768;assert(fabs(sample-reference)<0.000002);}
  }
  total+=n/8;assert(total<12000);
 }
 if(lossless)assert(total==8000);
 for(int ch=0;ch<2;ch++)assert(2*(sine[ch]*sine[ch]+cosine[ch]*cosine[ch])/(total*energy[ch])>0.85);
 printf("Decoded %s: %d frames, power %.3f\n",path,total,power);
 assert(n==0&&total>=7500&&total<=10000&&power>100&&power<1000);
 MIX_DestroyAudioDecoder(d);
}
int main(int argc,char **argv){
 assert(argc==2);assert(MIX_Init());
 SDL_AudioSpec spec={SDL_AUDIO_F32,2,32000};
 MIX_Mixer *m=MIX_CreateMixer(&spec);if(!m)puts(SDL_GetError());assert(m);
 float samples[128],output[128];for(int i=0;i<64;i++){samples[i*2]=0.2f;samples[i*2+1]=-0.1f;}
 MIX_Audio *audio=MIX_LoadRawAudio(m,samples,sizeof(samples),&spec);assert(audio);
 assert(MIX_GetAudioDuration(audio)==64);
 MIX_Track *a=MIX_CreateTrack(m),*b=MIX_CreateTrack(m);assert(a&&b);
 assert(MIX_SetTrackAudio(a,audio)&&MIX_SetTrackAudio(b,audio));
 assert(MIX_SetTrackGain(a,0.5f)&&MIX_SetTrackGain(b,0.25f));
 SDL_PropertiesID options=SDL_CreateProperties();assert(options);
 assert(SDL_SetNumberProperty(options,MIX_PROP_PLAY_LOOPS_NUMBER,-1));
 assert(MIX_PlayTrack(a,options)&&MIX_PlayTrack(b,options));
 assert(MIX_Generate(m,output,sizeof(output))==sizeof(output));
 for(int i=0;i<64;i++){near(output[i*2],0.15f);near(output[i*2+1],-0.075f);}
 assert(MIX_PauseTrack(b));assert(MIX_TrackPaused(b));
 assert(MIX_Generate(m,output,sizeof(output))==sizeof(output));
 for(int i=0;i<64;i++){near(output[i*2],0.1f);near(output[i*2+1],-0.05f);}
 assert(MIX_ResumeTrack(b));assert(MIX_TrackPlaying(b));
 assert(MIX_StopTrack(a,0)&&MIX_StopTrack(b,0));
 assert(MIX_Generate(m,output,sizeof(output))==0);for(int i=0;i<128;i++)near(output[i],0);
 assert(MIX_SetTrackGain(a,1));assert(MIX_PlayTrack(a,0));
 assert(MIX_SetTrackPlaybackPosition(a,32));
 assert(MIX_Generate(m,output,sizeof(output))==32*2*sizeof(float));
 for(int i=0;i<32;i++){near(output[i*2],0.2f);near(output[i*2+1],-0.1f);}for(int i=64;i<128;i++)near(output[i],0);
 assert(!MIX_TrackPlaying(a));
 SDL_DestroyProperties(options);MIX_DestroyTrack(a);MIX_DestroyTrack(b);MIX_DestroyAudio(audio);MIX_DestroyMixer(m);
 char path[1024];const char *exts[]={"wav","ogg","mp3","flac"};for(int i=0;i<4;i++){snprintf(path,sizeof(path),"%s/tone.%s",argv[1],exts[i]);decoder(path);}
 assert(!MIX_CreateAudioDecoder("/missing-audio",0));MIX_Quit();puts("SDL3-MIXER-PASS");return 0;
}
