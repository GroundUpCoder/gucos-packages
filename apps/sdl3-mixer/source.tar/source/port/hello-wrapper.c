#include <stdbool.h>
#include "upstream-hello.c"
