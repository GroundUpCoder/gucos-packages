#include <stdbool.h>
#include <assert.h>
#include "../../upstream/src/decoder_sinewave.c"
