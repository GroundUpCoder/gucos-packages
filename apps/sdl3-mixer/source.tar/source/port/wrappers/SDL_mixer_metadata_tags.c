#include <stdbool.h>
#include <assert.h>
#include "../../upstream/src/SDL_mixer_metadata_tags.c"
