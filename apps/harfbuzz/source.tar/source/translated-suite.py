#!/usr/bin/env python3
"""Run exactly one resumable acceptance batch inside a <=1800s machine-job.

Repeat the same command after each reservation finishes. This driver never
submits another reservation, retries admission, or loops over batches itself.
"""
import argparse, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
from batching import run_command, save_json, signature

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
p = argparse.ArgumentParser()
p.add_argument('work', type=Path)
p.add_argument('upstream', type=Path)
p.add_argument('native', type=Path)
p.add_argument('--status', action='store_true')
p.add_argument('--retry-failed', action='store_true', help='Retry a failed prerequisite, preserving its previous output')
a = p.parse_args()
w, u, n = a.work.resolve(), a.upstream.resolve(), a.native.resolve()
state_file = w / 'batch-state.json'
if a.status:
    path = state_file if state_file.exists() else w / 'stages.json'
    print(path.read_text() if path.exists() else 'No saved progress')
    sys.exit(0)
if not os.environ.get('MACHINE_JOB_ID'):
    p.error('Run one invocation through machine-job run --timeout 1800 -- ...')
if not state_file.exists() and w.exists() and any(w.iterdir()):
    p.error('Existing non-batched evidence is preserved; choose a new work directory')
w.mkdir(parents=True, exist_ok=True)
if not state_file.exists():
    save_json(state_file, {'format': 1, 'fingerprint': None, 'completed': [], 'attempts': []})
logs = w / 'build-logs'
logs.mkdir(exist_ok=True)
py = sys.executable
translator = ROOT / 'tools/cpp-translator'

# Reject mixed compiler/runtime/source inputs across resumed reservations.
# Documentation is excluded so recording results does not invalidate a build.
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', 'src', 'libc',
    'tools/cpp-translator', 'apps/harfbuzz', 'tools/compiler-context.mjs',
    'tools/libc-manifest.mjs', 'vendor/glib', 'vendor/pcre2', 'vendor/gettext',
    'vendor/libiconv', 'vendor/zlib'], cwd=ROOT).decode().split('\0')
inputs = {}
for relative in paths:
    path = ROOT / relative
    if relative and path.is_file() and path.suffix != '.md':
        inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
sdk = ROOT / 'test-results/cpp-translator/toolchains/wasi-sysroot-30.0/include/wasm32-wasi'
for base in (u, sdk):
    for directory, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in ('.git', 'subprojects')]
        for name in files:
            path = Path(directory) / name
            if path.is_file():
                inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ('intro-tests.json', 'intro-targets.json'):
    path = n / 'meson-info' / name
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
from importlib.metadata import version
for tool in ('clang', 'node'):
    value = subprocess.check_output([tool, '--version'], text=True)
    inputs['toolchain:' + tool] = hashlib.sha256(value.encode()).hexdigest()
inputs['toolchain:python'] = hashlib.sha256(sys.version.encode()).hexdigest()
inputs['toolchain:llvmlite'] = version('llvmlite')
fingerprint = signature(inputs)
state = json.loads(state_file.read_text())
if state['fingerprint'] is None:
    state['fingerprint'] = fingerprint
    save_json(w / 'batch-inputs.json', inputs)
    save_json(state_file, state)
elif state['fingerprint'] != fingerprint:
    p.error('Inputs changed since the first batch; preserve this run and use a new directory')

stages = [
    ('world-source', [py, str(HERE/'translate-world.py'), str(w/'generated')], True),
    ('world-compile', ['node', '--max-old-space-size=6144', str(translator/'compile-project.mjs'), str(w/'generated/world'), str(w/'world.a')], True),
    ('dependencies', ['node', '--max-old-space-size=6144', str(HERE/'build-test-runtime.mjs'), str(w/'runtime')], True),
    ('libcxx', [py, str(translator/'build-libcxx.py'), str(w/'libcxx'), str(w/'runtime/libcxx.a')], True),
    ('test-source', [py, str(HERE/'translate-upstream-tests.py'), str(w/'cxx'), str(n)], False),
    ('test-build', [py, str(HERE/'build-upstream-tests.py'), str(w), str(u), str(n), '--translated', str(w/'cxx'), '--run-c', '--resume', '--max-targets', '8', '--budget-seconds', '1500'], False),
    ('upstream', [py, str(HERE/'run-upstream.py'), str(w), str(n), '--translated', str(w/'cxx'), '--timeout', '600', '--resume', '--max-tests', '20', '--budget-seconds', '1500'], False),
    ('differential', [py, str(HERE/'differential-shape.py'), str(w), str(u), str(n)], False),
]
remaining = [stage for stage in stages if stage[0] not in state['completed']]
if not remaining:
    print(json.dumps({'complete': True, 'attempts': len(state['attempts'])}))
    sys.exit(1 if state.get('failedStages') else 0)
name, command, required = remaining[0]
prior = [row for row in state['attempts'] if row['stage'] == name]
if prior and (name not in ('test-build', 'upstream') or prior[-1].get('fatal')):
    if not a.retry_failed and not prior[-1].get('interrupted'):
        p.error('Previous stage failed; inspect its log before passing --retry-failed')
    # Keep interrupted/failed producer output intact before repeating that stage.
    patterns = {'world-source': ['generated'], 'world-compile': ['world.a*'],
                'dependencies': ['runtime'], 'libcxx': ['libcxx', 'libcxx.ll', 'runtime/libcxx.a*'],
                'test-source': ['cxx'], 'differential': ['differential-shape']}
    saved = w / 'attempts' / (name + '-' + str(len(prior)))
    for pattern in patterns.get(name, []):
        for path in w.glob(pattern):
            destination = saved / path.relative_to(w)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), str(destination))
log = logs / (name + '-' + str(len(prior) + 1) + '.log')
row = {'stage': name, 'command': command, 'log': str(log)}
try:
    with log.open('w') as output:
        try:
            code = run_command(command, cwd=ROOT, stdout=output,
                               stderr=subprocess.STDOUT, timeout=1650)
        except subprocess.TimeoutExpired:
            code = 124
            row['interrupted'] = True
except SystemExit as error:
    row.update(returncode=error.code, interrupted=True)
    state['attempts'].append(row)
    save_json(state_file, state)
    raise
row['returncode'] = code
complete = not row.get('interrupted') and (code == 0 or not required)
if name in ('test-build', 'upstream'):
    progress = w/'isolated-build/progress.json' if name == 'test-build' else w/'upstream-coverage.json'
    complete = progress.exists() and json.loads(progress.read_text()).get('complete', False)
    if code and not progress.exists() and not row.get('interrupted'):
        row['fatal'] = True
row['stageComplete'] = complete
state['attempts'].append(row)
if complete:
    state['completed'].append(name)
    if code:
        state.setdefault('failedStages', []).append(name)
state['complete'] = len(state['completed']) == len(stages)
save_json(state_file, state)
print(json.dumps({'batch': row, 'complete': state['complete'],
                  'next': next((s[0] for s in stages if s[0] not in state['completed']), None)}))
sys.exit(code if code else (1 if state['complete'] and state.get('failedStages') else 0))
