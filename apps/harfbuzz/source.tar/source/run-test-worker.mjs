import {Worker} from 'node:worker_threads';

export async function executeTest(binary,args=[],env=process.env,timeout=600000){
 const result={},start=performance.now();
 await new Promise(resolve=>{
  const worker=new Worker(new URL('./run-wasm.mjs',import.meta.url),{
   argv:[binary,...args],workerData:{kind:'test'},env,stdout:true,stderr:true,
  });
  const stdout=[],stderr=[];
  worker.stdout.on('data',b=>stdout.push(b));worker.stderr.on('data',b=>stderr.push(b));
  const timer=setTimeout(()=>{result.status='TIMEOUT';worker.terminate();},timeout);
  worker.on('error',error=>{result.status='FAIL';result.error=error.stack||String(error);});
  worker.on('exit',code=>{
   clearTimeout(timer);result.status??=code===0?'PASS':code===77?'SKIP':'FAIL';
   result.returncode=code;result.stdout=Buffer.concat(stdout).toString();result.stderr=Buffer.concat(stderr).toString();
   result.seconds=(performance.now()-start)/1000;resolve();
  });
 });
 return result;
}
