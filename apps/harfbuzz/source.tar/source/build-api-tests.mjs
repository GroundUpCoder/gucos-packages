import {buildRuntime} from '../../tools/cpp-translator/build-runtime.mjs';
import {executeTest} from './run-test-worker.mjs';
// Compile unmodified upstream C tests against translated HarfBuzz and real GLib.
import {runCompilerScript} from '../../tools/compiler-context.mjs';
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';
const work=path.resolve(process.argv[2]),upstream=path.resolve(process.argv[3]),native=path.resolve(process.argv[4]);
const targets=new Set();let report='api-build.json',execute=false;
for(let i=5;i<process.argv.length;i++){
 if(process.argv[i]==='--target'&&process.argv[i+1])targets.add(process.argv[++i]);
 else if(process.argv[i]==='--report'&&process.argv[i+1])report=process.argv[++i];
 else if(process.argv[i]==='--run')execute=true;
 else throw Error('Expected --target NAME, --report FILE, or --run');
}
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});c.self=c;
for(const name of ['path','compiler','trampoline','objects','compile'])runCompilerScript(fs.readFileSync(new URL('../../src/'+name+'.js',import.meta.url),'utf8'),c);
const files=new Proxy({},{get(_,name){if(typeof name!=='string')return;try{
 if(name===path.resolve('vendor/glib/glib/gthread.h'))return fs.readFileSync('vendor/glib/glib/gthread-wasm-posix.h','utf8');
 return fs.readFileSync(name,'utf8');}catch{return;}}});
const tests=JSON.parse(fs.readFileSync(native+'/meson-info/intro-tests.json','utf8')).filter(t=>t.suite.includes('harfbuzz:api'));
const allTests=JSON.parse(fs.readFileSync(native+'/meson-info/intro-tests.json','utf8'));
// This original C test lives outside test/api but is part of the upstream suite.
for(const test of allTests.filter(t=>t.cmd[0]===native+'/test/vector/test-vector-budget'))
 tests.push({...test,name:'test-vector-budget',source:upstream+'/test/vector/test-vector-budget.c'});
const includes=[path.resolve('apps/harfbuzz/include'),upstream+'/src',upstream+'/test/api',path.resolve('vendor/glib'),path.resolve('vendor/glib/glib')];
fs.writeFileSync(work+'/runtime/cxx.a',buildRuntime(c));
const archives=['world.a',...['cxx','glib','pcre2','gettext','libiconv','zlib','libc'].map(n=>'runtime/'+n+'.a')].map(name=>({name,bytes:fs.readFileSync(work+'/'+name)}));
const results=[];fs.mkdirSync(work+'/api',{recursive:true});
for(const test of tests){
 if(targets.size&&!targets.has(test.name))continue;
 const source=test.source||upstream+'/test/api/'+test.name+'.c';
 const row={name:test.name,source,args:test.cmd.slice(1),env:test.env,status:'PENDING'};results.push(row);
 if(!fs.existsSync(source)){row.status='CXX_TRANSLATION_REQUIRED';continue;}
 let diagnostics='';
 try{
 const object=c.compileObject(files,source,includes,s=>diagnostics+=s,{defines:['HAVE_STDBOOL_H=1','HAVE_GLIB=1','HB_NO_FEATURES_H=1']});
 fs.writeFileSync(work+'/api/'+test.name+'.o',object.bytes);
 row.backends=[];
 for(const nativeFunctions of [true,false]){
 const r=c.linkProgram([{name:source,bytes:object.bytes}],archives,s=>{throw Error(s);},{libcArchive:archives.at(-1).bytes,compilerOptions:{nativeFunctions}});
 const binary=work+'/api/'+test.name+'-'+nativeFunctions+'.wasm';
 fs.writeFileSync(binary,r.bytes);
 const backend={nativeFunctions,bytes:r.bytes.length,linkMilliseconds:r.stats.milliseconds};row.backends.push(backend);
 if(execute){
  const cwd=process.cwd();fs.mkdirSync(work+'/api-run',{recursive:true});process.chdir(work+'/api-run');
  try{backend.execution=await executeTest(binary,row.args,{...process.env,...Object.fromEntries(Object.entries(row.env).filter(([k])=>!k.endsWith('LIBRARY_PATH')))});}
  finally{process.chdir(cwd);}
  console.log(backend.execution.status,test.name,nativeFunctions);
 }
 fs.writeFileSync(work+'/'+report,JSON.stringify(results,null,2)+'\n');
 }
 row.status='BUILT';console.log('BUILT '+test.name);
 }catch(error){row.status='BUILD_FAILED';row.error=String(error);row.diagnostics=diagnostics;console.error(test.name+': '+error.message);}
 fs.writeFileSync(work+'/'+report,JSON.stringify(results,null,2)+'\n');
}
fs.writeFileSync(work+'/'+report,JSON.stringify(results,null,2)+'\n');
if(results.some(r=>r.status!=='BUILT'||r.backends?.some(b=>b.execution&&!['PASS','SKIP'].includes(b.execution.status))))process.exitCode=1;
