#include "upstream/src/hb.h"
#include "upstream/src/hb-ot.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
