#!/usr/bin/env python3
"""Run unchanged upstream shape runners against the translated hb-shape CLI."""
import argparse,json,os,shlex,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('native',type=Path);args=p.parse_args()
w=args.work.resolve();native=args.native.resolve()
tests=[t for t in json.loads((native/'meson-info/intro-tests.json').read_text()) if any(s.startswith('harfbuzz:shape') for s in t['suite'])]
results=[]
for mode in ['true','false']:
 wrapper=w/('hb-shape-'+mode)
 wrapper.write_text('#!/bin/sh\nexec node --experimental-wasm-jspi '+shlex.quote(str(HERE/'run-wasm.mjs'))+' '+shlex.quote(str(w/('hb-shape-'+mode+'.wasm')))+' "$@"\n');wrapper.chmod(0o755)
 if not (w/('hb-shape-'+mode+'.wasm')).is_file():
  raise FileNotFoundError('Build hb-shape-'+mode+'.wasm before running upstream tests')
 subprocess.run([str(wrapper),'--version'],check=True,timeout=600)
 for test in tests:
  command=[str(wrapper) if v.endswith('/util/hb-shape') or v=='util/hb-shape' else v for v in test['cmd']]
  if command[0].endswith('.py'):command[:0]=[sys.executable,'-u']
  log=w/f'shape-{test["name"]}-{mode}.log';start=time.monotonic()
  code=None;status='TIMEOUT'
  try:
   with log.open('w') as output:
    r=subprocess.run(command,cwd=native,env={**os.environ,**test['env']},stdout=output,stderr=subprocess.STDOUT,timeout=1800)
   code=r.returncode;status='PASS' if code==0 else 'FAIL'
  except subprocess.TimeoutExpired:
   pass
  row={'name':test['name'],'nativeFunctions':mode=='true','status':status,'returncode':code,'seconds':time.monotonic()-start,'log':str(log),'command':command}
  results.append(row);print(json.dumps(row),flush=True)
  (w/'shape-results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['status']!='PASS' for r in results):raise SystemExit(1)
