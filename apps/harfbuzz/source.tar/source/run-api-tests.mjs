// Execute original upstream C test binaries sequentially in isolated workers.
// Each gets a fresh host context, Wasm memory, environment and pthread workers.
// This avoids restarting the Node executable for every test on the build host.
import fs from 'node:fs';
import path from 'node:path';
import {executeTest} from './run-test-worker.mjs';
const work=path.resolve(process.argv[2]);
const rows=JSON.parse(fs.readFileSync(work+'/api-build.json','utf8'));
const results=[];
const previousCwd=process.cwd();
fs.mkdirSync(work+'/api-run',{recursive:true});process.chdir(work+'/api-run');
try{
for(const row of rows)for(const nativeFunctions of [true,false]){
 const binary=work+'/api/'+row.name+'-'+nativeFunctions+'.wasm';
 const result={name:row.name,nativeFunctions};results.push(result);
 if(row.status!=='BUILT'||!fs.existsSync(binary)){
  result.status='BUILD_FAILED';result.error=row.error||row.status;
 }else{
  const env={...process.env,...Object.fromEntries(Object.entries(row.env).filter(([k])=>!k.endsWith('LIBRARY_PATH')))};
  Object.assign(result,await executeTest(binary,row.args||[],env));
 }
 console.log(result.status,row.name,nativeFunctions);
 fs.writeFileSync(work+'/api-worker-results.json',JSON.stringify(results,null,2)+'\n');
}
}finally{process.chdir(previousCwd);}
if(results.some(r=>r.status!=='PASS'&&r.status!=='SKIP'))process.exitCode=1;
