/* Upstream-supported override hook, before hb-config.hh closes dependencies.
   Keep legacy cmap/kern/fallback support needed by ordinary text fonts. */
#undef HB_NO_LEGACY
