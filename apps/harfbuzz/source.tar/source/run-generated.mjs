import {runCompilerScript} from '../../tools/compiler-context.mjs';
import {readFileSync, readdirSync, writeFileSync} from 'node:fs';
import {resolve, relative, join} from 'node:path';
import vm from 'node:vm';

const work=resolve(process.argv[2]);
const app=resolve(new URL('.',import.meta.url).pathname);
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly}); c.self=c;
for(const n of ['path','compiler','trampoline','objects','compile'])
  runCompilerScript(readFileSync(new URL('../../src/'+n+'.js',import.meta.url),'utf8'),c);
const manifest=JSON.parse(readFileSync(work+'/project/manifest.json','utf8'));
const headerFiles={};
function headers(dir){
  for(const entry of readdirSync(dir,{withFileTypes:true})){
    const path=join(dir,entry.name);
    if(entry.isDirectory())headers(path);
    else if(/\.h$/.test(entry.name))headerFiles['/'+relative(app,path)]=readFileSync(path,'utf8');
  }
}
headers(app+'/upstream/src');
headerFiles['/cases.h']=readFileSync(work+'/cases.h','utf8');
const diagnostics=s=>{throw Error(s);};
const objects=[];
const sources=manifest.artifacts.map(row=>({name:'/generated/'+row.path,path:work+'/project/'+row.path}));
sources.push({name:'/driver.c',path:app+'/tests/driver.c',headers:true},
             {name:'/checks.c',path:work+'/checks.c'},
             {name:'/entry.c',text:'int run_tests(void); int main(void){return run_tests();}'});
for(const [i,source] of sources.entries()){
  const {name}=source;
  // Each generated definition is independent. Do not copy an N-source map
  // into N compiler invocations; only the ordinary C driver needs HB headers.
  const files=source.headers?{...headerFiles}:{};
  files[name]=source.text??readFileSync(source.path,'utf8');
  try{objects.push({name,bytes:c.compileObject(files,name,[],diagnostics).bytes});}
  catch(error){throw Error(name+': '+error.message,{cause:error});}
  if(i%500===0)console.error('Compiled '+i+'/'+sources.length+' C files');
}
const archive=c.WasmObjects.writeArchive(objects.filter(o=>o.name.startsWith('/generated/')));
writeFileSync(work+'/harfbuzz.a',archive);
const libc={name:'libc.a',bytes:c.buildLibc(diagnostics).bytes};
const results=[];
for(const nativeFunctions of [true,false]){
  const options={compilerOptions:{nativeFunctions},libcArchive:libc.bytes};
  const r=c.linkProgram(objects.filter(o=>!o.name.startsWith('/generated/')),
    [{name:'harfbuzz.a',bytes:archive},libc],diagnostics,options);
  if(!WebAssembly.validate(r.bytes))throw Error('Invalid generated Wasm');
  writeFileSync(work+'/shaping-'+nativeFunctions+'.wasm',r.bytes);
  const module=new WebAssembly.Module(r.bytes);
  const imports={c:{__cc_yield(){}}};
  for(const item of WebAssembly.Module.imports(module)){
    if(item.module!=='c'||item.kind!=='function')throw Error('Unexpected import '+JSON.stringify(item));
    imports.c[item.name]??=()=>{throw Error('Unexpected host call '+item.name);};
  }
  const instance=new WebAssembly.Instance(module,imports);
  const result=instance.exports.main();
  results.push({nativeFunctions,mode:'archive',result,wasmBytes:r.bytes.length});
  if(result!==0)throw Error('Shaping mismatch '+JSON.stringify(results.at(-1)));
}
console.log(JSON.stringify({definitionFiles:manifest.artifacts.length,archiveBytes:archive.length,results}));
