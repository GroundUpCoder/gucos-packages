// Execute translated tests with the real wasm-posix runtime and Node filesystem.
// Workers share Wasm memory/TLS through host.js's actual pthread entry protocol.
// This test host does not implement fork/exec or cross-thread descriptor sharing.
import fs from 'node:fs';import vm from 'node:vm';
import {Worker,isMainThread,parentPort,workerData} from 'node:worker_threads';
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly,SharedArrayBuffer,Atomics,crypto:globalThis.crypto,setTimeout,clearTimeout,MessageChannel,process,Buffer});c.self=c;
for(const name of ['dynamic-loader','host'])vm.runInContext(fs.readFileSync(new URL('../../src/'+name+'.js',import.meta.url),'utf8'),c,{filename:name+'.js'});
if(!isMainThread&&workerData?.kind!=='test'){
 let next=0;const pending=new Map();
 parentPort.on('message',m=>{if(m.type==='control-result'){pending.get(m.id)?.(m.result);pending.delete(m.id);}});
 try{
  const code=await c.runModule({...workerData,module:workerData.thread.module,thread:workerData.thread,fs,sdlBackend:'null',maxWallMs:600000,
   onReady(){parentPort.postMessage({type:'ready'});},
   processControl(op,data){return new Promise(resolve=>{const id=++next;pending.set(id,resolve);parentPort.postMessage({type:'control',id,op,data});});}});
  parentPort.postMessage({type:'done',code});parentPort.close();
 }catch(error){parentPort.postMessage({type:'failed',error:error.stack||String(error)});parentPort.close();}
}else{
 const filename=process.argv[2],args=[filename,...process.argv.slice(3)],env={...process.env};
 const workers=new Set();let nextTid=1,rejectFailure;
 const failure=new Promise((_,reject)=>{rejectFailure=reject;});
 async function control(op,data){
  if(op!=='thread')return {errno:'ENOSYS'};
  return await new Promise((resolve,reject)=>{
   const tid=++nextTid,worker=new Worker(new URL(import.meta.url),{workerData:{args,env,thread:data}});workers.add(worker);
   let completed=false;
   worker.on('message',m=>{
    if(m.type==='ready')resolve({tid});
    else if(m.type==='control')control(m.op,m.data).then(result=>worker.postMessage({type:'control-result',id:m.id,result}),error=>rejectFailure(error));
    else if(m.type==='failed'){const error=Error(m.error);reject(error);rejectFailure(error);}
    else if(m.type==='done'){
     completed=true;
     if(m.code)rejectFailure(Error('Thread exited with status '+m.code));
     // C execution and TLS destruction have finished. Node host IO handles can
     // otherwise retain the worker after pthread_join, exhausting OS threads
     // in programs that repeatedly create and join short-lived pthreads.
     worker.terminate().catch(rejectFailure);
    }
   });
   worker.on('error',error=>{reject(error);rejectFailure(error);});
   worker.on('exit',code=>{workers.delete(worker);if(code&&!completed){const error=Error('Thread worker exited with status '+code);reject(error);rejectFailure(error);}});
  });
 }
 try{
  process.exitCode=await Promise.race([failure,c.runModule({bytes:fs.readFileSync(filename),args,env,fs,sdlBackend:'null',maxWallMs:600000,processControl:control})]);
 }finally{
  // A process exit ends its unjoined threads, just as in the normal runtime.
  await Promise.all([...workers].map(worker=>worker.terminate()));
 }
}
