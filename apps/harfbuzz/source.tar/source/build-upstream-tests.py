#!/usr/bin/env python3
"""Build upstream targets in separate compiler processes under one machine job.

The process boundary releases compiler/linker heap between large targets.
Individual reports survive a crash, and every nonzero child status is retained.
"""
import argparse,json,subprocess,sys
from batching import Budget, check_selection, fresh_log, run_command, save_json
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path)
p.add_argument('upstream',type=Path);p.add_argument('native',type=Path)
p.add_argument('--translated',type=Path)
p.add_argument('--only',choices=['c','cxx','all'],default='all')
p.add_argument('--run-c',action='store_true')
p.add_argument('--resume',action='store_true')
p.add_argument('--max-targets',type=int,default=8)
p.add_argument('--budget-seconds',type=float,default=1500)
p.add_argument('--timeout',type=float,default=600)
a=p.parse_args();w=a.work.resolve();u=a.upstream.resolve();n=a.native.resolve()
if a.only!='c' and a.translated is None:p.error('--translated is required for C++ builds')
reports=w/'isolated-build';reports.mkdir(exist_ok=True)
jobs=[]
if a.only!='cxx':
    tests=json.loads((n/'meson-info/intro-tests.json').read_text())
    names=[t['name'] for t in tests if 'harfbuzz:api' in t['suite'] and
           (u/'test/api'/(t['name']+'.c')).is_file()]
    names.append('test-vector-budget')
    for name in names:
        report=reports/(name+'.json')
        command=['node','--max-old-space-size=6144','--experimental-wasm-jspi',str(HERE/'build-api-tests.mjs'),
                 str(w),str(u),str(n),'--target',name,'--report',str(report.relative_to(w))]
        if a.run_c:command.append('--run')
        jobs.append(('c',name,report,command))
if a.only!='c':
    translated=a.translated.resolve()
    for row in json.loads((translated/'translation-results.json').read_text()):
        name=row['target'];report=translated/('build-'+name.replace('/','_')+'.json')
        jobs.append(('cxx',name,report,['node','--max-old-space-size=6144',str(HERE/'build-cxx-tests.mjs'),
                     str(w),str(translated),'--target',name,'--report',report.name]))
budget=Budget(a.budget_seconds,a.timeout,a.max_targets)
check_selection(reports/'selection.json', [(kind,name,command) for kind,name,report,command in jobs],a.resume)
results=json.loads((reports/'results.json').read_text()) if a.resume and (reports/'results.json').exists() else []
finished={(r['kind'],r['target']) for r in results}
for kind,name,report,command in jobs:
    if (kind,name) in finished:continue
    if not budget.take():break
    log=fresh_log(reports/(kind+'-'+name.replace('/','_')+'.log'))
    with log.open('w') as output:
        try:code=run_command(command,timeout=a.timeout,stdout=output,stderr=subprocess.STDOUT)
        except subprocess.TimeoutExpired:code=124
    row={'kind':kind,'target':name,'returncode':code,'report':str(report),'log':str(log)}
    results.append(row);print(json.dumps(row),flush=True)
    save_json(reports/'results.json',results)
save_json(reports/'progress.json',{'complete':len(results)==len(jobs),'completed':len(results),'total':len(jobs)})
if any(r['returncode'] for r in results):sys.exit(1)
