"""Lightweight subprocess regressions for checkpointing, not HarfBuzz acceptance."""
import json, os, subprocess, sys, tempfile, time, unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1]

class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='hb-batching-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.native = self.root/'native'
        (self.native/'meson-info').mkdir(parents=True)
        self.work = self.root/'work'
        self.counter = self.root/'executed'
        self.subject = self.root/'subject.py'
        self.subject.write_text('''import pathlib,sys,time,subprocess
counter=pathlib.Path(sys.argv[1])
with counter.open('a') as f:f.write(sys.argv[2]+'\\n')
if sys.argv[2]=='slow':
 child=pathlib.Path(sys.argv[3]);ready=pathlib.Path(sys.argv[4])
 subprocess.Popen([sys.executable,'-c',"import pathlib,time;pathlib.Path("+repr(str(ready))+").write_text('ready');time.sleep(1);pathlib.Path("+repr(str(child))+").write_text('orphan')"])
 time.sleep(10)
''')
        self.tests = [{'name': name, 'suite':['harfbuzz:src'], 'env':{},
            'cmd':[sys.executable,str(self.subject),str(self.counter),name],
            'workdir':str(self.root)} for name in ('first','second')]
        self.write_tests()
        (self.native/'meson-info/intro-targets.json').write_text('[]')

    def write_tests(self):
        (self.native/'meson-info/intro-tests.json').write_text(json.dumps(self.tests))

    def run_batch(self, *extra):
        return subprocess.run([sys.executable,str(APP/'run-upstream.py'),str(self.work),
            str(self.native),'--resume','--max-tests','1','--budget-seconds','5',
            '--timeout','1',*extra],capture_output=True,text=True,timeout=15)

    def test_resume_does_not_repeat_completed_entries(self):
        for index in range(4):
            r=self.run_batch()
            self.assertEqual(r.returncode,0,r.stderr)
            rows=json.loads((self.work/'upstream-results.json').read_text())
            self.assertEqual(len(rows),index+1)
            coverage=json.loads((self.work/'upstream-coverage.json').read_text())
            self.assertEqual(coverage['complete'],index==3)
            self.assertEqual(coverage['fullInventory'],index==3)
        before=self.counter.read_text()
        self.assertEqual(before.splitlines(),['first','second','first','second'])
        self.assertEqual(self.run_batch().returncode,0) # Accepted exclusions are not failures.
        self.assertEqual(coverage['status'],'SUPPORTED_SCOPE_PASS')
        self.assertFalse(coverage['nativeEquivalent'])
        self.assertTrue(coverage['acceptedPlatformExclusions'])
        self.assertEqual(len(coverage['nativeOnlySubcases']),3)
        self.assertEqual(self.counter.read_text(),before)

    def test_changed_selection_rejects_resume(self):
        self.assertEqual(self.run_batch().returncode,0)
        self.tests[0]['name']='changed'
        self.write_tests()
        r=self.run_batch()
        self.assertNotEqual(r.returncode,0)
        self.assertIn('selection changed',r.stderr)
        self.assertEqual(self.counter.read_text().splitlines(),['first'])

    def test_timeout_kills_descendants_and_retains_result(self):
        child=self.root/'orphan';ready=self.root/'ready'
        self.tests[0]['cmd']=[sys.executable,str(self.subject),str(self.counter),'slow',str(child),str(ready)]
        self.write_tests()
        r=self.run_batch('--timeout','0.5')
        self.assertEqual(r.returncode,1,r.stderr)
        self.assertTrue(ready.exists(),'fixture child must have started')
        time.sleep(1.1)
        self.assertFalse(child.exists(),'timed-out test left a live descendant')
        rows=json.loads((self.work/'upstream-results.json').read_text())
        self.assertEqual(rows[0]['status'],'TIMEOUT')
        r=self.run_batch()
        self.assertEqual(r.returncode,1) # Earlier failure remains a failure.
        rows=json.loads((self.work/'upstream-results.json').read_text())
        self.assertEqual([row['status'] for row in rows],['TIMEOUT','PASS'])

    def test_budget_rejects_overlong_batch(self):
        r=self.run_batch('--budget-seconds','1800')
        self.assertNotEqual(r.returncode,0)
        self.assertIn('budget <= 1500',r.stderr)
        self.assertFalse(self.counter.exists())

    def test_interrupted_log_is_preserved(self):
        directory=self.work/'upstream/true';directory.mkdir(parents=True)
        old=directory/'0-first.log';old.write_text('interrupted evidence')
        self.assertEqual(self.run_batch().returncode,0)
        self.assertEqual(old.read_text(),'interrupted evidence')
        rows=json.loads((self.work/'upstream-results.json').read_text())
        self.assertNotEqual(Path(rows[0]['log']),old)

    def test_pipeline_status_preserves_legacy_run(self):
        self.work.mkdir();legacy=self.work/'stages.json'
        legacy.write_text('[{"stage":"world-source","returncode":0}]')
        command=[sys.executable,str(APP/'translated-suite.py'),str(self.work),str(self.root),str(self.native),'--status']
        r=subprocess.run(command,capture_output=True,text=True,timeout=5)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(list(self.work.iterdir()),[legacy])

    def test_build_checkpoint_skips_completed_targets(self):
        self.work.mkdir()
        upstream=self.root/'upstream';(upstream/'test/api').mkdir(parents=True)
        for name in ('first','second'):(upstream/'test/api'/(name+'.c')).write_text('/* mock */')
        self.tests=[{'name':name,'suite':['harfbuzz:api']} for name in ('first','second')]
        self.write_tests()
        bindir=self.root/'bin';bindir.mkdir()
        node=bindir/'node'
        node.write_text('#!'+sys.executable+'''\nimport pathlib,sys,json
args=sys.argv
work=pathlib.Path(args[next(i for i,a in enumerate(args) if a.endswith('build-api-tests.mjs'))+1]);target=args[args.index('--target')+1]
report=work/args[args.index('--report')+1]
report.write_text(json.dumps([{'name':target,'status':'BUILT'}]))
with (work/'mock-builds').open('a') as f:f.write(target+'\\n')
''');node.chmod(0o755)
        command=[sys.executable,str(APP/'build-upstream-tests.py'),str(self.work),str(upstream),str(self.native),
                 '--only','c','--resume','--max-targets','1','--budget-seconds','5','--timeout','1']
        env={**os.environ,'PATH':str(bindir)+os.pathsep+os.environ['PATH']}
        for index in range(3):
            r=subprocess.run(command,env=env,capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,0,r.stderr)
            progress=json.loads((self.work/'isolated-build/progress.json').read_text())
            self.assertEqual(progress['completed'],index+1)
            self.assertEqual(progress['complete'],index==2)
        subprocess.run(command,env=env,check=True,stdout=subprocess.DEVNULL,timeout=15)
        self.assertEqual((self.work/'mock-builds').read_text().splitlines(),['first','second','test-vector-budget'])

if __name__=='__main__':unittest.main()
