/* Ordinary C consumer of the unchanged upstream public headers. */
#include "upstream/src/hb.h"
#include "upstream/src/hb-ot.h"
#include "cases.h"

int shape_case(unsigned index, int *result, unsigned capacity) {
  const struct shape_input *input = &shape_inputs[index];
  hb_blob_t *blob = hb_blob_create((const char *)input->font, input->font_size,
                                  HB_MEMORY_MODE_READONLY, 0, 0);
  hb_face_t *face = hb_face_create(blob, 0);
  hb_font_t *font = hb_font_create(face);
  hb_buffer_t *buffer = hb_buffer_create();
  unsigned upem = hb_face_get_upem(face);
  hb_font_set_scale(font, upem, upem);
  hb_ot_font_set_funcs(font);
  hb_buffer_add_utf32(buffer, input->text, input->text_length, 0, input->text_length);
  hb_buffer_guess_segment_properties(buffer);
  hb_feature_t feature;
  unsigned count = 0;
  if (input->feature[0]) {
    if (!hb_feature_from_string(input->feature, -1, &feature)) return -1;
    count = 1;
  }
  hb_shape(font, buffer, count ? &feature : 0, count);
  unsigned length;
  hb_glyph_info_t *info = hb_buffer_get_glyph_infos(buffer, &length);
  hb_glyph_position_t *position = hb_buffer_get_glyph_positions(buffer, 0);
  if (!hb_buffer_allocation_successful(buffer) || length * 6 + 4 > capacity) return -2;
  result[0] = upem;
  result[1] = hb_buffer_get_direction(buffer);
  result[2] = hb_buffer_get_script(buffer);
  result[3] = length;
  for (unsigned i = 0; i < length; ++i) {
    result[4+i*6] = info[i].codepoint;
    result[5+i*6] = info[i].cluster;
    result[6+i*6] = position[i].x_advance;
    result[7+i*6] = position[i].y_advance;
    result[8+i*6] = position[i].x_offset;
    result[9+i*6] = position[i].y_offset;
  }
  hb_buffer_destroy(buffer);
  hb_font_destroy(font);
  hb_face_destroy(face);
  hb_blob_destroy(blob);
  return length * 6 + 4;
}
