#!/usr/bin/env python3
"""Exercise resumable execution with three already-built original HarfBuzz tests.

This is a batch-runner regression, not another complete upstream acceptance run.
Run inside one <=1800s machine-job. WORK must be new; prior binaries are read-only.
"""
import argparse, json, os, subprocess, sys
from pathlib import Path
APP = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('work', type=Path)
p.add_argument('translated', type=Path)
p.add_argument('native', type=Path)
a = p.parse_args()
if not os.environ.get('MACHINE_JOB_ID'):
    p.error('Run through machine-job with --timeout 1800')
w = a.work.resolve()
if w.exists():
    p.error('work must be new')
w.mkdir(parents=True)
command = [sys.executable, str(APP/'run-upstream.py'), str(w), str(a.native.resolve()),
           '--translated', str(a.translated.resolve()), '--suite', 'src', '--resume',
           '--max-tests', '1', '--budget-seconds', '90', '--timeout', '60']
previous = []
for index in range(3):
    subprocess.run(command, check=True, timeout=100)
    rows = json.loads((w/'upstream-results.json').read_text())
    assert len(rows) == index + 1 and rows[:-1] == previous
    assert rows[-1]['status'] == 'PASS'
    previous = rows
    coverage = json.loads((w/'upstream-coverage.json').read_text())
    assert not coverage['complete'] and not coverage['fullInventory']
print('PASS three original HarfBuzz entries across separate resumed batches:',
      ', '.join(r['name'] for r in previous))
