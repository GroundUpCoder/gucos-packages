#!/usr/bin/env python3
"""Execute each built upstream test in a fresh destination runtime process."""
import argparse,json,os,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('--timeout',type=int,default=600);args=p.parse_args()
w=args.work.resolve();rows=json.loads((w/'api-build.json').read_text());results=[]
for row in rows:
 for mode in ['true','false']:
  binary=w/'api'/f'{row["name"]}-{mode}.wasm'
  out={'name':row['name'],'nativeFunctions':mode=='true'};results.append(out)
  if not binary.exists():out['status']='BUILD_FAILED';out['error']=row.get('error',row['status']);continue
  env={**os.environ,**{k:v for k,v in row['env'].items() if not k.endswith('LIBRARY_PATH')}}
  start=time.monotonic()
  try:
   r=subprocess.run(['node','--experimental-wasm-jspi',str(HERE/'run-wasm.mjs'),str(binary),*row.get('args',[])],env=env,text=True,capture_output=True,timeout=args.timeout)
   out.update(status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
  except subprocess.TimeoutExpired as e:out.update(status='TIMEOUT',stderr=str(e))
  out['seconds']=time.monotonic()-start
  print(out['status'],row['name'],mode,flush=True)
  (w/'api-results.json').write_text(json.dumps(results,indent=2)+'\n')
(w/'api-results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['status']!='PASS' for r in results):raise SystemExit(1)
