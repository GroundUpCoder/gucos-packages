import {runCompilerScript} from '../../tools/compiler-context.mjs';
import {buildRuntime} from '../../tools/cpp-translator/build-runtime.mjs';
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';
const out=path.resolve(process.argv[2]);fs.mkdirSync(out,{recursive:true});
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});c.self=c;
for(const name of ['path','compiler','trampoline','objects','compile','compiler-driver'])runCompilerScript(fs.readFileSync(new URL('../../src/'+name+'.js',import.meta.url),'utf8'),c);
const files=new Proxy({},{get(_,name){if(typeof name!=='string')return;try{return fs.readFileSync(name,'utf8');}catch{return;}}});
const fail=s=>{process.stderr.write(s);};
for(const name of (process.argv.slice(3).length?process.argv.slice(3):['libiconv','gettext','pcre2','glib','zlib','cxx'])){
 if(name==='cxx'){
  const archive=buildRuntime(c);fs.writeFileSync(out+'/cxx.a',archive);console.log('cxx '+archive.length+' bytes');continue;
 }
 const dir=path.resolve('vendor/'+name),config=JSON.parse(fs.readFileSync(dir+'/lib.json','utf8'));
 if(name==='glib')config.sources=[...fs.readFileSync(dir+'/install.sh','utf8').matchAll(/^cc .* -c (\S+) -o /gm)].map(m=>m[1]);
 const project=c.project(config,dir,files),objects=[];
 for(const [i,source] of project.sources.entries()){
  try{objects.push({name:source,bytes:c.compileObject(files,source,project.includes,fail,project).bytes});}
  catch(error){throw Error(source+': '+error.message,{cause:error});}
  if(i%10===0)console.error(name+' '+i+'/'+project.sources.length);
 }
 const archive=c.WasmObjects.writeArchive(objects);fs.writeFileSync(out+'/'+name+'.a',archive);
 console.log(name+' '+archive.length+' bytes');
}
fs.writeFileSync(out+'/libc.a',c.buildLibc(fail).bytes);
