import {buildRuntime} from '../../tools/cpp-translator/build-runtime.mjs';
// Compile each original C++ test's generated C units, then link both backends.
import {runCompilerScript} from '../../tools/compiler-context.mjs';
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';
const work=path.resolve(process.argv[2]), translated=path.resolve(process.argv[3]);
const targets=new Set();let report='build-results.json',libcArchive=work+'/runtime/libc.a';
for(let i=4;i<process.argv.length;i++){
 if(process.argv[i]==='--target'&&process.argv[i+1])targets.add(process.argv[++i]);
 else if(process.argv[i]==='--report'&&process.argv[i+1])report=process.argv[++i];
 else if(process.argv[i]==='--libc'&&process.argv[i+1])libcArchive=path.resolve(process.argv[++i]);
 else throw Error('Expected --target NAME or --report FILE');
}
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});c.self=c;
for(const name of ['path','compiler','trampoline','objects','compile'])runCompilerScript(fs.readFileSync(new URL('../../src/'+name+'.js',import.meta.url),'utf8'),c);
fs.writeFileSync(work+'/runtime/cxx.a',buildRuntime(c));
const libraries=['world.a',...['cxx','glib','pcre2','gettext','libiconv','zlib','libc'].map(n=>'runtime/'+n+'.a')].map(name=>({name,bytes:fs.readFileSync(name==='runtime/libc.a'?libcArchive:work+'/'+name)}));
if(fs.existsSync(work+'/runtime/libcxx.a'))libraries.splice(1,0,{name:'runtime/libcxx.a',bytes:fs.readFileSync(work+'/runtime/libcxx.a')});
const rows=JSON.parse(fs.readFileSync(translated+'/translation-results.json','utf8'));
const results=[];
for(const row of rows){
 if(targets.size&&!targets.has(row.target))continue;
 const result={target:row.target,binary:row.binary,libcArchive,status:'PENDING'};results.push(result);
 try{
  if(row.status!=='TRANSLATED')throw Error('Source translation did not complete');
  const objects=[],startup=[],entries=new Set();
  for(const unit of row.units){
   const dir=path.dirname(unit.manifest),manifest=JSON.parse(fs.readFileSync(unit.manifest,'utf8'));
   for(const artifact of manifest.artifacts){
    const name=dir+'/'+artifact.path;
    const object={name,bytes:c.compileObject({[name]:fs.readFileSync(name,'utf8')},name,[],s=>{throw Error(s);}).bytes};
    ('constructorPriority' in artifact?startup:objects).push(object);
    if(['main','__main_argc_argv','__main_void','__original_main'].includes(artifact.original)||artifact.original.startsWith('_Z4main'))entries.add(artifact.symbol);
   }
  }
  if(entries.has('main'))for(const helper of ['__main_argc_argv','__main_void','__original_main'])entries.delete(helper);
  if(entries.size!==1)throw Error('Expected exactly one main, found '+[...entries]);
  const main=[...entries][0];let entry;
  if(main==='_Z4mainv')entry='unsigned int _Z4mainv(void);int main(void){return _Z4mainv();}';
  else if(main==='_Z4mainiPPc')entry='unsigned int _Z4mainiPPc(unsigned int,void *);int main(int n,char **v){return _Z4mainiPPc(n,v);}';
  else if(main==='__main_argc_argv')entry='unsigned int __main_argc_argv(unsigned int,void *);int main(int n,char **v){return __main_argc_argv(n,v);}';
  else if(['__main_void','__original_main'].includes(main))entry='unsigned int '+main+'(void);int main(void){return '+main+'();}';
  else if(main!=='main')throw Error('Unsupported main signature '+main);
  if(entry)startup.push({name:'entry.c',bytes:c.compileObject({'/entry.c':entry},'/entry.c').bytes});
  const archive={name:row.target+'.a',bytes:c.WasmObjects.writeArchive(objects)};
  for(const nativeFunctions of [true,false]){
   const linked=c.linkProgram(startup,[archive,...libraries],s=>{throw Error(s);},{libcArchive:libraries.at(-1).bytes,compilerOptions:{nativeFunctions}});
   const filename=translated+'/binaries/'+row.target+'-'+nativeFunctions+'.wasm';
   fs.mkdirSync(path.dirname(filename),{recursive:true});fs.writeFileSync(filename,linked.bytes);
  }
  result.status='BUILT';console.log('BUILT '+row.target);
 }catch(error){result.status='BUILD_FAILED';result.error=String(error);console.error(row.target+': '+error.message);}
 fs.writeFileSync(translated+'/'+report,JSON.stringify(results,null,2)+'\n');
}
if(results.some(r=>r.status!=='BUILT'))process.exitCode=1;
