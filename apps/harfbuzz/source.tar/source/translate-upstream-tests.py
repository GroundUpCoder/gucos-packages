#!/usr/bin/env python3
"""Translate original C++ test translation units selected by Meson metadata.

Run inside machine-job. The metadata selects the upstream sources and test
macros; destination include paths and explicit libc adapters select the ABI.
No test source rewriting or test-result substitution is performed.
"""
import argparse, json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('work', type=Path)
p.add_argument('native', type=Path)
p.add_argument('--target', action='append', default=[])
a = p.parse_args()
w = a.work.resolve(); native = a.native.resolve()
w.mkdir(parents=True, exist_ok=True)
sdk = ROOT/'test-results/cpp-translator/toolchains/wasi-sysroot-30.0/include/wasm32-wasi'
tests = json.loads((native/'meson-info/intro-tests.json').read_text())
tests = [t for t in tests if any(s=='harfbuzz' or s.startswith('harfbuzz:') for s in t['suite'])]
executables = {arg for t in tests for arg in t['cmd']}
targets = json.loads((native/'meson-info/intro-targets.json').read_text())
results = []
for target in targets:
    if target.get('subproject'): continue
    if not (any(f in executables for f in target['filename']) or target['name'] in ['hb-shape','hb-subset','hb-vector']): continue
    if a.target and target['name'] not in a.target: continue
    groups = [g for g in target['target_sources'] if g.get('language') == 'cpp']
    if not groups: continue
    # Relative binary paths distinguish src/test-ot-tag from test/api/test-ot-tag.
    key = str(Path(target['filename'][0]).relative_to(native))
    out = w/key; out.mkdir(parents=True, exist_ok=True)
    row = {'target': key, 'binary': target['filename'][0], 'units': [], 'status': 'PENDING'}
    results.append(row)
    for group in groups:
        flags = [x for x in group['parameters'] if x.startswith(('-D','-U')) and x != '-DHAVE_CONFIG_H']
        flags += ['-DHB_NO_FEATURES_H','-DHAVE_GLIB=1','-DHAVE_STDBOOL_H=1','-D_WASI_EMULATED_SIGNAL','-DZLIB_NO_REQUIRE_SOURCES']
        for number, source in enumerate(group['sources']):
            source = Path(source)
            unit = out/str(number)
            api = out/'api.h'
            api.write_text('#include "'+str(ROOT/'apps/harfbuzz/world-api.h')+'"\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <math.h>\n#include <locale.h>\n#include <unistd.h>\n')
            if key.startswith('test/fuzzing/'):
                with api.open('a') as header:header.write('int LLVMFuzzerTestOneInput(const unsigned char *, size_t);\n')
            command = [sys.executable, str(ROOT/'tools/cpp-translator/translate.py'), 'translate', str(source),
                '--unit-key', 'harfbuzz/'+key+'/'+source.name, '--wasi-libc', '--api-header', str(api),
                '--ir-output', str(out/(str(number)+'.ll')), '-o', str(unit)]
            for flag in flags: command += ['--clang-arg='+flag]
            for inc in [source.parent, ROOT/'apps/harfbuzz/upstream/src', ROOT/'vendor/glib', ROOT/'vendor/glib/glib', ROOT/'vendor/zlib/src', sdk/'c++/v1', sdk]:
                command += ['--clang-arg=-I'+str(inc)]
            log = out/(str(number)+'.log')
            with log.open('w') as stream:
                result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
            row['units'].append({'source':str(source),'manifest':str(unit/'manifest.json'),'returncode':result.returncode,'log':str(log),'command':command})
            print(key, source.name, result.returncode, flush=True)
            if result.returncode: break
        if any(u['returncode'] for u in row['units']): break
    row['status'] = 'FAILED' if any(u['returncode'] for u in row['units']) else 'TRANSLATED'
    (w/'translation-results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['status'] != 'TRANSLATED' for r in results): raise SystemExit(1)
