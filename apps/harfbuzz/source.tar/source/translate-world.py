#!/usr/bin/env python3
"""Produce the unrestricted combined library from source, inside machine-job."""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('work', type=Path, help='Fresh output directory')
p.add_argument('--sdk', type=Path, default=ROOT/'test-results/cpp-translator/toolchains/wasi-sysroot-30.0/include/wasm32-wasi')
a = p.parse_args()
w = a.work.resolve()
w.mkdir(parents=True, exist_ok=True)
command = [sys.executable, str(ROOT/'tools/cpp-translator/translate.py'),
    'translate', str(ROOT/'apps/harfbuzz/world.cpp'),
    '--unit-key', 'harfbuzz/world.cc', '--wasi-libc',
    '--api-header', str(ROOT/'apps/harfbuzz/world-api.h'),
    '--ir-output', str(w/'world.ll'), '-o', str(w/'world'),
    '--clang-arg=-D_WASI_EMULATED_SIGNAL', '--clang-arg=-DZLIB_NO_REQUIRE_SOURCES']
for include in [ROOT/'vendor/glib', ROOT/'vendor/glib/glib', ROOT/'vendor/zlib/src',
                a.sdk.resolve()/'c++/v1', a.sdk.resolve()]:
    command.append('--clang-arg=-I'+str(include))
subprocess.run(command, check=True, cwd=ROOT)
