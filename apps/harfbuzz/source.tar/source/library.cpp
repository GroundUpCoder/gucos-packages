// Include libc++ before HB_TINY installs its private errno macro.
#include <functional>
#define HB_CONFIG_OVERRIDE_H "../../translation-config.h"
#include "upstream/src/harfbuzz.cc"
