// Exercise actual shared-memory workers before trusting upstream pthread tests.
import {runCompilerScript} from '../../tools/compiler-context.mjs';
import {executeTest} from './run-test-worker.mjs';
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {execFileSync} from 'node:child_process';
const work=fs.mkdtempSync(path.resolve('test-results/hb-node-threads-'));
const source=`#include <pthread.h>
#include <errno.h>
#include <stdio.h>
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t ready=PTHREAD_COND_INITIALIZER;
static int go,count;
static void *worker(void *arg){int id=(int)(long)arg;errno=id;
 pthread_mutex_lock(&lock);while(!go)pthread_cond_wait(&ready,&lock);pthread_mutex_unlock(&lock);
 for(int i=0;i<1000;i++){pthread_mutex_lock(&lock);count++;pthread_mutex_unlock(&lock);}
 return (void *)(long)(errno==id?id:-1);
}
int main(void){pthread_t threads[4];errno=77;
 for(int i=0;i<4;i++)if(pthread_create(&threads[i],0,worker,(void *)(long)(i+1)))return 1;
 pthread_mutex_lock(&lock);go=1;pthread_cond_broadcast(&ready);pthread_mutex_unlock(&lock);
 for(int i=0;i<4;i++){void *v=0;if(pthread_join(threads[i],&v)||(long)v!=i+1)return 2;}
 if(count!=4000||errno!=77)return 3;printf("counter=%d threads=4 errno=77\\n",count);return 0;}
`;
try{
 fs.writeFileSync(work+'/main.c',source);execFileSync('clang',['-O2','-pthread',work+'/main.c','-o',work+'/native']);
 const env={...process.env,DYLD_INSERT_LIBRARIES:path.resolve('test-results/cpp-translator/harfbuzz/acceptance-final/libnocrash.dylib')};
 const expected=execFileSync(work+'/native',{encoding:'utf8',env,timeout:600000});
 const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});c.self=c;
 for(const n of ['path','compiler','trampoline','objects','compile'])runCompilerScript(fs.readFileSync('src/'+n+'.js','utf8'),c);
 for(const nativeFunctions of [true,false]){
  const result=c.compile({'/main.c':source},['/main.c'],[],s=>{throw Error(s);},{compilerOptions:{nativeFunctions}});
  fs.writeFileSync(work+'/threads.wasm',result.bytes);
  const actual=await executeTest(work+'/threads.wasm');
  if(actual.status!=='PASS'||actual.stdout!==expected)throw Error(JSON.stringify({nativeFunctions,expected,actual}));
 }
 console.log('PASS native Clang and both destination backends: four real workers, mutex, condition variable, join values, errno isolation');
}finally{fs.rmSync(work,{recursive:true,force:true});}
