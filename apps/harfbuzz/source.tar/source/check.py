#!/usr/bin/env python3
"""Translate the actual HB_TINY library and execute upstream shaping cases."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import struct
import sys
import tarfile
import tempfile
import urllib.request

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'test-results/cpp-translator'
TRANSLATOR=ROOT/'tools/cpp-translator/translate.py'
CLANG=os.environ.get('CLANG','clang')
SDK_URL='https://github.com/WebAssembly/wasi-sdk/releases/download/wasi-sdk-30/wasi-sysroot-30.0.tar.gz'
SDK_HASH='0c8f3e0acab6d3061834395a16550c359766909fda046af3d9b8cf3bfdb1c2cc'
ROOTS=['hb_blob_create','hb_blob_destroy','hb_face_create','hb_face_destroy','hb_face_get_upem',
       'hb_font_create','hb_font_destroy','hb_font_set_scale','hb_ot_font_set_funcs',
       'hb_buffer_create','hb_buffer_destroy','hb_buffer_add_utf32','hb_buffer_guess_segment_properties',
       'hb_buffer_get_direction','hb_buffer_get_script','hb_buffer_get_glyph_infos',
       'hb_buffer_get_glyph_positions','hb_buffer_allocation_successful','hb_feature_from_string','hb_shape']


def require(condition,message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args,env=None,stderr_path=None):
    if stderr_path:
        with stderr_path.open('w') as log:
            result=subprocess.run([str(x) for x in args],text=True,stdout=subprocess.PIPE,stderr=log,env=env)
        error=stderr_path.read_text()[-12000:] if result.returncode else ''
    else:
        result=subprocess.run([str(x) for x in args],text=True,capture_output=True,env=env)
        error=result.stderr
    if result.returncode:
        raise RuntimeError('Command failed: '+str(args)+'\n'+result.stdout+error)
    return result.stdout


def inputs():
    paths=[*HERE.rglob('*'),*(ROOT/'tools/cpp-translator').rglob('*.py'),*(ROOT/'tools/cpp-translator').glob('*.hpp'),
           *(ROOT/'src').glob('*.js'),*(ROOT/'libc').rglob('*'),ROOT/'tools/compiler-context.mjs',
           ROOT/'docs/research/compiler-hardening/harness/host-shim/nocrash.c']
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(set(paths)) if p.is_file() and '__pycache__' not in p.parts}


def headers(work):
    archive=BASE/'toolchains/wasi-sysroot-30.0.tar.gz'
    archive.parent.mkdir(parents=True,exist_ok=True)
    if not archive.exists():
        download=work/'sysroot-download.tar.gz'
        urllib.request.urlretrieve(SDK_URL,download)
        require(sha(download)==SDK_HASH,'SDK download digest mismatch')
        download.replace(archive)
    require(sha(archive)==SDK_HASH,'SDK archive digest mismatch')
    with tarfile.open(archive) as tar:
        tar.extractall(work/'toolchain',filter='data')
    return work/'toolchain/wasi-sysroot-30.0/include/wasm32-wasi'


def case_header(cases,work):
    lines=['struct shape_input {const unsigned char *font; unsigned font_size; const unsigned int *text; unsigned text_length; const char *feature;};']
    names={}
    for case in cases:
        if case['font'] not in names:
            name='font_'+str(len(names));names[case['font']]=name
            data=(HERE/'tests'/case['font']).read_bytes()
            lines.append('static const unsigned char '+name+'[] = {'+','.join(str(b) for b in data)+'};')
    for i,case in enumerate(cases):
        lines.append('static const unsigned int text_'+str(i)+'[] = {'+','.join(str(x)+'U' for x in case['codepoints'])+'};')
    lines.append('static const struct shape_input shape_inputs[] = {')
    for i,case in enumerate(cases):
        name=names[case['font']]
        lines.append('{'+name+',sizeof('+name+'),text_'+str(i)+','+str(len(case['codepoints']))+','+json.dumps(case['features'])+'},')
    lines.append('};')
    (work/'cases.h').write_text('\n'.join(lines)+'\n')


def glyph_names(font):
    """Read post v2 names from the pinned fixture, independently of shaping."""
    data=font.read_bytes()
    u16=lambda p: struct.unpack_from('>H',data,p)[0]
    u32=lambda p: struct.unpack_from('>I',data,p)[0]
    tables={data[p:p+4]:u32(p+8) for p in range(12,12+16*u16(4),16)}
    require(b'post' in tables,'Named expected glyphs require a post table')
    start=tables[b'post']
    require(u32(start)==0x20000,'Fixture requires post version 2')
    standard=re.findall(r'HB_STR\("([^"\n]+)"\)',(HERE/'upstream/src/hb-ot-post-macroman.hh').read_text())
    require(len(standard)==258,'Unexpected upstream standard glyph names')
    count=u16(start+32)
    indices=[u16(start+34+2*i) for i in range(count)]
    cursor=start+34+2*count
    names=list(standard)
    for _ in range(max(indices,default=257)+1-258):
        length=data[cursor];cursor+=1
        names.append(data[cursor:cursor+length].decode('ascii'));cursor+=length
    return {names[index]:gid for gid,index in enumerate(indices)}


def upstream_check(case,result):
    require(len(result)>=4 and len(result)==4+6*result[3],case['name']+': incomplete glyph records')
    names=None
    rows=[]
    for token in case['expected'][1:-1].split('|'):
        m=re.fullmatch(r'([^=]+)=(\d+)(?:@(-?\d+),(-?\d+))?\+(-?\d+)(?:,(-?\d+))?',token)
        require(m is not None,'Unsupported upstream expected token '+token)
        if re.fullmatch(r'(?:gid)?\d+',m[1]):
            glyph=int(m[1].removeprefix('gid'))
        else:
            if names is None:
                names=glyph_names(HERE/'tests'/case['font'])
            require(m[1] in names,'Missing named glyph '+m[1])
            glyph=names[m[1]]
        rows.append([glyph,int(m[2]),int(m[5]),int(m[6] or 0),int(m[3] or 0),int(m[4] or 0)])
    require(result[3]==len(rows),case['name']+': upstream glyph count mismatch')
    for i,row in enumerate(rows):
        actual=result[4+6*i:10+6*i]
        require(actual==row,case['name']+': upstream expected mismatch '+str((actual,row)))


def main():
    require(sys.version_info >= (3,12),'Python 3.12+ required')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--translated',type=Path,help='Reuse a supplied manifest for debugging; omitted for end-to-end acceptance')
    parser.add_argument('--work',type=Path,help='Fresh directory for the generated C project, native oracle, objects and evidence')
    args=parser.parse_args()
    BASE.mkdir(parents=True,exist_ok=True)
    if args.work:
        args.work.mkdir(parents=True,exist_ok=False);work=args.work.resolve()
    else:
        work=Path(tempfile.mkdtemp(prefix='harfbuzz-acceptance-',dir=BASE))
    print('Work directory: '+str(work),flush=True)
    before=inputs();(work/'inputs.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
    provenance=json.loads((HERE/'provenance.json').read_text())
    for path,expected in provenance['files'].items():
        require(sha(HERE/'upstream'/path)==expected,'Changed upstream source '+path)
    data=json.loads((HERE/'tests/cases.json').read_text());cases=data['cases']
    for path,expected in data['files_sha256'].items():
        require(sha(HERE/'tests'/path)==expected,'Changed upstream font '+path)
    case_header(cases,work)
    oracle=work/'oracle.c'
    oracle.write_text('#include <stdio.h>\nint shape_case(unsigned,int *,unsigned);\nint main(void){int a[1540];'
        +'for(unsigned i=0;i<'+str(len(cases))+';++i){int n=shape_case(i,a,1540);if(n<0)return 1;'
        +'printf("%d",n);for(int j=0;j<n;++j)printf(" %d",a[j]);puts("");}return 0;}\n')
    shim=work/'libnocrash.dylib'
    run(CLANG,'-O1','-dynamiclib',ROOT/'docs/research/compiler-hardening/harness/host-shim/nocrash.c','-o',shim)
    oracle_env={**os.environ,'DYLD_INSERT_LIBRARIES':str(shim)}
    references=[]
    for opt in ['-O0','-O2']:
        run(CLANG,'-std=c11',opt,'-DHB_TINY','-I'+str(HERE),'-I'+str(work),'-c',HERE/'tests/driver.c','-o',work/'driver.o')
        run(CLANG,'-std=c11',opt,'-c',oracle,'-o',work/'oracle.o')
        run(CLANG,'-std=c++17',opt,'-fno-exceptions','-fno-rtti','-ffp-contract=off','-DHB_TINY',
            HERE/'library.cpp',work/'driver.o',work/'oracle.o','-o',work/'oracle')
        lines=run(work/'oracle',env=oracle_env).splitlines()
        results=[]
        for line in lines:
            row=list(map(int,line.split()));require(row[0]==len(row)-1,'Malformed native output');results.append(row[1:])
        require(len(results)==len(cases),'Missing native shaping cases')
        references.append(results)
    require(references[0]==references[1],'Native O0/O2 shaping disagreement')
    expected=references[0]
    for case,result in zip(cases,expected):
        upstream_check(case,result)
    (work/'native-shapes.json').write_text(json.dumps(expected,indent=2)+'\n')
    print('PASS native O0/O2 and seven upstream shaping cases',flush=True)
    checks=['int shape_case(unsigned,int *,unsigned);','int run_tests(void){int values[1540];']
    for i,row in enumerate(expected):
        checks.append(f'if(shape_case({i},values,1540)!={len(row)})return {(i+1)*1000};')
        for j,value in enumerate(row):
            checks.append(f'if(values[{j}]!={value})return {(i+1)*1000+j+1};')
    (work/'checks.c').write_text('\n'.join(checks+['return 0;}'])+'\n')
    if args.translated:
        manifest=args.translated.resolve()
    else:
        sdk=headers(work)
        out=work/'translated'
        print(run(sys.executable,TRANSLATOR,'translate',HERE/'library.cpp','--unit-key','harfbuzz/harfbuzz.cc',
                  '--ir-output',work/'harfbuzz.ll',
                  '--api-header',HERE/'translation-api.h','--clang',CLANG,'--clang-arg=-DHB_TINY',
                  '--clang-arg=-I'+str(sdk/'c++/v1'),'--clang-arg=-I'+str(sdk),'-o',out),end='',flush=True)
        manifest=out/'manifest.json'
    roots=[arg for name in ROOTS for arg in ['--root',name]]
    print(run(sys.executable,TRANSLATOR,'link',manifest,*roots,'-o',work/'project'),end='',flush=True)
    result=json.loads(run('node',HERE/'run-generated.mjs',work,stderr_path=work/'compile.log'))
    require(inputs()==before,'Source inputs changed during acceptance')
    report={'upstream_revision':provenance['revision'],'configuration':'HB_TINY with legacy support restored; C++17, exceptions/RTTI disabled',
            'frontend':run(CLANG,'--version').splitlines()[0],'sysroot_sha256':SDK_HASH,
            'reused_manifest':str(manifest) if args.translated else None,
            'input_manifest_sha256':sha(work/'inputs.json'),'native_shapes_sha256':sha(work/'native-shapes.json'),
            'cases':[c['name'] for c in cases],'values_compared_per_mode':sum(map(len,expected)),
            'generated':result}
    (work/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)


if __name__ == '__main__':
    main()
