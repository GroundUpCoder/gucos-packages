#!/usr/bin/env python3
"""Seeded direct native/translated comparisons using the real hb-shape batch API."""
import argparse, hashlib, json, os, random, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('work',type=Path);p.add_argument('upstream',type=Path)
p.add_argument('native',type=Path);p.add_argument('--cases',type=int,default=2048)
p.add_argument('--seed',type=int,default=20261003)
a=p.parse_args();w=a.work.resolve();u=a.upstream.resolve()
fonts=sorted(f for f in (u/'test/shape/data').rglob('*') if f.suffix.lower() in ['.ttf','.otf'])
if not fonts:raise SystemExit('No original upstream font fixtures')
rng=random.Random(a.seed)
scripts=[list(range(0x20,0x7f)),list(range(0x600,0x700)),list(range(0x900,0x980)),
         list(range(0x1000,0x10a0)),list(range(0x1780,0x1800)),list(range(0x300,0x370))]
requests=[]
for i in range(a.cases):
    font=fonts[i%len(fonts)] if i<len(fonts) else rng.choice(fonts)
    alphabet=rng.choice(scripts)
    points=[rng.choice(alphabet) for _ in range(rng.randrange(1,49))]
    args=[str(font),'--unicodes',','.join('U+%04X'%v for v in points),
          '--shaper=ot','--face-loader=ot','--font-funcs=ot','--output-format=json',
          '--cluster-level='+str(rng.randrange(3)),
          '--direction='+rng.choice(['ltr','rtl','ttb','btt']),
          '--features='+rng.choice(['kern=0','liga=0','kern=1,liga=1','']),
          '--font-size='+rng.choice(['1000','2048','17.5','997,1201'])]
    requests.append(args)
payload=''.join(';'.join(args)+'\n' for args in requests)
out=w/'differential-shape';out.mkdir(exist_ok=True)
(out/'requests.json').write_text(json.dumps({'seed':a.seed,'requests':requests},indent=2)+'\n')
env={**os.environ,'LC_ALL':'C'}
results=[];baseline=None
backends=[('native',a.native.resolve()/'util/hb-shape')]
for mode in ['true','false']:
    wrapper=w/('hb-shape-'+mode)
    if not wrapper.exists():wrapper=w/'upstream'/mode/'util/hb-shape'
    backends.append((mode,wrapper))
for name,binary in backends:
    result=subprocess.run([str(binary),'--batch'],input=payload,text=True,
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=600)
    (out/(name+'.stdout')).write_text(result.stdout)
    (out/(name+'.stderr')).write_text(result.stderr)
    lines=result.stdout.splitlines()
    if name=='native':baseline=lines
    mismatches=[i for i,(left,right) in enumerate(zip(baseline,lines)) if left!=right]
    row={'backend':name,'returncode':result.returncode,'lines':len(lines),
         'stdoutSHA256':hashlib.sha256(result.stdout.encode()).hexdigest(),
         'mismatches':mismatches,'status':'PASS' if result.returncode==0 and
         len(lines)==a.cases and not mismatches else 'FAIL'}
    results.append(row);print(json.dumps(row),flush=True)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['status']!='PASS' for r in results):sys.exit(1)
