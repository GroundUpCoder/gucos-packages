#!/usr/bin/env python3
"""Build and run the pinned, unmodified native Clang upstream suite (not translated C)."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import urllib.request

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def report(build, output):
    output.mkdir(parents=True,exist_ok=False)
    raw=build/'meson-logs/testlog.json'
    rows=[json.loads(line) for line in raw.read_text().splitlines()]
    tests=[]
    for row in rows:
        # Do not publish inherited environment variables from Meson's logs.
        item={k:row[k] for k in ['name','result','returncode','duration','command','stdout'] if k in row}
        item=json.loads(json.dumps(item).replace(str(ROOT),'$PROJECT'))
        item['project']='harfbuzz' if re.match(r'^harfbuzz(?::| /)',row['name']) else 'dependency'
        item['runner_summaries']=re.findall(r'^# \d+ tests passed;.*$',row.get('stdout',''),re.M)
        tests.append(item)
    summary={
        'scope':'Native Clang upstream suite only; no translated execution implied',
        'upstream':json.loads((HERE/'provenance.json').read_text())['revision'],
        'raw_testlog_sha256':sha(raw),
        'counts':{p:dict(Counter(t['result'] for t in tests if t['project']==p)) for p in ['harfbuzz','dependency']},
        'tests':[{k:v for k,v in t.items() if k not in ['stdout','command']} for t in tests],
    }
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (output/'test-results.json.gz').open('wb') as f:
        with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:
            z.write((json.dumps(tests,indent=2)+'\n').encode())
    for name in ['intro-buildoptions.json','intro-buildsystem_files.json','intro-dependencies.json','intro-tests.json']:
        path=build/'meson-info'/name
        if path.exists():
            (output/name).write_text(path.read_text().replace(str(ROOT),'$PROJECT'))
    print(json.dumps(summary['counts'],indent=2))
    return all(t['result'] in {'OK','SKIP'} for t in tests if t['project']=='harfbuzz')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work',type=Path)
    parser.add_argument('--report-existing',type=Path,help='Summarize an existing Meson build without running tests')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.report_existing:
        return 0 if report(args.report_existing.resolve(),args.output.resolve()) else 1
    if not args.work:
        parser.error('--work is required for a fresh run')
    if not os.environ.get('MACHINE_JOB_ID'):
        parser.error('Run through machine-job run --timeout 7200 -- python ...')
    work=args.work.resolve();work.mkdir(parents=True,exist_ok=False)
    provenance=json.loads((HERE/'provenance.json').read_text())
    archive=work/'upstream.tar.gz'
    urllib.request.urlretrieve(provenance['archive_url'],archive)
    if sha(archive)!=provenance['archive_sha256']:
        raise RuntimeError('Upstream archive digest mismatch')
    with tarfile.open(archive) as tar:tar.extractall(work,filter='data')
    source=work/('harfbuzz-'+provenance['revision'])
    build=work/'native'
    env={**os.environ,'CC':'clang','CXX':'clang++','PATH':str(Path(sys.executable).parent)+os.pathsep+os.environ['PATH']}
    commands=[]
    def run(command, name, check=True):
        commands.append(command)
        with (work/name).open('w') as log:
            result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if check and result.returncode:raise RuntimeError(f'{name} failed; see {work/name}')
        return result.returncode
    if sys.platform=='darwin':
        shim=work/'libnocrash.dylib'
        run(['clang','-O1','-dynamiclib',str(ROOT/'docs/research/compiler-hardening/harness/host-shim/nocrash.c'),'-o',str(shim)],'shim.log')
        env['DYLD_INSERT_LIBRARIES']=str(shim)
    run(['meson','setup',str(build),str(source),'--wrap-mode=default','-Dglib=enabled','-Ddocs=disabled','-Dintrospection=disabled','-Dgpu_demo=disabled','-Dbuildtype=debugoptimized'],'setup.log')
    run(['meson','compile','-C',str(build),'-j','2'],'compile.log')
    # Deliberately includes dependency suites. Report their failures separately,
    # but preserve Meson's nonzero exit status instead of hiding it.
    status=run(['meson','test','-C',str(build),'--no-rebuild','--num-processes','1','--timeout-multiplier','4','--print-errorlogs'],'tests.log',False)
    report(build,args.output.resolve())
    return status

if __name__=='__main__':sys.exit(main())
