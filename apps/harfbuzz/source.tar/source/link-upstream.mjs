import {buildRuntime} from '../../tools/cpp-translator/build-runtime.mjs';
import {runCompilerScript} from '../../tools/compiler-context.mjs';
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';
const work=path.resolve(process.argv[2]),program=process.argv[3]||'hb-shape';
const c=vm.createContext({console,TextEncoder,TextDecoder,performance,WebAssembly});c.self=c;
for(const name of ['path','compiler','trampoline','objects','compile'])runCompilerScript(fs.readFileSync(new URL('../../src/'+name+'.js',import.meta.url),'utf8'),c);
fs.writeFileSync(work+'/runtime/cxx.a',buildRuntime(c));
const libraries=[program+'.a','harfbuzz.a',...['cxx','glib','pcre2','gettext','libiconv','libc'].map(n=>'runtime/'+n+'.a')];
const objects=[];
for(const file of libraries){const list=work+'/'+file+'.startup.json';if(fs.existsSync(list))for(const name of JSON.parse(fs.readFileSync(list)))objects.push({name,bytes:fs.readFileSync(name)});}
const archives=libraries.map(name=>({name,bytes:fs.readFileSync(work+'/'+name)}));
// Current producer output includes a normal C main. Older saved freestanding
// IR can still be diagnosed with an explicit fourth-argument entry symbol.
if(process.argv[4]){
 const symbol=process.argv[4];if(!/^[A-Za-z_]\w*$/.test(symbol))throw Error('Invalid entry symbol');
 const entry=c.compileObject({'/entry.c':'unsigned int '+symbol+'(unsigned int,void *); int main(int n,char **v){return '+symbol+'(n,v);}'},'/entry.c');
 objects.push({name:'entry.o',bytes:entry.bytes});
}
for(const nativeFunctions of [true,false]){
 const result=c.linkProgram(objects,archives,s=>{throw Error(s);},{libcArchive:archives.at(-1).bytes,compilerOptions:{nativeFunctions}});
 fs.writeFileSync(work+'/'+program+'-'+nativeFunctions+'.wasm',result.bytes);
 console.log(program+' nativeFunctions='+nativeFunctions+' '+result.bytes.length+' bytes');
}
