"""Small persisted-batch helpers; admission stays with the outer machine-job."""
import hashlib, json, os, signal, subprocess, time
from pathlib import Path


def save_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def fresh_log(path):
    if not path.exists():
        return path
    attempt = 2
    while True:
        candidate = path.with_name(path.stem + f'.attempt-{attempt}' + path.suffix)
        if not candidate.exists():
            return candidate
        attempt += 1


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def check_selection(path, selection, resume):
    fingerprint = signature(selection)
    if path.exists():
        if not resume:
            raise SystemExit('Existing batch evidence: pass --resume or use a new work directory')
        if json.loads(path.read_text())['fingerprint'] != fingerprint:
            raise SystemExit('Batch selection changed; use a new work directory')
    else:
        save_json(path, {'fingerprint': fingerprint, 'selection': selection})


def stop_group(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()


def run_command(command, *, timeout, **kwargs):
    process = subprocess.Popen(command, start_new_session=True, **kwargs)
    def interrupted(signum, frame):
        stop_group(process)
        raise SystemExit(128 + signum)
    previous = {sig: signal.signal(sig, interrupted)
                for sig in (signal.SIGTERM, signal.SIGINT)}
    try:
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            stop_group(process)
            raise
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)


class Budget:
    def __init__(self, seconds, timeout, limit):
        if not (0 < timeout <= seconds - 3 and seconds <= 1500 and limit > 0):
            raise SystemExit('Require 0 < timeout <= budget - 3, budget <= 1500, and a positive batch limit')
        self.deadline = time.monotonic() + seconds
        self.timeout, self.limit, self.started = timeout, limit, 0

    def take(self):
        if self.started >= self.limit or time.monotonic() + self.timeout + 2 >= self.deadline:
            return False
        self.started += 1
        return True
