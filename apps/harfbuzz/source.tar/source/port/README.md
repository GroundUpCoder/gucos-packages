# HarfBuzz package preparation

This experimental package is undergoing gucman source and binary acceptance;
it is not an approved artifact. The first package exposes the C library API.
It does not yet install hb-shape/hb-subset executables or GObject bindings.

The world amalgamation includes shaping, subsetting, raster, vector, GPU and
GLib and FreeType support. All five pkg-config components link the same combined archive;
use `pkg-config --static --libs harfbuzz` (or harfbuzz-subset, etc.). The explicit
runtime adapter archive follows it. GLib, zlib and FreeType are declared dependencies.
No private copy of libc or GLib is installed. The recipe also builds libharfbuzz.so for shared-library consumers.

## Host preparation

The C++ frontend still runs on the host. Run `port/translate-package.py` with the pinned SDK through the build lane.
This translates the world amalgamation with its actual FreeType bridge enabled.
The earlier upstream-suite world build did not include that bridge and is not
sufficient for this package. Then, from the repository root:

```sh
machine-job run --kind build --timeout 1800 -- test-results/cpp-translator/venv/bin/python apps/harfbuzz/port/translate-package.py test-results/harfbuzz-package-world --sdk /absolute/path/to/wasi-sysroot-30.0/include/wasm32-wasi
python3 apps/harfbuzz/port/prepare.py test-results/harfbuzz-package-world
node tools/package-job.mjs run harfbuzz
```

The preparation step verifies every generated C file against the translator
manifest, copies public headers selected from upstream Meson, exports the real
C runtime adapters, and records hashes and translation provenance. It refuses
startup objects rather than silently dropping constructors. The output is
gitignored under `port/generated/`; preserve it with the candidate's immutable
input bundle. A clean checkout requires this explicit preparation before a
source build. It is not yet an end-to-end in-guest C++ build.

The guest recipe compiles C definitions in batches of 64 and creates each archive once,
avoiding repeated archive rewrites. The package test installs through gucman,
compiles a separate C consumer using installed headers and pkg-config, checks
upstream's AB contextual-shaping golden output, performs font subsetting and FreeType-backed shaping, and
checks repeat installation. It checks both shared and explicit static consumers. Both source and binary phases must pass before
promotion. Browser execution must use the package scheduler.

## Remaining acceptance work

- Execute source and binary package acceptance against approved dependencies.
- Check downstream static archive resolution and dependency metadata in the
  actual guest; Node upstream-suite results alone do not establish this.
- Preserve the upstream suite's three inspection skips and three uncovered
  protected-mapping subcases in any release report.
- Promote only an accepted candidate. This preparation does not change the
  active release or provide a published gucman artifact.

The version is the pinned source's 14.5.0 header version; the exact upstream
revision is recorded in `../provenance.json` and the prepared manifest.

## FreeType ABI boundary

`freetype-abi.c` calls the real `FT_Get_Paint`, passing its aggregate by value
using the destination C compiler. The translated caller passes a pointer through
an inline C++ adapter. This preserves FreeType paint behavior without pretending
that the two compilers use identical aggregate argument conventions.

FreeType's public configuration includes setjmp declarations even though hb-ft
never calls them. The frontend overlay reads the destination's real setjmp
header, suppressing only its compiler-specific source inclusion directives.
It does not enable WASI exceptions or supply a replacement setjmp implementation.
The combined translation keeps template definitions in one translation unit;
separately translating hb-ft produced different references to internal helpers
in shared template definitions, so those outputs are not combined by guesswork.

## Integration status, October 4

The first package attempt reached bundling but stopped before browser acceptance:
no approved libiconv artifact matched the local libc digest. The local translator
checkout also predated the wide-character libc changes on origin/main. The
integration branch now merges origin/main and regenerates the combined libc
manifest (digest 5840afc892633909f5eb83c41266d1885c6ad86e1b759df8983bcbe1148a9ad8).
Its scalbnf/runtime changes remain unpublished pending the separate platform
review; no old dependency artifact is relabeled as compatible. Required package
dependencies are being rebuilt and accepted on this exact integration baseline.


### Baseline correction

Inspection of the world and hb-ft manifests found no scalbnf dependency. That
function was required by the upstream hb-shape test utility, not this library
package. The integration now restores the exact released libc sources and
manifest digest 07305461a0c739e9692c18017bb66a3f3093cb2efa0d063364a0e2bcf87951f4.
The queued pkgconf rebuild was cancelled before testing. Matching approved
artifacts may now be reused normally; the separate scalbnf work is untouched.
GLib has a local source fix and its acceptance is being rerun. The earlier
5840afc8 baseline and failed attempts above are historical evidence, not the
current package baseline.
