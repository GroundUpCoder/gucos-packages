/* FreeType's public configuration includes setjmp even though hb-ft does not
 * use it. Use the destination declarations; do not enable WASI exceptions. */
#define __require_source(...)
#define __require_source_if(...)
#ifdef __cplusplus
extern "C" {
#endif
#include "../../../../libc/include/setjmp.h"
#ifdef __cplusplus
}
#endif
#undef __require_source
#undef __require_source_if
