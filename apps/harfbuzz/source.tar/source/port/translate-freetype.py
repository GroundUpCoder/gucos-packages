#!/usr/bin/env python3
"""Translate the original hb-ft.cc with a pointer adapter for FreeType paint ABI.
Run through machine-job --kind build. OUTPUT must be fresh.
"""
import argparse, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('output',type=Path)
p.add_argument('--sdk',required=True,type=Path)
a=p.parse_args()
cmd=[sys.executable,str(ROOT/'tools/cpp-translator/translate.py'),'translate',str(HERE/'freetype.cpp'),
 '--unit-key','harfbuzz/hb-ft.cc','--wasi-libc','--api-header',str(HERE/'freetype-api.h'),
 '-o',str(a.output.resolve())]
for inc in [HERE/'ft-headers',ROOT/'vendor/freetype/include',a.sdk/'c++/v1',a.sdk]:
 cmd.append('--clang-arg=-I'+str(inc.resolve()))
subprocess.run(cmd,cwd=ROOT,check=True)
