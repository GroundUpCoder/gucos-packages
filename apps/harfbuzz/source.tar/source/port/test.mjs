import assert from 'node:assert/strict';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('harfbuzz',1800000);
try {
  const r=await runCached(page,`set -e
gucman install harfbuzz
mkdir -p /tmp/harfbuzz-consumer
cd /tmp/harfbuzz-consumer
pkg-config --exists harfbuzz harfbuzz-subset harfbuzz-raster harfbuzz-vector harfbuzz-gpu
cc $(pkg-config --cflags harfbuzz-subset) /usr/src/harfbuzz/port/consumer.c $(pkg-config --static --libs harfbuzz-subset) -o consumer
./consumer /usr/src/harfbuzz/tests/fonts/a59fd13f1525a91cbe529c882e93d9d1fbb80463.ttf /usr/src/harfbuzz/port/fonts/ABeeZee-Regular.ttf
cc $(pkg-config --cflags harfbuzz-subset) /usr/src/harfbuzz/port/consumer.c /usr/local/lib/libharfbuzz.a /usr/local/lib/libharfbuzz-runtime.a $(pkg-config --static --libs glib-2.0 zlib freetype2) -o consumer-static
./consumer-static /usr/src/harfbuzz/tests/fonts/a59fd13f1525a91cbe529c882e93d9d1fbb80463.ttf /usr/src/harfbuzz/port/fonts/ABeeZee-Regular.ttf
gucman install harfbuzz
echo HARFBUZZ-PACKAGE-PASS
`,{packages:['harfbuzz'],fresh:['harfbuzz']});
  const log=await page.evaluate(()=>shell.busybox.log);
  assert.equal(r.code,0,log);
  assert.match(log,/HARFBUZZ-CONSUMER-PASS/);
  assert.match(log,/HARFBUZZ-PACKAGE-PASS/);
  assert.deepEqual(errors,[]);
} finally {await close();}
