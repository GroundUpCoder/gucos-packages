#!/usr/bin/env python3
"""Export verified translated C sources for the guest package recipe.

No prebuilt archive or host executable is installed by this step.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
APP = HERE.parent
ROOT = APP.parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('world', type=Path, help='generated/world directory from translate-world.py')
    args = parser.parse_args()
    world = args.world.resolve()
    raw = (world / 'manifest.json').read_bytes()
    manifest = json.loads(raw)
    if manifest['unitKey'] != 'harfbuzz/world.cc':
        raise ValueError('Expected the combined HarfBuzz world translation')
    if 'hb_ft_font_create' not in {a['symbol'] for a in manifest['artifacts']}:
        raise ValueError('Package requires translate-package.py output including FreeType')
    if any('constructorPriority' in a for a in manifest['artifacts']):
        raise ValueError('Startup objects require explicit consumer integration; refusing archive-only export')
    destination = HERE / 'generated'
    if destination.exists():
        raise FileExistsError('Preserve or remove the previous generated directory explicitly')
    temporary = Path(tempfile.mkdtemp(prefix='.prepare-', dir=HERE))
    try:
        (temporary / 'c').mkdir()
        (temporary / 'include').mkdir()
        checksums = {}
        build = ['#!/bin/sh', 'set -eu', 'stage=$1',
                 'rm -rf port/build', 'mkdir -p port/build', 'cd port/build']
        units = []
        for i, artifact in enumerate(manifest['artifacts']):
            source = (world / artifact['path']).resolve()
            if not source.is_relative_to(world):
                raise ValueError('Artifact escapes the generated source directory')
            data = source.read_bytes()
            if sha(data) != artifact['sha256']:
                raise ValueError('Artifact hash mismatch: ' + artifact['path'])
            target = 'c/' + str(i) + '.c'
            (temporary / target).write_bytes(data)
            checksums[target] = sha(data)
            units.append('../generated/' + target)
        for first in range(0, len(units), 64):
            build.append('cc -c ' + ' '.join(units[first:first + 64]))
        build += ['ar qcs "$stage/lib/libharfbuzz.a" [0-9]*.o']
        runtime = ROOT / 'tools/cpp-translator/runtime_abi.py'
        bridges = json.loads(subprocess.check_output([sys.executable, str(runtime)]))
        for i, (symbol, source) in enumerate(sorted(bridges.items())):
            target = f'c/runtime-{i}.c'
            data = source.encode()
            (temporary / target).write_bytes(data)
            checksums[target] = sha(data)
            build += [f'cc -c ../generated/{target} -o runtime-{i}.o']
        build += ['cc -I/usr/local/include/freetype2 -c ../freetype-abi.c -o runtime-ft.o',
                  'ar qcs "$stage/lib/libharfbuzz-runtime.a" runtime-*.o',
                  "printf '%s\\n' [0-9]*.o > link.rsp",
                  'cc -shared @link.rsp "$stage/lib/libharfbuzz-runtime.a" -lglib-2.0 -lpcre2-8 -lintl -liconv -lz -lfreetype -Wl,-soname,libharfbuzz.so -o "$stage/lib/libharfbuzz.so"',
                  'cd ../..', 'rm -rf port/build']
        meson = (APP / 'upstream/src/meson.build').read_text()
        headers = ['hb-version.h', 'hb-glib.h', 'hb-ft.h']
        for group in ['base', 'subset', 'raster', 'vector', 'gpu']:
            block = re.search(r'hb_' + group + r'_headers = (?:files\((.*?)\)|\[(.*?)\])', meson, re.S)
            if not block:
                raise ValueError('Missing upstream header group: ' + group)
            headers += re.findall(r"'([^']+)'", block.group(1) or block.group(2))
        for name in headers:
            data = (APP / 'upstream/src' / name).read_bytes()
            (temporary / 'include' / name).write_bytes(data)
            checksums['include/' + name] = sha(data)
        data = (APP / 'include/hb-features.h').read_bytes() + b'\n#define HB_HAS_FREETYPE 1\n'
        (temporary / 'include/hb-features.h').write_bytes(data)
        checksums['include/hb-features.h'] = sha(data)
        (temporary / 'build.sh').write_text('\n'.join(build) + '\n')
        checksums['build.sh'] = sha((temporary / 'build.sh').read_bytes())
        (temporary / 'manifest.json').write_bytes(raw)
        provenance = {
            'format': 1, 'status': 'prepared-not-package-accepted',
            'upstream': json.loads((APP / 'provenance.json').read_text())['revision'],
            'translationManifestSha256': sha(raw),
            'runtimeAdapterSha256': sha(runtime.read_bytes()),
            'profile': manifest['profile'], 'producer': manifest['producer'],
            'translationProvenance': manifest['provenance'],
            'files': checksums,
        }
        (temporary / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
        temporary.rename(destination)
        print(f'Prepared {len(manifest["artifacts"])} library definitions and {len(bridges)} runtime adapters')
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


if __name__ == '__main__':
    main()
