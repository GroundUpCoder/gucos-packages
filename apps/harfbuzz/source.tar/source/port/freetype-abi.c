#include "freetype-abi.h"
/* Cross the target C ABI with pointers; only the C compiler passes the
 * FreeType aggregate by value. No paint behavior is replaced here. */
FT_Bool wasm_posix_FT_Get_Paint(FT_Face face, const FT_OpaquePaint *opaque, FT_COLR_Paint *paint) {
  return FT_Get_Paint(face, *opaque, paint);
}
