#include <hb.h>
#include <hb-ot.h>
#include <hb-subset.h>
#include <hb-ft.h>
#include <stdio.h>

/* Golden output from upstream context-matching.tests, case 5. */
int main(int argc, char **argv) {
  if (argc != 3) return 1;
  hb_blob_t *blob = hb_blob_create_from_file_or_fail(argv[1]);
  if (!blob) return 2;
  hb_face_t *face = hb_face_create(blob, 0);
  hb_font_t *font = hb_font_create(face);
  hb_ot_font_set_funcs(font);
  unsigned upem = hb_face_get_upem(face);
  hb_font_set_scale(font, upem, upem);
  hb_buffer_t *buffer = hb_buffer_create();
  hb_buffer_add_utf8(buffer, "AB", 2, 0, 2);
  hb_buffer_guess_segment_properties(buffer);
  hb_shape(font, buffer, 0, 0);
  unsigned n;
  hb_glyph_info_t *info = hb_buffer_get_glyph_infos(buffer, &n);
  hb_glyph_position_t *pos = hb_buffer_get_glyph_positions(buffer, 0);
  if (!hb_buffer_allocation_successful(buffer) || n != 5) return 3;
  for (unsigned i = 0; i < n; ++i)
    if (info[i].codepoint != (i == 4 ? 5 : 4) ||
        info[i].cluster != (i == 4 ? 1 : 0) || pos[i].x_advance != 1366 ||
        pos[i].y_advance || pos[i].x_offset || pos[i].y_offset) return 4;
  hb_subset_input_t *input = hb_subset_input_create_or_fail();
  if (!input) return 5;
  hb_set_add(hb_subset_input_unicode_set(input), 'A');
  hb_set_add(hb_subset_input_unicode_set(input), 'B');
  hb_face_t *subset = hb_subset_or_fail(face, input);
  if (!subset || !hb_face_get_glyph_count(subset)) return 6;
  FT_Library ft;
  FT_Face ft_face;
  int error = FT_Init_FreeType(&ft);
  if (error) { printf("FT_Init_FreeType: %d\n", error); return 7; }
  error = FT_New_Face(ft, argv[2], 0, &ft_face);
  if (error) { printf("FT_New_Face: %d\n", error); return 7; }
  if (FT_Set_Char_Size(ft_face, 0, ft_face->units_per_EM * 64, 72, 72)) return 8;
  hb_font_t *ft_font = hb_ft_font_create_referenced(ft_face);
  if (!ft_font) return 9;
  hb_buffer_clear_contents(buffer);
  hb_buffer_add_utf8(buffer, "AB", 2, 0, 2);
  hb_buffer_guess_segment_properties(buffer);
  hb_shape(ft_font, buffer, 0, 0);
  info = hb_buffer_get_glyph_infos(buffer, &n);
  /* Native FreeType: ABeeZee A=1, B=9, upem=1000. */
  if (n != 2 || info[0].codepoint != 1 || info[1].codepoint != 9) return 10;
  pos = hb_buffer_get_glyph_positions(buffer, 0);
  for (unsigned i = 0; i < n; ++i)
    if (info[i].cluster != i || pos[i].x_advance <= 0) return 11;
  hb_font_destroy(ft_font);
  FT_Done_Face(ft_face);
  FT_Done_FreeType(ft);
  hb_face_destroy(subset);
  hb_subset_input_destroy(input);
  hb_buffer_destroy(buffer);
  hb_font_destroy(font);
  hb_face_destroy(face);
  hb_blob_destroy(blob);
  puts("HARFBUZZ-CONSUMER-PASS");
  return 0;
}
