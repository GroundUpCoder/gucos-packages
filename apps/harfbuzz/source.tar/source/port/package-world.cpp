#include <functional>
#include "freetype-abi.h"
static inline FT_Bool ft_get_paint_adapter(FT_Face face, FT_OpaquePaint opaque, FT_COLR_Paint *paint) {
  return wasm_posix_FT_Get_Paint(face, &opaque, paint);
}
#define FT_Get_Paint ft_get_paint_adapter
#define HB_HAS_FREETYPE 1
#define HAVE_FT_GET_TRANSFORM 1
#define HAVE_FT_GET_VAR_BLEND_COORDINATES 1
#define HAVE_FT_DONE_MM_VAR 1
#include "../world.cpp"
