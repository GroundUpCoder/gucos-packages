#!/usr/bin/env python3
"""Translate the combined package library, including the real FreeType bridge.
Run through machine-job --kind build. OUTPUT must be fresh.
"""
import argparse, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('output',type=Path)
p.add_argument('--sdk',required=True,type=Path)
a=p.parse_args()
cmd=[sys.executable,str(ROOT/'tools/cpp-translator/translate.py'),'translate',str(HERE/'package-world.cpp'),
 '--unit-key','harfbuzz/world.cc','--wasi-libc','--api-header',str(HERE/'package-api.h'),
 '-o',str(a.output.resolve()),'--clang-arg=-D_WASI_EMULATED_SIGNAL','--clang-arg=-DZLIB_NO_REQUIRE_SOURCES']
for inc in [HERE/'ft-headers',ROOT/'vendor/freetype/include',ROOT/'vendor/glib',ROOT/'vendor/glib/glib',ROOT/'vendor/zlib/src',a.sdk/'c++/v1',a.sdk]:
 cmd.append('--clang-arg=-I'+str(inc.resolve()))
subprocess.run(cmd,cwd=ROOT,check=True)
