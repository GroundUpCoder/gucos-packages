#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_COLOR_H
#ifdef __cplusplus
extern "C" {
#endif
FT_Bool wasm_posix_FT_Get_Paint(FT_Face face, const FT_OpaquePaint *opaque, FT_COLR_Paint *paint);
#ifdef __cplusplus
}
#endif
