# HarfBuzz C++ → LLVM → C acceptance

The full workflow below translates the unrestricted upstream world amalgamation
and executes the original configured test inventory. The smaller seven-case
HB_TINY smoke workflow is retained separately for quick checks.

This harness translates the actual upstream HarfBuzz amalgamation, then compiles
the selected generated C definitions into a wasm-posix archive and links it to an
ordinary C client using the original HarfBuzz headers. It exercises OpenType
shaping, including Arabic marks, Myanmar marks, Syriac stretching, Indic shaping,
contextual substitution and Latin kerning.

The pinned source is HarfBuzz revision
`a8dc5479c55c7e51c0e8d576ae379b5dbb4e8f67`. `provenance.json` records the archive
and every vendored source digest. `tests/cases.json` records the original upstream
test lines, font digests and expected results. Vendored sources are unchanged.
The upstream copyright and license are retained in `upstream/COPYING`.

## Original smoke-test configuration

`library.cpp` builds the upstream `harfbuzz.cc` amalgamation with `HB_TINY`, C++17,
exceptions and RTTI disabled. `translation-config.h` uses the upstream-supported
configuration override hook to restore legacy font support (including legacy
kerning); plain `HB_TINY` does not pass the selected legacy-kerning case.
Other tiny-profile exclusions remain, including AAT and variable-font support.
This does not establish full-feature HarfBuzz or exception support.

The wrapper preincludes `<functional>` before HarfBuzz's private errno macro is
installed. LLVM production uses the exact WASI SDK 30 libc/libc++ headers. Native
reference binaries use the host headers and the same source/configuration.

## Run the original smoke check

Install the translator's pinned Python dependency as described in
`../../tools/cpp-translator/README.md`, then:

```sh
node tools/libc-gates.mjs test-results/cpp-translator/venv/bin/python apps/harfbuzz/check.py
```

The harness retains its fresh work directory under `test-results/cpp-translator/`:

- Native O0/O2 reference binaries must agree and match seven upstream cases.
  Named glyphs are resolved independently from the fixtures’ PostScript tables.
  Every glyph ID, cluster, advance and offset is checked. The complete native
  output becomes the differential oracle for generated code.
- Clang emits wasm32 LLVM IR; the translator emits independently compilable C
  definitions. The manifest resolver selects the dependencies of twenty public
  C entry points used by the test client.
- The generated definitions compile independently to objects and a real archive.
  The C driver calls HarfBuzz through the original public headers. Archive linking
  and execution run with native functions enabled and disabled.
- Every glyph, cluster, advance, offset, direction, script and UPEM value must
  match the native reference. Called unexpected host imports fail the test.
- Source hashes are captured before execution and checked again afterwards.
  `report.json`, `inputs.json`, `native-shapes.json`, raw IR, generated C, archive,
  Wasm binaries and compilation diagnostics remain in the work directory.

`--work PATH` chooses a fresh work directory. `--translated PATH/manifest.json`
reuses an existing translation for debugging and is explicitly marked in the
report; use a run without that option for end-to-end acceptance.

This is a translator acceptance workload, not a published browser package.
General build-system capture, installation of generated development headers,
additional HarfBuzz configurations and C++ exceptions remain separate work.

## Full upstream native baseline

The seven-case translated smoke test above is not the full upstream suite.
`upstream-suite.py` builds the full pinned source with native Clang and runs the
unmodified Meson tests, including GLib dependency tests. Install Meson 1.9.1 and
fonttools 4.60.1 in the Python environment and provide Ninja, then run:

```sh
machine-job run --kind build --lane wasm-posix --timeout 1800 -- test-results/cpp-translator/venv/bin/python \
  apps/harfbuzz/upstream-suite.py --work test-results/cpp-translator/harfbuzz/native-new \
  --output test-results/cpp-translator/harfbuzz/native-new-report
```

Both directories must be new. The script preserves Meson's failure status and
reports dependency failures separately. `--report-existing PATH --output PATH`
only summarizes existing results; it does not run tests. The initial full run
used the equivalent setup/compile/test commands directly; the report-only mode
was executed to preserve its results.

On October 3, the native baseline had 256 HarfBuzz tests pass, none fail, and the
symbol-export test skip. Subtest skips and absent optional backends still apply.
GLib had seven failing tests. The full translated inventory has also been executed; native-equivalent
coverage retains the gaps documented below. See `docs/research/cpp-translator/harfbuzz/upstream-native/` from the
repository root for exact configuration, results and limitations.

## Full translated upstream execution

The unrestricted combined library is `world.cpp`: core, subset, raster, vector,
GPU and GLib integration, with zlib enabled. It does not use `HB_TINY`. The
following tools use the original upstream test sources and Meson inventory:

- `translate-world.py WORK` produces fresh LLVM and generated C for the library.
- `tools/cpp-translator/compile-project.mjs GENERATED OUTPUT.a` compiles every
  definition and preserves constructor objects beside the archive for direct
  linking. An archive alone is insufficient when startup objects exist.
- `build-test-runtime.mjs WORK/runtime` builds the existing C dependency ports
  and the explicit C++ ABI facades.
- `build-api-tests.mjs WORK UPSTREAM NATIVE_BUILD` compiles original C tests.
  Use `--target NAME --report FILE --run` for isolated build/execute batches.
  Large combined runs exhausted Node's default heap; separate processes with
  `--max-old-space-size=6144` passed the previously failing subset link.
- `translate-upstream-tests.py OUTPUT NATIVE_BUILD` translates original C++
  test units; `--target NAME` restricts a debugging batch.
- `tools/cpp-translator/build-libcxx.py OUTPUT WORK/runtime/libcxx.a` produces
  shared libc++ string/hash template providers from the pinned SDK headers.
- `build-upstream-tests.py WORK UPSTREAM NATIVE_BUILD --translated OUTPUT`
  runs each test build in a separate compiler process and preserves reports.
  Add `--run-c` for immediate C API execution; the complete upstream runner
  below also executes C++ and script-driven suites.
- `build-cxx-tests.mjs WORK OUTPUT` compiles those C definitions and links both
  execution backends. It accepts `--target RELATIVE_BINARY --report FILE`
  so each large target can use a separate compiler process.
- `run-api-tests.mjs WORK` executes built C tests sequentially in isolated
  workers; its launch path is checked by `check-node-threads.mjs`. The Python
  `run-api-tests.py` retains a separate-process debugging path.
- `run-upstream.py WORK NATIVE_BUILD --translated OUTPUT` executes the original
  Meson test commands using translated executables. Repeat `--translated` for
  separate build batches. Missing binaries are failures, never native fallbacks.

Use the pinned Python environment for Python scripts, Node with
`--experimental-wasm-jspi` for execution, and `machine-job run --timeout N --`
around every heavy command. `WORK/world.a` and `WORK/runtime/*.a` are inputs to
the test builders. `UPSTREAM` is the complete pinned source tree extracted by
the native baseline workflow, not the smaller vendored source directory here.

The Node execution host uses the real runtime, filesystem and shared-memory
pthread workers. It does not implement fork/exec or shared descriptor tables
across workers. Three native subcases also require protected mappings that the
current platform rejects. The user accepted these platform exclusions on October 4;
their disposition is recorded in
`docs/research/cpp-translator/harfbuzz/runtime-abi/coverage-gaps.json` from the
repository root. The full runner reports this gap separately and returns a
failure status for actual test failures or unaccepted gaps. A completed passing run
reports SUPPORTED_SCOPE_PASS with these accepted exclusions retained and
nativeEquivalent=false. Historical run reports retain their original statuses. Current
destination GLib is the existing 2.84.4 port; the native baseline used 2.90.0.

The three original shaping suites have passed on both translated backends:
5,741 cases pass, zero fail and 137 skip per backend, matching the native
baseline counts and golden outputs. The fresh full inventory run completed 254 PASS, zero FAIL and three documented
SKIP per backend. All nine failures from the first full attempt are fixed. The
2,048 seeded native differential requests also match byte-for-byte. Native
coverage remains incomplete for the explicitly recorded gaps above. Complete
evidence is under `docs/research/cpp-translator/harfbuzz/runtime-abi/final-v4/`
from the repository root.

`differential-shape.py WORK UPSTREAM NATIVE_BUILD` additionally compares seeded
batch requests directly with native output. It preserves every request and
each backend's output and reports count discrepancies and mismatches as failures.
Prepared scripts are not evidence of execution; consult the recorded results.

For a fresh source-to-C build followed by all original selected Meson entries
and native differential requests, run ONE batch per reservation:

```sh
machine-job run --kind build --lane wasm-posix --timeout 1800 -- test-results/cpp-translator/venv/bin/python \
  apps/harfbuzz/translated-suite.py WORK UPSTREAM NATIVE_BUILD
```

WORK must be new for the first invocation. Repeat the same command after each
reservation finishes; it resumes the next unfinished stage or batch. Do not
wrap this in a submission loop. Keep at most one job queued/running; after
admission exit 75, wait and retry once, never in a loop. Use `--status` without
a reservation for a read-only progress report, including historical runs.

Each invocation performs one build stage, up to eight test-target builds, or up
to twenty upstream entries. Test batches use a 1,500-second internal budget,
reserve the full timeout before starting another child, and save each completed
target/test atomically. Stage watchdogs are capped at 1,650 seconds, leaving
cleanup time inside the outer 1,800-second reservation. Node compilers have a
6 GiB heap cap; runtime test wrappers have a 2 GiB cap. These are heap caps,
not requests to expand the machine scheduler's resource budget.

The driver rejects compiler/runtime/source/SDK/tool-version drift between
batches. Failed prerequisite retries require `--retry-failed` and retain their
previous output. Interrupted prerequisites can resume on the next invocation;
completed test entries are not repeated. Failed entries remain failures in the
record. The final coverage gaps still produce nonzero exit status even when
every runnable test passes. A successful partial invocation is only a completed
batch, not full-suite acceptance; inspect `batch-state.json`'s `complete` field.

Historical monolithic work directories remain intact and can be inspected with
`--status`; start a new directory for this batch protocol. The complete final-v4
results were produced before the batching change. The lightweight protocol
regression `python3 apps/harfbuzz/tests/test-batching.py` uses mock subprocesses
to check resume identities, input-selection rejection, timeout descendant
cleanup, log retention and limits. It is not additional HarfBuzz acceptance.
