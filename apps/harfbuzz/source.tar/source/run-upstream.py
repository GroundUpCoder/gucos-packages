#!/usr/bin/env python3
"""Run Meson's original HarfBuzz test commands against destination executables.

Missing translations are failures. Native executables are never fallback test
subjects. Build-inspection scripts receive the destination build directory.
"""
import argparse, collections, json, os, shlex, subprocess, sys, time
from batching import Budget, check_selection, fresh_log, run_command, save_json
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('native',type=Path)
p.add_argument('--suite',action='append',default=[]);p.add_argument('--timeout',type=float,default=600)
p.add_argument('--resume',action='store_true')
p.add_argument('--max-tests',type=int,default=20)
p.add_argument('--budget-seconds',type=float,default=1500)
p.add_argument('--translated',type=Path,action='append',default=[],help='Additional C++ build directories, searched before work/cxx')
a=p.parse_args();w=a.work.resolve();native=a.native.resolve()
tests=[t for t in json.loads((native/'meson-info/intro-tests.json').read_text()) if any(s=='harfbuzz' or s.startswith('harfbuzz:') for s in t['suite'])]
if a.suite:tests=[t for t in tests if any('harfbuzz:'+s in t['suite'] for s in a.suite)]
targets=json.loads((native/'meson-info/intro-targets.json').read_text())
executables={str(Path(f).relative_to(native)) for t in targets if t.get('type')=='executable' and not t.get('subproject') for f in t['filename']}
w.mkdir(parents=True,exist_ok=True)
budget=Budget(a.budget_seconds,a.timeout,a.max_tests)
check_selection(w/'upstream-selection.json',{'tests':tests,'native':str(native),'translated':[str(x.resolve()) for x in a.translated]},a.resume)
results=json.loads((w/'upstream-results.json').read_text()) if a.resume and (w/'upstream-results.json').exists() else []
if any('testIndex' not in r for r in results):raise SystemExit('Legacy results lack batch identities; preserve them and use a new work directory')
finished={(r['nativeFunctions'],r['testIndex']) for r in results}
for mode in ['true','false']:
 build=w/'upstream'/mode;build.mkdir(parents=True,exist_ok=True)
 def binary(key):
  choices=[directory.resolve()/'binaries'/(key+'-'+mode+'.wasm') for directory in a.translated]
  choices.append(w/'cxx/binaries'/(key+'-'+mode+'.wasm'))
  if key.startswith('test/api/'):choices.append(w/'api'/(Path(key).name+'-'+mode+'.wasm'))
  if key=='test/vector/test-vector-budget':choices.append(w/'api'/('test-vector-budget-'+mode+'.wasm'))
  if key=='util/hb-shape':choices.append(w/('hb-shape-'+mode+'.wasm'))
  found=next((f for f in choices if f.is_file()),None)
  if found is None:raise FileNotFoundError('No translated binary for '+key)
  wrapper=build/key;wrapper.parent.mkdir(parents=True,exist_ok=True)
  wrapper.write_text('#!/bin/sh\nexec node --max-old-space-size=2048 --experimental-wasm-jspi '+shlex.quote(str(HERE/'run-wasm.mjs'))+' '+shlex.quote(str(found))+' "$@"\n')
  wrapper.chmod(0o755);return str(wrapper)
 for index,test in enumerate(tests):
  if (mode=='true',index) in finished:continue
  if not budget.take():break
  row={'name':test['name'],'suite':test['suite'],'nativeFunctions':mode=='true','testIndex':index};results.append(row)
  start=time.monotonic();command=[]
  try:
   for arg in test['cmd']:
    key=arg[len(str(native))+1:] if arg.startswith(str(native)+'/') else arg
    if key in executables:command.append(binary(key))
    elif arg.startswith(str(native)+'/'):
     # Inspection scripts must inspect destination files, never native objects.
     destination=build/key;destination.parent.mkdir(parents=True,exist_ok=True)
     if (native/key).is_dir():destination.mkdir(parents=True,exist_ok=True)
     command.append(str(destination))
    else:command.append(arg)
   if command[0].endswith('.py'):command[:0]=[sys.executable,'-u']
   row['command']=command
   env={**os.environ,**{k:v for k,v in test['env'].items() if not k.endswith('LIBRARY_PATH')}}
   log=fresh_log(build/(str(index)+'-'+test['name']+'.log'));row['log']=str(log)
   cwd=test.get('workdir') or str(build)
   if cwd.startswith(str(native)):
    cwd=str(Path(str(build)+cwd[len(str(native)):]).resolve())
    Path(cwd).mkdir(parents=True,exist_ok=True)
   with log.open('w') as output:
    code=run_command(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=a.timeout)
   row.update(returncode=code,status={0:'PASS',77:'SKIP'}.get(code,'FAIL'))
  except FileNotFoundError as error:row.update(status='BUILD_FAILED',error=str(error))
  except subprocess.TimeoutExpired:row.update(status='TIMEOUT')
  row['seconds']=time.monotonic()-start
  print(row['status'],test['name'],mode,flush=True)
  save_json(w/'upstream-results.json',results)
gaps=json.loads((HERE.parents[1]/'docs/research/cpp-translator/harfbuzz/runtime-abi/coverage-gaps.json').read_text())
complete=len(results)==2*len(tests)
accepted=gaps.get('acceptedPlatformExclusions',False)
failed=any(r['status'] not in ['PASS','SKIP'] for r in results)
coverage={'status':('FAIL' if failed else 'SUPPORTED_SCOPE_PASS' if accepted else 'INCOMPLETE') if complete else 'PARTIAL','selectedMesonEntries':len(tests),'fullInventory':complete and not bool(a.suite),
          'complete':complete,'completedExecutions':len(results),'expectedExecutions':2*len(tests),
          'results':dict(collections.Counter(r['status'] for r in results)),
          'entrySkips':[{'name':r['name'],'nativeFunctions':r['nativeFunctions'],'log':r['log']} for r in results if r['status']=='SKIP'],
          'nativeOnlySubcases':gaps['nativeOnlySubcases'],
          'acceptedPlatformExclusions':accepted,'nativeEquivalent':False,
          'note':'Entry-level passes do not cover these native-only protected-mapping subcases.'}
save_json(w/'upstream-coverage.json',coverage)
if (complete and gaps['nativeOnlySubcases'] and not accepted) or failed:raise SystemExit(1)
