/* Feature configuration of the translated harfbuzz-world.cc library. */
#ifndef WASM_POSIX_HB_FEATURES_INCLUDED
#define WASM_POSIX_HB_FEATURES_INCLUDED
#define HB_HAS_GLIB 1
#define HB_HAS_SUBSET 1
#define HB_HAS_RASTER 1
#define HB_HAS_VECTOR 1
#define HB_HAS_GPU 1
#endif

#define HB_HAS_FREETYPE 1
