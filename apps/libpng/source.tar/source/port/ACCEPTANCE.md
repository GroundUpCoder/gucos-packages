# Independent libpng acceptance

Run `node tools/package-job.mjs run libpng`. Both isolated phases test installed
shared/static libraries against unchanged upstream v1.6.58 `pngtest.c` and its
`pngtest.png` fixture. Exact upstream URLs and SHA-256 digests are recorded and
checked in `port/upstream/ORIGIN.json`.

The installed consumer adapts the existing `test_main.c` fixture checker, adding
proper multi-pass interlace handling with `png_read_image`. It decodes nine
existing RGB/RGBA/grayscale/grayscale-alpha/palette/1-bit/gradient/interlace/large
fixtures, compares each pixel to its RGB oracle, writes each fixture and compares
its encoded bytes to the existing golden PNG, and reads the output again. Both
shared and static linking run the full fixture matrix. Invalid PNG input must be
rejected. Host pngjs independently decodes the guest-produced large PNG and checks
every pixel against the RGB oracle.

Test sources reside below port so quoted includes resolve only installed headers.
Binary acceptance receives only the declared consumers and fixtures; it restores
the exact candidate plus the approved zlib dependency without rebuilding packages.
