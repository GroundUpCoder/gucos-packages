import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';

const origin=JSON.parse(await readFile(new URL('upstream/ORIGIN.json',import.meta.url),'utf8'));
for(const [name,{sha256}] of Object.entries(origin.files))assert.equal(createHash('sha256').update(await readFile(new URL('upstream/'+name,import.meta.url))).digest('hex'),sha256);
const fixtures=['rgb_2x2','rgba_3x1','gray_4x1','graya_3x2','palette_2x2','bw_4x2','gradient_8x8','interlaced_8x8','large_64x64'];
const {page,errors,output,close}=await appBrowser('libpng',600000);
try {
 const result=await runCached(page,`set -e
gucman install libpng
mkdir -p /tmp/libpng-acceptance
cd /tmp/libpng-acceptance
test -f /usr/local/lib/libpng16.so
test -f /usr/local/lib/libpng16.a
cc /usr/src/libpng/port/upstream/pngtest.c -I/usr/local/include -lpng16 -lz -lm -o pngtest-shared
./pngtest-shared /usr/src/libpng/port/upstream/pngtest.png upstream-shared.png
cc -static /usr/src/libpng/port/upstream/pngtest.c -I/usr/local/include -lpng16 -lz -lm -o pngtest-static
./pngtest-static /usr/src/libpng/port/upstream/pngtest.png upstream-static.png
cc /usr/src/libpng/port/consumer.c -I/usr/local/include -lpng16 -lz -lm -o consumer-shared
cc -static /usr/src/libpng/port/consumer.c -I/usr/local/include -lpng16 -lz -lm -o consumer-static
for mode in shared static; do
 for name in ${fixtures.join(' ')}; do
  ./consumer-$mode read /usr/src/libpng/testdata/$name.png /usr/src/libpng/testdata/$name.rgb
  ./consumer-$mode write /usr/src/libpng/testdata/$name.rgb $name-$mode.png /usr/src/libpng/testdata/$name"_written.png"
  ./consumer-$mode read $name-$mode.png /usr/src/libpng/testdata/$name.rgb
 done
done
printf 'invalid png bytes' > invalid.png
if ./consumer-shared read invalid.png /usr/src/libpng/testdata/rgb_2x2.rgb; then exit 91; fi
base64 large_64x64-shared.png > /tmp/libpng-output.b64
gucman install libpng
echo LIBPNG-PACKAGE-PASS
`,{packages:['libpng'],fresh:['libpng']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.equal((log.match(/libpng passes test/g)||[]).length,2,log);
 assert.match(log,/LIBPNG-PACKAGE-PASS/);
 const bytes=Buffer.from(await page.evaluate(async()=>new TextDecoder().decode(await shell.busybox.read('/tmp/libpng-output.b64'))),'base64');
 await writeFile(output+'/large_64x64.png',bytes);
 const decoded=PNG.sync.read(bytes),reference=(await readFile(new URL('../testdata/large_64x64.rgb',import.meta.url),'utf8')).trim().split(/\s+/);
 assert.equal(decoded.width,Number(reference.shift()));assert.equal(decoded.height,Number(reference.shift()));
 const rgb=reference.flatMap(pixel=>pixel.split(',').map(Number));
 assert.equal(rgb.length,decoded.width*decoded.height*3);
 for(let i=0;i<decoded.width*decoded.height;i++)assert.deepEqual([...decoded.data.subarray(i*4,i*4+4)],[...rgb.slice(i*3,i*3+3),255]);
 assert.deepEqual(errors,[]);
 console.log('PASS libpng unchanged upstream shared/static pngtest, nine-format golden decode/encode consumers, invalid input and independent host pixel decode');
} finally {await close();}
