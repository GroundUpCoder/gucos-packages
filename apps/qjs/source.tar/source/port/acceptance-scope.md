# QuickJS acceptance scope and process-limit correction

The core, standard-library and worker tests are unchanged copies of the pinned
2025-09-13 release2 archive; upstream-tests.json records every hash. Fixtures
are injected as exact bytes because the legacy source filter omits JavaScript.
The initial missing-fixture and setup failures remain preserved, not accepted.

Five core suites passed before test_std stalled. A flushed diagnostic passed
printf, file1, file2, getline and popen, then stalled in test_os. The existing
libc sysconf(_SC_OPEN_MAX) returns -1 (indeterminate); QuickJS takes min(-1,1024)
and compares that signed result with unsigned i, attempting billions of closes.
The package correction maps a negative result to its existing1024 cap. It does
not reduce a known positive limit or introduce caching, preloading or a new
algorithm: the upstream capped close loop and constant work per descriptor
remain. No platform source or identity changes. Descriptor closing above the
existing upstream cap is not newly claimed.

The interactive REPL remains unavailable (empty precompiled bytecode stub).
Native bjson module, cyclic-import resolution case and full Test262 are outside
this selected acceptance. Full selected test results must be recorded separately;
this note does not predeclare a pass. Existing feature limits remain.
