import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {appBrowser} from '../../../tests/app-browser.mjs';
import {runCached} from '../../../tests/package-cache.mjs';
const {page,errors,close}=await appBrowser('qjs',1700000);
try {
 const fixtures=[];
 for(const name of await readdir(new URL('./upstream-tests/',import.meta.url)))
  fixtures.push([name,(await readFile(new URL('./upstream-tests/'+name,import.meta.url))).toString('base64')]);
 await page.evaluate(async fixtures=>{
  const made=await shell.command("sh -c 'mkdir -p /tmp/qjs-upstream'");
  if(made.code!==0)throw Error('fixture directory');
  for(const [name,data] of fixtures)
   await shell.busybox.write('/tmp/qjs-upstream/'+name,Uint8Array.from(atob(data),c=>c.charCodeAt(0)));
 },fixtures);
 const script=await readFile(new URL('./qjs-accept.sh',import.meta.url),'utf8');
 const result=await runCached(page,script,{packages:['qjs'],fresh:['qjs']});
 const log=await page.evaluate(()=>shell.busybox.log);
 assert.equal(result.code,0,log);
 assert.ok(log.includes('QJS-ACCEPTANCE-PASS'),log);
 assert.deepEqual(errors,[]);
} finally {await close();}
