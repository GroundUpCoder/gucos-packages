#ifndef __GDKCONFIG_H__
#define __GDKCONFIG_H__

#if !defined (__GDK_H_INSIDE__) && !defined (GDK_COMPILATION)
#error "Only <gdk/gdk.h> can be included directly."
#endif

#include <glib.h>

G_BEGIN_DECLS


/* GDK_WINDOWING_X11 disabled */
#define GDK_WINDOWING_X11 1
/* GDK_WINDOWING_WAYLAND disabled */
/* GDK_WINDOWING_WIN32 disabled */
/* GDK_WINDOWING_QUARTZ disabled */

G_END_DECLS

#endif  /* __GDKCONFIG_H__ */
