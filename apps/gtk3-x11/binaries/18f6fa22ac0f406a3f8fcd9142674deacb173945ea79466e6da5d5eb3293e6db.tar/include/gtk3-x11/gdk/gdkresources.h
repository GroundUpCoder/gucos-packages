/* The upstream GDK resource bundle contains only GL shaders.
 * This software-only build does not use those resources. */
static inline void _gdk_register_resource (void) {}
