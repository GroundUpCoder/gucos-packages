/* GTK3 on software X11: ordinary upstream widget and Cairo APIs. */
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <string.h>
#include <stdlib.h>

static GtkWidget *window,*label;
static unsigned clicks;
static gboolean test_mode;
static void clicked(GtkButton *button,gpointer data){
 char text[80];g_snprintf(text,sizeof text,"Button clicked %u times",++clicks);
 gtk_label_set_text(GTK_LABEL(label),text);gtk_window_resize(GTK_WINDOW(window),640,480);
 g_print("GTK-X11-CLICK %u\n",clicks);
}
static void changed(GtkEditable *editable,gpointer data){g_print("GTK-X11-TEXT %s\n",gtk_entry_get_text(GTK_ENTRY(editable)));}
static gboolean draw(GtkWidget *widget,cairo_t *cr,gpointer data){
 cairo_set_source_rgb(cr,0.1,0.25,0.6);cairo_paint(cr);
 cairo_set_source_rgb(cr,0.95,0.15,0.1);cairo_rectangle(cr,15,10,100,55);cairo_fill(cr);
 cairo_set_source_rgb(cr,1,1,1);cairo_set_line_width(cr,3);cairo_arc(cr,155,37,22,0,6.283185);cairo_stroke(cr);return FALSE;
}
static gboolean key(GtkWidget *widget,GdkEventKey *event,gpointer data){if(event->keyval==GDK_KEY_Escape){gtk_widget_destroy(widget);return TRUE;}return FALSE;}
static gboolean configured(GtkWidget *widget,GdkEventConfigure *event,gpointer data){g_print("GTK-X11-SIZE %d %d\n",event->width,event->height);return FALSE;}
static gboolean report(gpointer data){
 GtkWidget *button=g_object_get_data(G_OBJECT(window),"button"),*entry=g_object_get_data(G_OBJECT(window),"entry");
 GtkAllocation a;int x,y,ox,oy;GdkWindow *native=gtk_widget_get_window(window);
 gdk_window_get_origin(native,&ox,&oy);gdk_window_focus(native,GDK_CURRENT_TIME);
 gtk_widget_get_allocation(button,&a);gtk_widget_translate_coordinates(button,window,0,0,&x,&y);
 g_print("GTK-X11-BUTTON %d %d %d %d\n",ox+x,oy+y,a.width,a.height);
 gtk_widget_get_allocation(entry,&a);gtk_widget_translate_coordinates(entry,window,0,0,&x,&y);
 g_print("GTK-X11-ENTRY %d %d %d %d\n",ox+x,oy+y,a.width,a.height);
 GError *error=NULL;GdkGLContext *gl=gdk_window_create_gl_context(native,&error);
 g_assert_null(gl);g_assert_error(error,GDK_GL_ERROR,GDK_GL_ERROR_NOT_AVAILABLE);g_clear_error(&error);
 g_print("GTK-X11-READY\n");return G_SOURCE_REMOVE;
}
static gboolean timeout(gpointer data){g_printerr("GTK X11 input deadline\n");exit(1);return G_SOURCE_REMOVE;}
int main(int argc,char **argv){
 gboolean read_clipboard=argc>1&&!strcmp(argv[1],"--clipboard-read");test_mode=argc>1&&!strcmp(argv[1],"--test");
 if(test_mode)g_log_set_always_fatal(G_LOG_FATAL_MASK|G_LOG_LEVEL_CRITICAL);
 if(!gtk_init_check(&argc,&argv)){g_printerr("Start Xvfb and set DISPLAY before launching GTK X11.\n");return 1;}
 g_assert_true(GDK_IS_X11_DISPLAY(gdk_display_get_default()));
 if(read_clipboard){char *text=gtk_clipboard_wait_for_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD));g_assert_cmpstr(text,==,"GTK X11 clipboard café");g_free(text);g_print("GTK-X11-CLIPBOARD-PASS\n");return 0;}
 window=gtk_window_new(GTK_WINDOW_TOPLEVEL);gtk_window_set_title(GTK_WINDOW(window),"GTK 3 on software X11");gtk_window_set_default_size(GTK_WINDOW(window),500,380);gtk_window_move(GTK_WINDOW(window),20,20);
 GtkWidget *box=gtk_box_new(GTK_ORIENTATION_VERTICAL,10);gtk_container_set_border_width(GTK_CONTAINER(box),16);gtk_container_add(GTK_CONTAINER(window),box);
 label=gtk_label_new("GTK 3 on software X11 — Cairo rendering");gtk_box_pack_start(GTK_BOX(box),label,FALSE,FALSE,0);
 GtkWidget *button=gtk_button_new_with_label("Click to resize"),*entry=gtk_entry_new();gtk_entry_set_placeholder_text(GTK_ENTRY(entry),"Type here");
 gtk_box_pack_start(GTK_BOX(box),button,FALSE,FALSE,0);gtk_box_pack_start(GTK_BOX(box),entry,FALSE,FALSE,0);
 GtkWidget *drawing=gtk_drawing_area_new();gtk_widget_set_size_request(drawing,-1,80);gtk_box_pack_start(GTK_BOX(box),drawing,TRUE,TRUE,0);g_signal_connect(drawing,"draw",G_CALLBACK(draw),NULL);
 GtkListStore *store=gtk_list_store_new(2,G_TYPE_STRING,G_TYPE_STRING);GtkTreeIter iter;gtk_list_store_append(store,&iter);gtk_list_store_set(store,&iter,0,"Backend",1,"Upstream GDK X11",-1);gtk_list_store_append(store,&iter);gtk_list_store_set(store,&iter,0,"Rendering",1,"Cairo software",-1);
 GtkWidget *tree=gtk_tree_view_new_with_model(GTK_TREE_MODEL(store));gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree),-1,"Feature",gtk_cell_renderer_text_new(),"text",0,NULL);gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree),-1,"Implementation",gtk_cell_renderer_text_new(),"text",1,NULL);gtk_box_pack_start(GTK_BOX(box),tree,FALSE,FALSE,0);g_object_unref(store);
 g_object_set_data(G_OBJECT(window),"button",button);g_object_set_data(G_OBJECT(window),"entry",entry);
 g_signal_connect(button,"clicked",G_CALLBACK(clicked),NULL);g_signal_connect(entry,"changed",G_CALLBACK(changed),NULL);g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);g_signal_connect(window,"key-press-event",G_CALLBACK(key),NULL);g_signal_connect(window,"configure-event",G_CALLBACK(configured),NULL);
 gtk_clipboard_set_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD),"GTK X11 clipboard café",-1);
 gtk_widget_show_all(window);gtk_widget_grab_focus(entry);g_timeout_add(200,report,NULL);if(test_mode)g_timeout_add_seconds(90,timeout,NULL);
 gtk_main();g_print("GTK-X11-CLOSED\n");return 0;
}
