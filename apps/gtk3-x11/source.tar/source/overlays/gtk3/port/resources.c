#include <gio/gio.h>
void _gtk_register_resource(void) {
 GError *error=NULL;
 GResource *resource=g_resource_load("/usr/local/lib/gtk-3-x11/gtk.gresource",&error);
 if(!resource)g_error("GTK resources: %s",error->message);
 g_resources_register(resource);g_resource_unref(resource);
}
