#include "config.h"
#include "gdk/x11/gdkglcontext-x11.h"
#include "gdk/x11/gdkx11glcontext.h"
G_DEFINE_TYPE(GdkX11GLContext,gdk_x11_gl_context,GDK_TYPE_GL_CONTEXT)
static void gdk_x11_gl_context_class_init(GdkX11GLContextClass*c){}
static void gdk_x11_gl_context_init(GdkX11GLContext*c){}
gboolean gdk_x11_screen_init_gl(GdkScreen*s){return FALSE;}
void _gdk_x11_screen_update_visuals_for_gl(GdkScreen*s){}
gboolean gdk_x11_display_get_glx_version(GdkDisplay*d,gint*major,gint*minor){if(major)*major=0;if(minor)*minor=0;return FALSE;}
GdkGLContext *gdk_x11_window_create_gl_context(GdkWindow*w,gboolean attached,GdkGLContext*share,GError**error){g_set_error_literal(error,GDK_GL_ERROR,GDK_GL_ERROR_NOT_AVAILABLE,"This X11 profile uses Cairo software rendering");return NULL;}
void gdk_x11_window_invalidate_for_new_frame(GdkWindow*w,cairo_region_t*r){}
gboolean gdk_x11_display_make_gl_context_current(GdkDisplay*d,GdkGLContext*c){return c==NULL;}
