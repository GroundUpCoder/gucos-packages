/* Independent consumer of the installed GTK X11 SDK. */
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
int main(int argc,char **argv){
 if(!gtk_init_check(&argc,&argv))return 1;
 g_assert_true(GDK_IS_X11_DISPLAY(gdk_display_get_default()));
 GdkDisplay *display=gdk_display_get_default();
 GdkCursor *blank=gdk_cursor_new_from_name(display,"none");
 g_assert_nonnull(blank);
 g_assert_cmpint(gdk_cursor_get_cursor_type(blank),==,GDK_BLANK_CURSOR);
 g_assert_true(gdk_cursor_get_display(blank)==display);
 g_assert_cmpuint(gdk_x11_cursor_get_xcursor(blank),!=,0);
 guint refs=G_OBJECT(blank)->ref_count;
 GdkCursor *again=gdk_cursor_new_from_name(display,"none");
 g_assert_true(again==blank);
 g_assert_cmpuint(G_OBJECT(blank)->ref_count,==,refs+1);
 g_object_unref(again);
 g_assert_cmpuint(G_OBJECT(blank)->ref_count,==,refs);
 g_object_unref(blank);
 g_assert_null(gdk_cursor_new_from_name(display,"wasm-posix-unknown-cursor"));
 g_print("GTK-X11-BLANK-CURSOR-PASS\n");
 char *text=gtk_clipboard_wait_for_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD));
 g_assert_cmpstr(text,==,"GTK X11 clipboard café");g_free(text);
 g_print("GTK-X11-CLIPBOARD-PASS\n");return 0;
}
