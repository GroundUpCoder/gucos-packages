/* Independent consumer of all eight shared X11 client libraries. */
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xauth.h>
#include <X11/extensions/shape.h>
#include <X11/extensions/XTest.h>
#include <X11/extensions/Xrender.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/XInput2.h>
#include <xcb/xcb.h>
int main(void){
 assert(XauFileName());
 Display *d=XOpenDisplay(NULL);assert(d);
 int event,error,major=2,minor=0;
 assert(XShapeQueryExtension(d,&event,&error));
 assert(XTestQueryExtension(d,&event,&error,&major,&minor));
 assert(XRenderQueryVersion(d,&major,&minor));
 assert(XFixesQueryExtension(d,&event,&error));
 major=2;minor=0;assert(XIQueryVersion(d,&major,&minor)==Success);
 XRectangle rect={3,4,20,30};XserverRegion region=XFixesCreateRegion(d,&rect,1);
 int count=0;XRectangle *got=XFixesFetchRegion(d,region,&count);
 assert(got&&count==1&&got[0].x==3&&got[0].y==4&&got[0].width==20&&got[0].height==30);
 XFree(got);XFixesDestroyRegion(d,region);
 assert(XTestFakeMotionEvent(d,DefaultScreen(d),7,9,CurrentTime));XSync(d,False);
 Window root,child;int rx,ry,wx,wy;unsigned mask;
 assert(XQueryPointer(d,DefaultRootWindow(d),&root,&child,&rx,&ry,&wx,&wy,&mask));assert(rx==7&&ry==9);
 xcb_connection_t *c=xcb_connect(NULL,NULL);assert(c&&!xcb_connection_has_error(c));
 xcb_screen_t *screen=xcb_setup_roots_iterator(xcb_get_setup(c)).data;assert(screen);
 xcb_get_geometry_reply_t *geometry=xcb_get_geometry_reply(c,xcb_get_geometry(c,screen->root),NULL);
 assert(geometry&&geometry->width==800&&geometry->height==600);free(geometry);
 xcb_disconnect(c);XCloseDisplay(d);puts("X11-SHARED-SDK-PASS");return 0;
}
