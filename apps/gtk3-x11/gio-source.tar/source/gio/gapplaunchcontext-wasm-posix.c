/* GIO - GLib Input, Output and Streaming Library
 *
 * Copyright (C) 2006-2007 Red Hat, Inc.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Alexander Larsson <alexl@redhat.com>
 */

#include "config.h"
#include "gappinfo.h"
#include "glibintl.h"
#include "gmarshal-internal.h"
struct _GAppLaunchContextPrivate {
  char **envp;
};

typedef GAppInfoIface GAppInfoInterface;
G_DEFINE_INTERFACE (GAppInfo, g_app_info, G_TYPE_OBJECT)

static void
g_app_info_default_init (GAppInfoInterface *iface)
{
}

enum {
  LAUNCH_FAILED,
  LAUNCH_STARTED,
  LAUNCHED,
  LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

G_DEFINE_TYPE_WITH_PRIVATE (GAppLaunchContext, g_app_launch_context, G_TYPE_OBJECT)

/**
 * g_app_launch_context_new:
 * 
 * Creates a new application launch context. This is not normally used,
 * instead you instantiate a subclass of this, such as
 * [`GdkAppLaunchContext`](https://docs.gtk.org/gdk4/class.AppLaunchContext.html).
 *
 * Returns: a launch context.
 **/
GAppLaunchContext *
g_app_launch_context_new (void)
{
  return g_object_new (G_TYPE_APP_LAUNCH_CONTEXT, NULL);
}

static void
g_app_launch_context_finalize (GObject *object)
{
  GAppLaunchContext *context = G_APP_LAUNCH_CONTEXT (object);

  g_strfreev (context->priv->envp);

  G_OBJECT_CLASS (g_app_launch_context_parent_class)->finalize (object);
}

static void
g_app_launch_context_class_init (GAppLaunchContextClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = g_app_launch_context_finalize;

  /**
   * GAppLaunchContext::launch-failed:
   * @context: the object emitting the signal
   * @startup_notify_id: the startup notification id for the failed launch
   *
   * The [signal@Gio.AppLaunchContext::launch-failed] signal is emitted when a
   * [iface@Gio.AppInfo] launch fails. The startup notification id is provided,
   * so that the launcher can cancel the startup notification.
   *
   * Because a launch operation may involve spawning multiple instances of the
   * target application, you should expect this signal to be emitted multiple
   * times, one for each spawned instance.
   *
   * Since: 2.36
   */
  signals[LAUNCH_FAILED] = g_signal_new (I_("launch-failed"),
                                         G_OBJECT_CLASS_TYPE (object_class),
                                         G_SIGNAL_RUN_LAST,
                                         G_STRUCT_OFFSET (GAppLaunchContextClass, launch_failed),
                                         NULL, NULL, NULL,
                                         G_TYPE_NONE, 1, G_TYPE_STRING);

  /**
   * GAppLaunchContext::launch-started:
   * @context: the object emitting the signal
   * @info: the [iface@Gio.AppInfo] that is about to be launched
   * @platform_data: (nullable): additional platform-specific data for this launch
   *
   * The [signal@Gio.AppLaunchContext::launch-started] signal is emitted when a
   * [iface@Gio.AppInfo] is about to be launched. If non-null the
   * @platform_data is an GVariant dictionary mapping strings to variants
   * (ie `a{sv}`), which contains additional, platform-specific data about this
   * launch. On UNIX, at least the `startup-notification-id` keys will be
   * present.
   *
   * The value of the `startup-notification-id` key (type `s`) is a startup
   * notification ID corresponding to the format from the [startup-notification
   * specification](https://specifications.freedesktop.org/startup-notification-spec/startup-notification-0.1.txt).
   * It allows tracking the progress of the launchee through startup.
   *
   * It is guaranteed that this signal is followed by either a
   * [signal@Gio.AppLaunchContext::launched] or
   * [signal@Gio.AppLaunchContext::launch-failed] signal.
   *
   * Because a launch operation may involve spawning multiple instances of the
   * target application, you should expect this signal to be emitted multiple
   * times, one for each spawned instance.
   *
   * Since: 2.72
   */
  signals[LAUNCH_STARTED] = g_signal_new (I_("launch-started"),
                                          G_OBJECT_CLASS_TYPE (object_class),
                                          G_SIGNAL_RUN_LAST,
                                          G_STRUCT_OFFSET (GAppLaunchContextClass, launch_started),
                                          NULL, NULL,
                                          _g_cclosure_marshal_VOID__OBJECT_VARIANT,
                                          G_TYPE_NONE, 2,
                                          G_TYPE_APP_INFO, G_TYPE_VARIANT);
  g_signal_set_va_marshaller (signals[LAUNCH_STARTED],
                              G_TYPE_FROM_CLASS (klass),
                              _g_cclosure_marshal_VOID__OBJECT_VARIANTv);

  /**
   * GAppLaunchContext::launched:
   * @context: the object emitting the signal
   * @info: the [iface@Gio.AppInfo] that was just launched
   * @platform_data: additional platform-specific data for this launch
   *
   * The [signal@Gio.AppLaunchContext::launched] signal is emitted when a
   * [iface@Gio.AppInfo] is successfully launched.
   *
   * Because a launch operation may involve spawning multiple instances of the
   * target application, you should expect this signal to be emitted multiple
   * times, one time for each spawned instance.
   *
   * The @platform_data is an GVariant dictionary mapping
   * strings to variants (ie `a{sv}`), which contains additional,
   * platform-specific data about this launch. On UNIX, at least the
   * `pid` and `startup-notification-id` keys will be present.
   *
   * Since 2.72 the `pid` may be 0 if the process id wasn’t known (for
   * example if the process was launched via D-Bus). The `pid` may not be
   * set at all in subsequent releases.
   *
   * On Windows, `pid` is guaranteed to be valid only for the duration of the
   * [signal@Gio.AppLaunchContext::launched] signal emission; after the signal
   * is emitted, GLib will call [func@GLib.spawn_close_pid]. If you need to
   * keep the [alias@GLib.Pid] after the signal has been emitted, then you can
   * duplicate `pid` using `DuplicateHandle()`.
   *
   * Since: 2.36
   */
  signals[LAUNCHED] = g_signal_new (I_("launched"),
                                    G_OBJECT_CLASS_TYPE (object_class),
                                    G_SIGNAL_RUN_LAST,
                                    G_STRUCT_OFFSET (GAppLaunchContextClass, launched),
                                    NULL, NULL,
                                    _g_cclosure_marshal_VOID__OBJECT_VARIANT,
                                    G_TYPE_NONE, 2,
                                    G_TYPE_APP_INFO, G_TYPE_VARIANT);
  g_signal_set_va_marshaller (signals[LAUNCHED],
                              G_TYPE_FROM_CLASS (klass),
                              _g_cclosure_marshal_VOID__OBJECT_VARIANTv);
}

static void
g_app_launch_context_init (GAppLaunchContext *context)
{
  context->priv = g_app_launch_context_get_instance_private (context);
}

/**
 * g_app_launch_context_setenv:
 * @context: the launch context
 * @variable: (type filename): the environment variable to set
 * @value: (type filename): the value for to set the variable to.
 *
 * Arranges for @variable to be set to @value in the child’s environment when
 * @context is used to launch an application.
 *
 * Since: 2.32
 */
void
g_app_launch_context_setenv (GAppLaunchContext *context,
                             const char        *variable,
                             const char        *value)
{
  g_return_if_fail (G_IS_APP_LAUNCH_CONTEXT (context));
  g_return_if_fail (variable != NULL);
  g_return_if_fail (value != NULL);

  if (!context->priv->envp)
    context->priv->envp = g_get_environ ();

  context->priv->envp =
    g_environ_setenv (context->priv->envp, variable, value, TRUE);
}

/**
 * g_app_launch_context_unsetenv:
 * @context: the launch context
 * @variable: (type filename): the environment variable to remove
 *
 * Arranges for @variable to be unset in the child’s environment when @context
 * is used to launch an application.
 *
 * Since: 2.32
 */
void
g_app_launch_context_unsetenv (GAppLaunchContext *context,
                               const char        *variable)
{
  g_return_if_fail (G_IS_APP_LAUNCH_CONTEXT (context));
  g_return_if_fail (variable != NULL);

  if (!context->priv->envp)
    context->priv->envp = g_get_environ ();

  context->priv->envp =
    g_environ_unsetenv (context->priv->envp, variable);
}

/**
 * g_app_launch_context_get_environment:
 * @context: the launch context
 *
 * Gets the complete environment variable list to be passed to
 * the child process when @context is used to launch an application.
 * This is a `NULL`-terminated array of strings, where each string has
 * the form `KEY=VALUE`.
 *
 * Returns: (array zero-terminated=1) (element-type filename) (transfer full):
 *   the child’s environment
 *
 * Since: 2.32
 */
char **
g_app_launch_context_get_environment (GAppLaunchContext *context)
{
  g_return_val_if_fail (G_IS_APP_LAUNCH_CONTEXT (context), NULL);

  if (!context->priv->envp)
    context->priv->envp = g_get_environ ();

  return g_strdupv (context->priv->envp);
}

/**
 * g_app_launch_context_get_display:
 * @context: the launch context
 * @info: the app info
 * @files: (element-type GFile): a list of [iface@Gio.File] objects
 *
 * Gets the display string for the @context. This is used to ensure new
 * applications are started on the same display as the launching
 * application, by setting the `DISPLAY` environment variable.
 *
 * Returns: (nullable): a display string for the display.
 */
char *
g_app_launch_context_get_display (GAppLaunchContext *context,
				  GAppInfo          *info,
				  GList             *files)
{
  GAppLaunchContextClass *class;

  g_return_val_if_fail (G_IS_APP_LAUNCH_CONTEXT (context), NULL);
  g_return_val_if_fail (G_IS_APP_INFO (info), NULL);

  class = G_APP_LAUNCH_CONTEXT_GET_CLASS (context);

  if (class->get_display == NULL)
    return NULL;

  return class->get_display (context, info, files);
}

/**
 * g_app_launch_context_get_startup_notify_id:
 * @context: the launch context
 * @info: (nullable): the app info
 * @files: (nullable) (element-type GFile): a list of [iface@Gio.File] objects
 * 
 * Initiates startup notification for the application and returns the
 * `XDG_ACTIVATION_TOKEN` or `DESKTOP_STARTUP_ID` for the launched operation,
 * if supported.
 *
 * The returned token may be referred to equivalently as an ‘activation token’
 * (using Wayland terminology) or a ‘startup sequence ID’ (using X11 terminology).
 * The two [are interoperable](https://gitlab.freedesktop.org/wayland/wayland-protocols/-/blob/main/staging/xdg-activation/x11-interoperation.rst).
 *
 * Activation tokens are defined in the [XDG Activation Protocol](https://wayland.app/protocols/xdg-activation-v1),
 * and startup notification IDs are defined in the 
 * [freedesktop.org Startup Notification Protocol](http://standards.freedesktop.org/startup-notification-spec/startup-notification-latest.txt).
 *
 * Support for the XDG Activation Protocol was added in GLib 2.76.
 * Since GLib 2.82 @info and @files can be `NULL`. If that’s not supported by the backend,
 * the returned token will be `NULL`.
 *
 * Returns: (nullable): a startup notification ID for the application, or `NULL` if
 *   not supported.
 **/
char *
g_app_launch_context_get_startup_notify_id (GAppLaunchContext *context,
					    GAppInfo          *info,
					    GList             *files)
{
  GAppLaunchContextClass *class;

  g_return_val_if_fail (G_IS_APP_LAUNCH_CONTEXT (context), NULL);
  g_return_val_if_fail (info == NULL || G_IS_APP_INFO (info), NULL);

  class = G_APP_LAUNCH_CONTEXT_GET_CLASS (context);

  if (class->get_startup_notify_id == NULL)
    return NULL;

  return class->get_startup_notify_id (context, info, files);
}


/**
 * g_app_launch_context_launch_failed:
 * @context: the launch context
 * @startup_notify_id: the startup notification id that was returned by
 *   [method@Gio.AppLaunchContext.get_startup_notify_id].
 *
 * Called when an application has failed to launch, so that it can cancel
 * the application startup notification started in
 * [method@Gio.AppLaunchContext.get_startup_notify_id].
 * 
 **/
void
g_app_launch_context_launch_failed (GAppLaunchContext *context,
				    const char        *startup_notify_id)
{
  g_return_if_fail (G_IS_APP_LAUNCH_CONTEXT (context));
  g_return_if_fail (startup_notify_id != NULL);

  g_signal_emit (context, signals[LAUNCH_FAILED], 0, startup_notify_id);
}


