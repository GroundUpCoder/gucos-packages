/* -*- mode: C; c-file-style: "gnu"; indent-tabs-mode: nil; -*- */

/* GIO - GLib Input, Output and Streaming Library
 *
 * Copyright (C) 2008 Red Hat, Inc.
 * Copyright (C) 2018 Igalia S.L.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <glib.h>
#include "glibintl.h"

#include <stdio.h>
#include <string.h>

#include "glib/glib-private.h"
#include "gthreadedresolver.h"
#include "gthreadedresolver-private.h"
#include "gnetworkingprivate.h"

#include "gcancellable.h"
#include "ginetaddress.h"
#include "ginetsocketaddress.h"
#include "gtask.h"
#include "gsocketaddress.h"
#include "gsrvtarget.h"

/*
 * GThreadedResolver is a threaded wrapper around the system libc’s
 * `getaddrinfo()`.
 *
 * It has to be threaded, as `getaddrinfo()` is synchronous. libc does provide
 * `getaddrinfo_a()` as an asynchronous version of `getaddrinfo()`, but it does
 * not integrate with a poll loop. It requires use of sigevent to notify of
 * completion of an asynchronous operation. That either emits a signal, or calls
 * a callback function in a newly spawned thread.
 *
 * A signal (`SIGEV_SIGNAL`) can’t be used for completion as (aside from being
 * another expensive round trip into the kernel) GLib cannot pick a `SIG*`
 * number which is guaranteed to not be in use elsewhere in the process. Various
 * other things could be interfering with signal dispositions, such as gdb or
 * other libraries in the process. Using a `signalfd()`
 * [cannot improve this situation](https://ldpreload.com/blog/signalfd-is-useless).
 *
 * A callback function in a newly spawned thread (`SIGEV_THREAD`) could be used,
 * but that is very expensive. Internally, glibc currently also just implements
 * `getaddrinfo_a()`
 * [using its own thread pool](https://github.com/bminor/glibc/blob/master/resolv/gai_misc.c),
 * and then
 * [spawns an additional thread for each completion callback](https://github.com/bminor/glibc/blob/master/resolv/gai_notify.c).
 * That is very expensive.
 *
 * No other appropriate sigevent callback types
 * [currently exist](https://sourceware.org/bugzilla/show_bug.cgi?id=30287), and
 * [others agree that sigevent is not great](http://davmac.org/davpage/linux/async-io.html#posixaio).
 *
 * Hence, #GThreadedResolver calls the normal synchronous `getaddrinfo()` in its
 * own thread pool. Previously, #GThreadedResolver used the thread pool which is
 * internal to #GTask by calling g_task_run_in_thread(). That lead to exhaustion
 * of the #GTask thread pool in some situations, though, as DNS lookups are
 * quite frequent leaf operations in some use cases. Now, #GThreadedResolver
 * uses its own private thread pool.
 *
 * This is similar to what
 * [libasyncns](http://git.0pointer.net/libasyncns.git/tree/libasyncns/asyncns.h)
 * and other multi-threaded users of `getaddrinfo()` do.
 */

struct _GThreadedResolver
{
  GResolver parent_instance;

  GThreadPool *thread_pool;  /* (owned) */
};

G_DEFINE_TYPE (GThreadedResolver, g_threaded_resolver, G_TYPE_RESOLVER)

static void run_task_in_thread_pool_async (GThreadedResolver *self,
                                           GTask             *task);
static void run_task_in_thread_pool_sync (GThreadedResolver *self,
                                          GTask             *task);
static void threaded_resolver_worker_cb (gpointer task_data,
                                         gpointer user_data);

static void
g_threaded_resolver_init (GThreadedResolver *self)
{
  self->thread_pool = g_thread_pool_new_full (threaded_resolver_worker_cb,
                                              self,
                                              (GDestroyNotify) g_object_unref,
                                              20,
                                              FALSE,
                                              NULL);
}

static void
g_threaded_resolver_finalize (GObject *object)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (object);

  g_thread_pool_free (self->thread_pool, TRUE, FALSE);
  self->thread_pool = NULL;

  G_OBJECT_CLASS (g_threaded_resolver_parent_class)->finalize (object);
}

static GResolverError
g_resolver_error_from_addrinfo_error (gint err)
{
  switch (err)
    {
    case EAI_FAIL:
#if defined(EAI_NODATA) && (EAI_NODATA != EAI_NONAME)
    case EAI_NODATA:
#endif
    case EAI_NONAME:
      return G_RESOLVER_ERROR_NOT_FOUND;

    case EAI_AGAIN:
      return G_RESOLVER_ERROR_TEMPORARY_FAILURE;

    default:
      return G_RESOLVER_ERROR_INTERNAL;
    }
}

typedef struct {
  enum {
    LOOKUP_BY_NAME,
    LOOKUP_BY_ADDRESS,
    LOOKUP_RECORDS,
  } lookup_type;

  union {
    struct {
      char *hostname;
      int address_family;
    } lookup_by_name;
    struct {
      GInetAddress *address;  /* (owned) */
    } lookup_by_address;
    struct {
      char *rrname;
      GResolverRecordType record_type;
    } lookup_records;
  };

  GCond cond;  /* used for signalling completion of the task when running it sync */
  GMutex lock;

  GSource *timeout_source;  /* (nullable) (owned) */
  GSource *cancellable_source;  /* (nullable) (owned) */

  /* This enum indicates that a particular code path has claimed the
   * task and is shortly about to call g_task_return_*() on it.
   * This must be accessed with GThreadedResolver.lock held. */
  enum
    {
      NOT_YET,
      COMPLETED,  /* libc lookup call has completed successfully or errored */
      TIMED_OUT,
      CANCELLED,
    } will_return;

  /* Whether the thread pool thread executing this lookup has finished executing
   * it and g_task_return_*() has been called on it already.
   * This must be accessed with GThreadedResolver.lock held. */
  gboolean has_returned;
} LookupData;

static LookupData *
lookup_data_new_by_name (const char *hostname,
                         int         address_family)
{
  LookupData *data = g_new0 (LookupData, 1);
  data->lookup_type = LOOKUP_BY_NAME;
  g_cond_init (&data->cond);
  g_mutex_init (&data->lock);
  data->lookup_by_name.hostname = g_strdup (hostname);
  data->lookup_by_name.address_family = address_family;
  return g_steal_pointer (&data);
}

static LookupData *
lookup_data_new_by_address (GInetAddress *address)
{
  LookupData *data = g_new0 (LookupData, 1);
  data->lookup_type = LOOKUP_BY_ADDRESS;
  g_cond_init (&data->cond);
  g_mutex_init (&data->lock);
  data->lookup_by_address.address = g_object_ref (address);
  return g_steal_pointer (&data);
}

static LookupData *
lookup_data_new_records (const gchar         *rrname,
                         GResolverRecordType  record_type)
{
  LookupData *data = g_new0 (LookupData, 1);
  data->lookup_type = LOOKUP_RECORDS;
  g_cond_init (&data->cond);
  g_mutex_init (&data->lock);
  data->lookup_records.rrname = g_strdup (rrname);
  data->lookup_records.record_type = record_type;
  return g_steal_pointer (&data);
}

static void
lookup_data_free (LookupData *data)
{
  switch (data->lookup_type) {
  case LOOKUP_BY_NAME:
    g_free (data->lookup_by_name.hostname);
    break;
  case LOOKUP_BY_ADDRESS:
    g_clear_object (&data->lookup_by_address.address);
    break;
  case LOOKUP_RECORDS:
    g_free (data->lookup_records.rrname);
    break;
  default:
    g_assert_not_reached ();
  }

  if (data->timeout_source != NULL)
    {
      g_source_destroy (data->timeout_source);
      g_clear_pointer (&data->timeout_source, g_source_unref);
    }

  if (data->cancellable_source != NULL)
    {
      g_source_destroy (data->cancellable_source);
      g_clear_pointer (&data->cancellable_source, g_source_unref);
    }

  g_mutex_clear (&data->lock);
  g_cond_clear (&data->cond);

  g_free (data);
}

static GList *
do_lookup_by_name (const gchar   *hostname,
                   int            address_family,
                   GCancellable  *cancellable,
                   GError       **error)
{
  struct addrinfo *res = NULL;
  GList *addresses;
  gint retval;
  struct addrinfo addrinfo_hints = { 0 };

#ifdef AI_ADDRCONFIG
  addrinfo_hints.ai_flags = AI_ADDRCONFIG;
#endif
  /* socktype and protocol don't actually matter, they just get copied into the
  * returned addrinfo structures (and then we ignore them). But if
  * we leave them unset, we'll get back duplicate answers.
  */
  addrinfo_hints.ai_socktype = SOCK_STREAM;
  addrinfo_hints.ai_protocol = IPPROTO_TCP;

  addrinfo_hints.ai_family = address_family;
  retval = getaddrinfo (hostname, NULL, &addrinfo_hints, &res);

  if (retval == 0)
    {
      struct addrinfo *ai;
      GSocketAddress *sockaddr;
      GInetAddress *addr;

      addresses = NULL;
      for (ai = res; ai; ai = ai->ai_next)
        {
          sockaddr = g_socket_address_new_from_native (ai->ai_addr, ai->ai_addrlen);
          if (!sockaddr)
            continue;
          if (!G_IS_INET_SOCKET_ADDRESS (sockaddr))
            {
              g_clear_object (&sockaddr);
              continue;
            }

          addr = g_object_ref (g_inet_socket_address_get_address ((GInetSocketAddress *)sockaddr));
          addresses = g_list_prepend (addresses, addr);
          g_object_unref (sockaddr);
        }

      g_clear_pointer (&res, freeaddrinfo);

      if (addresses != NULL)
        {
          addresses = g_list_reverse (addresses);
          return g_steal_pointer (&addresses);
        }
      else
        {
          /* All addresses failed to be converted to GSocketAddresses. */
          g_set_error (error,
                       G_RESOLVER_ERROR,
                       G_RESOLVER_ERROR_NOT_FOUND,
                       _("Error resolving “%s”: %s"),
                       hostname,
                       _("No valid addresses were found"));
          return NULL;
        }
    }
  else
    {
#ifdef G_OS_WIN32
      gchar *error_message = g_win32_error_message (WSAGetLastError ());
#else
      gchar *error_message = g_locale_to_utf8 (gai_strerror (retval), -1, NULL, NULL, NULL);
      if (error_message == NULL)
        error_message = g_strdup ("[Invalid UTF-8]");
#endif

      g_clear_pointer (&res, freeaddrinfo);

      g_set_error (error,
                   G_RESOLVER_ERROR,
                   g_resolver_error_from_addrinfo_error (retval),
                   _("Error resolving “%s”: %s"),
                   hostname, error_message);
      g_free (error_message);

      return NULL;
    }
}

static GList *
lookup_by_name (GResolver     *resolver,
                const gchar   *hostname,
                GCancellable  *cancellable,
                GError       **error)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  GTask *task;
  GList *addresses;
  LookupData *data;

  data = lookup_data_new_by_name (hostname, AF_UNSPEC);
  task = g_task_new (resolver, cancellable, NULL, NULL);
  g_task_set_source_tag (task, lookup_by_name);
  g_task_set_name (task, "[gio] resolver lookup");
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_sync (self, task);

  addresses = g_task_propagate_pointer (task, error);
  g_object_unref (task);

  return addresses;
}

static int
flags_to_family (GResolverNameLookupFlags flags)
{
  int address_family = AF_UNSPEC;

  if (flags & G_RESOLVER_NAME_LOOKUP_FLAGS_IPV4_ONLY)
    address_family = AF_INET;

  if (flags & G_RESOLVER_NAME_LOOKUP_FLAGS_IPV6_ONLY)
    {
      address_family = AF_INET6;
      /* You can only filter by one family at a time */
      g_return_val_if_fail (!(flags & G_RESOLVER_NAME_LOOKUP_FLAGS_IPV4_ONLY), address_family);
    }

  return address_family;
}

static GList *
lookup_by_name_with_flags (GResolver                 *resolver,
                           const gchar               *hostname,
                           GResolverNameLookupFlags   flags,
                           GCancellable              *cancellable,
                           GError                   **error)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  GTask *task;
  GList *addresses;
  LookupData *data;

  data = lookup_data_new_by_name (hostname, flags_to_family (flags));
  task = g_task_new (resolver, cancellable, NULL, NULL);
  g_task_set_source_tag (task, lookup_by_name_with_flags);
  g_task_set_name (task, "[gio] resolver lookup");
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_sync (self, task);

  addresses = g_task_propagate_pointer (task, error);
  g_object_unref (task);

  return addresses;
}

static void
lookup_by_name_with_flags_async (GResolver                *resolver,
                                 const gchar              *hostname,
                                 GResolverNameLookupFlags  flags,
                                 GCancellable             *cancellable,
                                 GAsyncReadyCallback       callback,
                                 gpointer                  user_data)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  GTask *task;
  LookupData *data;

  data = lookup_data_new_by_name (hostname, flags_to_family (flags));
  task = g_task_new (resolver, cancellable, callback, user_data);

  g_debug ("%s: starting new lookup for %s with GTask %p, LookupData %p",
           G_STRFUNC, hostname, task, data);

  g_task_set_source_tag (task, lookup_by_name_with_flags_async);
  g_task_set_name (task, "[gio] resolver lookup");
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_async (self, task);

  g_object_unref (task);
}

static void
lookup_by_name_async (GResolver           *resolver,
                      const gchar         *hostname,
                      GCancellable        *cancellable,
                      GAsyncReadyCallback  callback,
                      gpointer             user_data)
{
  lookup_by_name_with_flags_async (resolver,
                                   hostname,
                                   G_RESOLVER_NAME_LOOKUP_FLAGS_DEFAULT,
                                   cancellable,
                                   callback,
                                   user_data);
}

static GList *
lookup_by_name_finish (GResolver     *resolver,
                       GAsyncResult  *result,
                       GError       **error)
{
  g_return_val_if_fail (g_task_is_valid (result, resolver), NULL);

  return g_task_propagate_pointer (G_TASK (result), error);
}

static GList *
lookup_by_name_with_flags_finish (GResolver     *resolver,
                                  GAsyncResult  *result,
                                  GError       **error)
{
  g_return_val_if_fail (g_task_is_valid (result, resolver), NULL);

  return g_task_propagate_pointer (G_TASK (result), error);
}

static gchar *
do_lookup_by_address (GInetAddress  *address,
                      GCancellable  *cancellable,
                      GError       **error)
{
  struct sockaddr_storage sockaddr_address;
  gsize sockaddr_address_size;
  GSocketAddress *gsockaddr;
  gchar name[NI_MAXHOST];
  gint retval;

  gsockaddr = g_inet_socket_address_new (address, 0);
  g_socket_address_to_native (gsockaddr, (struct sockaddr *)&sockaddr_address,
                              sizeof (sockaddr_address), NULL);
  sockaddr_address_size = g_socket_address_get_native_size (gsockaddr);
  g_object_unref (gsockaddr);

  retval = getnameinfo ((struct sockaddr *) &sockaddr_address, sockaddr_address_size,
                        name, sizeof (name), NULL, 0, NI_NAMEREQD);
  if (retval == 0)
    return g_strdup (name);
  else
    {
      gchar *phys;

#ifdef G_OS_WIN32
      gchar *error_message = g_win32_error_message (WSAGetLastError ());
#else
      gchar *error_message = g_locale_to_utf8 (gai_strerror (retval), -1, NULL, NULL, NULL);
      if (error_message == NULL)
        error_message = g_strdup ("[Invalid UTF-8]");
#endif

      phys = g_inet_address_to_string (address);
      g_set_error (error,
                   G_RESOLVER_ERROR,
                   g_resolver_error_from_addrinfo_error (retval),
                   _("Error reverse-resolving “%s”: %s"),
                   phys ? phys : "(unknown)",
                   error_message);
      g_free (phys);
      g_free (error_message);

      return NULL;
    }
}

static gchar *
lookup_by_address (GResolver        *resolver,
                   GInetAddress     *address,
                   GCancellable     *cancellable,
                   GError          **error)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  LookupData *data = NULL;
  GTask *task;
  gchar *name;

  data = lookup_data_new_by_address (address);
  task = g_task_new (resolver, cancellable, NULL, NULL);
  g_task_set_source_tag (task, lookup_by_address);
  g_task_set_name (task, "[gio] resolver lookup");
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_sync (self, task);

  name = g_task_propagate_pointer (task, error);
  g_object_unref (task);

  return name;
}

static void
lookup_by_address_async (GResolver           *resolver,
                         GInetAddress        *address,
                         GCancellable        *cancellable,
                         GAsyncReadyCallback  callback,
                         gpointer             user_data)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  LookupData *data = NULL;
  GTask *task;

  data = lookup_data_new_by_address (address);
  task = g_task_new (resolver, cancellable, callback, user_data);
  g_task_set_source_tag (task, lookup_by_address_async);
  g_task_set_name (task, "[gio] resolver lookup");
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_async (self, task);

  g_object_unref (task);
}

static gchar *
lookup_by_address_finish (GResolver     *resolver,
                          GAsyncResult  *result,
                          GError       **error)
{
  g_return_val_if_fail (g_task_is_valid (result, resolver), NULL);

  return g_task_propagate_pointer (G_TASK (result), error);
}


/* DNS record transport is unavailable in the browser local-IPC profile. */

static void
free_records (GList *records)
{
  g_list_free_full (records, (GDestroyNotify) g_variant_unref);
}

#if defined(G_OS_UNIX)
#ifdef __BIONIC__
#ifndef C_IN
#define C_IN 1
#endif
int res_query(const char *, int, int, u_char *, int);
#endif
#endif

static GList *
do_lookup_records (const gchar *rrname, GResolverRecordType type,
                   GCancellable *cancellable, GError **error)
{
  if (!g_cancellable_set_error_if_cancelled (cancellable, error))
    g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_NOT_SUPPORTED,
                         "DNS record queries are unavailable in this browser platform");
  return NULL;
}

static GList *
lookup_records (GResolver              *resolver,
                const gchar            *rrname,
                GResolverRecordType     record_type,
                GCancellable           *cancellable,
                GError                **error)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  GTask *task;
  GList *records;
  LookupData *data = NULL;

  task = g_task_new (resolver, cancellable, NULL, NULL);
  g_task_set_source_tag (task, lookup_records);
  g_task_set_name (task, "[gio] resolver lookup records");

  data = lookup_data_new_records (rrname, record_type);
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_sync (self, task);

  records = g_task_propagate_pointer (task, error);
  g_object_unref (task);

  return records;
}

static void
lookup_records_async (GResolver           *resolver,
                      const char          *rrname,
                      GResolverRecordType  record_type,
                      GCancellable        *cancellable,
                      GAsyncReadyCallback  callback,
                      gpointer             user_data)
{
  GThreadedResolver *self = G_THREADED_RESOLVER (resolver);
  GTask *task;
  LookupData *data = NULL;

  task = g_task_new (resolver, cancellable, callback, user_data);
  g_task_set_source_tag (task, lookup_records_async);
  g_task_set_name (task, "[gio] resolver lookup records");

  data = lookup_data_new_records (rrname, record_type);
  g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) lookup_data_free);

  run_task_in_thread_pool_async (self, task);

  g_object_unref (task);
}

static GList *
lookup_records_finish (GResolver     *resolver,
                       GAsyncResult  *result,
                       GError       **error)
{
  g_return_val_if_fail (g_task_is_valid (result, resolver), NULL);

  return g_task_propagate_pointer (G_TASK (result), error);
}

/* Will be called in the GLib worker thread, so must lock all accesses to shared
 * data. */
static gboolean
timeout_cb (gpointer user_data)
{
  GWeakRef *weak_task = user_data;
  GTask *task = NULL;  /* (owned) */
  LookupData *data;
  gboolean should_return;

  task = g_weak_ref_get (weak_task);
  if (task == NULL)
    return G_SOURCE_REMOVE;

  data = g_task_get_task_data (task);

  g_mutex_lock (&data->lock);

  should_return = g_atomic_int_compare_and_exchange (&data->will_return, NOT_YET, TIMED_OUT);
  g_clear_pointer (&data->timeout_source, g_source_unref);

  g_mutex_unlock (&data->lock);

  if (should_return)
    {
      g_task_return_new_error_literal (task, G_IO_ERROR, G_IO_ERROR_TIMED_OUT,
                                       _("Socket I/O timed out"));
    }

  /* Signal completion of the task. */
  g_mutex_lock (&data->lock);
  data->has_returned = TRUE;
  g_cond_broadcast (&data->cond);
  g_mutex_unlock (&data->lock);

  g_object_unref (task);

  return G_SOURCE_REMOVE;
}

/* Will be called in the GLib worker thread, so must lock all accesses to shared
 * data. */
static gboolean
cancelled_cb (GCancellable *cancellable,
              gpointer      user_data)
{
  GWeakRef *weak_task = user_data;
  GTask *task = NULL;  /* (owned) */
  LookupData *data;
  gboolean should_return;

  task = g_weak_ref_get (weak_task);
  if (task == NULL)
    return G_SOURCE_REMOVE;

  data = g_task_get_task_data (task);

  g_mutex_lock (&data->lock);

  g_assert (g_cancellable_is_cancelled (cancellable));
  should_return = g_atomic_int_compare_and_exchange (&data->will_return, NOT_YET, CANCELLED);
  g_clear_pointer (&data->cancellable_source, g_source_unref);

  g_mutex_unlock (&data->lock);

  if (should_return)
    g_task_return_error_if_cancelled (task);

  /* Signal completion of the task. */
  g_mutex_lock (&data->lock);
  data->has_returned = TRUE;
  g_cond_broadcast (&data->cond);
  g_mutex_unlock (&data->lock);

  g_object_unref (task);

  return G_SOURCE_REMOVE;
}

static void
weak_ref_clear_and_free (GWeakRef *weak_ref)
{
  g_weak_ref_clear (weak_ref);
  g_free (weak_ref);
}

static void
run_task_in_thread_pool_async (GThreadedResolver *self,
                               GTask             *task)
{
  LookupData *data = g_task_get_task_data (task);
  guint timeout_ms = g_resolver_get_timeout (G_RESOLVER (self));
  GCancellable *cancellable = g_task_get_cancellable (task);

  g_mutex_lock (&data->lock);

  g_thread_pool_push (self->thread_pool, g_object_ref (task), NULL);

  if (timeout_ms != 0)
    {
      GWeakRef *weak_task = g_new0 (GWeakRef, 1);
      g_weak_ref_set (weak_task, task);

      data->timeout_source = g_timeout_source_new (timeout_ms);
      g_source_set_static_name (data->timeout_source, "[gio] threaded resolver timeout");
      g_source_set_callback (data->timeout_source, G_SOURCE_FUNC (timeout_cb), g_steal_pointer (&weak_task), (GDestroyNotify) weak_ref_clear_and_free);
      g_source_attach (data->timeout_source, GLIB_PRIVATE_CALL (g_get_worker_context) ());
    }

  if (cancellable != NULL)
    {
      GWeakRef *weak_task = g_new0 (GWeakRef, 1);
      g_weak_ref_set (weak_task, task);

      data->cancellable_source = g_cancellable_source_new (cancellable);
      g_source_set_static_name (data->cancellable_source, "[gio] threaded resolver cancellable");
      g_source_set_callback (data->cancellable_source, G_SOURCE_FUNC (cancelled_cb), g_steal_pointer (&weak_task), (GDestroyNotify) weak_ref_clear_and_free);
      g_source_attach (data->cancellable_source, GLIB_PRIVATE_CALL (g_get_worker_context) ());
    }

  g_mutex_unlock (&data->lock);
}

static void
run_task_in_thread_pool_sync (GThreadedResolver *self,
                              GTask             *task)
{
  LookupData *data = g_task_get_task_data (task);

  run_task_in_thread_pool_async (self, task);

  g_mutex_lock (&data->lock);
  while (!data->has_returned)
    g_cond_wait (&data->cond, &data->lock);
  g_mutex_unlock (&data->lock);
}

static void
threaded_resolver_worker_cb (gpointer task_data,
                             gpointer user_data)
{
  GTask *task = G_TASK (g_steal_pointer (&task_data));
  LookupData *data = g_task_get_task_data (task);
  GCancellable *cancellable = g_task_get_cancellable (task);
  GError *local_error = NULL;
  gboolean should_return;

  switch (data->lookup_type) {
  case LOOKUP_BY_NAME:
    {
      GList *addresses = do_lookup_by_name (data->lookup_by_name.hostname,
                                            data->lookup_by_name.address_family,
                                            cancellable,
                                            &local_error);

      g_mutex_lock (&data->lock);
      should_return = g_atomic_int_compare_and_exchange (&data->will_return, NOT_YET, COMPLETED);
      g_mutex_unlock (&data->lock);

      if (should_return)
        {
          if (addresses != NULL)
            g_task_return_pointer (task, g_steal_pointer (&addresses), (GDestroyNotify) g_resolver_free_addresses);
          else
            g_task_return_error (task, g_steal_pointer (&local_error));
        }

      g_clear_pointer (&addresses, g_resolver_free_addresses);
      g_clear_error (&local_error);
    }
    break;
  case LOOKUP_BY_ADDRESS:
    {
      gchar *name = do_lookup_by_address (data->lookup_by_address.address,
                                          cancellable,
                                          &local_error);

      g_mutex_lock (&data->lock);
      should_return = g_atomic_int_compare_and_exchange (&data->will_return, NOT_YET, COMPLETED);
      g_mutex_unlock (&data->lock);

      if (should_return)
        {
          if (name != NULL)
            g_task_return_pointer (task, g_steal_pointer (&name), g_free);
          else
            g_task_return_error (task, g_steal_pointer (&local_error));
        }

      g_clear_pointer (&name, g_free);
      g_clear_error (&local_error);
    }
    break;
  case LOOKUP_RECORDS:
    {
      GList *records = do_lookup_records (data->lookup_records.rrname,
                                          data->lookup_records.record_type,
                                          cancellable,
                                          &local_error);

      g_mutex_lock (&data->lock);
      should_return = g_atomic_int_compare_and_exchange (&data->will_return, NOT_YET, COMPLETED);
      g_mutex_unlock (&data->lock);

      if (should_return)
        {
          if (records != NULL)
            g_task_return_pointer (task, g_steal_pointer (&records), (GDestroyNotify) free_records);
          else
            g_task_return_error (task, g_steal_pointer (&local_error));
        }

      g_clear_pointer (&records, free_records);
      g_clear_error (&local_error);
    }
    break;
  default:
    g_assert_not_reached ();
  }

  /* Signal completion of a task. */
  g_mutex_lock (&data->lock);
  data->has_returned = TRUE;
  g_cond_broadcast (&data->cond);
  g_mutex_unlock (&data->lock);

  g_object_unref (task);
}

static void
g_threaded_resolver_class_init (GThreadedResolverClass *threaded_class)
{
  GObjectClass *object_class = G_OBJECT_CLASS (threaded_class);
  GResolverClass *resolver_class = G_RESOLVER_CLASS (threaded_class);

  object_class->finalize = g_threaded_resolver_finalize;

  resolver_class->lookup_by_name                   = lookup_by_name;
  resolver_class->lookup_by_name_async             = lookup_by_name_async;
  resolver_class->lookup_by_name_finish            = lookup_by_name_finish;
  resolver_class->lookup_by_name_with_flags        = lookup_by_name_with_flags;
  resolver_class->lookup_by_name_with_flags_async  = lookup_by_name_with_flags_async;
  resolver_class->lookup_by_name_with_flags_finish = lookup_by_name_with_flags_finish;
  resolver_class->lookup_by_address                = lookup_by_address;
  resolver_class->lookup_by_address_async          = lookup_by_address_async;
  resolver_class->lookup_by_address_finish         = lookup_by_address_finish;
  resolver_class->lookup_records                   = lookup_records;
  resolver_class->lookup_records_async             = lookup_records_async;
  resolver_class->lookup_records_finish            = lookup_records_finish;
}
