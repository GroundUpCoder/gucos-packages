This is an explicitly limited GIO 2.84.4 package, not libgio-2.0.

It builds upstream streams, cancellables, tasks, converters, zlib/charset
conversion, Unix FD streams, GResource/GVDB, file metadata, and memory/themed
icons. It depends on gio-listmodel, GObject, GLib and zlib. The AppLaunchContext
class and bare AppInfo interface come from upstream gappinfo.c; application
launching and application discovery are not provided.

Headers live in include/gio-core-2.0; pkg-config gio-core selects that path
before GLib's headers. This prevents a gio-listmodel reinstall from replacing
the expanded umbrella header. gio/gio-upstream.h is retained ONLY for compile
probes, where declaration availability must not be confused with working
implementations. GModule declarations are included for dependent headers,
but this package does not implement GModule loading.

Adaptations, with original upstream files retained:
- gresource-wasm-posix.c opens resource overlays using open() and an upstream
  GUnixInputStream instead of requiring a full GFile/VFS implementation.
- gicon-wasm-posix.c excludes FileIcon deserialization without VFS support.
- giounix-private-wasm-posix.c spells the GNU statement-expression retry as
  ordinary C. It preserves EINTR retry behavior.
- gapplaunchcontext-wasm-posix.c extracts the upstream context class and
  interface type without pulling in the desktop application database.
- port/task-test.c substitutes a plain GObject for the upstream dummy socket
  client; those tests only need a refcounted object and never use networking.

Upstream memory-input-stream (6) and memory-output-stream (10) tests pass.
The task runner explicitly excludes /gtask/run-in-thread-overflow: all 1024
jobs complete but the upstream timing-dependent upper bound on observed
concurrent threads fails here. The other 35 task cases pass. This is not a
claim that all upstream GIO tests pass.

port/resource-pack.c uses upstream GVDB serialization and reads the result
back through GResource. TSV input stores raw, uncompressed bytes; XML and
asset preprocessing are not needed. gvdb-builder-sync.c contains only the
upstream synchronous writer, without its unused GFile async writer.
