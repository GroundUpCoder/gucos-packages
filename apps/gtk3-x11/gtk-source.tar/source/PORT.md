See ../../docs/GTK.md for the architecture, tests and remaining work.

Upstream GTK 3.24.43 gdk/ and gtk/ trees are retained. install-gdk.sh installs
GDK only, using the upstream Broadway backend and port/browser/server.c.
port/browser/no-gl.c reports unavailable GL contexts. gdkwindow-wasm-posix.c
is the original gdkwindow.c with unreachable GL calls replaced by assertions;
the software surface paths are unchanged. gdkeventsource-wasm-posix.c routes
browser-initiated resize notifications through GDK's resize path, updating
clipping and backing surfaces. Upstream Broadway normally receives only
acknowledgements of its own resize requests. Both original files remain present.

config.h, gdkconfig.h and version headers select a software browser target.
Enum and marshal sources are generated with bundled GLib Python generators
and upstream templates/lists. tools/port-recipes/gtk-generated.py regenerates
GTK's type-function list and D-Bus glue used by the diagnostic compile probe.
D-Bus declarations are not a D-Bus implementation. gtk-sources.json is a
probe list, not an installable complete GTK build. Its full GIO umbrella is
provided only in the probe's virtual source map, never installed as gio.h.

port/resources.tsv is derived from upstream gtk.gresource.xml, keeping raw
assets rather than compressed/preprocessed copies. gio-core's resource-pack
writes and verifies the GVDB bundle on the target. port/resources.c registers
the GTK bundle in the software widget library; it is not linked into GDK.

The gucman gtk3 package installs the software widget profile through
install-gtk.sh and gtk-browser-sources.json. See ../../docs/GTK.md for the distinction
between the historical full-source probe and this linkable profile. The
separate gtk3-demo package contains selected upstream demos and a
browser launcher; changing those app sources does not invalidate GTK itself.

The browser server preserves upstream Broadway's nullable window-update
contract: a popup closed before its first paint has no backing surface. Such
updates are ignored instead of passing NULL to Cairo.
