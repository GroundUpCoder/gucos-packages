# GNU m4 port

Pinned upstream GNU m4 1.4.19 release:
https://ftp.gnu.org/gnu/m4/m4-1.4.19.tar.xz
SHA-256: 63aede5c6d33b6d9b13511cd0be2cac046f2e70fd0a07aa9573a04a82783af96
License: GPLv3+ (COPYING).

Vendored upstream files are unmodified. Local additions are this file, install.build,
and port/executables, which records upstream executable file modes for the
browser source payload. The recipe uses the shipped configure script and
Makefiles, builds in a disposable copy, runs m4's upstream documentation
checks, and installs through DESTDIR. It does not regenerate configure or
Makefile.in; regenerating those requires the still-unported Autotools tools.
The source payload has no original mtimes, so the recipe restores release-file
dependency ordering, including version.texi/stamp-vti and the shipped Info
manual. It does not require Texinfo to regenerate an unchanged manual.

The recipe defines __unix__ to select m4's Unix platform and subprocess
semantics; the generic WebAssembly compiler does not advertise an OS by default.

The configure cache supplies one known negative: gl_cv_func_strstr_linear=no.
Our libc strstr is quadratic; the original test relies on an alarm interrupting
pure computation. This selects the upstream replacement, not a false pass.

The complete top-level make check also exercises gnulib's platform conformance
suite. Its results must be reported separately from m4's documentation checks.

One test expectation is adjusted in the disposable build copy:
checks/198.sysval expects an additional stderr line, "Killed". BusyBox ash
prints that diagnostic for the deliberately SIGKILLed nested shell. The
signal exit values (2304 in m4), stdout, and all other stderr remain checked
exactly. The unadjusted upstream run had this single stderr mismatch.

Expected upstream skips are six optional changeword cases (125–130) and
stackovf.test, which needs OS-level stack-overflow handling. These are separate
from the above expectation adjustment; Unix subprocess tests must not skip.
