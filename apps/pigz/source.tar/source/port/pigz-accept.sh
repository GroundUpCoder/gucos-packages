set -e
gucman install pigz
cp /usr/src/pigz/port/fixtures/input.bin /tmp/pigz-input
for options in '-p 1' '-p 2 -b 32' '-p 2 -z' '-p 2 -K'; do
    pigz $options -c /tmp/pigz-input > /tmp/compressed
    pigz -t /tmp/compressed
    pigz -dc /tmp/compressed > /tmp/restored
    cmp /tmp/pigz-input /tmp/restored
done
unpigz -c /usr/src/pigz/port/fixtures/native.gz > /tmp/restored
cmp /tmp/pigz-input /tmp/restored
for value in '' x xy xyz; do
    printf '%s' "$value" > /tmp/plain
    pigz -cdf /tmp/plain > /tmp/restored
    cmp /tmp/plain /tmp/restored
done
printf 'invalid gzip stream' > /tmp/invalid
status=0
pigz -t /tmp/invalid 2>/tmp/rejected.err || status=$?
[ "$status" -ne 0 ]
echo PIGZ-ACCEPTANCE-PASS
