#!/bin/sh
set -e
stage=$1
mkdir -p "$stage/lib/wasm-posix"
cd /usr/src/pigz
cc -DNOZOPFLI -I. -I/usr/local/include pigz.c yarn.c try.c -L/usr/local/lib -lz -o "$stage/lib/wasm-posix/pigz"
