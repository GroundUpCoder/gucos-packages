# pigz 2.8 (parallel gzip)

Upstream: https://zlib.net/pigz/pigz-2.8.tar.gz (Mark Adler, zlib license;
see the notice at the top of `pigz.c`). Vendored: `pigz.c`, `yarn.c/h`
(the pthread layer), `try.c/h` (setjmp-based try/catch with a
pthread key), and the upstream README. zopfli is not vendored;
`bin.json` builds with `-DNOZOPFLI`, so `-11` is unavailable.

Depends on `../zlib/lib.json`. Built by `cc --project /usr/src/pigz/bin.json`
on first use of `/usr/bin/pigz`; `/usr/bin/unpigz` runs the same binary with
`-d`. No source changes were needed: the port's `pthread.h` gained
`pthread_cleanup_push/pop` (no cancellation, so the routine runs only when
popped with a nonzero argument) for `yarn.c`.

Package acceptance now uses install.sh with the installed zlib headers and shared
library, declared as an exact runtime dependency. The historical project manifest
still describes the source-tree build; isolated package installation no longer
rebuilds that undeclared source dependency. Acceptance covers multiblock gzip,
zlib and zip streams, one/two compression threads, native gzip interoperability,
pass-through input and malformed-stream rejection. Zopfli remains excluded.
