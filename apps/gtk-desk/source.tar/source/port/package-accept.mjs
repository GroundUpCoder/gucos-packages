import {acceptInstalledApp} from '../../../vendor/gtk3/port/installed-app.mjs';
await acceptInstalledApp("gtk-desk","gtk-desk");
