# GTK Desk

Local, self-contained GTK 3 applications: a four-operation calculator, solvable Lights Out puzzles, and session-local appearance and hint controls. No external game data or desktop services required. Calculator operations run left to right. Escape closes the desk. Settings are session-only.

Install with `gucman install gtk-desk`, then run `gtk-desk`.
