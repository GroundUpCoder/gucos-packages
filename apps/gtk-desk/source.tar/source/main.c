/* Small, self-contained GTK applications for the wasm-posix desktop. */
#include <gtk/gtk.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
static GtkWidget *display, *status, *tiles[25], *window;
static double accumulator;
static char operation;
static gboolean fresh=TRUE, failed;
static unsigned board, moves;
static gboolean hints;
static void show_number(double v) {
  char text[64];
  failed=!isfinite(v);
  if(failed) strcpy(text,"Error"); else g_snprintf(text,sizeof text,"%.12g",v);
  gtk_entry_set_text(GTK_ENTRY(display),text);fresh=TRUE;
}
static void calculate(const char *key) {
  const char *old=gtk_entry_get_text(GTK_ENTRY(display));
  if(!strcmp(key,"C")){accumulator=0;operation=0;failed=FALSE;show_number(0);return;}
  if(strchr("0123456789.",key[0])&&key[1]==0) {
    if(failed){operation=0;accumulator=0;failed=FALSE;}
    char text[64];
    if(fresh)old="";
    if(key[0]=='.'&&strchr(old,'.'))return;
    if(strlen(old)>24)return;
    g_snprintf(text,sizeof text,"%s%s",*old?old:(key[0]=='.'?"0":""),key);
    gtk_entry_set_text(GTK_ENTRY(display),text);fresh=FALSE;return;
  }
  if(failed)return;
  double n=g_ascii_strtod(old,NULL);
  if(!strcmp(key,"+/-")){show_number(-n);fresh=FALSE;return;}
  if(!strcmp(key,"Back")){
    if(fresh)return;
    char *text=g_strdup(old);size_t len=strlen(text);
    if(len>1)text[len-1]=0;else strcpy(text,"0");
    if(!strcmp(text,"-"))strcpy(text,"0");
    gtk_entry_set_text(GTK_ENTRY(display),text);g_free(text);return;
  }
  if(operation&&!fresh){
    if(operation=='+')n=accumulator+n;
    if(operation=='-')n=accumulator-n;
    if(operation=='*')n=accumulator*n;
    if(operation=='/')n=n==0?NAN:accumulator/n;
  }else if(fresh&&operation)n=accumulator;
  accumulator=n;operation=key[0]=='='?0:key[0];show_number(n);
}
static void calc_click(GtkButton *b,gpointer unused){calculate(gtk_button_get_label(b));}
static unsigned toggle(unsigned value,int i){
  value^=1u<<i;
  if(i%5)value^=1u<<(i-1);
  if(i%5<4)value^=1u<<(i+1);
  if(i>=5)value^=1u<<(i-5);
  if(i<20)value^=1u<<(i+5);
  return value;
}
static void paint_board(void){
  for(int i=0;i<25;i++){
    gtk_button_set_label(GTK_BUTTON(tiles[i]),board&(1u<<i)?"ON":"off");
    GtkStyleContext *s=gtk_widget_get_style_context(tiles[i]);
    if(board&(1u<<i))gtk_style_context_add_class(s,"lit");else gtk_style_context_remove_class(s,"lit");
  }
  char text[160];g_snprintf(text,sizeof text,board?"Moves: %u%s":"Solved in %u moves! Play again?",moves,hints?" — Each tile flips itself and its neighbors.":"");
  gtk_label_set_text(GTK_LABEL(status),text);
}
static void tile_click(GtkButton *b,gpointer data){if(board){board=toggle(board,GPOINTER_TO_INT(data));moves++;paint_board();}}
static void new_game(GtkButton *b,gpointer data){
  /* Applying legal moves to the solved board guarantees a solvable puzzle. */
  board=0;do {for(int i=0;i<25;i++)if(g_random_int_range(0,2))board=toggle(board,i);}while(!board);
  moves=0;paint_board();
}
static void practice(GtkButton *b,gpointer data){board=toggle(0,12);moves=0;paint_board();}
static GtkWidget *box(void){GtkWidget *w=gtk_box_new(GTK_ORIENTATION_VERTICAL,12);gtk_container_set_border_width(GTK_CONTAINER(w),18);return w;}
static void pack(GtkWidget *b,GtkWidget *w){gtk_box_pack_start(GTK_BOX(b),w,FALSE,FALSE,0);}
static GtkWidget *button(const char *label,GCallback cb,gpointer data){GtkWidget *w=gtk_button_new_with_label(label);g_signal_connect(w,"clicked",cb,data);return w;}
static GtkWidget *calculator(void){
  GtkWidget *b=box();pack(b,gtk_label_new("Calculator · operations run left to right"));
  display=gtk_entry_new();gtk_editable_set_editable(GTK_EDITABLE(display),FALSE);gtk_entry_set_alignment(GTK_ENTRY(display),1);pack(b,display);show_number(0);
  GtkWidget *grid=gtk_grid_new();gtk_grid_set_row_spacing(GTK_GRID(grid),6);gtk_grid_set_column_spacing(GTK_GRID(grid),6);gtk_grid_set_column_homogeneous(GTK_GRID(grid),TRUE);pack(b,grid);
  const char *keys[]={"C","Back","+/-","/","7","8","9","*","4","5","6","-","1","2","3","+","0",".","="};
  for(int i=0;i<19;i++){GtkWidget *w=button(keys[i],G_CALLBACK(calc_click),NULL);gtk_widget_set_size_request(w,80,48);gtk_grid_attach(GTK_GRID(grid),w,i%4,i/4,i==18?2:1,1);}
  pack(b,gtk_label_new("Use the buttons or your keyboard. Enter = result, Delete = clear."));return b;
}
static GtkWidget *game(void){
  GtkWidget *b=box();pack(b,gtk_label_new("Lights Out · Turn every light off to win."));
  GtkWidget *grid=gtk_grid_new();gtk_grid_set_row_spacing(GTK_GRID(grid),4);gtk_grid_set_column_spacing(GTK_GRID(grid),4);gtk_grid_set_column_homogeneous(GTK_GRID(grid),TRUE);pack(b,grid);
  for(int i=0;i<25;i++){tiles[i]=button("",G_CALLBACK(tile_click),GINT_TO_POINTER(i));gtk_widget_set_size_request(tiles[i],64,48);gtk_grid_attach(GTK_GRID(grid),tiles[i],i%5,i/5,1,1);}
  status=gtk_label_new("");pack(b,status);pack(b,button("New puzzle",G_CALLBACK(new_game),NULL));pack(b,button("Practice: one move to win",G_CALLBACK(practice),NULL));new_game(NULL,NULL);return b;
}
static void dark_changed(GtkSwitch *w,GParamSpec *p,gpointer data){g_object_set(gtk_settings_get_default(),"gtk-application-prefer-dark-theme",gtk_switch_get_active(w),NULL);}
static void hints_changed(GtkSwitch *w,GParamSpec *p,gpointer data){hints=gtk_switch_get_active(w);paint_board();}
static void scale_changed(GtkRange *range,gpointer data){char font[32];g_snprintf(font,sizeof font,"Sans %.0f",gtk_range_get_value(range));g_object_set(gtk_settings_get_default(),"gtk-font-name",font,NULL);}
static GtkWidget *settings(void){
  GtkWidget *b=box();pack(b,gtk_label_new("Desk settings · apply to this window during this session"));
  GtkWidget *w=gtk_switch_new();gtk_widget_set_halign(w,GTK_ALIGN_START);pack(b,gtk_label_new("Dark theme"));pack(b,w);g_signal_connect(w,"notify::active",G_CALLBACK(dark_changed),NULL);
  w=gtk_switch_new();gtk_widget_set_halign(w,GTK_ALIGN_START);pack(b,gtk_label_new("Puzzle hints"));pack(b,w);g_signal_connect(w,"notify::active",G_CALLBACK(hints_changed),NULL);
  pack(b,gtk_label_new("Text size"));w=gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL,10,18,1);gtk_range_set_value(GTK_RANGE(w),10);pack(b,w);g_signal_connect(w,"value-changed",G_CALLBACK(scale_changed),NULL);
  pack(b,gtk_label_new("Real GTK switches and sliders. No system-wide settings are changed."));return b;
}
static gboolean keyboard(GtkWidget *w,GdkEventKey *e,gpointer notebook){
  if(e->keyval==GDK_KEY_Escape){gtk_widget_destroy(window);return TRUE;}
  if(gtk_notebook_get_current_page(GTK_NOTEBOOK(notebook))!=0)return FALSE;
  char key[2]={(char)e->keyval,0};
  if(e->keyval<128&&strchr("0123456789.+-*/=",key[0]))calculate(key);
  else if(e->keyval==GDK_KEY_Return||e->keyval==GDK_KEY_KP_Enter)calculate("=");
  else if(e->keyval==GDK_KEY_BackSpace)calculate("Back");
  else if(e->keyval==GDK_KEY_Delete)calculate("C");else return FALSE;
  return TRUE;
}
int main(int argc,char **argv){
  if(!gtk_init_check(&argc,&argv))return 1;
  window=gtk_window_new(GTK_WINDOW_TOPLEVEL);gtk_window_set_title(GTK_WINDOW(window),"GTK Desk");gtk_window_set_default_size(GTK_WINDOW(window),540,540);
  GtkCssProvider *css=gtk_css_provider_new();gtk_css_provider_load_from_data(css,"button.lit { background-image: none; background-color: #f6c945; color: #242424; }",-1,NULL);gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),GTK_STYLE_PROVIDER(css),GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);g_object_unref(css);
  GtkWidget *tabs=gtk_notebook_new();gtk_container_add(GTK_CONTAINER(window),tabs);
  gtk_notebook_append_page(GTK_NOTEBOOK(tabs),calculator(),gtk_label_new("Calculator"));
  gtk_notebook_append_page(GTK_NOTEBOOK(tabs),game(),gtk_label_new("Lights Out"));
  gtk_notebook_append_page(GTK_NOTEBOOK(tabs),settings(),gtk_label_new("Settings"));
  g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);g_signal_connect(window,"key-press-event",G_CALLBACK(keyboard),tabs);
  gtk_widget_show_all(window);gtk_main();return 0;
}
