#!/bin/sh
set -e
stage=$1
cd /usr/src/gtk-desk
mkdir -p "$stage/bin" "$stage/libexec" "$stage/share/doc/gtk-desk"
cc -O2 main.c $(pkg-config --cflags --libs gtk+-3.0) -lintl -o "$stage/libexec/gtk-desk"
cp PORT.md "$stage/share/doc/gtk-desk/"
# The runtime selects its window frontend before main(), at process startup.
cat > "$stage/bin/gtk-desk" <<'EOF'
#!/bin/sh
export WASM_POSIX_SURFACES=1
exec /usr/local/libexec/gtk-desk "$@"
EOF
chmod +x "$stage/bin/gtk-desk"
